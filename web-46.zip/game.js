/* game.js —— 合体债 · 画面 / 输入 / 存档 / 提示
 *
 * 规则全在 engine.js；这里只负责把状态画出来、把手感做出来。
 * 入口：window.TetrisGame.start({mode, seed, settings})
 *   mode: 'solo' | 'resume'（ai / lan 还没做，返回 false 让菜单提示）
 */
(function () {
  'use strict';

  const E = window.TetrisEngine;
  if (!E) { console.error('[tetris] engine.js 没加载'); return; }
  const C = E.CONST;
  const SHAPES = E.SHAPES;
  const COLORS = E.COLORS;
  const fmtScore = E.fmtScore;

  const LS = {
    auto: 'tetris.auto',
    autoClassic: 'tetris.auto.classic',
    autoCasual: 'tetris.casual.auto',
    zenAuto: 'tetris.zen.auto',
    slot: 'tetris.slot',
    slotClassic: 'tetris.cslot',
    slotCasual: 'tetris.casual.slot',
    carry: 'tetris.carry',
    high: 'tetris.high',
    highClassic: 'tetris.high.classic',
    highCasual: 'tetris.high.casual',
    zenHigh5: 'tetris.zen.high.5',
    zenHigh10: 'tetris.zen.high.10'
  };

  const SAVE_NAME = { normal: '单人玩法', classic: '经典玩法', casual: '常驻玩法' };

  let W = 480, H = 320, BOARD = 320, PX = 328, PW = 144, BW = 320;

  // 棋盘尺寸跟着引擎走：合体债 10×10（32px 格），原版 10×20（16px 格，盘面更高）
  function layoutFor(g) {
    const classic = !!(g && g.classic);
    C.CELL = classic ? 16 : 32;
    const cols = g ? g.cols : C.COLS;
    const rows = g ? g.rows : C.ROWS;
    BW = C.CELL * cols;
    H = C.CELL * rows;
    BOARD = H;
    PX = BW + 8;
    W = PX + PW + 8;
  }
  const FONT = 'system-ui,-apple-system,"Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif';

  let root = null, canvas = null, ctx = null, stageEl = null;
  let pauseLayer = null, slotsBox = null, overBar = null, toastEl = null;
  let fileInput = null, modeEl = null;
  let built = false;
  let running = false;
  let raf = 0, lastFrame = 0;
  let game = null;
  let paused = false;
  let over = false;
  let overInfo = null;
  let effects = [];
  let dasDir = 0, dasT = 0, arrT = 0;
  let touchAct = null;
  let taps = { n: 0, t: 0 };
  let toastTimer = 0;
  let highScore = 0;
  let settings = { sound: true, haptic: true, fps: '60' };

  // 统一入口：按设置决定场地要不要自己转
  function highKey() {
    if (game && game.zen) return game.zenMinutes === 10 ? LS.zenHigh10 : LS.zenHigh5;
    return game && game.casual ? LS.highCasual
      : (game && game.classic ? LS.highClassic : LS.high);
  }

  function mk(opts) {
    const g = new E.Tetris(opts || {});
    if (!g.casual) g.rotateEnabled = !!settings.rotate;
    return g;
  }
  let startSeed = null;
  let modeLabel = '单人';
  let fpsCap = 60;
  let frameAcc = 0;
  let restartArmed = 0;
  let lastInputAt = 0;
  let idleHintShown = false;
  let net = null;
  let multi = null;
  let spectate = null;
  let aiMode = false;
  let aiState = null;
  let resultEl = null, vsEl = null, vsYou = null, vsOpp = null, vsState = null;
  let aiCanvas = null, aiCtx = null, aiScoreEl = null, aiInfoEl = null, aiDebtEl = null;

  /* ---------------- 小工具 ---------------- */

  function $(sel) { return root ? root.querySelector(sel) : null; }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function readJSON(key) {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : null; } catch (e) { return null; }
  }
  function writeJSON(key, obj) {
    try { localStorage.setItem(key, JSON.stringify(obj)); return true; } catch (e) { return false; }
  }
  function readCarry() {
    try { const n = parseInt(localStorage.getItem(LS.carry) || '0', 10); return isFinite(n) && n > 0 ? n : 0; } catch (e) { return 0; }
  }
  function setCarry(n) {
    try { localStorage.setItem(LS.carry, String(Math.max(0, n | 0))); } catch (e) {}
  }
  function dispatch(name, detail) {
    try { document.dispatchEvent(new CustomEvent(name, { detail: detail })); } catch (e) {}
  }
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('on'); }, 2200);
  }
  function haptic(ms) {
    if (!settings.haptic) return;
    try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) {}
  }
  function cue(name, data) {
    if (!window.Cues) return;
    try { window.Cues.cue(name, data); } catch (e) {}
  }

  function applyFps() {
    const v = settings.fps;
    if (v === 'auto') fpsCap = 0;
    else fpsCap = clamp(parseInt(v, 10) || 60, 30, 144);
    frameAcc = 0;
    updatePauseNote();
  }

  function updatePauseNote() {
    const el = $('#tgNote');
    if (!el) return;
    let dev = '';
    if (window.TetrisDevice) {
      try {
        const d = window.TetrisDevice.info();
        dev = '屏幕 ' + d.width + '×' + d.height + (d.hz ? ' · ' + d.hz + 'Hz' : '') + ' · ';
      } catch (e) {}
    }
    el.textContent = dev + '帧率' + (fpsCap ? ('上限 ' + fpsCap + ' 帧') : '跟随屏幕')
      + '。每块落地自动存档。';
  }

  /* R / 暂停里的「重开」都走这里：第一次只提醒，3 秒内再来一次才真的重开 */
  function requestRestart() {
    if (!game) return;
    if (multi) { toast('联机中不能重开，返回菜单再开一局'); return; }
    if (aiMode) { toast('打 AI 中不能重开，返回菜单再开一局'); return; }
    if (over) { restartGame(); return; }
    const now = performance.now();
    if (restartArmed && now - restartArmed < 3000) {
      restartArmed = 0;
      restartGame();
      return;
    }
    restartArmed = now;
    toast('再按一次 R / 再点一次「重开」确认');
    const b = $('#tgRestart');
    if (b) {
      b.textContent = '再点一次确认';
      if (b._armTimer) clearTimeout(b._armTimer);
      b._armTimer = setTimeout(function () { b.textContent = '重开'; }, 3000);
    }
    haptic(12);
  }

  function resetRestartButton() {
    restartArmed = 0;
    const b = $('#tgRestart');
    if (b) {
      b.textContent = '重开';
      if (b._armTimer) clearTimeout(b._armTimer);
    }
  }

  /* ---------------- DOM / CSS ---------------- */

  const CSS = `
  #tg{
    position:fixed;inset:0;z-index:50;display:none;flex-direction:column;align-items:center;
    gap:8px;padding:calc(env(safe-area-inset-top) + 8px) 10px calc(env(safe-area-inset-bottom) + 8px);
    background:radial-gradient(120% 70% at 50% -12%,rgba(62,224,198,.10),transparent 55%),#08090d;
    color:#e9edf6;font-family:${FONT};user-select:none;-webkit-user-select:none;
    overflow:hidden;touch-action:manipulation;
  }
  #tg.on{display:flex}
  /* AI 观战：只留画布和返回，其他操作全藏掉 */
  #tg.is-spectate .tg-pad,
  #tg.is-spectate .tg-keys,
  #tg.is-spectate .tg-vs,
  #tg.is-spectate .tg-ai,
  #tg.is-spectate .tg-over,
  #tg.is-spectate [data-cmd="pause"]{display:none!important}
  .tg-bar{width:100%;max-width:560px;height:38px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex:0 0 auto}
  .tg-btn{
    height:38px;padding:0 14px;border-radius:11px;border:1px solid #232838;background:#12141b;color:#e9edf6;
    font:inherit;font-size:13px;cursor:pointer;transition:.15s;
  }
  .tg-btn:active{transform:scale(.96)}
  .tg-title{font-size:11px;letter-spacing:.28em;color:#79839a;white-space:nowrap}
  .tg-vs{
    display:none;width:100%;max-width:560px;height:24px;flex:0 0 auto;
    align-items:center;justify-content:center;gap:12px;font-size:11px;color:#79839a;
  }
  #tg.is-multi .tg-vs{display:flex}
  .tg-vs b{color:#e9edf6;font-size:13px;font-variant-numeric:tabular-nums}
  .tg-vs-state{margin-left:auto;color:#5b6479;font-size:10px}
  .tg-ai{
    display:none;width:100%;max-width:560px;height:100px;flex:0 0 auto;
    align-items:center;justify-content:center;gap:12px;
  }
  #tg.is-ai .tg-ai{display:flex}
  #tg.is-ai .tg-keys{display:none}
  #tg.is-ai .tg-vs{display:flex}
  .tg-ai canvas{width:96px;height:96px;border-radius:10px;border:1px solid #232838;background:#0a0c12}
  .tg-ai-info{display:flex;flex-direction:column;gap:4px;font-size:11px;color:#79839a;line-height:1.4}
  .tg-ai-info b{color:#ffd479;font-size:15px;font-variant-numeric:tabular-nums}
  .tg-result{
    position:absolute;inset:0;z-index:6;display:none;align-items:center;justify-content:center;
    padding:18px;background:rgba(4,5,8,.78);backdrop-filter:blur(6px);
  }
  .tg-result.on{display:flex}
  #tg.is-result .tg-pad,#tg.is-result .tg-keys{display:none}
  .tg-result .tg-btn{margin-top:4px}
  .tg-stage{flex:1 1 auto;min-height:0;width:100%;display:flex;align-items:center;justify-content:center}
  /* 联机开局：双方握手，然后进入棋盘 */
  .tg-intro{
    position:absolute;inset:0;z-index:60;display:none;flex-direction:column;
    align-items:center;justify-content:center;gap:6px;
    background:rgba(5,6,10,.86);backdrop-filter:blur(5px);
  }
  #tg.is-intro .tg-intro{display:flex}
  .tg-hands{
    font-size:76px;line-height:1;filter:drop-shadow(0 0 22px rgba(62,224,198,.45));
    animation:handshake .55s ease-in-out infinite alternate;
  }
  .tg-intro h3{margin:6px 0 0;font-size:22px;letter-spacing:.18em;color:#e9edf6}
  .tg-intro p{margin:0;font-size:11px;letter-spacing:.08em;color:#79839a}
  @keyframes handshake{
    from{transform:translateX(-7px) rotate(-4deg)}
    to{transform:translateX(7px) rotate(4deg)}
  }
  #tgCanvas{
    max-width:min(96vw,560px);max-height:100%;width:auto;height:auto;border-radius:12px;display:block;
    box-shadow:0 22px 60px -26px #000,0 0 0 1px rgba(62,224,198,.09);
    touch-action:none;
  }
  .tg-pad{
    width:100%;max-width:560px;display:flex;justify-content:space-between;align-items:flex-end;
    gap:10px;flex:0 0 auto;touch-action:none;
  }
  .pad-side{display:grid;gap:8px;width:calc(50% - 5px)}
  .pad-left{grid-template-columns:1fr 1fr}
  .pad-left [data-act="down"]{grid-column:1 / -1}
  .pad-right{grid-template-columns:1fr 1fr}
  .pad-right [data-act="cw"]{grid-column:1 / -1;height:64px}
  .tg-pad button{
    height:52px;border-radius:13px;border:1px solid #232838;background:linear-gradient(180deg,#171a23,#101219);
    color:#e9edf6;font:inherit;font-size:15px;font-weight:600;cursor:pointer;touch-action:none;
    transition:transform .06s,background .12s,border-color .12s;
  }
  .tg-pad button:active{transform:scale(.97);background:#1c2029;border-color:rgba(62,224,198,.4)}
  .tg-keys{font-size:9px;line-height:1.6;color:#5b6479;text-align:center;letter-spacing:.02em;flex:0 0 auto;padding:0 4px}
  .tg-over{display:none;width:100%;max-width:560px;flex-direction:column;gap:8px;flex:0 0 auto}
  #tg.is-over .tg-pad,#tg.is-over .tg-keys{display:none}
  #tg.is-over .tg-over{display:flex}
  .tg-over-tip{font-size:12px;color:#ff8b96;text-align:center;letter-spacing:.1em}
  .tg-over-btns{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .tg-over-btns button,.tg-cmds button,.tg-ghost{
    height:52px;border-radius:13px;border:1px solid #232838;background:#12141b;color:#e9edf6;
    font:inherit;font-size:15px;font-weight:600;cursor:pointer;
  }
  .tg-over-btns button:first-child{border-color:rgba(62,224,198,.42);color:#c9fff6;background:linear-gradient(180deg,rgba(62,224,198,.14),rgba(62,224,198,.04))}
  .tg-pause{
    position:absolute;inset:0;z-index:5;display:none;align-items:center;justify-content:center;
    padding:18px;background:rgba(4,5,8,.76);backdrop-filter:blur(6px);
  }
  .tg-pause.on{display:flex}
  .tg-card{
    width:100%;max-width:380px;max-height:calc(100% - 12px);overflow-y:auto;scrollbar-width:none;
    background:#12141b;border:1px solid #232838;border-radius:18px;padding:18px;
    display:flex;flex-direction:column;gap:10px;box-shadow:0 30px 80px -30px #000;
  }
  .tg-card::-webkit-scrollbar{display:none}
  .tg-card h3{margin:0;font-size:17px;letter-spacing:.08em}
  .tg-note{margin:0;font-size:11px;line-height:1.6;color:#79839a}
  .tg-slots{display:flex;flex-direction:column;gap:8px}
  .tg-slot{display:flex;align-items:center;justify-content:space-between;gap:10px;background:#0d0f16;border:1px solid #232838;border-radius:12px;padding:8px 10px}
  .tg-slot-t{display:flex;flex-direction:column;gap:2px;min-width:0}
  .tg-slot-t b{font-size:12px;letter-spacing:.12em;color:#aab3c6}
  .tg-slot-t span{font-size:11px;color:#5b6479;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .tg-slot-b{display:flex;gap:6px;flex:0 0 auto}
  .tg-slot-b button{height:34px;padding:0 10px;border-radius:9px;border:1px solid #232838;background:#171a23;color:#c6cdda;font:inherit;font-size:12px;cursor:pointer}
  .tg-slot-b button:disabled{opacity:.3;pointer-events:none}
  .tg-cmds{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .tg-cmds button{height:46px;font-size:13px;font-weight:500}
  .tg-ghost{height:42px;font-size:13px;font-weight:400;color:#79839a;background:transparent}
  .tg-toast{
    position:absolute;left:50%;bottom:calc(env(safe-area-inset-bottom) + 22px);z-index:8;
    transform:translate(-50%,14px);opacity:0;pointer-events:none;transition:.2s;
    background:#181c26;border:1px solid #232838;color:#e9edf6;font-size:13px;
    padding:10px 16px;border-radius:12px;white-space:nowrap;
  }
  .tg-toast.on{opacity:1;transform:translate(-50%,0)}

  /* 横屏（含强制旋转）：左右手各占一边，棋盘在中间 */
  html.land .tg-pad{
    position:fixed;left:0;right:0;bottom:calc(env(safe-area-inset-bottom) + 8px);
    max-width:none;padding:0 12px;display:block;pointer-events:none;
  }
  html.land .pad-side{
    position:absolute;bottom:0;pointer-events:auto;width:auto;
    grid-template-columns:repeat(2,minmax(58px,84px));gap:8px;
  }
  html.land .pad-left{left:12px}
  html.land .pad-right{right:12px}
  html.land .tg-pad button{height:64px;font-size:14px}
  html.land .tg-stage{padding:0 152px}
  html.land .tg-keys{display:none}
  html.land .tg-toast{bottom:calc(env(safe-area-inset-bottom) + 120px)}
  /* 内容自己转 90° 时，把按键条放到物理屏幕的底边：
     正转（cw）时内容右边=物理下边，反转（ccw）时内容左边=物理下边 */
  html.rot .tg-pad{
    position:fixed;top:0;bottom:0;left:auto;right:0;width:168px;
    display:flex;flex-direction:column-reverse;justify-content:center;gap:12px;
    padding:10px;max-width:none;pointer-events:none;
  }
  html.rot.rot-ccw .tg-pad{left:0;right:auto;flex-direction:column}
  html.rot .pad-side{position:static;width:100%;grid-template-columns:1fr 1fr;gap:8px}
  html.rot .tg-pad button{height:56px;font-size:13px}
  html.rot .tg-stage{padding:0 178px}
  html.rot #tgCanvas{max-width:min(80vw,640px)}
  `;

  const HTML = `
    <div class="tg-bar">
      <button class="tg-btn" data-cmd="exit">返回</button>
      <div class="tg-title" id="tgMode">合体债 · 单人</div>
      <button class="tg-btn" data-cmd="pause">暂停</button>
    </div>
    <div class="tg-vs">
      <span>你 <b id="vsYou">0</b></span>
      <span>对手 <b id="vsOpp">0</b></span>
      <span class="tg-vs-state" id="vsState">准备</span>
    </div>
    <div class="tg-stage"><canvas id="tgCanvas" width="480" height="320"></canvas></div>
    <div class="tg-ai" id="tgAI">
      <canvas id="aiCanvas" width="96" height="96"></canvas>
      <div class="tg-ai-info">
        <div>AI <b id="aiScore">0</b></div>
        <div id="aiInfo">消 0 · 活</div>
        <div id="aiDebt"></div>
      </div>
    </div>
    <div class="tg-pad">
      <div class="pad-side pad-left">
        <button data-act="left">◀</button>
        <button data-act="right">▶</button>
        <button data-act="down">▼ 软降</button>
      </div>
      <div class="pad-side pad-right">
        <button data-act="cw">↻ 转</button>
        <button data-act="drop">⤓ 硬降</button>
        <button data-act="hold">暂存</button>
      </div>
    </div>
    <div class="tg-keys">←→ 移动 · ↓ 软降 · 空格 硬降 · ↑/X 转 · Z 反着转 · C 暂存 · P 暂停 · R 重开×2</div>
    <div class="tg-over">
      <div class="tg-over-tip">债还不完，本局结束</div>
      <div class="tg-over-btns">
        <button data-cmd="restart">重开 R</button>
        <button data-cmd="exit">返回</button>
      </div>
    </div>
    <div class="tg-result" id="tgResult">
      <div class="tg-card">
        <h3 id="resTitle">对局结束</h3>
        <p class="tg-note" id="resText"></p>
        <button class="tg-btn" data-cmd="exit">返回菜单</button>
      </div>
    </div>
    <div class="tg-pause" id="tgPause">
      <div class="tg-card">
        <h3>暂停</h3>
        <p class="tg-note" id="tgNote">每块落地自动存档。</p>
        <div class="tg-slots" id="tgSlots"></div>
        <div class="tg-cmds">
          <button data-cmd="resume">继续</button>
          <button data-cmd="restart" id="tgRestart">重开</button>
          <button data-cmd="export">导出存档</button>
          <button data-cmd="import">导入存档</button>
        </div>
        <button class="tg-ghost" data-cmd="exit">退出到菜单</button>
      </div>
    </div>
    <div class="tg-intro" id="tgIntro">
      <div class="tg-hands">🤝</div>
      <h3>决斗开始</h3>
      <p id="tgIntroSub">双方已握手</p>
    </div>
    <div class="tg-toast" id="tgToast"></div>
    <input id="tgFile" type="file" accept="application/json,.json" hidden>
  `;

  function build() {
    if (built) return;
    const style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);

    root = document.createElement('div');
    root.id = 'tg';
    root.innerHTML = HTML;
    document.body.appendChild(root);

    canvas = $('#tgCanvas');
    ctx = canvas.getContext('2d');
    stageEl = root.querySelector('.tg-stage');
    pauseLayer = $('#tgPause');
    slotsBox = $('#tgSlots');
    toastEl = $('#tgToast');
    fileInput = $('#tgFile');
    modeEl = $('#tgMode');
    overBar = root.querySelector('.tg-over');
    resultEl = $('#tgResult');
    vsEl = root.querySelector('.tg-vs');
    vsYou = $('#vsYou');
    vsOpp = $('#vsOpp');
    vsState = $('#vsState');
    aiCanvas = $('#aiCanvas');
    aiCtx = aiCanvas ? aiCanvas.getContext('2d') : null;
    aiScoreEl = $('#aiScore');
    aiInfoEl = $('#aiInfo');
    aiDebtEl = $('#aiDebt');

    root.addEventListener('click', onClick);
    root.addEventListener('pointerdown', onPadDown);
    root.addEventListener('pointerup', onPadUp);
    root.addEventListener('pointercancel', onPadUp);
    canvas.addEventListener('pointerdown', onCanvasDown);
    fileInput.addEventListener('change', onImportFile);

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('resize', fit);
    document.addEventListener('visibilitychange', function () {
      if (document.hidden && running && !paused && !over) togglePause(true);
    });

    built = true;
  }

  /* ---------------- 启动 / 退出 ---------------- */

  function start(payload) {
    payload = payload || {};
    const mode = payload.mode || 'solo';
    build();
    settings = Object.assign({ sound: true, haptic: true, fps: '60' }, payload.settings || {});
    applyFps();
    if (typeof payload.seed === 'number' && isFinite(payload.seed)) startSeed = payload.seed >>> 0;
    net = payload.net || null;
    if (mode === 'spectate') return startSpectate();

    aiMode = (mode === 'ai');
    aiState = null;
    multi = net ? {
      mode: mode,
      opponent: { score: 0, clears: 0, debt: 0, dead: false, name: payload.opponentName || '对手' },
      started: false,
      settled: false,
      result: null,
      startAtLocal: 0,
      lastState: 0
    } : null;

    const labelMap = { solo: '单人', casual: '常驻 · 连击', zen: '禅模式', resume: '继续', resumeCasual: '继续常驻', resumeZen: '继续禅模式', lan_parallel: '并行赛', lan_battle: '干扰战', ai: '打 AI', classic: '原版' };
    modeLabel = labelMap[mode] || '单人';
    if (payload.bt) modeLabel = (mode === 'lan_battle' ? '蓝牙 · 干扰战' : '蓝牙 · 并行赛');
    if (mode === 'ai') {
      const d = payload.difficulty || 'normal';
      const tn = { easy: '简单', normal: '普通', hard: '困难' }[d] || '普通';
      const tv = { easy: '0.3', normal: '0.5', hard: '1.0' }[d] || '0.5';
      modeLabel += ' · ' + tn + '（温度 ' + tv + '）';
      if (payload.aiAuto) modeLabel += ' · 自动';
    }
    if (modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = '合体债 v' + ver + ' · ' + modeLabel;
    }

    try { highScore = parseInt(localStorage.getItem(LS.high) || '0', 10) || 0; } catch (e) { highScore = 0; }

    if (window.Cues) {
      try {
        window.Cues.setSound(!!settings.sound);
        window.Cues.selfCheck();
      } catch (e) {}
    }

    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    taps = { n: 0, t: 0 };
    dasDir = 0;

    if (multi) {
      const classicRules = payload.rules === 'classic';
      game = classicRules
        ? new E.Tetris({ seed: (payload.seed >>> 0) || 1, classic: true, cols: 10, rows: 20 })
        : mk({ seed: (payload.seed >>> 0) || 1, carryDebt: 0 });
      game.suppressFusion = (mode === 'lan_battle' && !classicRules);
      net.onMessage = onNetMessage;
      net.onError = function () {
        if (multi && !multi.settled) settleMulti('disconnect');
      };
      const delay = Math.max(0, (payload.startAt || 0) - (Date.now() + (net.offset || 0)));
      multi.startAtLocal = performance.now() + delay;
      multi.started = delay <= 0;
      paused = !multi.started;
    } else if (aiMode) {
      const seed = (payload.seed >>> 0) || 1;
      game = mk({ seed: seed, carryDebt: 0 });
      aiState = {
        game: mk({ seed: seed, carryDebt: 0 }),
        difficulty: payload.difficulty || 'normal',
        nextStep: performance.now() + 600,
        dead: false
      };
      aiState.game.noGravity = true;
      paused = false;
    } else if (mode === 'classic') {
      // 原版：10×20，标准计分，没有债/合体块/旋转/方向块
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({ seed: seed, classic: true, cols: 10, rows: 20 });
      paused = false;
    } else if (mode === 'casual') {
      // 常驻：10×10，没有债/合体块，连续消行叠连击倍数
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({ seed: seed, casual: true, cols: 10, rows: 10 });
      paused = false;
    } else if (mode === 'zen') {
      // 禅模式：10×12，5/10 分钟倒计时，堆满自动整理，不会死
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({
        seed: seed, zen: true,
        zenMinutes: payload.zenMinutes === 10 ? 10 : 5,
        cols: 10, rows: 12
      });
      paused = false;
    } else {
      let resumed = false;
      if (mode === 'resume') resumed = loadAutoIntoGame(!!payload.classic, false);
      if (mode === 'resumeCasual') resumed = loadAutoIntoGame(false, true);
      if (mode === 'resumeZen') resumed = loadAutoIntoGame(false, false, true);
      if (!resumed) {
        if (mode === 'resumeCasual') game = new E.Tetris({ seed: (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0, casual: true, cols: 10, rows: 10 });
        else if (mode === 'resumeZen') game = new E.Tetris({ seed: (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0, zen: true, zenMinutes: 5, cols: 10, rows: 12 });
        else game = makeGame(readCarry());
        if (mode === 'resume' || mode === 'resumeCasual' || mode === 'resumeZen') toast('存档读不了，先开新局');
      }
    }

    if (game && game.zen && modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = '合体债 v' + ver + ' · 禅模式 · ' + game.zenMinutes + ' 分钟';
    }

    try {
      highScore = parseInt(localStorage.getItem(highKey()) || '0', 10) || 0;
    } catch (e) { highScore = 0; }
    if ((mode === 'resume' || mode === 'resumeCasual' || mode === 'resumeZen') && modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeLabel = game.zen ? ('禅模式 · ' + game.zenMinutes + ' 分钟')
        : (game.casual ? '继续常驻' : (game.classic ? '经典玩法' : '继续'));
      modeEl.textContent = '合体债 v' + ver + ' · ' + modeLabel;
    }
    if (multi && modeEl && game && game.classic) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeLabel = '经典 · ' + (multi.mode === 'lan_battle' ? '干扰战' : '并行赛');
      modeEl.textContent = '合体债 v' + ver + ' · ' + modeLabel;
    }

    root.classList.add('on');
    root.classList.remove('is-over');
    root.classList.remove('is-result');
    if (multi && !multi.started) {
      root.classList.add('is-intro');
      const sub = $('#tgIntroSub');
      if (sub) sub.textContent = '对手：' + (multi.opponent.name || '对手') + ' · 双方已握手';
    } else {
      root.classList.remove('is-intro');
    }
    root.classList.toggle('is-multi', !!multi);
    root.classList.toggle('is-ai', !!aiMode);
    root.classList.toggle('is-classic', !!(game && game.classic));
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    if (multi || aiMode) updateVs();
    resetRestartButton();
    frameAcc = 0;
    lastInputAt = performance.now();
    idleHintShown = false;
    layoutFor(game);
    fit();
    lastFrame = 0;
    running = true;
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
    return true;
  }

  /* ---------------- AI 观战：两个随机 AI 自己打 ---------------- */

  function spectateSeed() {
    return (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
  }

  function makeSpectateEngine() {
    const g = new E.Tetris({ seed: spectateSeed(), carryDebt: 0 });
    g.noGravity = true;          // 由 AI 直接落子
    g.rotateEnabled = false;     // 观战不转场，画面稳一点
    return g;
  }

  function resetSpectate() {
    spectate = spectate || { round: 0 };
    spectate.a = makeSpectateEngine();
    spectate.b = makeSpectateEngine();
    spectate.accA = 0;
    spectate.accB = 0;
    spectate.over = false;
    spectate.winner = '';
    spectate.nextAt = 0;
    spectate.round = (spectate.round || 0) + 1;
  }

  function startSpectate() {
    build();
    multi = null;
    aiMode = false;
    aiState = null;
    game = null;
    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    resetSpectate();
    modeLabel = 'AI 观战';
    if (modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = '合体债 v' + ver + ' · ' + modeLabel;
    }
    root.classList.add('on');
    root.classList.remove('is-over', 'is-result', 'is-multi', 'is-ai', 'is-classic');
    root.classList.add('is-spectate');
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    W = 520;
    H = 360;
    BW = W;
    BOARD = H;
    PX = W;
    if (canvas) { canvas.width = 1; canvas.height = 1; }
    fit();
    lastFrame = 0;
    running = true;
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
    return true;
  }

  function AI_step(g, diff) {
    if (!g || g.status !== 'playing') return;
    const AI = window.TetrisAI;
    if (!AI) return;
    const mv = AI.choose(g, diff || 'normal');
    if (mv) AI.apply(g, mv);
    else g.gameOver('blockout');
  }

  function stepSpectate(dt) {
    const sp = spectate;
    if (!sp) return;
    const now = performance.now();
    if (sp.over) {
      if (now >= sp.nextAt) resetSpectate();
      return;
    }
    sp.accA += dt;
    sp.accB += dt;
    if (sp.accA >= 500) { sp.accA = 0; AI_step(sp.a, 'hard'); }
    if (sp.accB >= 500) { sp.accB = 0; AI_step(sp.b, 'hard'); }
    const aDead = sp.a.status === 'over';
    const bDead = sp.b.status === 'over';
    if (aDead || bDead) {
      sp.over = true;
      if (aDead && bDead) sp.winner = sp.a.score === sp.b.score ? '平局' : (sp.a.score > sp.b.score ? 'AI-1' : 'AI-2');
      else sp.winner = aDead ? 'AI-2' : 'AI-1';
      sp.nextAt = now + 3500;
    }
  }

  function drawSpectateBoard(g, x, y, cell, name, accent) {
    const bw = cell * 10;
    ctx.save();
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = accent;
    ctx.font = '700 13px ' + FONT;
    ctx.fillText(name, x, y - 34);
    ctx.fillStyle = '#e9edf6';
    ctx.font = '700 20px ' + FONT;
    ctx.textAlign = 'right';
    ctx.fillText(fmtScore(g.score), x + bw, y - 34);
    ctx.textAlign = 'left';

    ctx.fillStyle = '#0a0c12';
    ctx.fillRect(x, y, bw, bw);
    ctx.strokeStyle = 'rgba(255,255,255,.04)';
    ctx.lineWidth = 1;
    for (let i = 1; i < 10; i++) {
      ctx.beginPath(); ctx.moveTo(x + i * cell + 0.5, y); ctx.lineTo(x + i * cell + 0.5, y + bw); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x, y + i * cell + 0.5); ctx.lineTo(x + bw, y + i * cell + 0.5); ctx.stroke();
    }
    for (let yy = 0; yy < g.rows; yy++) {
      for (let xx = 0; xx < g.cols; xx++) {
        const c = g.board[yy][xx];
        if (!c) continue;
        const px = x + xx * cell, py = y + yy * cell;
        let col = '#39415a';
        if (c.k === 'p') col = '#4a2630';
        else if (c.k === 'n') col = cellColor(c.t);
        ctx.fillStyle = col;
        ctx.fillRect(px + 1, py + 1, cell - 2, cell - 2);
      }
    }
    if (g.piece && g.status === 'playing') {
      const cells = g.pieceCells();
      const col = g.piece.type === 'ARROW' ? '#f2f5ff' : cellColor(g.piece.type);
      ctx.fillStyle = col;
      for (let i = 0; i < cells.length; i++) {
        const px = x + cells[i][0] * cell, py = y + cells[i][1] * cell;
        ctx.fillRect(px + 1, py + 1, cell - 2, cell - 2);
      }
    }
    ctx.strokeStyle = 'rgba(255,255,255,.10)';
    ctx.strokeRect(x + 0.5, y + 0.5, bw - 1, bw - 1);

    ctx.fillStyle = '#79839a';
    ctx.font = '11px ' + FONT;
    ctx.fillText('消 ' + g.clears + ' · 等级 ' + g.lockLevel
      + (g.debt > 0 ? ' · 债 -' + g.debt : ' · 债 0'), x, y + bw + 18);
    ctx.restore();
  }

  function drawSpectate(now) {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#08090d';
    ctx.fillRect(0, 0, W, H);

    const cell = 18;
    const bw = cell * 10;
    const gap = 42;
    const x0 = Math.round((W - (bw * 2 + gap)) / 2);
    const y0 = 96;
    drawSpectateBoard(spectate.a, x0, y0, cell, 'AI-1 · 随机', '#3ee0c6');
    drawSpectateBoard(spectate.b, x0 + bw + gap, y0, cell, 'AI-2 · 随机', '#ff9f43');

    ctx.save();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#5b6479';
    ctx.font = '700 12px ' + FONT;
    ctx.fillText('VS', W / 2, y0 + 84);
    ctx.fillStyle = '#ffd479';
    ctx.font = '700 22px ' + FONT;
    ctx.fillText('第 ' + spectate.round + ' 局', W / 2, 42);
    if (spectate.over) {
      ctx.fillStyle = '#fff';
      ctx.font = '700 18px ' + FONT;
      ctx.fillText(spectate.winner.replace('AI-', 'AI-') + ' 赢', W / 2, y0 + bw + 62);
      ctx.fillStyle = '#79839a';
      ctx.font = '11px ' + FONT;
      ctx.fillText('3 秒后自动下一局', W / 2, y0 + bw + 82);
    } else {
      ctx.fillStyle = '#79839a';
      ctx.font = '11px ' + FONT;
      ctx.fillText('两个随机 AI 自己打 · 双手可以歇着', W / 2, y0 + bw + 62);
    }
    ctx.restore();
  }

  function makeGame(carry) {
    const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
    return mk({ seed: seed, carryDebt: Math.max(0, carry | 0) });
  }

  function loadAutoIntoGame(wantClassic, wantCasual, wantZen) {
    const key = wantZen ? LS.zenAuto
      : (wantCasual ? LS.autoCasual : (wantClassic ? LS.autoClassic : LS.auto));
    const data = readJSON(key);
    if (!data) return false;
    const g = data.classic
      ? new E.Tetris({ seed: (data.seed >>> 0) || 1, classic: true, cols: data.cols || 10, rows: data.rows || 20 })
      : (data.zen
        ? new E.Tetris({ seed: (data.seed >>> 0) || 1, zen: true, zenMinutes: data.zenMinutes || 5, cols: data.cols || 10, rows: data.rows || 12 })
        : (data.casual
          ? new E.Tetris({ seed: (data.seed >>> 0) || 1, casual: true, cols: data.cols || 10, rows: data.rows || 10 })
          : mk({ seed: (data.seed >>> 0) || 1 })));
    if (g.loadJSON(data)) return false;
    game = g;
    return true;
  }

  function exitToMenu() {
    if (game && game.status === 'playing' && !over) saveAuto();
    spectate = null;
    if (root) root.classList.remove('is-spectate');
    if (multi) {
      if (net) { try { net.leave(); } catch (e) {} }
      net = null;
      multi = null;
    }
    aiMode = false;
    aiState = null;
    running = false;
    cancelAnimationFrame(raf);
    raf = 0;
    if (root) {
      root.classList.remove('on');
      root.classList.remove('is-over');
      root.classList.remove('is-multi');
      root.classList.remove('is-ai');
      root.classList.remove('is-result');
      root.classList.remove('is-intro');
    }
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    paused = false;
    dispatch('tetris-exit');
    dispatch('tetris-save-change');
  }

  function restartGame() {
    const wasClassic = !!(game && game.classic);
    const wasZen = !!(game && game.zen);
    const wasCasual = !!(game && game.casual && !wasZen);
    const carry = over ? (game.carryDebt || 0)
      : (game && game.debt > 0 ? game.debt : readCarry());
    if (wasClassic || wasCasual || wasZen) {
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = wasClassic
        ? new E.Tetris({ seed: seed, classic: true, cols: 10, rows: 20 })
        : (wasZen
          ? new E.Tetris({ seed: seed, zen: true, zenMinutes: game.zenMinutes, cols: 10, rows: 12 })
          : new E.Tetris({ seed: seed, casual: true, cols: 10, rows: 10 }));
    } else {
      game = makeGame(carry);
    }
    layoutFor(game);
    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    taps = { n: 0, t: 0 };
    dasDir = 0;
    frameAcc = 0;
    resetRestartButton();
    lastInputAt = performance.now();
    idleHintShown = false;
    if (root) root.classList.remove('is-over');
    if (pauseLayer) pauseLayer.classList.remove('on');
    lastFrame = 0;
    if (!running) {
      running = true;
      raf = requestAnimationFrame(frame);
    }
  }

  function togglePause(force) {
    if (!running || over || !game) return;
    if (multi) { toast('联机中不能暂停'); return; }
    paused = (force === undefined) ? !paused : !!force;
    if (paused) {
      dasDir = 0;
      if (game) game.setSoftDrop(false);
      saveAuto();
      refreshSlots();
      updatePauseNote();
      resetRestartButton();
      dispatch('tetris-save-change');
    } else {
      frameAcc = 0;
      lastInputAt = performance.now();
      resetRestartButton();
    }
    if (pauseLayer) pauseLayer.classList.toggle('on', paused);
  }

  /* ---------------- 主循环 ---------------- */

  function frame(t) {
    if (!running) return;
    raf = requestAnimationFrame(frame);

    let dt = lastFrame ? (t - lastFrame) : 16;
    lastFrame = t;
    if (!isFinite(dt) || dt < 0) dt = 0;
    if (dt > 120) dt = 120;

    // 帧率上限：默认 60；「自动」= 不限，跟屏幕 rAF 走
    frameAcc += dt;
    if (frameAcc > 200) frameAcc = 0;
    const gap = fpsCap ? 1000 / fpsCap : 0;
    if (gap && frameAcc < gap - 1.5) return;
    const step = Math.min(frameAcc, 120);
    frameAcc = gap ? Math.max(0, frameAcc - step) : 0;

    if (spectate) {
      stepSpectate(step);
      render(performance.now());
      return;
    }

    if (multi && !multi.started) {
      const nowMs = performance.now();
      if (nowMs >= multi.startAtLocal) {
        multi.started = true;
        paused = false;
        lastInputAt = nowMs;
        if (root) root.classList.remove('is-intro');
        toast('开始');
        haptic(20);
      } else {
        if (game) render(nowMs);
        return;
      }
    }
    if (multi && multi.settled) {
      if (game) render(performance.now());
      return;
    }

    if (!paused && !over && game) {
      game.tick(step);
      updateDAS(step);
      pumpEvents();

      if (aiMode) stepAI(step);

      if (multi && !multi.settled) {
        const nowMs = performance.now();
        if (nowMs - multi.lastState >= 250 && game.status === 'playing') {
          multi.lastState = nowMs;
          if (net) net.send({ t: 'state', score: game.score, debt: game.debt, clears: (game.classic ? game.lines : game.clears), dead: false });
        }
        updateVs();
      } else if (game.score > highScore) {
        highScore = game.score;
        try { localStorage.setItem(highKey(), String(highScore)); } catch (e) {}
      }
      if (game.status === 'over' && !over) {
        onGameOver({ debt: game.carryDebt, score: game.score, reason: game.reason });
      }
      if (!multi && !idleHintShown && game.status === 'playing' && (game.classic ? game.lines : game.clears) === 0
          && performance.now() - lastInputAt > 6000) {
        idleHintShown = true;
        toast('方块会自己往下掉：← → 移动，空格直接落到底');
      }
    }

    const now = performance.now();
    effects = effects.filter(function (e) { return e.until > now; });
    if (game) render(now);
  }

  function updateDAS(dt) {
    if (!game || game.status !== 'playing' || paused || over) return;
    if (dasDir === 0) return;
    dasT += dt;
    if (dasT < C.DAS_MS) return;
    arrT += dt;
    while (arrT >= C.ARR_MS) {
      arrT -= C.ARR_MS;
      if (!game.move(dasDir)) break;
    }
  }

  /* AI 一方的时间推进：转场/合体块照走，落子由 AI 直接给 */
  function stepAI(step) {
    if (!aiMode || !aiState || aiState.dead) return;
    const ag = aiState.game;
    const nowMs = performance.now();
    ag.tick(step);
    if (ag.status === 'over') {
      aiState.dead = true;
    } else if (nowMs >= aiState.nextStep) {
      const mv = window.TetrisAI ? window.TetrisAI.choose(ag, aiState.difficulty) : null;
      if (!mv) {
        aiState.dead = true;
      } else {
        window.TetrisAI.apply(ag, mv);
        aiState.nextStep = nowMs + window.TetrisAI.stepMs(aiState.difficulty);
        if (ag.status === 'over') aiState.dead = true;
      }
    }
    ag.drainEvents();
    updateVs();
  }

  function pumpEvents() {
    if (!game) return;
    const evs = game.drainEvents();
    const now = performance.now();
    for (let i = 0; i < evs.length; i++) {
      const ev = evs[i];
      switch (ev.type) {
        case 'lock':
          saveAuto();
          break;
        case 'lineClear':
          cue('lineClear', { lines: ev.lines });
          effects.push({ type: 'rows', rows: ev.rows || [], until: now + 260 });
          haptic(10);
          if (multi && multi.mode === 'lan_battle' && net) {
            net.send({ t: 'clear', lines: ev.lines });
          }
          break;
        case 'rotateSoon':
          cue('rotateSoon');
          break;
        case 'fieldRotate':
          effects.push({ type: 'flash', until: now + 420 });
          haptic(16);
          break;
        case 'fusion':
          effects.push({ type: 'fusion', until: now + 460 });
          haptic(8);
          break;
        case 'arrowWipe':
          effects.push({ type: 'arrow', until: now + 360 });
          haptic(20);
          break;
        case 'arrowClear':
          cue('lineClear', { lines: 1 });
          if (multi && multi.mode === 'lan_battle' && net) {
            net.send({ t: 'clear', lines: 1 });
          }
          break;
        case 'debtHigh':
          cue('debtHigh', { pct: ev.pct });
          break;
        case 'debtCleared':
          cue('debtCleared');
          setCarry(0);
          break;
        case 'zenRescue':
          toast('堆满了，整理一下 · 连击断了');
          effects.push({ type: 'flash', until: now + 360 });
          haptic(14);
          break;
        case 'arrowUnlock':
          cue('arrowUnlock');
          break;
        case 'topOut':
          cue('topOut');
          break;
        case 'gameOver':
          onGameOver(ev);
          break;
      }
    }
  }

  function onGameOver(ev) {
    if (over) return;
    over = true;
    overInfo = ev || { debt: 0, score: game.score, reason: 'topout' };
    paused = false;
    dasDir = 0;
    if (game) game.setSoftDrop(false);
    if (multi) {
      if (net) net.send({ t: 'dead', score: game.score });
      settleMulti('youDead');
      return;
    }
    if (aiMode) {
      paused = true;
      if (aiState) aiState.dead = true;
      const ys = game ? game.score : 0;
      const as = aiState && aiState.game ? aiState.game.score : 0;
      const winner = ys > as ? 'you' : (ys < as ? 'opp' : 'draw');
      if (resultEl) {
        const title = $('#resTitle');
        const text = $('#resText');
        if (title) title.textContent = winner === 'you' ? '你赢' : (winner === 'opp' ? '你输' : '平局');
        if (text) text.textContent = '你 ' + ys + ' ： AI ' + as;
        resultEl.classList.add('on');
      }
      if (root) root.classList.add('is-result');
      haptic(40);
      return;
    }
    if (game) {
      try {
        localStorage.removeItem(game.zen ? LS.zenAuto
          : (game.casual ? LS.autoCasual
            : (game.classic ? LS.autoClassic : LS.auto)));
      } catch (e) {}
    }
    if (!(game && (game.classic || game.casual))) setCarry(overInfo.debt || 0);
    if (game && game.score > highScore) {
      highScore = game.score;
      try { localStorage.setItem(highKey(), String(highScore)); } catch (e) {}
    }
    if (game && game.zen) {
      const tip = root ? root.querySelector('.tg-over-tip') : null;
      if (tip) tip.textContent = '时间到，本局结束';
    }
    if (root) root.classList.add('is-over');
    if (pauseLayer) pauseLayer.classList.remove('on');
    resetRestartButton();
    if (ev && ev.reason !== 'topout' && !(game && game.zen)) cue('gameOver', { debt: overInfo.debt });
    dispatch('tetris-save-change');
    haptic(40);
  }

  /* ---------------- 联机 ---------------- */

  function updateVs() {
    if (!vsEl) return;
    if (aiMode && aiState) {
      if (vsYou) vsYou.textContent = fmtScore(game ? game.score : 0);
      if (vsOpp) vsOpp.textContent = fmtScore(aiState.game ? aiState.game.score : 0);
      if (vsState) {
        vsState.textContent = aiState.dead
          ? 'AI 已死'
          : ('AI 消 ' + (aiState.game ? aiState.game.clears : 0) + ' 行');
      }
      return;
    }
    if (!multi) return;
    if (vsYou) vsYou.textContent = fmtScore(game ? game.score : 0);
    if (vsOpp) vsOpp.textContent = fmtScore(multi.opponent.score || 0);
    if (vsState) {
      if (!multi.started) vsState.textContent = '准备';
      else if (multi.opponent.dead) vsState.textContent = '对手已死';
      else vsState.textContent = '对手消 ' + (multi.opponent.clears || 0) + ' 行';
    }
  }

  function onNetMessage(m) {
    if (!multi || !m) return;
    if (m.t === 'state') {
      multi.opponent.score = m.score | 0;
      multi.opponent.debt = m.debt | 0;
      multi.opponent.clears = m.clears | 0;
      if (m.dead) multi.opponent.dead = true;
      updateVs();
      if (m.dead && !multi.settled) settleMulti('oppDead');
      return;
    }
    if (m.t === 'dead') {
      multi.opponent.score = m.score | 0;
      multi.opponent.dead = true;
      updateVs();
      if (!multi.settled) settleMulti('oppDead');
      return;
    }
    if (m.t === 'clear') {
      if (multi.mode === 'lan_battle' && game && game.status === 'playing') {
        game.pendingFusion += 1;
        toast('对手送来一块合体块');
        haptic(18);
      }
      return;
    }
    if (m.t === 'peerLeft') {
      multi.opponent.dead = true;
      updateVs();
      toast('对手掉线了');
      if (!multi.settled) settleMulti('oppLeft');
    }
  }

  function settleMulti(reason) {
    if (!multi || multi.settled) return;
    multi.settled = true;
    paused = true;
    dasDir = 0;
    if (game) game.setSoftDrop(false);

    const youDead = !!(game && game.status === 'over');
    const oppDead = !!(multi.opponent.dead || reason === 'oppDead'
      || reason === 'oppLeft' || reason === 'disconnect');
    const ys = game ? game.score : 0;
    const os = multi.opponent.score || 0;
    let winner;
    if (youDead && oppDead) winner = ys > os ? 'you' : (ys < os ? 'opp' : 'draw');
    else if (youDead) winner = ys > os ? 'you' : 'opp';
    else if (oppDead) winner = ys > os ? 'you' : (ys === os ? 'you' : 'opp');
    else winner = 'draw';

    multi.result = { winner: winner, you: ys, opp: os, reason: reason };
    updateVs();

    if (resultEl) {
      const title = $('#resTitle');
      const text = $('#resText');
      if (title) title.textContent = winner === 'you' ? '你赢' : (winner === 'opp' ? '你输' : '平局');
      if (text) {
        let why = '';
        if (reason === 'oppLeft') why = ' · 对手掉线';
        else if (reason === 'disconnect') why = ' · 连接断了';
        text.textContent = '你 ' + ys + ' ： 对手 ' + os + why
          + (winner === 'you' && youDead ? ' · 死的人分高也算赢' : '');
      }
      resultEl.classList.add('on');
    }
    if (root) root.classList.add('is-result');
    haptic(40);
  }

  function drawCountdown(now) {
    const left = Math.max(0, multi.startAtLocal - now);
    const n = Math.ceil(left / 1000);
    ctx.save();
    ctx.fillStyle = 'rgba(5,6,10,.62)';
    ctx.fillRect(0, 0, BW, H);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e9edf6';
    ctx.font = '800 64px ' + FONT;
    ctx.fillText(n > 0 ? String(n) : '开始', BW / 2, 140);
    ctx.fillStyle = '#3ee0c6';
    ctx.font = '600 14px ' + FONT;
    ctx.fillText(multi.mode === 'lan_battle' ? '干扰战' : '并行赛', BW / 2, 200);
    ctx.fillStyle = '#79839a';
    ctx.font = '11px ' + FONT;
    ctx.fillText('对手：' + (multi.opponent.name || '对手'), BW / 2, 222);
    ctx.restore();
  }

  /* ---------------- 输入 ---------------- */

  function onKeyDown(e) {
    if (!running) return;
    if (spectate) {
      if (e.key === 'Escape') { e.preventDefault(); exitToMenu(); }
      return;
    }
    lastInputAt = performance.now();
    const k = e.key;

    if (k === 'Escape' || k === 'p' || k === 'P') {
      e.preventDefault();
      if (!over) togglePause();
      return;
    }
    if (k === 'r' || k === 'R') {
      e.preventDefault();
      if (!e.repeat) requestRestart();
      return;
    }
    if (paused || over || !game) return;

    switch (k) {
      case 'ArrowLeft':
        e.preventDefault();
        if (!e.repeat) { dasDir = -1; dasT = 0; arrT = 0; game.move(-1); }
        break;
      case 'ArrowRight':
        e.preventDefault();
        if (!e.repeat) { dasDir = 1; dasT = 0; arrT = 0; game.move(1); }
        break;
      case 'ArrowDown':
        e.preventDefault();
        game.setSoftDrop(true);
        touchAct = 'down';
        break;
      case 'ArrowUp':
      case 'x':
      case 'X':
        e.preventDefault();
        game.rotate(1);
        break;
      case 'z':
      case 'Z':
        e.preventDefault();
        game.rotate(-1);
        break;
      case 'c':
      case 'C':
        e.preventDefault();
        game.holdPiece();
        break;
      case ' ':
      case 'Spacebar':
        e.preventDefault();
        game.hardDrop();
        break;
      default:
        break;
    }
  }

  function onKeyUp(e) {
    if (!running) return;
    const k = e.key;
    if (k === 'ArrowLeft' && dasDir === -1) dasDir = 0;
    if (k === 'ArrowRight' && dasDir === 1) dasDir = 0;
    if (k === 'ArrowDown' && game) game.setSoftDrop(false);
  }

  function onPadDown(e) {
    const b = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!b || !running || paused || over || !game) return;
    e.preventDefault();
    lastInputAt = performance.now();
    const act = b.dataset.act;
    touchAct = act;
    try { b.setPointerCapture(e.pointerId); } catch (err) {}
    if (act === 'left') { dasDir = -1; dasT = 0; arrT = 0; game.move(-1); }
    else if (act === 'right') { dasDir = 1; dasT = 0; arrT = 0; game.move(1); }
    else if (act === 'down') { game.setSoftDrop(true); }
    else if (act === 'cw') { game.rotate(1); haptic(6); }
    else if (act === 'ccw') { game.rotate(-1); haptic(6); }
    else if (act === 'drop') { game.hardDrop(); haptic(12); }
    else if (act === 'hold') { game.holdPiece(); haptic(6); }
  }

  function onPadUp() {
    if (touchAct === 'left' || touchAct === 'right') dasDir = 0;
    if (touchAct === 'down' && game) game.setSoftDrop(false);
    touchAct = null;
  }

  function onCanvasDown(e) {
    if (!over || !game) return;
    const r = canvas.getBoundingClientRect();
    const x = (e.clientX - r.left) * W / r.width;
    const y = (e.clientY - r.top) * H / r.height;
    if (x < 8 || x > 82 || y < 246 || y > 312) return;
    const now = performance.now();
    if (now - taps.t > 1400) taps.n = 0;
    taps.t = now;
    taps.n += 1;
    if (taps.n >= 5) {
      taps.n = 0;
      game.carryDebt = 0;
      if (overInfo) overInfo.debt = 0;
      setCarry(0);
      toast('档清了，下一局不用还');
      haptic(30);
    }
  }

  function onClick(e) {
    const b = e.target.closest ? e.target.closest('button') : null;
    if (!b) return;
    const cmd = b.dataset.cmd;
    if (cmd) {
      if (cmd === 'exit') exitToMenu();
      else if (cmd === 'pause') togglePause();
      else if (cmd === 'resume') togglePause(false);
      else if (cmd === 'restart') requestRestart();
      else if (cmd === 'export') exportSave();
      else if (cmd === 'import') fileInput.click();
      return;
    }
    if (b.dataset.save) { saveSlot(parseInt(b.dataset.save, 10)); return; }
    if (b.dataset.load) { loadSlot(parseInt(b.dataset.load, 10)); return; }
    if (b.dataset.del) { delSlot(parseInt(b.dataset.del, 10)); return; }
  }

  /* ---------------- 存档 ---------------- */

  function saveAuto() {
    if (!game || multi || aiMode || game.status !== 'playing' || over) return;
    const data = game.toJSON();
    data.savedAt = Date.now();
    const ok = writeJSON(game.zen ? LS.zenAuto
      : (game.casual ? LS.autoCasual
        : (game.classic ? LS.autoClassic : LS.auto)), data);
    if (ok) dispatch('tetris-save-change', { score: game.score, classic: !!game.classic, casual: !!game.casual });
  }

  function slotKey(n) {
    if (game && game.casual) return LS.slotCasual + n;
    return (game && game.classic ? LS.slotClassic : LS.slot) + n;
  }

  function slotModeName(n) {
    return (game && game.casual ? SAVE_NAME.casual
      : (game && game.classic ? SAVE_NAME.classic : SAVE_NAME.normal)) + n;
  }

  function refreshSlots() {
    if (!slotsBox) return;
    let html = '';
    for (let n = 1; n <= 3; n++) {
      const data = readJSON(slotKey(n));
      const valid = !!data && !E.validateSave(data);
      let title = '空';
      if (valid) {
        if (data.classic) {
          title = fmtScore(data.score) + ' 分 · 消 ' + (data.lines || 0) + ' 行 · 等级 ' + (data.level || 1);
        } else {
          title = fmtScore(data.score) + ' 分 · 消 ' + (data.clears || 0) + ' 行'
            + (data.debt > 0 ? ' · 欠 -' + data.debt : '');
        }
      }
      html += '<div class="tg-slot">'
        + '<div class="tg-slot-t"><b>' + slotModeName(n) + '</b><span>' + title + '</span></div>'
        + '<div class="tg-slot-b">'
        + '<button data-save="' + n + '"' + (over || !game ? ' disabled' : '') + '>存</button>'
        + '<button data-load="' + n + '"' + (valid ? '' : ' disabled') + '>读</button>'
        + '<button data-del="' + n + '"' + (valid ? '' : ' disabled') + '>删</button>'
        + '</div></div>';
    }
    slotsBox.innerHTML = html;
  }

  function saveSlot(n) {
    if (game && game.zen) { toast('禅模式只自动存档'); return; }
    if (!game || over) { toast('现在没有在玩的局'); return; }
    if (writeJSON(slotKey(n), game.toJSON())) {
      refreshSlots();
      toast('存进「' + slotModeName(n) + '」');
    } else {
      toast('存不进去（浏览器不给写）');
    }
  }

  function loadSlot(n) {
    if (game && game.zen) { toast('禅模式只自动存档'); return; }
    const data = readJSON(slotKey(n));
    if (!data) { toast('「' + slotModeName(n) + '」是空的'); return; }
    const g = data.classic
      ? new E.Tetris({ seed: (data.seed >>> 0) || 1, classic: true, cols: data.cols || 10, rows: data.rows || 20 })
      : (data.casual
        ? new E.Tetris({ seed: (data.seed >>> 0) || 1, casual: true, cols: data.cols || 10, rows: data.rows || 10 })
        : mk({ seed: (data.seed >>> 0) || 1 }));
    const err = g.loadJSON(data);
    if (err) { toast('这个槽读不了：' + err); return; }
    game = g;
    layoutFor(game);
    over = false;
    overInfo = null;
    paused = false;
    effects = [];
    taps = { n: 0, t: 0 };
    dasDir = 0;
    if (root) root.classList.remove('is-over');
    if (pauseLayer) pauseLayer.classList.remove('on');
    lastFrame = 0;
    toast('读了「' + slotModeName(n) + '」');
    saveAuto();
    if (!running) { running = true; raf = requestAnimationFrame(frame); }
  }

  function delSlot(n) {
    try { localStorage.removeItem(slotKey(n)); } catch (e) {}
    refreshSlots();
    toast('「' + slotModeName(n) + '」删了');
  }

  function exportSave() {
    if (!game) { toast('还没开局'); return; }
    const data = game.toJSON();
    data.savedAt = new Date().toISOString();
    const text = JSON.stringify(data, null, 2);
    try {
      const blob = new Blob([text], { type: 'application/json' });
      const a = document.createElement('a');
      const d = new Date();
      const pad = function (v) { return v < 10 ? '0' + v : '' + v; };
      a.download = (game.classic ? '经典玩法' : '单人玩法') + '-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate())
        + '-' + pad(d.getHours()) + pad(d.getMinutes()) + '.json';
      a.href = URL.createObjectURL(blob);
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      toast('存档已导出');
    } catch (e) {
      toast('导出失败');
    }
  }

  function onImportFile() {
    const f = fileInput && fileInput.files && fileInput.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = function () {
      try {
        const data = JSON.parse(String(reader.result || ''));
        const err = E.validateSave(data);
        if (err) { toast('这个文件不对：' + err); return; }
        const g = data.classic
          ? new E.Tetris({ seed: (data.seed >>> 0) || 1, classic: true, cols: data.cols || 10, rows: data.rows || 20 })
          : mk({ seed: (data.seed >>> 0) || 1 });
        if (g.loadJSON(data)) { toast('读不进去'); return; }
        game = g;
        layoutFor(game);
        over = false;
        overInfo = null;
        paused = false;
        effects = [];
        if (root) root.classList.remove('is-over');
        if (pauseLayer) pauseLayer.classList.remove('on');
        lastFrame = 0;
        saveAuto();
        toast('存档导入成功');
        if (!running) { running = true; raf = requestAnimationFrame(frame); }
      } catch (e) {
        toast('不是 JSON 文件');
      }
    };
    reader.readAsText(f);
    fileInput.value = '';
  }

  /* ---------------- 画 ---------------- */

  function fit() {
    if (!canvas) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.round(W * dpr), h = Math.round(H * dpr);
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function rr(x, y, w, h, r) {
    ctx.beginPath();
    if (ctx.roundRect) { ctx.roundRect(x, y, w, h, r); return; }
    const rad = Math.min(r, w / 2, h / 2);
    ctx.moveTo(x + rad, y);
    ctx.arcTo(x + w, y, x + w, y + h, rad);
    ctx.arcTo(x + w, y + h, x, y + h, rad);
    ctx.arcTo(x, y + h, x, y, rad);
    ctx.arcTo(x, y, x + w, y, rad);
    ctx.closePath();
  }

  function render(now) {
    if (!ctx) return;
    if (spectate) { drawSpectate(now); return; }
    if (!game) return;
    ctx.clearRect(0, 0, W, H);

    ctx.fillStyle = '#08090d';
    ctx.fillRect(0, 0, W, H);

    drawBoard(now);
    drawPanel(now);
    renderAI();
    if (multi && !multi.started) drawCountdown(now);
    if (over && !multi && !aiMode) drawGameOver();
  }

  function renderAI() {
    if (!aiMode || !aiState || !aiCtx) return;
    const g = aiState.game;
    const size = 96, n = 10, cell = size / n;
    aiCtx.clearRect(0, 0, size, size);
    aiCtx.fillStyle = '#0a0c12';
    aiCtx.fillRect(0, 0, size, size);
    aiCtx.strokeStyle = 'rgba(255,255,255,.06)';
    aiCtx.lineWidth = 1;
    for (let i = 1; i < n; i++) {
      aiCtx.beginPath(); aiCtx.moveTo(i * cell, 0); aiCtx.lineTo(i * cell, size); aiCtx.stroke();
      aiCtx.beginPath(); aiCtx.moveTo(0, i * cell); aiCtx.lineTo(size, i * cell); aiCtx.stroke();
    }
    function paint(cx, cy, color) {
      aiCtx.fillStyle = color;
      aiCtx.fillRect(cx * cell + 0.7, cy * cell + 0.7, cell - 1.4, cell - 1.4);
    }
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        const c = g.board[y][x];
        if (!c) continue;
        paint(x, y, c.k === 'f' ? '#5c6a88' : (c.k === 'p' ? '#7a3442' : (E.COLORS[c.t] || '#8b95a8')));
      }
    }
    if (g.piece) {
      const cells = g.pieceCells();
      for (let i = 0; i < cells.length; i++) {
        const x = cells[i][0], y = cells[i][1];
        if (x >= 0 && x < n && y >= 0 && y < n) paint(x, y, '#f2f5ff');
      }
    }
    if (aiScoreEl) aiScoreEl.textContent = fmtScore(g.score);
    if (aiInfoEl) {
      aiInfoEl.textContent = '消 ' + g.clears + ' · ' + (aiState.dead ? '死' : '活')
        + ' · 等级 ' + g.lockLevel;
    }
    if (aiDebtEl) {
      const d = g.projectedDebt ? g.projectedDebt() : g.debt;
      aiDebtEl.textContent = d > 0 ? ('结束欠 -' + d) : '债 0';
    }
  }

  function cellColor(type) { return COLORS[type] || '#8b95a8'; }

  function drawBlock(px, py, fill, opts) {
    opts = opts || {};
    const pad = 2, s = C.CELL - pad * 2;
    ctx.save();
    if (opts.alpha !== undefined) ctx.globalAlpha = opts.alpha;
    rr(px + pad, py + pad, s, s, 6);
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.strokeStyle = opts.stroke || 'rgba(0,0,0,.28)';
    ctx.lineWidth = 1;
    ctx.stroke();
    // 上面一道高光，让块看起来是立体的
    ctx.beginPath();
    ctx.moveTo(px + pad + 3, py + pad + 1.5);
    ctx.lineTo(px + pad + s - 3, py + pad + 1.5);
    ctx.strokeStyle = 'rgba(255,255,255,.28)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
  }

  function drawBoard(now) {
    // 底
    ctx.fillStyle = '#0a0c12';
    ctx.fillRect(0, 0, BW, H);

    // 格线
    ctx.strokeStyle = 'rgba(255,255,255,.035)';
    ctx.lineWidth = 1;
    for (let i = 1; i < game.cols; i++) {
      ctx.beginPath(); ctx.moveTo(i * C.CELL + 0.5, 0); ctx.lineTo(i * C.CELL + 0.5, H); ctx.stroke();
    }
    for (let i = 1; i < game.rows; i++) {
      ctx.beginPath(); ctx.moveTo(0, i * C.CELL + 0.5); ctx.lineTo(BW, i * C.CELL + 0.5); ctx.stroke();
    }

    // 场上
    const fusionGroups = {};
    for (let y = 0; y < game.rows; y++) {
      for (let x = 0; x < game.cols; x++) {
        const c = game.board[y][x];
        if (!c) continue;
        const px = x * C.CELL, py = y * C.CELL;
        if (c.k === 'f') {
          drawBlock(px, py, '#39415a', { stroke: 'rgba(160,178,210,.5)' });
          if (c.l) {
            const grp = fusionGroups[c.g] ||
              (fusionGroups[c.g] = { l: c.l, minx: x, maxx: x, miny: y, maxy: y });
            if (x < grp.minx) grp.minx = x;
            if (x > grp.maxx) grp.maxx = x;
            if (y < grp.miny) grp.miny = y;
            if (y > grp.maxy) grp.maxy = y;
          }
        } else if (c.k === 'p') {
          drawBlock(px, py, '#4a2630', { stroke: 'rgba(255,77,94,.55)' });
          ctx.save();
          ctx.strokeStyle = 'rgba(255,120,135,.28)';
          ctx.beginPath();
          ctx.moveTo(px + 9, py + 16); ctx.lineTo(px + 23, py + 16);
          ctx.moveTo(px + 16, py + 9); ctx.lineTo(px + 16, py + 23);
          ctx.stroke();
          ctx.restore();
        } else {
          drawBlock(px, py, cellColor(c.t));
        }
      }
    }

    // 字母块的字母：整块画一次，不一个格子一个
    for (const key in fusionGroups) {
      const grp = fusionGroups[key];
      const cx = (grp.minx + grp.maxx + 1) / 2 * C.CELL;
      const cy = (grp.miny + grp.maxy + 1) / 2 * C.CELL;
      ctx.save();
      ctx.fillStyle = 'rgba(255,212,121,.5)';
      ctx.font = '800 28px ' + FONT;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(grp.l, cx, cy + 1);
      ctx.restore();
    }

    // 顶块预警：最后 0.9 秒 / 顶上两行已经有东西，直接把危险画在盘面上
    if (!game.classic && game.pendingFusion > 0) {
      const danger = game.topBusy(2);
      const warn = game.fusionWarned || danger;
      ctx.save();
      ctx.fillStyle = danger ? 'rgba(255,77,94,.14)' : 'rgba(255,200,80,.07)';
      ctx.fillRect(0, 0, BW, 2 * C.CELL);
      ctx.strokeStyle = danger ? 'rgba(255,77,94,.85)' : 'rgba(255,200,80,.45)';
      ctx.lineWidth = warn ? 2 : 1;
      ctx.strokeRect(1, 1, BW - 2, 2 * C.CELL - 2);
      ctx.restore();
    }

    // 消行闪光
    for (let i = 0; i < effects.length; i++) {
      const e = effects[i];
      if (e.type !== 'rows') continue;
      const k = clamp((e.until - now) / 260, 0, 1);
      ctx.save();
      ctx.fillStyle = 'rgba(255,255,255,' + (0.55 * k) + ')';
      for (let r = 0; r < e.rows.length; r++) ctx.fillRect(0, e.rows[r] * C.CELL, BW, C.CELL);
      ctx.restore();
    }

    // 落点预览 + 当前块
    if (game.piece && game.status === 'playing') {
      drawGhost();
      drawActive();
    }

    // 转场闪白
    for (let i = 0; i < effects.length; i++) {
      const e = effects[i];
      if (e.type === 'flash') {
        const k = clamp((e.until - now) / 420, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(255,255,255,' + (0.16 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
      if (e.type === 'fusion') {
        const k = clamp((e.until - now) / 460, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(62,224,198,' + (0.13 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
      if (e.type === 'arrow') {
        const k = clamp((e.until - now) / 360, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(255,255,255,' + (0.18 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
    }

    // 边框 + 转场预警
    const muted = document.documentElement.classList.contains('cues-muted');
    ctx.strokeStyle = muted ? 'rgba(62,224,198,.35)' : 'rgba(255,255,255,.08)';
    ctx.lineWidth = 1;
    ctx.strokeRect(0.5, 0.5, BW - 1, H - 1);
    if (muted) {
      // 没有声音的时候，边框常亮，替声音告诉你“局还在”
      ctx.save();
      ctx.strokeStyle = 'rgba(62,224,198,.22)';
      ctx.strokeRect(2.5, 2.5, BW - 5, H - 5);
      ctx.restore();
    }

    if (game.status === 'playing' && game.rotateEnabled !== false) {
      const rem = C.ROTATE_MS - game.rotTimer;
      if (rem <= C.ROTATE_WARN_MS) {
        const k = 1 - rem / C.ROTATE_WARN_MS;
        const pulse = 0.5 + 0.5 * Math.sin(now / 90);
        ctx.save();
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.18 + 0.55 * k * pulse) + ')';
        ctx.lineWidth = 2;
        ctx.strokeRect(1, 1, BW - 2, H - 2);
        ctx.restore();
        drawSpin(now, k);
      }
    }
  }

  function drawSpin(now, k) {
    ctx.save();
    ctx.translate(300, 20);
    ctx.rotate((now / 260) % (Math.PI * 2));
    ctx.strokeStyle = 'rgba(255,255,255,' + (0.45 + 0.45 * k) + ')';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 9, -Math.PI * 0.75, Math.PI * 0.75);
    ctx.stroke();
    // 箭头
    ctx.beginPath();
    ctx.moveTo(0, -12);
    ctx.lineTo(-4.5, -6.5);
    ctx.lineTo(4.5, -6.5);
    ctx.closePath();
    ctx.fillStyle = 'rgba(255,255,255,' + (0.55 + 0.4 * k) + ')';
    ctx.fill();
    ctx.restore();
  }

  function ghostY() {
    const p = game.piece;
    if (!p) return 0;
    let y = p.y;
    while (!game.collides({ type: p.type, rot: p.rot, x: p.x, y: y + 1 })) y++;
    return y;
  }

  function drawGhost() {
    const p = game.piece;
    if (!p) return;
    const gy = ghostY();
    if (gy === p.y) return;
    const cells = game.pieceCells({ type: p.type, rot: p.rot, x: p.x, y: gy });
    const color = p.type === 'ARROW' ? '#f2f5ff' : cellColor(p.type);
    ctx.save();
    ctx.globalAlpha = 0.16;
    ctx.fillStyle = color;
    for (let i = 0; i < cells.length; i++) {
      const px = cells[i][0] * C.CELL, py = cells[i][1] * C.CELL;
      rr(px + 4, py + 4, C.CELL - 8, C.CELL - 8, 5);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawActive() {
    const p = game.piece;
    if (!p) return;
    const cells = game.pieceCells();
    const isArrow = p.type === 'ARROW';
    const color = isArrow ? '#f2f5ff' : cellColor(p.type);
    ctx.save();
    ctx.shadowColor = isArrow ? 'rgba(255,255,255,.85)' : color;
    ctx.shadowBlur = 12;
    for (let i = 0; i < cells.length; i++) {
      const px = cells[i][0] * C.CELL, py = cells[i][1] * C.CELL;
      drawBlock(px, py, color, { stroke: 'rgba(255,255,255,.4)' });
    }
    ctx.restore();
    if (isArrow) {
      const glyph = { up: '↑', down: '↓', left: '←', right: '→' }[p.dir] || '↑';
      ctx.save();
      ctx.fillStyle = '#08090d';
      ctx.font = '700 22px ' + FONT;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(glyph, p.x * C.CELL + 16, p.y * C.CELL + 17);
      ctx.restore();
    }
  }

  function drawPreview(entry, x, y, size) {
    ctx.save();
    rr(x, y, size, size, 9);
    ctx.fillStyle = '#10131b';
    ctx.fill();
    ctx.strokeStyle = '#232838';
    ctx.lineWidth = 1;
    ctx.stroke();

    if (entry) {
      if (entry.t === 'ARROW') {
        const glyph = { up: '↑', down: '↓', left: '←', right: '→' }[entry.d] || '↑';
        ctx.fillStyle = '#f2f5ff';
        ctx.font = '700 ' + Math.round(size * 0.5) + 'px ' + FONT;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(glyph, x + size / 2, y + size / 2 + 1);
      } else {
        const shape = SHAPES[entry.t];
        let minx = 9, maxx = -9, miny = 9, maxy = -9;
        for (let i = 0; i < shape.cells.length; i++) {
          minx = Math.min(minx, shape.cells[i][0]); maxx = Math.max(maxx, shape.cells[i][0]);
          miny = Math.min(miny, shape.cells[i][1]); maxy = Math.max(maxy, shape.cells[i][1]);
        }
        const bw = maxx - minx + 1, bh = maxy - miny + 1;
        const u = size / 4.6;
        const ox = (size - bw * u) / 2 - minx * u;
        const oy = (size - bh * u) / 2 - miny * u;
        ctx.fillStyle = cellColor(entry.t);
        for (let i = 0; i < shape.cells.length; i++) {
          const cx = x + ox + shape.cells[i][0] * u;
          const cy = y + oy + shape.cells[i][1] * u;
          rr(cx + 1, cy + 1, u - 2, u - 2, 3);
          ctx.fill();
        }
      }
    }
    ctx.restore();
  }

  function drawPanel(now) {
    ctx.save();
    rr(PX, 0, PW, H, 12);
    ctx.fillStyle = '#0d0f16';
    ctx.fill();
    ctx.strokeStyle = '#1c2130';
    ctx.lineWidth = 1;
    ctx.stroke();

    const L = PX + 8, R = PX + PW - 8;

    // NEXT
    label('NEXT', L, 14);
    for (let i = 0; i < 3; i++) {
      drawPreview(game.queue[i] || null, L + i * 44, 20, 40);
    }

    // HOLD
    label('HOLD', L, 77);
    drawPreview(game.hold || null, L, 83, 40);

    // 分数
    label('分数', L, 141);
    ctx.fillStyle = '#e9edf6';
    ctx.font = '700 26px ' + FONT;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(fmtScore(game.score), L, 168);

    // 三行数据
    const projected = game.projectedDebt ? game.projectedDebt() : game.debt;
    if (game.zen) {
      const left = Math.max(0, game.zenTimeLeft || 0);
      const mm = Math.floor(left / 60000);
      const ss = Math.floor(left % 60000 / 1000);
      stat('剩余', mm + ':' + (ss < 10 ? '0' : '') + ss, 192, left < 30000 ? '#ff5c6c' : '#3ee0c6');
      stat('连击', game.combo > 0 ? game.combo + 'x' : '0', 214, game.combo > 0 ? '#ffc857' : '#c6cdda');
      stat('消行', String(game.clears), 236, '#c6cdda');
      stat('最高', fmtScore(highScore), 258, '#79839a');
    } else if (game.casual) {
      const mult = 1 + Math.min(Math.max(0, game.combo - 1), 5) * 0.25;
      stat('连击', game.combo > 0 ? game.combo + 'x' : '0', 192, game.combo > 0 ? '#ffc857' : '#c6cdda');
      stat('倍数', 'x' + mult.toFixed(2).replace(/\.?0+$/, ''), 214, '#ffc857');
      stat('消行', String(game.clears), 236, '#c6cdda');
      stat('最高', fmtScore(highScore), 258, '#79839a');
    } else {
      stat('等级', String(game.classic ? game.level : game.lockLevel), 192, '#c6cdda');
      stat('结束欠', game.classic ? '—' : (projected > 0 ? '-' + projected : '0'), 214,
        game.classic ? '#79839a' : (projected > 0 ? '#ff5c6c' : '#79839a'));
      stat('消行', String(game.classic ? game.lines : game.clears), 236, '#c6cdda');
      stat('最高', fmtScore(highScore), 258, '#79839a');
    }

    // 状态小字
    ctx.textAlign = 'left';
    ctx.font = '10px ' + FONT;
    ctx.fillStyle = '#4a5264';
    if (game.zen) {
      ctx.fillStyle = game.zenTimeLeft < 30000 ? '#ff8b96' : '#4a5264';
      ctx.fillText('禅 · ' + game.zenMinutes + ' 分钟 · 整理 ' + (game.zenRescues || 0), L, 286);
      ctx.fillStyle = '#4a5264';
    } else if (game.casual) {
      const next = 1 + Math.min(Math.max(0, game.combo), 5) * 0.25;
      if (game.combo > 0) {
        ctx.fillStyle = '#ffc857';
        ctx.fillText('下一消 x' + next.toFixed(2).replace(/\.?0+$/, '') + ' · 断击 ' + game.comboMiss + '/3', L, 286);
      } else {
        ctx.fillText('消一行起连击 · 断击 ' + game.comboMiss + '/3', L, 286);
      }
    } else if (game.classic) {
      ctx.fillText('原版规则', L, 286);
    } else if (game.pendingFusion > 0) {
      const left = Math.max(0, ((E.CONST ? E.CONST.FUSION_DELAY_MS : 2500) - game.fusionTimer) / 1000);
      let holes = '';
      if (game.fusionPreview && game.fusionPreview.holes) {
        const xs = [];
        game.fusionPreview.holes.forEach(function (h) {
          const v = String(h[0] + 1);
          if (xs.indexOf(v) < 0) xs.push(v);
        });
        holes = ' · 洞 ' + xs.join('/');
      }
      ctx.fillStyle = '#ff8b96';
      ctx.fillText('顶块 ' + left.toFixed(1) + 's' + holes, L, 286);
      ctx.fillStyle = '#4a5264';
    } else if (game.grace > 0) {
      ctx.fillText('奖励期 ' + game.grace + ' 次', L, 286);
    } else if (game.debt > 0) {
      ctx.fillText('还债中', L, 286);
    } else {
      ctx.fillText('债已清', L, 286);
    }
    ctx.fillStyle = '#3a4152';
    if (game.zen) {
      ctx.fillText('禅 · 最高连击 ' + (game.maxCombo || 0) + 'x', L, 304);
    } else if (game.casual) {
      ctx.fillText('常驻 · 最高连击 ' + (game.maxCombo || 0) + 'x', L, 304);
    } else if (game.classic) {
      ctx.fillText('SEED ' + game.seed, L, 304);
    } else if (game.clears < (E.CONST ? E.CONST.MORPH_AT_CLEARS : 40)) {
      ctx.fillText('变形 ' + game.clears + '/' + (E.CONST ? E.CONST.MORPH_AT_CLEARS : 40), L, 304);
    } else {
      ctx.fillText('字母块 ' + Math.floor(game.clears / (E.CONST ? E.CONST.MORPH_AT_CLEARS : 40)), L, 304);
    }

    ctx.restore();

    function label(t, x, y) {
      ctx.fillStyle = '#5b6479';
      ctx.font = '600 9px ' + FONT;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
      ctx.fillText(t, x, y);
    }
    function stat(k, v, y, color) {
      ctx.textAlign = 'left';
      ctx.font = '11px ' + FONT;
      ctx.fillStyle = '#79839a';
      ctx.fillText(k, L, y);
      ctx.textAlign = 'right';
      ctx.font = '600 13px ' + FONT;
      ctx.fillStyle = color;
      ctx.fillText(v, R, y);
    }
  }

  function drawGameOver() {
    const info = overInfo || { debt: 0 };
    ctx.save();
    ctx.fillStyle = 'rgba(5,6,10,.78)';
    ctx.fillRect(0, 0, BW, H);

    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';

    ctx.shadowColor = 'rgba(255,77,94,.7)';
    ctx.shadowBlur = 24;
    ctx.fillStyle = '#ff4d5e';
    ctx.font = '800 48px ' + FONT;
    ctx.fillText(game.zen ? '禅' : (game.casual ? '常驻' : '债'), 14, 300);
    ctx.shadowBlur = 0;

    ctx.fillStyle = '#e9edf6';
    ctx.font = '700 18px ' + FONT;
    ctx.fillText('本局 ' + fmtScore(game.score), 80, 262);

    ctx.fillStyle = '#ffc857';
    ctx.font = '700 15px ' + FONT;
    if (game.casual) {
      ctx.fillText('最高连击 ' + (game.maxCombo || 0) + 'x', 80, 286);
    } else {
      ctx.fillText((info.debt || 0) > 0 ? '带走 -' + info.debt : '带走 0', 80, 286);
    }

    ctx.fillStyle = '#79839a';
    ctx.font = '11px ' + FONT;
    ctx.fillText('按 R 重开', 80, 308);

    ctx.fillStyle = '#3a4152';
    ctx.font = '9px ' + FONT;
    ctx.textAlign = 'right';
    ctx.fillText(game.zen ? '禅模式 · 时间到'
      : (game.casual ? '常驻 · 连击' : (game.classic ? '原版规则' : '连点「债」5 下清档')), BW - 12, 308);
    ctx.restore();
  }

  /* ---------------- 对外 ---------------- */

  window.TetrisGame = {
    start: start,
    stop: exitToMenu,
    isRunning: function () { return running; },
    // 给控制台 / 测试用的把手，不参与游戏逻辑
    _state: function () { return game; },
    _aiState: function () { return aiState; },
    _spectate: function () { return spectate; },
    _spectateStep: function (ms) {
      if (!spectate) return;
      stepSpectate(Math.max(0, ms || 16));
      render(performance.now());
    },
    _stepForTest: function (ms) {
      if (!game || over) return;
      const step = Math.max(0, Math.min(ms || 16, 120));
      game.tick(step);
      updateDAS(step);
      pumpEvents();
      if (aiMode) stepAI(step);
      render(performance.now());
    }
  };
})();
