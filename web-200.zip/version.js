/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '4.3',
  code: 65,
  web: 200,
  date: '2026-11-24',
  title: '工作室标记 2.0',
  titleEn: 'Studio mark v2',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单 / 普通 / 困难 / 地狱——越难越聪明，落子速度最多比你快 5%。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard / Hell — higher is sharper, and it never drops more than 5% faster than you."
    }
  ],
  log: [
    {
      "v": "4.3",
      "date": "2026-11-24",
      "title": "工作室标记 2.0",
      "summary": "光绘 D 摆正：把标记移出齿轮的旋转容器，改成独立绝对定位（原来会继承齿轮的随机角度，D 是歪的）；轮廓改成直边 + 正半圆，和图标同一套几何；字标收紧到 0.18em。图标也改成「D己」两个字紧凑排一起。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "4.2",
      "date": "2026-11-24",
      "title": "工作室标记",
      "summary": "开屏收尾换成工作室 logo：齿轮被切开后，一个霓虹 D 在同一个位置一笔画出来（描边生长 + 亮一下），「己」在肚子里；「自我突破」留着，字标改成逐字浮现。App 图标也换成同一个 D己：深底、青霓虹 D 描边、中间一个己。壳升到 2.2·65。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "4.1",
      "date": "2026-11-24",
      "title": "键位贴手",
      "summary": "方向键拆到屏幕左右两边：左边 ← →，右边 ↻（旋转独立成键）和 ↓；暂存删掉（按钮、C 键、教程里的说明一起去掉）。按键加大，并且离屏幕底边留一点拇指高度、离左右边留一点边距——横屏贴左右下角、竖屏贴左右两边，两边同一套落点。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "4.0",
      "date": "2026-11-24",
      "title": "键位贴手",
      "summary": "方向键拆到屏幕左右两边：左边 ← →，右边 ↻（旋转独立成键）和 ↓；暂存删掉（按钮、C 键、教程里的说明一起去掉）。按键加大一档，并且离屏幕底边留一点拇指高度——横屏贴左右下角、竖屏贴左右两边，两边都用同一套落点算。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.9",
      "date": "2026-11-24",
      "title": "一个按钮找对家",
      "summary": "多人对战只剩一个「快速匹配」：Wi-Fi 找房和蓝牙同时试，哪条先连上就走哪条，另一条立刻关掉（Wi-Fi 赢了关蓝牙、蓝牙赢了关 Wi-Fi 房）。去掉手动填地址/房间码的入口，也去掉单独的网络、蓝牙两个按钮和它们的子选项。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.8",
      "date": "2026-11-24",
      "title": "AI 跟着你的节奏走",
      "summary": "打 AI 的难度改成跟着你走：你每消一行，AI 升一级（更准、更会救场）；落子速度用你最近几块的平均节奏封顶——最多比你快 5%，再难也不会甩开你。四档都是这条规矩，区别只在于它有多聪明；原来「每 30 秒自动升一档」去掉。顺带修掉 3.7 里「难度越高越慢」那个写反的间隔表。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.7",
      "date": "2026-11-24",
      "title": "AI 会提速了",
      "summary": "打 AI 太慢的根因：AI 落子间隔写的是「简单 2 秒 / 普通 3 秒 / 困难 5 秒」——难度越高反而越慢，跟界面写的「难度越高落子越快」正好相反。现在改成 简单 1.7 秒 / 普通 1.15 秒 / 困难 0.78 秒，并新加一档「地狱」0.42 秒；每 30 秒升一档（间隔 ×0.9，最低 1.4 / 0.8 / 0.4 / 0.22 秒），升档时会提示「现在几秒一块」。开屏随机切的 3.6 也一并在内。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.6",
      "date": "2026-11-24",
      "title": "一个齿轮，随机切",
      "summary": "开屏改成只有一个齿轮：每次进来整块转一个随机角度（-50°~+50°）、刀口高低也随机（44%~56%），一刀沿切口分成上下两半飞开。顺手修了两个坑：3.5 的随机参数根本没生效（el 跨作用域被 catch 吞了，永远停在 0°/46%），以及裁切放在外壳上会让两半看着像两个齿轮叠着（改成裁在齿轮自己身上）。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.5",
      "date": "2026-11-23",
      "title": "刀气劈开",
      "summary": "开屏：一道刀气扫过把齿轮劈成两半，不撒碎片、不闪白；音效是代码合成的刀风 + 金属铮。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.4",
      "date": "2026-11-23",
      "title": "开屏改成刀气劈碎",
      "summary": "开屏不再从中心裂开：一道斜的刀光扫过，齿轮沿着切线分成两半飞开，留一道余光；音效换成刀气风声 + 金属铮；之后才是「自我突破」，下面一行「D己工作室」。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.3",
      "date": "2026-11-23",
      "title": "开屏齿轮像齿轮了",
      "summary": "开屏那段齿轮里有两个「多出来的东西」——一个故意调亮的齿、一个小蓝点、一道黑键槽，是 2.1 为了让人看出它在转硬加的，看着像脏东西。现在去掉，改成齿轮自己的辐板 + 3 个错开 120° 的减重孔：像真齿轮，转动照样一眼看得出来。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.2",
      "date": "2026-11-22",
      "title": "联机开局不再黑屏",
      "summary": "联机点开始后棋盘全黑、什么都不动：倒计时那 2 秒把主循环停死了（paused 早早为 true，frame 直接 return，倒计时本身又在 frame 里判断，于是永远走不完）。现在倒计时期间循环照常跑，只有真暂停才停 rAF；check.mjs 加了闸门防回归。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.1",
      "date": "2026-11-22",
      "title": "蓝牙连不上会自己重试",
      "summary": "配对好了还是加不进来：客机原来只重试 3 次（约 3 秒）就放弃，对方慢半拍就永远连不上。现在重试 8 次、连接卡住 12 秒也算失败重来；房主/客机的文字说清楚谁点「我开房」，已配对列表把上次那台放最前。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.0",
      "date": "2026-11-22",
      "title": "联机开局回来了",
      "summary": "修掉多人开局里引用已删变量 matchTier 的 ReferenceError（Wi-Fi/蓝牙点开始都没反应），并把联机入口简化为两个按钮：同一 Wi-Fi、蓝牙。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.9",
      "date": "2026-11-22",
      "title": "横竖屏都居中",
      "summary": "所有界面重新按横竖屏适配：横屏时内容列放宽到 780px、按钮 480px，卡片最高 88vh 并可滚动；竖屏时侧边抽屉最多占 92vw；矮屏（高度 ≤560px，比如横着的平板）按钮收到 46px、标题和间距一起收紧，避免内容顶到外面。所有屏仍然水平垂直双居中，超长内容才滚动。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.8",
      "date": "2026-11-22",
      "title": "更新源按实测排序",
      "summary": "实测这台平板的网络：raw.githubusercontent 被重置（要 23 秒才失败），ghproxy.net 能通（2.5~13 秒）。所以更新源改成「镜像第一、raw 备胎」，不再让壳白等 20 秒；同时把网页端「等结果」的超时从 12 秒放宽到 30 秒，避免镜像慢一点就显示超时。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.7",
      "date": "2026-11-22",
      "title": "更新不再超时",
      "summary": "你联网却更新失败的真因：镜像 ghproxy.net 冷启动要 17~29 秒，而壳里的超时是连接 3 秒 / 读取 6 秒 —— 三个源全被判超时；gh-proxy 还会直接 403。改法：① 壳的超时放宽到连接 8 秒 / 读取 20 秒；② 默认更新源换成 raw.githubusercontent 直连（本机实测 0.5 秒），ghproxy.net 做备用，403 的 gh-proxy 删掉；③ 安装包链接也默认给直连。这一版壳升到 2.1（versionCode 64），装一次就恢复正常更新。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.6",
      "date": "2026-11-22",
      "title": "默认镜像换成 ghproxy.net",
      "summary": "gh-proxy.com 从今天上午开始整站回 403，导致更新和安装包链接都打不开。现在默认更新源和安装包下载地址都改成 ghproxy.net（gh-proxy 留作备用源，第二顺位）。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.5",
      "date": "2026-11-22",
      "title": "连机能连上了，开局不再被更新踢出去",
      "summary": "两个真问题：① 蓝牙连失败现在会自动重试 3 次（每次隔 0.9 秒），失败时把话说明白——对方是不是还没点「我是房主」、两台配对没有；房主这边也会提示怎么让对方连进来。② 「点了开始游戏却被弹回主菜单」的根因是自动更新：上一版更新正好在连接/开局时落地，更新流程直接重启 WebView。现在装了更新也会先看忙不忙，游戏里/大厅里/正在连都不重启，回到主菜单才生效并提示一句。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.4",
      "date": "2026-11-22",
      "title": "连上就开，不用再点",
      "summary": "联机连上之后不再干等房主点按钮：人一齐、网页包对得上，房主这边 2.5 秒后自动开局（想提前就自己点，按钮上会写「马上开局…点这里立刻开」）；人数没齐或版本不一致会自动取消。房客那边等两三秒就自动进棋盘，提示也改成「房主那边会自动开局」。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.3",
      "date": "2026-11-22",
      "title": "蓝牙并进速配",
      "summary": "多人页只留一个「快速匹配」：先在同一个 Wi-Fi 里找房，找不到就自动看蓝牙——有配过对的手机就弹出「用蓝牙连谁 / 我当房主」，都没有才问你要开几人的 Wi-Fi 房。原来那两个独立入口（蓝牙对战、手动输入地址）删掉了，手动填地址和「自己开 Wi-Fi 房」挪进那张兜底卡片里，需要时一键退回。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.2",
      "date": "2026-11-22",
      "title": "AI 不再罢工：换板续命、难度随时间爬",
      "summary": "打 AI 不再因为 AI 顶死就结束：它顶爆或被堵死时会换一块空板接着打，分数继续累计，一局可以一直打下去。难度每 45 秒升一级——算得更准、落子更快（3 秒→最低 0.7 秒）、更愿意单消救场；场地快堆满时会先保命再谈划不划算。左侧排行榜的 AI 行会显示当前「难度 N」和「换板 N」。",
      "added": [
        "打 AI：AI 顶死后自动换空板续命，分数累计，一局可以无限打",
        "打 AI：难度每 45 秒升一级（更准 / 更快 / 更会救场）",
        "排行榜 AI 行显示「难度 N · 换板 N」"
      ],
      "changed": [
        "打 AI 的结算条件改成「你死了才结算」，AI 死不再结束整局"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.1",
      "date": "2026-11-22",
      "title": "开屏齿轮真的转起来了",
      "summary": "上一版齿轮看着不动：转速 2.2 秒才一圈，十分钟对称的十个齿在这点角度里几乎看不出位移；而且缩放动画和旋转动画抢同一个 transform。现在转速提到 1.1 秒一圈，缩放改成只动透明度，另加一个亮齿和一道键槽当参照物，一眼就能看出在转；转完从中心裂开、炸碎的流程不变。",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.0",
      "date": "2026-11-22",
      "title": "版本号改规矩",
      "summary": "从这一版起版本号只走两位：1.1 … 1.9 → 2.0 → 2.1 …，不会再有 1.10 这种写法。这一版游戏和壳同时进 2.0（壳 versionCode 63）。功能上沿用上一版的开屏：齿轮转着转着自己从中心裂开、炸成碎片，收尾是「自我突破」和「D己工作室」。",
      "added": [],
      "changed": [
        "版本号规矩：主.次 两位，次版本只走 0~9，1.9 之后是 2.0（不写 1.10）",
        "游戏与壳同时进 2.0；壳 versionCode 63",
        "新增 bump.mjs：按规矩升号（--dry 先看，--shell 连壳一起升）",
        "check.mjs 增加版本号规矩校验，写错直接报错"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.64",
      "date": "2026-11-21",
      "title": "开屏：齿轮自己碎",
      "summary": "手整个撤掉（锤子、拳头、人手都不用了）。现在是齿轮自己从中间碎：转到约 2.2 秒，中心先裂出第一道缝，接着四条裂纹依次往外爬（stroke 逐段画出来，不是突然出现），中心一点点发白、越撑越亮，2.62 秒炸开——闪白、齿轮消失、十块碎片带着旋转飞散。声音跟着画面走：裂纹每条一下干脆的金属裂响（3.2k→4.2k 高频短点），撑到极点有一段 180→760Hz 的上升应力声，炸开是闷响 + 多层金属余音 + 宽带噪声。裂纹只动 stroke-dashoffset、碎片只动 transform/opacity，都是合成层动画，不掉帧。",
      "added": [
        "开屏：齿轮自己从中心裂开再炸碎（裂纹逐条爬开 + 中心发白）",
        "开屏：裂纹有金属裂响，撑裂有上升应力声，炸开有破碎声"
      ],
      "changed": [
        "收尾保持「自我突破」居中、「D己工作室」在下"
      ],
      "balance": [],
      "removed": [
        "开屏里的手（拳头 / 人手）"
      ]
    },
    {
      "v": "1.63",
      "date": "2026-11-21",
      "title": "开屏：一只手捏碎齿轮",
      "summary": "开屏再改：拳头换成一只人手，从右边伸过来、捏住齿轮，咯吱一下把它捏碎（加了齿轮被捏住的应力声，接着才是破碎声）；手的大小按齿轮直径配，张开到收紧的幅度只走一点点，动作走 ease-out，不再有生硬的直上直下。「你怎么看」删掉，收尾只留「自我突破」，居中对齐，下面一行还是「D己工作室」。齿轮和手都做了轻微位移与旋转，帧间不会跳。",
      "added": [],
      "changed": [
        "开屏：拳头换成人手，从右边伸过来捏碎齿轮（不是一拳打碎）",
        "开屏：手的大小按齿轮配比，捏合幅度小、缓动柔和，动作更顺",
        "收尾文字改成居中的「自我突破」，删掉「你怎么看」",
        "新增齿轮被捏住的应力声（210→620Hz 锯齿短音），随后才是破碎声"
      ],
      "balance": [],
      "removed": [
        "开屏的拳头",
        "「你怎么看」四个字"
      ]
    },
    {
      "v": "1.62",
      "date": "2026-11-21",
      "title": "开屏：齿轮与拳头",
      "summary": "按你说的改了：锤子撤掉，D己工作室也从开头删掉、挪到最后当签名。现在是齿轮在中间转（带低频转动声和咔哒），一只拳头从齿轮后面伸出来把它一拳打碎——低频闷响 + 多层金属高频 + 宽带噪声，比上一版碎得更彻底，碎片四散；碎完先浮现「自我突破，你怎么看？」，再浮现「D己工作室」，然后整屏淡出进菜单。点屏幕随时跳过；系统开了「减少动态效果」时直接过。",
      "added": [],
      "changed": [
        "开屏：锤子换成从齿轮后面伸出的拳头，一拳打碎齿轮",
        "开屏：破碎音效加厚（闷响 + 多层金属余音 + 宽带噪声）",
        "「D己工作室」从开头挪到最后，和「自我突破，你怎么看？」一起收尾"
      ],
      "balance": [],
      "removed": [
        "开屏的锤子"
      ]
    },
    {
      "v": "1.61",
      "date": "2026-11-21",
      "title": "开屏：齿轮与锤子",
      "summary": "开屏换成哥要的那一段：先浮出「D己工作室」，接着一个齿轮从中间放大、开始转（有低频转动声，每 0.17 秒一下金属咔哒），约 2.5 秒时锤子从右上砸下来——闪白、齿轮碎成十块金属片飞散，同时一记重击加碎裂声；碎完浮现一行「自我突破，你怎么看？」，四秒后整屏淡出进菜单。声音全部用 WebAudio 现场合成，不占包体；游戏里关了音效就不出声。点屏幕随时跳过。",
      "added": [
        "开屏动画：D己工作室 → 转动齿轮（带转动音）→ 锤子砸碎齿轮 → 「自我突破，你怎么看？」"
      ],
      "changed": [
        "开屏时长 1.0s → 4.0s（点一下仍可跳过；系统「减少动态效果」时 1.4s 直接过）"
      ],
      "balance": [],
      "removed": [
        "上一版的方块落地开屏"
      ]
    },
    {
      "v": "1.60",
      "date": "2026-11-21",
      "title": "开屏过场",
      "summary": "打开软件不再直接从菜单开始：先是一屏黑底，五块方块从上面落成一排（青、金、紫三色，跟方块材质一个调子），标题「合体债 / FUSION DEBT」跟着浮上来，约 1 秒后整屏淡出进菜单。点一下屏幕可以直接跳过。过场期间首页已经在底下排好版，淡出后不会跳一下；开了「减少动态效果」的系统设置就按静态显示。",
      "added": [
        "冷启动过场：方块落地 → 标题浮起 → 淡出进菜单（约 1 秒，可点击跳过）"
      ],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.59",
      "date": "2026-11-21",
      "title": "设置瘦身，排行榜上墙",
      "summary": "排行榜从棋盘左侧那一列挪到「返回」下面，宽度 88→112、字号跟着放大，不再跟棋盘抢位置（棋盘回到满宽）。分数一律用数字显示，不再出现「二千四百」这种写法。「更多」里的「版本与更新」整页删掉——网页包本来就是每次启动自动更新，不需要玩家点；入口留着只会让人以为要手动更。设置也瘦了一遍：流畅度（自动）、屏幕方向、当前方向、系统音量、最近错误、安装包（壳）这些要么是游戏自己算的、要么是诊断信息，全部写进本体，界面上不再出现；方向固定按自动旋转走（系统锁了也会自己转）。现在设置里只剩手感、开场动画、材质、音效、语言。",
      "added": [],
      "changed": [
        "排行榜挪到「返回」下方，加宽到 112px、字号放大；棋盘恢复满宽",
        "排行榜分数改用纯数字显示（不再有「1.2万」这类写法）",
        "设置精简：流畅度 / 屏幕方向 / 当前方向 / 系统音量 / 最近错误 / 安装包信息全部移除，改为游戏内部自动处理",
        "屏幕方向固定自动旋转（系统锁了也会自己转）",
        "「更多」里去掉「版本与更新」，网页包继续启动时自动更新"
      ],
      "balance": [],
      "removed": [
        "「版本与更新」页面（含「怎么更新」「复制这一版说明」入口）",
        "设置里的「流畅度（自动）」「屏幕方向」「系统音量」「最近错误」「安装包（壳）」"
      ]
    },
    {
      "v": "1.58",
      "date": "2026-11-21",
      "title": "排行榜挪到左边",
      "summary": "打 AI 和联机对战时，比分不再占用顶上那条横条，也不在底下单开一栏，而是收到棋盘左侧的一列窄排行榜里：名次、名字、分数、等级和消行，按分数实时换位。打 AI 只在「你 / AI」之间排；局域网、蓝牙的 2 人和 3~4 人按名册逐人排，出局那行整行变暗。排行榜只换文本、没有任何过渡动画，棋盘会自动让出左边这一列，不会压到方块。",
      "added": [
        "多人（局域网/蓝牙 2~4 人）：左侧排行榜按名册逐人排名，出局变暗"
      ],
      "changed": [
        "排行榜挪到棋盘左侧（窄列），打 AI 与联机共用同一套",
        "打 AI / 多人：顶部那条比分条收掉，分数只看排行榜",
        "棋盘宽度：多出排行榜那一列时自动让位，不压棋盘"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.57",
      "date": "2026-11-21",
      "title": "打 AI 只看榜，不看动画",
      "summary": "打 AI 不再放开局动画（原来那句「来！咱俩练练！」会把整个循环停一两秒，AI 也跟着不动），一进来就直接开打。右边那块 96×96 的 AI 小盘也撤了——它每帧重绘，还挡着排行榜的位置；换成一张两行的实时排行榜：名次、谁、分数、等级和消行，按分数实时换位。排行榜只换文本、不加过渡动画，AI 的模拟一点没动（实测 40 秒 AI 从 3 消打到 13 消、16200 分）。",
      "added": [
        "打 AI：右侧改成实时排行榜（名次 / 分数 / 等级 / 消行），按分数实时换位"
      ],
      "changed": [
        "打 AI：去掉开局动画，进局立刻开打，不让动画停住循环",
        "打 AI：撤掉每帧重绘的 96×96 小盘，排行榜只在文字变化时重画"
      ],
      "balance": [],
      "removed": [
        "打 AI 的 AI 小盘（改由排行榜显示）"
      ]
    },
    {
      "v": "1.56",
      "date": "2026-11-21",
      "title": "打 AI 不再被网卡住",
      "summary": "打 AI 打到一半画面冻住、右边小盘不再刷新，真凶在渲染：右侧面板末尾残留着一段旧版结算面板的代码，还在引用早就删掉的 bigColor / line3 / foot，于是每画一帧就抛一次 ReferenceError——面板后面的 AI 小盘、倒计时全被跳过，严重时把主循环整个停掉，看着就像 AI 罢工。这段死代码已删（同样悬空的 drawGameOver 调用也删了）。顺带把两件跟「网络」有关的事办了：ai.js 万一没加载上，开局当场补一次并明说，不再静默把 AI 判成「已死」；AI 先被顶死或被堵死立刻出结算。更新包装入前也改成按包内清单逐个校验文件，缺一个就整包不装。",
      "added": [],
      "changed": [
        "渲染：删掉右侧面板里残留的旧代码——它每帧抛一次 ReferenceError，AI 小盘因此不刷新，严重时主循环停住",
        "打 AI：模块缺失时自动补加载，补不上会明确提示，不再判「已死」",
        "打 AI：AI 先死立刻结算（以前会一直挂着让你一个人打）",
        "更新包：安装前按包内 web.json 的文件清单逐个校验"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.55",
      "date": "2026-11-20",
      "title": "音量别缩两次",
      "summary": "上一版把系统音量映射成游戏音量，结果缩了两次——手机 50% × 游戏 50% = 25%，比设的还小。现在游戏音量固定 1，只跟系统走；系统音量那行只显示真实值。顺带把多人页两句「没人开就替你开一个 N 人的」改成「让你选开几人的」（上一版已经改成先问人数了，文字没跟上）。",
      "added": [],
      "changed": [
        "音量：游戏不再按系统音量二次缩放，只跟随系统",
        "多人页提示：没人开房时会先问你开几人"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.54",
      "date": "2026-11-20",
      "title": "更多页瘦身",
      "summary": "「更多」从 7 行收成 4 行：存档那三行（分组标题 + 当前存档 + 存档管理按钮）并成一个「存档管理」按钮，当前存档摘要写进它的 tag；删掉两个空行；页面底部那行脚注（又写一遍版本号）也删了。",
      "added": [],
      "changed": [
        "更多页：7 行 → 4 行，当前存档摘要并进「存档管理」按钮"
      ],
      "balance": [],
      "removed": [
        "更多页的分组标题、空行和底部脚注"
      ]
    },
    {
      "v": "1.53",
      "date": "2026-11-20",
      "title": "人数挪进开房时",
      "summary": "多人面板上那行「2 人 / 3 人 / 4 人」删了——它只对自己开房有用，客人永远用不到。现在改成「开房那一刻才问」：快速匹配没找到房间时，出来一张小卡「没人开房。开一间：[2 人][3 人][4 人]」，点一下就开。",
      "added": [
        "开房时机里选人数（2/3/4 一次点击）"
      ],
      "changed": [
        "多人面板：去掉常驻的人数选择，首屏少一行"
      ],
      "balance": [],
      "removed": [
        "多人面板的「人数 2/3/4」seg"
      ]
    },
    {
      "v": "1.52",
      "date": "2026-11-19",
      "title": "版本页只留这一版",
      "summary": "版本页的「更新记录」那 15 张卡片删了——没人往下翻，占地方还占包体。现在页面只显示这一版是什么（版本号、日期、标题），要更新就看「怎么更新」，「复制这一版说明」仍然带本次和上一版的正文；全量历史在仓库 CHANGELOG.md。顺带把「更新前先存档」那条红字改成只在安装包真的旧了时才出现。",
      "added": [],
      "changed": [
        "版本页：去掉更新记录列表，只显示当前版本",
        "「更新前先存档」只在安装包旧了时显示"
      ],
      "balance": [],
      "removed": [
        "版本页的更新记录卡片（15 条）"
      ]
    },
    {
      "v": "1.51",
      "date": "2026-11-19",
      "title": "帮助页收成速查",
      "summary": "「玩法说明」从 12 条压到 7 条：模式入口、经典玩法、分数、存档、联机、安装与更新、以及一句「细节看教程」。合体块、债、转场、方向块、怎么算死和重开这几条原来和教程逐句重复，删掉了——教程那 7 页带图，还更清楚。中英文两份一起改。",
      "added": [
        "玩法说明补上「安装与更新」一条"
      ],
      "changed": [
        "「玩法说明」12 条 → 7 条速查，过程讲解归到新手教程"
      ],
      "balance": [],
      "removed": [
        "帮助页里与教程重复的 5 条（合体块/债/转场/方向块/重开清档）"
      ]
    }
  ],
  logEn: [
    {
      "v": "4.3",
      "date": "2026-11-24",
      "title": "Studio mark v2",
      "summary": "The neon D is now upright (it used to inherit the gear's random rotation), drawn with the same straight-edge + semicircle geometry as the launcher icon; the wordmark is tightened.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "4.2",
      "date": "2026-11-24",
      "title": "Studio mark",
      "summary": "The boot splash now ends with the studio mark: after the gear is cut, a neon D draws itself stroke by stroke in the same spot (with a soft glow) with 己 inside, the tagline stays, and the wordmark comes letter by letter. The launcher icon is the same D己 mark. Shell now 2.2·65.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "4.1",
      "date": "2026-11-24",
      "title": "Thumb-friendly controls",
      "summary": "The keys are split to the two thumbs and sized for them: ← → bottom-left, a dedicated ↻ rotate key and ↓ bottom-right, both a thumb's height above the bottom edge and inset from the sides, in landscape and portrait alike. Hold is gone (button, C key and tutorial text).",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "4.0",
      "date": "2026-11-24",
      "title": "Thumb-friendly controls",
      "summary": "The movement keys are split to the two thumbs: ← → on the left, a dedicated ↻ rotate key and ↓ on the right; Hold is gone (button, C key and tutorial text). Keys are a size larger and sit a thumb's height above the bottom edge, in both landscape and portrait.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.9",
      "date": "2026-11-24",
      "title": "One button to find a match",
      "summary": "Multiplayer now has a single Quick match button: it looks for a LAN room and tries your paired Bluetooth phone at the same time; whichever connects first wins and the other is shut down. The manual address/room-code entry is gone, along with the separate network and Bluetooth buttons and their sub-options.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.8",
      "date": "2026-11-24",
      "title": "The AI keeps to your pace",
      "summary": "AI duel difficulty now follows you: every line you clear raises the AI one level (sharper, more willing to clear for survival), and its drop interval is capped by your own recent pace — never more than 5% faster, so it can never run away. All four tiers follow this rule; they differ only in how smart the AI is. The old 'level up every 30s' timer is gone.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.7",
      "date": "2026-11-24",
      "title": "The AI picks up the pace",
      "summary": "Why AI duels felt slow: the AI drop interval was hard-coded at 2s / 3s / 5s for Easy / Normal / Hard — harder meant slower, the opposite of what the UI promised. Now 1.7s / 1.15s / 0.78s, plus a new Hell tier at 0.42s; the interval shrinks 10% every 30s down to 1.4 / 0.8 / 0.4 / 0.22s, and each level-up toast reports the current seconds-per-piece. Also includes the 3.6 random-split splash.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.6",
      "date": "2026-11-24",
      "title": "One gear, cut at a random angle",
      "summary": "The boot screen now has a single gear: each launch it is rotated by a random angle (-50 to +50) and cut at a random height (44-56%) before the halves fly apart. Also fixed two traps: the random values were never applied (an out-of-scope reference swallowed by try/catch), and clipping the static shell made the halves look like two overlapping gears (now clipped on the gear itself).",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.5",
      "date": "2026-11-23",
      "title": "Blade-qi slash",
      "summary": "Splash: one blade-qi slash splits the gear in two; no debris, no flash; sword-qi whoosh + metallic shing synthesized in code.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.4",
      "date": "2026-11-23",
      "title": "Splash: blade-qi slash",
      "summary": "The splash gear is now cut by a sweeping blade: a diagonal light slash splits it into two halves, with a sword-qi whoosh and a metallic shing; then the two lines appear.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.3",
      "date": "2026-11-23",
      "title": "Splash gear looks like a gear",
      "summary": "Removed the fake markers inside the splash gear (a brightened tooth, a blue dot, a black keyway). It now has a proper web with three lightening holes 120 degrees apart, so the spin reads naturally.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.2",
      "date": "2026-11-22",
      "title": "No more black screen in matches",
      "summary": "The pre-match countdown killed the render loop (paused=true made frame() return before the countdown could ever finish), so the board stayed black and ignored input. The loop now keeps running during the countdown; a check gate guards it.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.1",
      "date": "2026-11-22",
      "title": "Bluetooth retries by itself",
      "summary": "Bluetooth gave up after 3 quick retries; now it retries 8 times and restarts a hung connect after 12s, with clearer host/guest wording and the last-used device first in the paired list.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "3.0",
      "date": "2026-11-22",
      "title": "Multiplayer starts again",
      "summary": "Fixed a ReferenceError (matchTier) that silently killed every multiplayer start; multiplayer is now two plain buttons: same Wi-Fi, Bluetooth.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.9",
      "date": "2026-11-22",
      "title": "Centred in both orientations",
      "summary": "Every screen now adapts to orientation: in landscape the content column widens to 780px with 480px buttons, modal cards cap at 88vh and scroll; in portrait the side sheet takes at most 92vw; on short screens (height <= 560px, e.g. a landscape tablet) buttons shrink to 46px and headings/gaps tighten so nothing overflows. Everything stays centred both ways, scrolling only when content is longer than the screen.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.8",
      "date": "2026-11-22",
      "title": "Sources ordered by what actually works",
      "summary": "Measured on the tablet: raw.githubusercontent gets reset (23s to fail) while ghproxy.net works (2.5-13s). The source order is now mirror-first with raw as a fallback, so the shell no longer waits 20s on a blocked host; the web side's result timeout also went from 12s to 30s so a slow mirror no longer shows as a timeout.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.7",
      "date": "2026-11-22",
      "title": "Updates stop timing out",
      "summary": "The real reason updates failed while online: the ghproxy.net mirror takes 17-29s cold, but the shell's timeouts were 3s connect / 6s read, so every source timed out (and gh-proxy returns 403 outright). Fixes: shell timeouts raised to 8s connect / 20s read; the default source is now raw.githubusercontent directly (0.5s measured here) with ghproxy.net as fallback and the 403 gh-proxy dropped; the APK link also points at the direct URL. Shell is 2.1 (versionCode 64) — install it once and updates work again.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.6",
      "date": "2026-11-22",
      "title": "Default mirror is ghproxy.net now",
      "summary": "gh-proxy.com has been returning 403 site-wide since this morning, which broke both the update check and the APK link. The default update source and APK download URL now point at ghproxy.net, with gh-proxy kept as a second fallback.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.5",
      "date": "2026-11-22",
      "title": "Connection retries, updates stop interrupting",
      "summary": "Two real problems fixed: (1) a failed Bluetooth connect now retries three times (0.9s apart) and the message says what to check — did the other phone tap 'I host', are both paired; the host side explains how to get the other phone to connect. (2) 'I tapped Start and got thrown back to the menu' was the auto-updater: an update landed mid-connection and the updater restarted the WebView. It now checks whether you are busy — in a game, in the lobby, or connecting — and defers the restart until you are back at the menu, with a toast.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.4",
      "date": "2026-11-22",
      "title": "Start as soon as connected",
      "summary": "After connecting you no longer have to wait for someone to tap Start: once the room is full and versions match, the host starts the match automatically after 2.5 seconds (tap Start to go sooner, the button says so). If players are missing or bundles differ it cancels. Guests drop into the board a couple of seconds later, and the hint says so.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.3",
      "date": "2026-11-22",
      "title": "Bluetooth folded into quick match",
      "summary": "The multiplayer screen now has a single Quick match button: it looks for a LAN room first, then falls back to Bluetooth (if a phone is paired it offers 'connect to whom / host here'), and only then asks how many players to host. The old separate Bluetooth and manual-address entries are gone; manual address and 'host a Wi-Fi room instead' live inside that fallback sheet.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.2",
      "date": "2026-11-22",
      "title": "AI keeps playing: revives and ramps up",
      "summary": "An AI duel no longer ends when the AI tops out: it swaps in a fresh board, keeps its accumulated score, and the match goes on. Difficulty steps up every 45s — sharper choices, faster drops (3s down to 0.7s), and a willingness to clear singles to survive; when the stack gets high it plays safe first. The AI row on the left shows the current difficulty level and how many boards it has gone through.",
      "added": [
        "AI duel: when the AI tops out it gets a fresh board and keeps its score, so a match can run indefinitely",
        "AI duel: difficulty rises every 45s (sharper / faster / more willing to clear for survival)",
        "Leaderboard: the AI row shows difficulty level and board count"
      ],
      "changed": [
        "AI duel only settles when you die — the AI dying no longer ends the match"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.1",
      "date": "2026-11-22",
      "title": "The launch gear actually spins now",
      "summary": "The gear looked static: one turn every 2.2s on a ten-tooth gear is barely visible, and the scale-in animation was fighting the spin for the same transform. Spin is now 1.1s per turn, the scale-in only animates opacity, and a bright tooth plus a keyway give it something to read against. The crack-and-shatter sequence is unchanged.",
      "added": [],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "2.0",
      "date": "2026-11-22",
      "title": "Version numbering rule",
      "summary": "From this build on the version is always two parts: 1.1 … 1.9 → 2.0 → 2.1 …, never 1.10. Game and shell both move to 2.0 here (shell versionCode 63). Features are the same as the previous build: the gear cracks from its centre and blows apart, ending on 「自我突破」 and 「D己工作室」.",
      "added": [],
      "changed": [
        "Versioning: major.minor, minor only 0-9, 1.9 rolls to 2.0 (no 1.10)",
        "Game and shell both at 2.0; shell versionCode 63",
        "New bump.mjs bumps versions by that rule (--dry to preview, --shell to bump the APK too)",
        "check.mjs now enforces the version rule"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.64",
      "date": "2026-11-21",
      "title": "Launch: the gear cracks itself",
      "summary": "The hand is gone entirely (no hammer, no fist, no hand). The gear now shatters by itself: at about 2.2s the first seam opens at the centre, four more cracks crawl outward one after another (drawn segment by segment, not popped in), the core glows brighter and brighter, and at 2.62s it blows apart — flash, the gear vanishes, ten shards spin away. Sound follows the picture: one crisp metallic crack per seam, a rising 180→760Hz stress tone as it strains, then the shatter (thud + layered metal ring + wide noise). Cracks only animate stroke-dashoffset and shards only transform/opacity, so the motion stays smooth.",
      "added": [
        "Launch: the gear cracks from the centre and blows apart by itself (cracks crawl out, core glows)",
        "Launch: metallic crack ticks per seam, rising stress tone, then the shatter"
      ],
      "changed": [
        "Closing captions unchanged: centred 「自我突破」 with 「D己工作室」 below"
      ],
      "balance": [],
      "removed": [
        "The hand from the launch sequence (fist / human hand)"
      ]
    },
    {
      "v": "1.63",
      "date": "2026-11-21",
      "title": "Launch: a hand crushes the gear",
      "summary": "Another pass on the launch screen: the fist is now a human hand that reaches in from the right, grips the gear and crushes it with a metallic stress sound right before the shatter. The hand is sized against the gear, only a small squeeze on the way to the crack, eased with ease-out so nothing snaps between frames. The closing caption is now just「自我突破」, centred, with 「D己工作室」 still underneath.",
      "added": [],
      "changed": [
        "Launch: the fist became a hand that reaches in from the right and crushes the gear instead of punching it",
        "Launch: hand scaled to the gear diameter, small squeeze with soft easing",
        "Closing caption: centred 「自我突破」, 「你怎么看」 removed",
        "Added a gear-under-stress sound (210→620Hz saw) before the shatter"
      ],
      "balance": [],
      "removed": [
        "The fist in the launch sequence",
        "The words 「你怎么看」"
      ]
    },
    {
      "v": "1.62",
      "date": "2026-11-21",
      "title": "Launch: gear and fist",
      "summary": "Changed as you asked: the hammer is gone, and D己工作室 no longer opens the sequence — it moved to the end as a signature. The gear now spins in the middle (low mechanical hum with clicks) and a fist comes out from behind it and punches it apart — low thud, layered metallic ring and a wide noise burst, a much bigger shatter than before, with shards flying out. Then 「自我突破，你怎么看？」fades in, followed by 「D己工作室」, and the whole thing fades to the menu. Tap to skip; with reduce-motion it is a straight pass.",
      "added": [],
      "changed": [
        "Launch: the hammer is replaced by a fist reaching out from behind the gear and shattering it",
        "Launch: fatter shatter sound (thud + layered metallic ring + wide noise)",
        "D己工作室 moved from the opening to the closing caption"
      ],
      "balance": [],
      "removed": [
        "The hammer in the launch sequence"
      ]
    },
    {
      "v": "1.61",
      "date": "2026-11-21",
      "title": "Launch: gear and hammer",
      "summary": "The launch screen is now the sequence you asked for: D己工作室 fades in, a gear scales up and starts spinning (low mechanical hum, plus a metallic click every 0.17s), at about 2.5s a hammer swings down from the top right — flash, the gear shatters into ten flying metal shards with a heavy impact and crack, then the line 「自我突破，你怎么看？」fades in and the whole thing fades to the menu at four seconds. All sounds are synthesised live with WebAudio (nothing added to the bundle); if in-game sound is muted the splash stays silent. Tap anywhere to skip.",
      "added": [
        "Launch sequence: studio name → spinning gear with sound → hammer shatters it → the closing line"
      ],
      "changed": [
        "Launch splash 1.0s → 4.0s (tap to skip; with reduce-motion it's a 1.4s pass)"
      ],
      "balance": [],
      "removed": [
        "The previous falling-blocks splash"
      ]
    },
    {
      "v": "1.60",
      "date": "2026-11-21",
      "title": "Launch transition",
      "summary": "Opening the app no longer starts straight at the menu: a dark screen comes up, five blocks drop into a row (teal, gold, violet — same palette as the block materials), the FUSION DEBT title rises in, and about a second later the whole thing fades out into the menu. Tap anywhere to skip. The menu finishes laying out underneath, so nothing jumps when the splash fades; with the system reduce-motion setting the splash shows statically.",
      "added": [
        "Cold-start transition: blocks drop, title rises, then a fade into the menu (~1s, tap to skip)"
      ],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.59",
      "date": "2026-11-21",
      "title": "Leaner settings, leaderboard up top",
      "summary": "The leaderboard moved from a column beside the board to just below the Back button, wider (88 → 112px) with larger type, so the board gets its full width back. Scores are now plain digits instead of the Chinese numeral style. The whole Version & Updates page is gone from More — the web bundle already updates itself at launch, and the entry only made it look manual. Settings got trimmed too: smoothness (auto), screen orientation, current orientation, system volume, last error and APK info were all either computed by the game or diagnostics, so they now live inside the game and no longer appear. Orientation is always auto-rotate (it still rotates when the system is locked). What remains in Settings: feel, intro animation, block material, sound, language.",
      "added": [],
      "changed": [
        "Leaderboard moved just below the Back button, widened to 112px with larger type; the board is full width again",
        "Leaderboard scores use plain digits (no more \"1.2万\" style)",
        "Settings trimmed: smoothness / orientation / system volume / last error / APK info are gone, handled by the game itself",
        "Orientation is always auto-rotate (works even when the system is locked)",
        "More screen: Version & Updates removed; the web bundle keeps auto-updating at launch"
      ],
      "balance": [],
      "removed": [
        "The Version & Updates page (including 'How to update' and 'Copy release notes')",
        "Settings rows for smoothness (auto), orientation, system volume, last error and APK info"
      ]
    },
    {
      "v": "1.58",
      "date": "2026-11-21",
      "title": "Leaderboard on the left",
      "summary": "In AI duels and multiplayer matches the score no longer takes the top bar or a separate strip at the bottom — it now lives in a narrow leaderboard column on the left of the board: rank, name, score, level and lines, re-sorted live by score. AI duels rank just you and the AI; LAN and Bluetooth matches rank every player from the roster, with eliminated rows dimmed. The leaderboard only rewrites text, has no transition animations, and the board gives up that one column so nothing covers the blocks.",
      "added": [
        "Multiplayer (LAN/Bluetooth, 2-4 players): the left leaderboard ranks everyone from the roster and dims eliminated players"
      ],
      "changed": [
        "Leaderboard moved to a narrow column on the left, shared by AI duels and multiplayer",
        "AI duel / multiplayer: the top score bar is gone; the leaderboard is the only score display",
        "Board width: automatically yields the leaderboard column instead of covering the board"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.57",
      "date": "2026-11-21",
      "title": "Leaderboard instead of AI animations",
      "summary": "Duelling the AI no longer plays the mode intro (the splash froze the whole loop for a second or two, AI included) — the match starts immediately. The 96×96 AI mini-board is gone too: it repainted every frame and took the space the leaderboard now uses. In its place is a two-row live leaderboard — rank, name, score, level and lines — that re-sorts by score as you play. It only rewrites text when something changes, with no transition animations, and the AI simulation is untouched (measured: 3 clears to 13 clears and 16,200 points in 40 seconds).",
      "added": [
        "AI duel: live leaderboard on the right (rank / score / level / lines), re-sorted live"
      ],
      "changed": [
        "AI duel: no mode intro — the match starts at once instead of freezing the loop",
        "AI duel: the per-frame 96×96 mini-board is gone; the leaderboard only redraws on text change"
      ],
      "balance": [],
      "removed": [
        "The AI mini-board in duel mode (the leaderboard replaces it)"
      ]
    },
    {
      "v": "1.56",
      "date": "2026-11-21",
      "title": "AI duel off the network",
      "summary": "Mid-duel the picture froze and the little AI board stopped updating. The real culprit was rendering: the right-hand panel still ended with leftover code from an old results panel, referencing bigColor / line3 / foot that had long been deleted, so every single frame threw a ReferenceError. Everything drawn after the panel — including the AI mini-board and the countdown — was skipped, and in bad cases the whole main loop stopped, which looks exactly like the AI going on strike. That dead code is gone (plus a dangling drawGameOver call). Two network-adjacent things were also fixed: if ai.js is missing at match start the game fetches it once more and says so instead of silently marking the AI dead, and the match settles immediately when the AI dies first. Update packs are now validated file by file against the pack manifest before install.",
      "added": [],
      "changed": [
        "Rendering: removed leftover code in the right panel that threw a ReferenceError every frame, freezing the AI mini-board and sometimes the whole loop",
        "AI duel: re-loads the AI module once if missing, and says so instead of marking it dead",
        "AI duel: settles immediately when the AI dies first",
        "Updates: every file in the pack manifest is verified before install"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.55",
      "date": "2026-11-20",
      "title": "Stop scaling the volume twice",
      "summary": "The last version mapped the system volume onto the game volume, which attenuated twice — 50% on the phone times 50% in the game is 25%, quieter than set. Game volume is now fixed at 1 and simply follows the system; the system-volume line shows the real value. Also fixed two multiplayer hints that still claimed the game opens a room for you.",
      "added": [],
      "changed": [
        "Volume: no second scaling inside the game; it just follows the system",
        "Multiplayer hint: when nobody hosts, it asks how many players"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.54",
      "date": "2026-11-20",
      "title": "A leaner More screen",
      "summary": "More went from seven rows to four: the three save rows (group label, current save, Saves button) are now one button whose tag carries the current-save summary; two blank rows and the footer line (which repeated the version) are gone.",
      "added": [],
      "changed": [
        "More screen: seven rows to four; the current-save summary lives in the Saves button tag"
      ],
      "balance": [],
      "removed": [
        "The save group label, blank rows and footer line on the More screen"
      ]
    },
    {
      "v": "1.53",
      "date": "2026-11-20",
      "title": "Pick the player count when hosting",
      "summary": "The 2/3/4 player row is gone from the multiplayer panel — it only mattered when you host, and guests never used it. The choice now happens at the moment of hosting: when quick match finds no room, a small card asks \"Nobody is hosting. Open a room: [2][3][4]\" and one tap opens it.",
      "added": [
        "Choose the player count at hosting time (one tap for 2/3/4)"
      ],
      "changed": [
        "Multiplayer panel: the always-on player-count row is gone; one less row up front"
      ],
      "balance": [],
      "removed": [
        "The 2/3/4 player row in the multiplayer panel"
      ]
    },
    {
      "v": "1.52",
      "date": "2026-11-19",
      "title": "Version page shows just this build",
      "summary": "The changelog cards on the version page are gone — nobody scrolls that far, and they cost space and bytes. The page now shows only what this build is (version, date, title); How to update keeps the steps, Copy this version still carries this and the previous entry, and the full history lives in CHANGELOG.md.",
      "added": [],
      "changed": [
        "Version page: no changelog list, just the current build",
        "The save-first warning only appears when the APK is actually old"
      ],
      "balance": [],
      "removed": [
        "The changelog cards on the version page"
      ]
    },
    {
      "v": "1.51",
      "date": "2026-11-19",
      "title": "Help is a quick-reference now",
      "summary": "How to Play went from 12 blocks to 7: mode entry, classic rules, score, saves, multiplayer, install & update, and one line pointing at the tutorial. Fusion blocks, debt, rotation, arrow blocks and restart were word-for-word duplicates of the tutorial, which has pictures — those are gone. Both languages updated.",
      "added": [
        "An Install & update line in How to Play"
      ],
      "changed": [
        "How to Play: 12 blocks to 7; the walk-throughs live in the tutorial"
      ],
      "balance": [],
      "removed": [
        "Five help blocks that duplicated the tutorial (fusion blocks, debt, rotation, arrow blocks, restart)"
      ]
    }
  ],




  };
})();
