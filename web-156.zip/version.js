/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '1.52',
  code: 61,
  web: 156,
  date: '2026-11-19',
  title: '版本页只留这一版',
  titleEn: 'Version page shows just this build',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单/普通/困难。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard."
    }
  ],
  log: [
    {
      "v": "1.52",
      "date": "2026-11-19",
      "title": "版本页只留这一版",
      "summary": "版本页的「更新记录」那 15 张卡片删了——没人往下翻，占地方还占包体。现在页面只显示这一版是什么（版本号、日期、标题），要更新就看「怎么更新」，「复制这一版说明」仍然带本次和上一版的正文；全量历史在仓库 CHANGELOG.md。顺带把「更新前先存档」那条红字改成只在安装包真的旧了时才出现。",
      "added": [],
      "changed": [
        "版本页：去掉更新记录列表，只显示当前版本",
        "「更新前先存档」只在安装包旧了时显示"
      ],
      "balance": [],
      "removed": [
        "版本页的更新记录卡片（15 条）"
      ]
    },
    {
      "v": "1.51",
      "date": "2026-11-19",
      "title": "帮助页收成速查",
      "summary": "「玩法说明」从 12 条压到 7 条：模式入口、经典玩法、分数、存档、联机、安装与更新、以及一句「细节看教程」。合体块、债、转场、方向块、怎么算死和重开这几条原来和教程逐句重复，删掉了——教程那 7 页带图，还更清楚。中英文两份一起改。",
      "added": [
        "玩法说明补上「安装与更新」一条"
      ],
      "changed": [
        "「玩法说明」12 条 → 7 条速查，过程讲解归到新手教程"
      ],
      "balance": [],
      "removed": [
        "帮助页里与教程重复的 5 条（合体块/债/转场/方向块/重开清档）"
      ]
    },
    {
      "v": "1.50",
      "date": "2026-11-19",
      "title": "语言只留两选",
      "summary": "语言从「简体中文 / English / 跟随系统」三选收成两选。第一次进来会把「跟随系统」按手机当前语言折成具体一种并存下来，之后不再随手机语言变——要换就点另一个。语言那组的说明也改成「英文覆盖全部界面、教程、帮助和更新记录」。",
      "added": [],
      "changed": [
        "设置 → 语言：删「跟随系统」，首次启动按手机语言定一次"
      ],
      "balance": [],
      "removed": [
        "语言「跟随系统」选项"
      ]
    },
    {
      "v": "1.49",
      "date": "2026-11-19",
      "title": "音量跟着手机走",
      "summary": "音量那三个选项（小/中/大）删了。现在跟着手机的系统媒体音量走：手机调到 40%，游戏就是 40%（最低给 35%，免得小到听不见）；静音就自动改用右上角文字提示。设置里那行只读「系统音量 7/15 · 游戏音量 47%」。没有新壳的旧安装包读不到系统音量，就维持满音量。",
      "added": [],
      "changed": [
        "设置 → 声音：删掉音量三档，改成跟随系统媒体音量（每 15 秒对一次）"
      ],
      "balance": [],
      "removed": [
        "音量「小 / 中 / 大」三个选项"
      ]
    },
    {
      "v": "1.48",
      "date": "2026-11-19",
      "title": "流畅度也交给自动",
      "summary": "帧率那 5 个选项删了，改成读设备算力（核心数/内存/GPU/屏幕/pixel 各占权重算出来的 0~100 分）和屏幕刷新率自己定上限：算力 ≥70 跟随屏幕（最多 120），45~69 封顶 60，更弱封顶 45。设置里只剩一行结果，比如「本机 60Hz · 跟随屏幕 · 算力 79」。排障时可以在网址后面加 ?fps=60 手动压一档。",
      "added": [],
      "changed": [
        "设置 → 游戏：帧率 5 个选项 → 一行自动结果「流畅度（自动）」"
      ],
      "balance": [],
      "removed": [
        "手动选帧率（30/60/90/120）"
      ]
    }
  ],
  logEn: [
    {
      "v": "1.52",
      "date": "2026-11-19",
      "title": "Version page shows just this build",
      "summary": "The changelog cards on the version page are gone — nobody scrolls that far, and they cost space and bytes. The page now shows only what this build is (version, date, title); How to update keeps the steps, Copy this version still carries this and the previous entry, and the full history lives in CHANGELOG.md.",
      "added": [],
      "changed": [
        "Version page: no changelog list, just the current build",
        "The save-first warning only appears when the APK is actually old"
      ],
      "balance": [],
      "removed": [
        "The changelog cards on the version page"
      ]
    },
    {
      "v": "1.51",
      "date": "2026-11-19",
      "title": "Help is a quick-reference now",
      "summary": "How to Play went from 12 blocks to 7: mode entry, classic rules, score, saves, multiplayer, install & update, and one line pointing at the tutorial. Fusion blocks, debt, rotation, arrow blocks and restart were word-for-word duplicates of the tutorial, which has pictures — those are gone. Both languages updated.",
      "added": [
        "An Install & update line in How to Play"
      ],
      "changed": [
        "How to Play: 12 blocks to 7; the walk-throughs live in the tutorial"
      ],
      "balance": [],
      "removed": [
        "Five help blocks that duplicated the tutorial (fusion blocks, debt, rotation, arrow blocks, restart)"
      ]
    },
    {
      "v": "1.50",
      "date": "2026-11-19",
      "title": "Only two languages",
      "summary": "The language choice went from three options (Simplified Chinese / English / Follow system) to two. On the first run after updating, Follow system is resolved once from the phone language and saved, so the game stops following later system changes — tap the other one to switch. The hint now says English covers every screen, the tutorial, help and the changelog.",
      "added": [],
      "changed": [
        "Settings → Language: Follow system removed; the first launch picks one based on the phone"
      ],
      "balance": [],
      "removed": [
        "The Follow system language option"
      ]
    },
    {
      "v": "1.49",
      "date": "2026-11-19",
      "title": "Volume follows the phone",
      "summary": "The three volume choices (Low / Medium / High) are gone. Volume now follows the system media volume: 40% on the phone means 40% in the game (with a 35% floor so it never becomes inaudible), and muting the phone switches to corner text hints. Settings shows a read-only line such as \"System volume 7/15 · game volume 47%\". Older shells without the audio bridge keep full volume.",
      "added": [],
      "changed": [
        "Settings → Sound: the three volume levels became a system-volume follower (re-checked every 15 s)"
      ],
      "balance": [],
      "removed": [
        "The Low / Medium / High volume choices"
      ]
    },
    {
      "v": "1.48",
      "date": "2026-11-19",
      "title": "Frame rate is automatic too",
      "summary": "The five frame-rate buttons are gone. The cap is now derived from a device score (cores, memory, GPU, screen, pixels) and the display refresh rate: score 70+ follows the screen (up to 120), 45-69 caps at 60, weaker caps at 45. Settings shows one result line such as \"60Hz screen · follows the screen · score 79\". For troubleshooting you can still add ?fps=60 to the URL.",
      "added": [],
      "changed": [
        "Settings → Game: five frame-rate choices became one automatic result line"
      ],
      "balance": [],
      "removed": [
        "Manual frame-rate selection (30/60/90/120)"
      ]
    }
  ],




  };
})();
