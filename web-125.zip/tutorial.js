/* tutorial.js —— 新手教程（分页，独立于游戏画面）
 *
 * 用法：
 *   Tutorial.open({ onClose: function(reason){} })
 * 首次玩单人时由 start.html 自动打开；菜单里也能随时打开。
 * 看完/跳过会写 localStorage 的 tetris.tutorialDone，之后不再自动弹。
 */
(function () {
  'use strict';

  const FONT = 'system-ui,-apple-system,"Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif';
  const COLORS = (window.TetrisEngine && window.TetrisEngine.COLORS) || {
    I: '#3ee0c6', O: '#ffc857', T: '#b07cff', S: '#5bd75b',
    Z: '#ff5c6c', J: '#4f8cff', L: '#ff9f43', ARROW: '#f2f5ff'
  };

  const CSS = `
  #tut{
    position:fixed;inset:0;z-index:70;display:none;align-items:center;justify-content:center;
    padding:calc(env(safe-area-inset-top) + 12px) 12px calc(env(safe-area-inset-bottom) + 12px);
    background:rgba(4,5,8,.82);backdrop-filter:blur(6px);
    font-family:${FONT};color:#e9edf6;overflow:hidden;
  }
  #tut.on{display:flex}
  .tut-card{
    width:100%;max-width:440px;max-height:calc(100% - 6px);overflow-y:auto;scrollbar-width:none;
    background:#12141b;border:1px solid #232838;border-radius:18px;padding:16px 16px 14px;
    display:flex;flex-direction:column;gap:10px;box-shadow:0 30px 90px -30px #000;
  }
  .tut-card::-webkit-scrollbar{display:none}
  .tut-top{display:flex;align-items:center;justify-content:space-between;gap:10px}
  .tut-step{font-size:10px;letter-spacing:.2em;color:#5b6479}
  .tut-skip{border:0;background:transparent;color:#79839a;font:inherit;font-size:12px;cursor:pointer;padding:6px}
  .tut-card h3{margin:0;font-size:18px;line-height:1.35;letter-spacing:.02em}
  #tutCanvas{width:100%;height:auto;display:block;border-radius:12px;background:#0a0c12;border:1px solid #232838}
  .tut-body{font-size:13px;line-height:1.7;color:#c6cdda}
  .tut-body p{margin:0 0 7px}
  .tut-body p:last-child{margin-bottom:0}
  .tut-body b{color:#ffd479;font-weight:600}
  .tut-body i{color:#ff8b96;font-style:normal}
  .tut-dots{display:flex;gap:5px;justify-content:center;padding:2px 0}
  .tut-dot{width:6px;height:6px;border-radius:50%;background:#2a3040}
  .tut-dot.on{background:#3ee0c6;box-shadow:0 0 8px rgba(62,224,198,.6)}
  .tut-btns{display:grid;grid-template-columns:1fr 1.25fr;gap:8px}
  .tut-btns button{
    height:48px;border-radius:12px;border:1px solid #232838;background:#171a23;color:#e9edf6;
    font:inherit;font-size:14px;font-weight:600;cursor:pointer;
  }
  .tut-btns button:disabled{opacity:.28;pointer-events:none}
  .tut-btns button.primary{border-color:rgba(62,224,198,.42);color:#c9fff6;
    background:linear-gradient(180deg,rgba(62,224,198,.15),rgba(62,224,198,.04))}
  `;

  let root = null, canvas = null, ctx = null, built = false;
  let index = 0;
  let onClose = null;
  let keyHandler = null;
  let closedByUser = false;

  /* ---------------- 画小图 ---------------- */

  const W = 520, H = 300;
  const BX = 150, BY = 40, CELL = 22;
  const BOARD = CELL * 10;

  function rr(x, y, w, h, r) {
    ctx.beginPath();
    if (ctx.roundRect) { ctx.roundRect(x, y, w, h, r); return; }
    const rad = Math.min(r, w / 2, h / 2);
    ctx.moveTo(x + rad, y);
    ctx.arcTo(x + w, y, x + w, y + h, rad);
    ctx.arcTo(x + w, y + h, x, y + h, rad);
    ctx.arcTo(x, y + h, x, y, rad);
    ctx.arcTo(x, y, x + w, y, rad);
    ctx.closePath();
  }

  function base() {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#0a0c12';
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = 'rgba(255,255,255,.05)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 10; i++) {
      const p = BX + i * CELL;
      ctx.beginPath(); ctx.moveTo(p + 0.5, BY); ctx.lineTo(p + 0.5, BY + BOARD); ctx.stroke();
      const q = BY + i * CELL;
      ctx.beginPath(); ctx.moveTo(BX, q + 0.5); ctx.lineTo(BX + BOARD, q + 0.5); ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(255,255,255,.1)';
    ctx.strokeRect(BX + 0.5, BY + 0.5, BOARD - 1, BOARD - 1);
  }

  function block(x, y, color, alpha) {
    const px = BX + x * CELL, py = BY + y * CELL;
    ctx.save();
    if (alpha != null) ctx.globalAlpha = alpha;
    rr(px + 2, py + 2, CELL - 4, CELL - 4, 5);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,.22)';
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.restore();
  }

  function text(str, x, y, size, color, align) {
    ctx.save();
    ctx.fillStyle = color || '#e9edf6';
    ctx.font = '700 ' + (size || 14) + 'px ' + FONT;
    ctx.textAlign = align || 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(T(str), x, y);
    ctx.restore();
  }

  function arrow(x1, y1, x2, y2, color, width) {
    ctx.save();
    ctx.strokeStyle = color || 'rgba(255,255,255,.65)';
    ctx.fillStyle = color || 'rgba(255,255,255,.65)';
    ctx.lineWidth = width || 3;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    const a = Math.atan2(y2 - y1, x2 - x1);
    const L = 9;
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - L * Math.cos(a - 0.5), y2 - L * Math.sin(a - 0.5));
    ctx.lineTo(x2 - L * Math.cos(a + 0.5), y2 - L * Math.sin(a + 0.5));
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function row(y, from, to, color) {
    for (let x = from; x <= to; x++) block(x, y, color);
  }

  /* ---------------- 每一页 ---------------- */

  const PAGES = [
    {
      title: '方块会自己往下掉',
      draw: function () {
        base();
        row(9, 0, 8, COLORS.J);
        block(9, 7, COLORS.O);
        block(8, 7, COLORS.O);
        block(8, 8, COLORS.O);
        block(9, 8, COLORS.O);
        ctx.save();
        ctx.strokeStyle = 'rgba(255,255,255,.75)';
        ctx.lineWidth = 2;
        ctx.setLineDash([6, 5]);
        ctx.strokeRect(BX + 1, BY + 9 * CELL + 1, BOARD - 2, CELL - 2);
        ctx.restore();
        text('填满一行 → 消', BX + BOARD + 22, BY + 9 * CELL + 11, 15, '#ffd479');
        text('10 × 10', BX + BOARD + 22, BY + 50, 13, '#79839a');
      },
      body: '<p>10×10 的场地，七种方块从顶上往下掉。把一行填满就消掉：每行 <b>+600</b>，每完成一次消行再 <b>+600</b>。</p>'
        + '<p><i>不管它，它会一直往下堆，堆到顶这一局就结束。</i>不是游戏卡了，也不是重开——是得动它。</p>'
    },
    {
      title: '操作：先记住这几个',
      draw: function () {
        base();
        block(4, 3, COLORS.T); block(5, 3, COLORS.T); block(6, 3, COLORS.T); block(5, 4, COLORS.T);
        arrow(BX - 34, BY + 120, BX - 8, BY + 120, '#3ee0c6');
        arrow(BX + BOARD + 34, BY + 120, BX + BOARD + 8, BY + 120, '#3ee0c6');
        text('←', BX - 48, BY + 120, 22, '#3ee0c6');
        text('→', BX + BOARD + 50, BY + 120, 22, '#3ee0c6');
        text('↓ 软降', BX + BOARD / 2, BY + BOARD + 24, 12, '#79839a', 'center');
        text('↻ 转', BX + BOARD + 26, BY + 24, 12, '#79839a');
        text('空格 硬降', BX + BOARD + 26, BY + 44, 12, '#79839a');
      },
      body: '<p><b>键盘：</b>← → 移动 · ↓ 软降 · 空格 硬降 · ↑ 或 X 顺时针 · Z 逆时针 · C 暂存 · P 暂停。</p>'
        + '<p><b>手机：</b>用下面的方向键和「暂存」；↓ 连点两下硬降。</p>'
        + '<p><b>R 是重开，要按两次才生效</b>；暂停里的「重开」也要点两次。避免手滑把一局弄没。</p>'
    },
    {
      title: '普通以上：场地会自己转',
      draw: function () {
        base();
        row(8, 0, 5, COLORS.T);
        block(2, 6, COLORS.O); block(3, 6, COLORS.O); block(2, 7, COLORS.O);
        block(7, 4, COLORS.S); block(8, 4, COLORS.S); block(7, 5, COLORS.S);
        ctx.save();
        ctx.strokeStyle = 'rgba(255,255,255,.5)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(BX + BOARD / 2, BY + BOARD / 2, BOARD / 2 + 20, -Math.PI * 0.8, Math.PI * 0.55);
        ctx.stroke();
        const a = Math.PI * 0.55;
        const cx = BX + BOARD / 2 + Math.cos(a) * (BOARD / 2 + 20);
        const cy = BY + BOARD / 2 + Math.sin(a) * (BOARD / 2 + 20);
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx - 12, cy - 4);
        ctx.lineTo(cx - 4, cy - 14);
        ctx.closePath();
        ctx.fillStyle = 'rgba(255,255,255,.7)';
        ctx.fill();
        ctx.restore();
        text('15s', BX + BOARD + 24, BY + 68, 18, '#ffd479');
        text('落沙', BX + BOARD + 24, BY + 92, 12, '#79839a');
      },
      body: '<p><b>轻松档不转；普通和困难档，每 15 秒</b>，整个场地顺时针转 90°，'
        + '然后所有悬空的格子往下落（落沙）。</p>'
        + '<p>转之前 <b>1.5 秒</b>，边框闪白、右上角箭头转圈。看到这个不是重开，是转场来了。</p>'
        + '<p>底部红色的常驻块不跟着转，其他格子会停在它上面。不想让它转，就选「轻松」。</p>'
    },
    {
      title: '消一行，底下顶一块合体块',
      draw: function () {
        base();
        for (let x = 0; x < 10; x++) { block(x, 8, '#39415a'); block(x, 9, '#39415a'); }
        ctx.save();
        ctx.fillStyle = '#0a0c12';
        ctx.fillRect(BX + 4 * CELL, BY + 8 * CELL, 2 * CELL, CELL);
        ctx.fillRect(BX + 4 * CELL, BY + 9 * CELL, CELL, CELL);
        ctx.restore();
        ctx.strokeStyle = 'rgba(62,224,198,.55)';
        ctx.lineWidth = 2;
        ctx.strokeRect(BX + 0.5, BY + 8 * CELL + 0.5, BOARD - 1, 2 * CELL - 1);
        arrow(BX - 28, BY + 9 * CELL, BX - 6, BY + 9 * CELL, '#3ee0c6');
        arrow(BX + BOARD + 28, BY + 9 * CELL, BX + BOARD + 6, BY + 9 * CELL, '#3ee0c6');
        text('洞 1~2 个', BX + BOARD + 22, BY + 60, 12, '#79839a');
      },
      body: '<p>每次消行，<b>2.5 秒后</b>从底下顶上来一块合体块：占 2 行，只有 1~2 个洞，场上所有东西往上推 2 行。</p>'
        + '<p><i>最后 0.9 秒顶部两行会闪红；顶的时候最上面 2 行只要不是全空，就顶不上来——这一局直接结束。</i></p>'
        + '<p><b>所以单行消是净亏的：</b>消 1 行，顶 2 行。尽量一次消 2~4 行。</p>'
    },
    {
      title: '债：这一局欠的，下一局还',
      draw: function () {
        base();
        for (let y = 6; y <= 9; y++) {
          for (let x = 0; x < 10; x++) {
            if ((y === 7 && x === 3) || (y === 8 && x === 6) || (y === 9 && x === 1)) continue;
            block(x, y, '#4a2630');
          }
        }
        text('-500', BX + BOARD + 22, BY + 70, 24, '#ff5c6c');
        text('按债 1~4 行', BX + BOARD + 22, BY + 100, 12, '#79839a');
        text('消一行 -100', BX + BOARD + 22, BY + 120, 12, '#79839a');
      },
      body: '<p>死的时候，场上还活着的合体块每行算 <b>100</b>。下一局开局欠 <b>-N</b>，底部按债摆 <b>1~4 行</b>红色常驻块（欠多少摆多少）。</p>'
        + '<p>消掉常驻块一行 <b>-100</b>；消光还没清完，会按剩余债再补。债清零以后，接下来 <b>18 次消行</b>是奖励期：不顶合体块。</p>'
    },
    {
      title: '4000 分以后：方向块',
      draw: function () {
        base();
        for (let y = 0; y < 10; y++) {
          ctx.save();
          ctx.fillStyle = 'rgba(255,255,255,.08)';
          ctx.fillRect(BX + 4 * CELL, BY, CELL, BOARD);
          ctx.restore();
        }
        for (let y = 0; y <= 8; y++) block(4, y, '#39415a');
        block(4, 9, '#f2f5ff');
        text('↑', BX + 4 * CELL + CELL / 2, BY + 9 * CELL + CELL / 2 + 1, 18, '#08090d', 'center');
        text('↑ 清上面整列', BX + BOARD + 22, BY + 60, 13, '#ffd479');
        text('↓ 清下面整列', BX + BOARD + 22, BY + 82, 12, '#79839a');
        text('← / → 清左边 / 右边整行', BX + BOARD + 22, BY + 104, 12, '#79839a');
      },
      body: '<p>分数第一次到 <b>4000</b>，下一块必定是方向块；之后每 12 块里掺 1 块。它只有 1×1 大，不能转。</p>'
        + '<p>落地锁死时，<b>只抹箭头指的那一侧</b>：↑ 清它上面整列（含自己），↓ 下面整列，← 左边整行，→ 右边整行。</p>'
        + '<p>抹一条线 <b>+600</b>，算一次消行；反方向的东西一点不动。<b>只清堆积，不直接还债。</b></p>'
    },

    {
      title: '怎么算死，怎么重开',
      draw: function () {
        base();
        for (let y = 0; y < 10; y++) {
          ctx.save();
          ctx.fillStyle = 'rgba(5,6,10,.72)';
          ctx.fillRect(BX, BY + y * CELL, BOARD, CELL);
          ctx.restore();
        }
        const en = !!(window.TetrisI18n && window.TetrisI18n.lang === 'en');
        if (en) {
          text('债', BX + 18, BY + 9 * CELL + 2, 30, '#ff4d5e');
          text(T('本局') + ' 1200', BX + 118, BY + 7 * CELL + 10, 15, '#e9edf6');
          text('按 R 重开', BX + 118, BY + 9 * CELL + 2, 12, '#79839a');
          text('连点「债」5 下清档', BX + 118, BY + 9 * CELL + 24, 9, '#6b7488');
          return;
        }
        text('债', BX + 18, BY + 9 * CELL + 2, 38, '#ff4d5e');
        text(T('本局') + ' 1200', BX + 78, BY + 7 * CELL + 10, 15, '#e9edf6');
        text('按 R 重开', BX + 78, BY + 9 * CELL + 2, 12, '#79839a');
        text('连点「债」5 下清档', BX + 78, BY + 9 * CELL + 24, 10, '#3a4152');
      },
      body: '<p>只有两种死法：① 该顶合体块时，最上面 2 行有东西；② 新方块出生的格子被占。</p>'
        + '<p>结束后按 <b>R</b> 或点「重开」开下一局。想清掉下一局的账，<b>连点左下角「债」5 下</b>。</p>'
        + '<p><b>再强调一次：</b>方块会自己往下掉，不操作也会死；普通/困难档的转场不是重开。</p>'
    }
  ];

  const EN_PAGES = [
    {
      title: 'Blocks fall on their own',
      body: '<p>A 10×10 board. Seven shapes fall from the top. Fill a row to clear it: each row <b>+600</b>, plus <b>+600</b> for each clear.</p>'
        + '<p><i>Ignore it and the stack grows until it tops out. That is not a bug or a restart — you have to move it.</i></p>'
    },
    {
      title: 'Controls: learn these first',
      body: '<p><b>Keyboard:</b> ← → move · ↓ soft drop · Space hard drop · ↑ or X rotate · Z reverse · C hold · P pause.</p>'
        + '<p><b>Phone:</b> use the D-pad and Hold below; double-tap ↓ to hard drop.</p>'
        + '<p><b>R restarts and must be pressed twice.</b> The pause-menu Restart also needs two taps — it prevents accidental restarts.</p>'
    },
    {
      title: 'Normal / Hard: the field rotates itself',
      body: '<p><b>Easy never rotates.</b> On Normal and Hard, every <b>15 seconds</b> the whole field turns 90° clockwise, then loose cells fall (sand).</p>'
        + '<p><b>1.5s</b> before it happens the border flashes white and the corner arrow spins — that is a rotation warning, <b>not a restart</b>.</p>'
        + '<p>Red permanent rows do not rotate; other cells come to rest on them. If you do not want it, play on Easy.</p>'
    },
    {
      title: 'Clear a row, a fusion block pushes up',
      body: '<p>Every clear: <b>2.5s later</b> a fusion block rises from the bottom — 2 rows tall, 1–2 holes, and everything is pushed up 2 rows.</p>'
        + '<p><i>For the last 0.9s the top two rows flash red; if they are not empty when it lands, the game ends.</i></p>'
        + '<p><b>So a single-row clear is a net loss:</b> clear 1 row, get 2. Aim for 2–4 rows at once.</p>'
    },
    {
      title: 'Debt: what you owe carries to the next game',
      body: '<p>When you die, each fusion row still on the board counts <b>100</b>. The next game starts with that debt and <b>1–4</b> red permanent rows at the bottom.</p>'
        + '<p>Clearing a permanent row pays <b>-100</b>; if debt remains, rows refill. After debt hits 0 the next <b>18 clears</b> are a grace period with no fusion blocks.</p>'
    },
    {
      title: 'After 4000 points: arrow blocks',
      body: '<p>From <b>4000</b> points arrow blocks appear — 1 in 12 pieces. A 1×1 block that cannot rotate.</p>'
        + '<p>When it locks, <b>only the side the arrow points to</b> is wiped: ↑ the column above (including itself), ↓ below, ← the row to the left, → right.</p>'
        + '<p>Wiping gives <b>+600</b> and counts as a clear; the other side is untouched. <b>It only clears stack, not debt.</b></p>'
    },
    {
      title: 'How you die, how to restart',
      body: '<p>Only two ways to die: ① a fusion block must rise but the top two rows are occupied; ② a new piece\'s spawn cells are taken.</p>'
        + '<p>After game over press <b>R</b> or tap Restart. To wipe the next game\'s debt, <b>tap the red Debt number in the bottom-left 5 times</b>.</p>'
        + '<p><b>One more time:</b> pieces fall by themselves; doing nothing kills. A rotation is not a restart.</p>'
    }
  ];

  function T(s) {
    return window.TetrisI18n ? window.TetrisI18n.t(s) : s;
  }

  function pages() {
    if (!(window.TetrisI18n && window.TetrisI18n.lang === 'en')) return PAGES;
    return PAGES.map(function (p, i) {
      const e = EN_PAGES[i] || {};
      return { title: e.title || p.title, body: e.body || p.body, draw: p.draw };
    });
  }

  function build() {
    if (built) return;
    const style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);

    root = document.createElement('div');
    root.id = 'tut';
    root.innerHTML = ''
      + '<div class="tut-card">'
      + '  <div class="tut-top"><span class="tut-step" id="tutStep">1 / 8</span>'
      + '  <button class="tut-skip" data-tut="skip">跳过</button></div>'
      + '  <h3 id="tutTitle"></h3>'
      + '  <canvas id="tutCanvas" width="1040" height="600"></canvas>'
      + '  <div class="tut-body" id="tutBody"></div>'
      + '  <div class="tut-dots" id="tutDots"></div>'
      + '  <div class="tut-btns">'
      + '    <button data-tut="prev" id="tutPrev">上一步</button>'
      + '    <button class="primary" data-tut="next" id="tutNext">下一步</button>'
      + '  </div>'
      + '</div>';
    document.body.appendChild(root);

    canvas = root.querySelector('#tutCanvas');
    ctx = canvas.getContext('2d');
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    root.addEventListener('click', function (e) {
      const b = e.target.closest ? e.target.closest('[data-tut]') : null;
      if (!b) return;
      const act = b.dataset.tut;
      if (act === 'skip') close('skip');
      else if (act === 'prev') { if (index > 0) { index--; render(); } }
      else if (act === 'next') {
        if (index < pages().length - 1) { index++; render(); }
        else close('done');
      }
    });

    built = true;
  }

  function render() {
    if (!root) return;
    const L = pages();
    const p = L[index];
    root.querySelector('#tutStep').textContent = (index + 1) + ' / ' + L.length;
    root.querySelector('#tutTitle').textContent = p.title;
    root.querySelector('#tutBody').innerHTML = p.body;
    const skip = root.querySelector('.tut-skip');
    if (skip) skip.textContent = T('跳过');
    root.querySelector('#tutPrev').textContent = T('上一步');
    root.querySelector('#tutPrev').disabled = index === 0;
    root.querySelector('#tutNext').textContent = index === L.length - 1
      ? T(onClose ? '开始游戏' : '知道了')
      : T('下一步');

    const dots = root.querySelector('#tutDots');
    let html = '';
    for (let i = 0; i < L.length; i++) html += '<span class="tut-dot' + (i === index ? ' on' : '') + '"></span>';
    dots.innerHTML = html;

    ctx.save();
    ctx.clearRect(0, 0, W, H);
    ctx.restore();
    try { p.draw(); } catch (e) { /* 画坏了也不挡文字 */ }
  }

  function open(opts) {
    build();
    opts = opts || {};
    onClose = typeof opts.onClose === 'function' ? opts.onClose : null;
    index = 0;
    closedByUser = false;
    render();
    root.classList.add('on');

    if (keyHandler) window.removeEventListener('keydown', keyHandler, true);
    keyHandler = function (e) {
      if (!root.classList.contains('on')) return;
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close('skip'); return; }
      if (e.key === 'ArrowLeft') { e.preventDefault(); e.stopPropagation(); if (index > 0) { index--; render(); } return; }
      if (e.key === 'ArrowRight' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault(); e.stopPropagation();
        if (index < pages().length - 1) { index++; render(); } else close('done');
      }
    };
    window.addEventListener('keydown', keyHandler, true);
  }

  function close(reason) {
    if (!root || !root.classList.contains('on')) return;
    root.classList.remove('on');
    if (keyHandler) { window.removeEventListener('keydown', keyHandler, true); keyHandler = null; }
    try { localStorage.setItem('tetris.tutorialDone', '1'); } catch (e) {}
    const cb = onClose;
    onClose = null;
    closedByUser = true;
    if (cb) cb(reason || 'close');
  }

  window.Tutorial = {
    open: open,
    close: close,
    isOpen: function () { return !!(root && root.classList.contains('on')); },
    done: function () {
      try { return localStorage.getItem('tetris.tutorialDone') === '1'; } catch (e) { return false; }
    }
  };
})();
