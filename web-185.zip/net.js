/* net.js —— 联机客户端：协议一层，管道两套（Wi‑Fi 轮询 / 蓝牙 RFCOMM）
 *
 * 两个传输层只做一件事：把消息送到对面、把对面的消息收回来。
 * 「到齐进大厅、房主定玩法、开局时刻、版本指纹」这些规则只写在 Proto 里一份，
 * 以后加「再来一局」「断线重连」不用 Wi‑Fi 和蓝牙各改一遍。
 *
 * 用法（对外没变）：
 *   const s = await TetrisNet.join({base, room, name, onReady, onLobby, onPeer, onMessage, onStatus, onError});
 *   const b = TetrisNet.bt({host, mac, name, onReady, ...});
 *   s.send({t:'state', score, debt, clears});   s.go(rules, mode);   s.leave();
 */
(function () {
  'use strict';

  const POLL_MS = 250;
  const RECONNECT_MS = 8000;
  /* 联机协议的「网页包版本」。APK 不带它——协议只在 JS 里演进，
     这样联机永远不需要装新 APK，靠网页包自动同步就能对齐。
     4 = 多座位（2/3/4 人、名册、房主手动开局、昵称）。 */
  const PROTO = 4;

  function myWeb() {
    return (window.TetrisVersion && window.TetrisVersion.web) || 0;
  }
  function myApk() {
    try {
      if (window.TetrisHost && typeof window.TetrisHost.apkInfo === 'function') {
        return JSON.parse(window.TetrisHost.apkInfo()).versionCode || 0;
      }
    } catch (e) {}
    return 0;
  }

  /** 我自己的版本指纹，用来和对面比（顺带报难度档，让对面能跟）。 */
  function myStamp(name, tier) {
    return { t: 'ready', web: myWeb(), apk: myApk(), proto: PROTO, name: name || '你', tier: tier || '' };
  }

  function normalizeBase(input) {
    let s = String(input || '').trim();
    if (!s) return '';
    if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
    s = s.replace(/\/+$/, '');
    try {
      const u = new URL(s);
      if (!u.port) u.port = '8788';
      return u.protocol + '//' + u.host;
    } catch (e) {
      return s;
    }
  }

  const REQ_MS = 6000;      // 单个 HTTP 请求最多等这么久，别让界面一直卡在「连接中」
  function EN() { return !!(window.TetrisI18n && window.TetrisI18n.lang === 'en'); }
  function S(zh, en) { return EN() ? en : zh; }

  async function timedFetch(url, opt) {
    if (typeof AbortController !== 'function') return fetch(url, opt);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), REQ_MS);
    try {
      return await fetch(url, Object.assign({}, opt, { signal: ctrl.signal }));
    } catch (e) {
      if (e && (e.name === 'AbortError' || /aborted/i.test(String(e.message)))) {
        const en = !!(window.TetrisI18n && window.TetrisI18n.lang === 'en');
        throw new Error(en ? 'Host did not respond (' + (REQ_MS / 1000) + 's timeout)' : '房主没响应（' + (REQ_MS / 1000) + ' 秒超时）');
      }
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  /* file:// 页面 fetch 不到局域网（Chromium 限制），装了壳就走壳里的 HTTP。
     返回仍是 JSON 对象；失败抛 Error，和 fetch 路径的行为保持一致。 */
  function lanBridge() {
    var h = window.TetrisHost;
    return (h && typeof h.lanPost === 'function' && typeof h.lanGet === 'function') ? h : null;
  }
  function viaBridge(url, body) {
    var h = lanBridge();
    var raw = (body == null) ? h.lanGet(url) : h.lanPost(url, JSON.stringify(body || {}));
    var r = null;
    try { r = JSON.parse(raw || '{}'); } catch (e) { r = null; }
    if (!r) throw new Error('房主返回读不出来');
    if (r.ok) {
      try { return JSON.parse(r.body || 'null'); } catch (e) { return null; }
    }
    var err = new Error(r.error || ('HTTP ' + (r.status || '?')));
    err.status = r.status;
    throw err;
  }

  async function postJSON(url, body) {
    if (lanBridge()) return viaBridge(url, body);
    const res = await timedFetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify(body || {}),
      cache: 'no-store',
      credentials: 'omit'
    });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const err = new Error((data && data.error) || ('HTTP ' + res.status));
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  async function getJSON(url) {
    if (lanBridge()) return viaBridge(url, null);
    const res = await timedFetch(url, { cache: 'no-store', credentials: 'omit' });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const err = new Error((data && data.error) || ('HTTP ' + res.status));
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  /* ================= 协议层（Wi‑Fi / 蓝牙共用） =================
     管道负责连接和收发；这里只做四件事：
       1. 记名册（每人 web/apk/分数/死活）   2. 到齐只进一次大厅
       3. 房主定玩法 → 所有人只开一次局       4. 开局后的消息转给游戏
     players 统一是对象数组：{seat,name,web,apk,ready,score,clears,dead,host}
     （老房主只发名字字符串，setRoster 会补成对象，2 人老协议照样能连）
  */
  function Proto(kind, opts) {
    opts = opts || {};
    this.kind = kind;                       // 'lan' | 'bt'
    this.rules = (opts.rules === 'classic') ? 'classic' : 'debt';
    this.mode = (opts.mode === 'lan_battle') ? 'lan_battle' : 'lan_parallel';
    this.name = String(opts.name || '玩家').slice(0, 8);
    this.tier = String(opts.tier || '');
    this.onReady = opts.onReady || function () {};
    this.onLobby = opts.onLobby || function () {};
    this.onPeer = opts.onPeer || function () {};
    this.onPlayers = opts.onPlayers || function () {};
    this.onMessage = opts.onMessage || function () {};
    this.onStatus = opts.onStatus || function () {};
    this.onError = opts.onError || function () {};
    this.seed = opts.seed || 0;
    this.startAt = 0;
    this.offset = 0;                        // 服务端时间 - 本机时间（蓝牙恒为 0）
    this.seats = Math.max(2, Math.min(4, Number(opts.seats) || 2));
    this.seat = -1;                         // 我的座位号（服务端给的）
    this.players = [];
    this.hasRoster = false;                 // 服务端有没有发名册（老房主没有）
    this.rosterSig = '';
    this.peer = { web: 0, apk: 0, proto: 0, name: '', tier: '' };
    this.started = false;                   // 已经开局（onReady 发过）
    this.lobbyFired = false;
    this.readyFired = false;
    this.closed = false;
  }

  Proto.prototype.status = function (text, kind) {
    try { this.onStatus(text, kind || ''); } catch (e) {}
  };

  /** 谁当房主：两条管道各有各的判定，默认不是。 */
  Proto.prototype.isHost = function () { return false; };

  /** 对外的「我」和「对面」用的名字。 */
  Proto.prototype.lobbyInfo = function () {
    return {
      host: this.isHost(), rules: this.rules, mode: this.mode,
      seats: this.seats, seat: this.seat,
      players: this.players, hasRoster: this.hasRoster
    };
  };

  /** 我自己的那条名册（没进名册时给个兜底）。 */
  Proto.prototype.me = function () {
    const list = this.players || [];
    if (this.seat >= 0) {
      const p = list.filter(x => x.seat === this.seat)[0];
      if (p) return p;
    }
    return { seat: this.seat, name: this.name, web: myWeb(), apk: myApk(), ready: true, score: 0, clears: 0, dead: false, host: this.isHost() };
  };

  /** 除我以外还活着的人（按座位排好）。 */
  Proto.prototype.aliveOthers = function () {
    return (this.players || [])
      .filter(p => p.seat !== this.seat && !p.dead)
      .sort((a, b) => a.seat - b.seat);
  };

  /** 干扰战打谁：座位往后轮一位（只有一个人时就是他）。 */
  Proto.prototype.battleTarget = function () {
    const others = this.aliveOthers();
    if (!others.length) return undefined;
    const mine = this.seat | 0;
    for (const p of others) if (p.seat > mine) return p.seat;
    return others[0].seat;
  };

  /** 服务端的名册变了就通知游戏（分数/死活/掉线都走这一条路）。
   *  老房主只发名字字符串：那种情况不算「有名册」，分数还是从点对点 state 来。 */
  Proto.prototype.setRoster = function (raw, seat) {
    if (typeof seat === 'number' && seat >= 0) this.seat = seat;
    if (!Array.isArray(raw) || !raw.length) return false;
    const legacy = (typeof raw[0] === 'string');
    const list = [];
    for (const it of raw) {
      if (!it) continue;
      if (typeof it === 'string') {
        list.push({ seat: list.length, name: it, web: 0, apk: 0, ready: false, score: 0, clears: 0, dead: false, host: false });
      } else {
        list.push({
          seat: it.seat | 0, name: String(it.name || ''), web: it.web | 0, apk: it.apk | 0,
          ready: !!it.ready, score: it.score | 0, clears: it.clears | 0, dead: !!it.dead, host: !!it.host
        });
      }
    }
    const sig = JSON.stringify(list);
    if (sig === this.rosterSig) return false;
    this.rosterSig = sig;
    this.players = list;
    this.hasRoster = !legacy;
    try { this.onPlayers(this.players, this.lobbyInfo()); } catch (e) {}
    return true;
  };

  /** 没有名册的管道（蓝牙 / 老房主）：把对面推来的分数记到对面那一条上。 */
  Proto.prototype.applyPeerState = function (m) {
    if (!m) return false;
    const others = (this.players || []).filter(p => p.seat !== this.seat);
    if (!others.length) return false;
    const p = others[0];
    let hit = false;
    if (m.t === 'state') {
      p.score = m.score | 0; p.clears = m.clears | 0; hit = true;
      if (m.dead) p.dead = true;
    } else if (m.t === 'dead') {
      p.score = m.score | 0; p.dead = true; hit = true;
    } else return false;
    if (!hit) return false;
    try { this.onPlayers(this.players, this.lobbyInfo()); } catch (e) {}
    return true;
  };

  Proto.prototype.setPeer = function (stamp) {
    if (!stamp) return;
    const web = stamp.web | 0, apk = stamp.apk | 0, proto = stamp.proto | 0;
    if (!web && !apk && !proto && !stamp.tier) return;
    this.peer = { web: web, apk: apk, proto: proto, name: stamp.name || '', tier: String(stamp.tier || '') };
    try { this.onPeer(this.peer); } catch (e) {}
  };

  Proto.prototype.fireLobby = function (info) {
    if (this.lobbyFired || this.closed) return;
    this.lobbyFired = true;
    try { this.onLobby(info || this.lobbyInfo()); } catch (e) {}
  };

  Proto.prototype.fireReady = function (info) {
    if (this.readyFired || this.closed) return;
    this.readyFired = true;
    this.started = true;
    try { this.onReady(info); } catch (e) {}
  };

  /** 房主选好玩法：管道负责把 go 送出去 / 定开局时刻。 */
  Proto.prototype.go = function (rules, mode) {
    if (this.closed) return;
    this.rules = rules === 'classic' ? 'classic' : 'debt';
    this.mode = (mode === 'lan_battle' && this.rules !== 'classic') ? 'lan_battle' : 'lan_parallel';
    return this._go(this.rules, this.mode);
  };

  Proto.prototype._go = function () {};
  Proto.prototype.send = function () {};
  Proto.prototype.leave = function () { this.closed = true; };

  /* ================= 管道一：Wi‑Fi 轮询（电脑/手机房主共用） ================= */
  function Session(opts) {
    Proto.call(this, 'lan', opts);
    this.base = normalizeBase(opts.base);
    this.room = String(opts.room || '').replace(/\D/g, '').slice(0, 4);
    this.seatsWanted = Math.max(2, Math.min(4, Number(opts.seats) || 2));
    this.playerId = '';
    this.token = '';
    this.hostId = '';
    this.seq = 0;
    this.gathered = false;                  // 服务端说「至少两个人都在了」
    this.allReady = false;                  // 每个人都报到过（房主才能开局）
    this.timer = 0;
    this.polling = false;
    this.reconnectingSince = 0;
  }
  Session.prototype = Object.create(Proto.prototype);
  Session.prototype.constructor = Session;

  Session.prototype.isHost = function () {
    return !!this.playerId && this.playerId === this.hostId;
  };

  Session.prototype.connect = async function () {
    if (!this.base) throw new Error(S('没有房主地址', 'No host address'));
    if (this.room.length !== 4) throw new Error(S('房间码要 4 位数字', 'Room code must be 4 digits'));
    const fresh = !this.playerId;
    this.status(S('连接房主…', 'Connecting to host…'), 'wait');
    const data = await postJSON(this.base + '/api/join', {
      room: this.room,
      name: this.name,
      rules: this.rules,
      seats: fresh ? this.seatsWanted : undefined,
      playerId: this.playerId || undefined,
      token: this.token || undefined
    });
    this.applyState(data);
    if (fresh) this.seq = data.seq || 0;
    if (!this.reconnectingSince) this.status(this.gathered ? S('已就绪', 'Ready') : S('等别人进来…', 'Waiting for more players…'), 'wait');
    this.offset = data.serverTime - Date.now();
    this.schedulePoll(0);
    try { this.send(myStamp(this.name, this.tier)); } catch (e) {}
    return this;
  };

  Session.prototype.applyState = function (data) {
    if (!data) return;
    if (data.playerId) this.playerId = data.playerId;
    if (data.token) this.token = data.token;
    if (typeof data.seed === 'number') this.seed = data.seed;
    if (data.startAt) this.startAt = data.startAt;
    if (typeof data.seats === 'number') this.seats = Math.max(2, Math.min(4, data.seats));
    this.setRoster(data.players, typeof data.seat === 'number' ? data.seat : -1);
    if (data.rules) this.rules = (data.rules === 'classic') ? 'classic' : 'debt';
    if (data.mode) this.mode = (data.mode === 'lan_battle') ? 'lan_battle' : 'lan_parallel';
    if (data.host) this.hostId = String(data.host);
    if (data.serverTime) this.offset = data.serverTime - Date.now();
    const wasGathered = this.gathered;
    this.gathered = !!data.ready;
    this.allReady = !!data.allReady;
    // 到齐了先开「选玩法」的房间；老房主（自己会定 startAt）就直接开局，不硬等大厅
    if (this.gathered && !this.startAt) {
      this.fireLobby({
        players: this.players,
        host: this.isHost(),
        rules: this.rules,
        mode: this.mode,
        seats: this.seats,
        seat: this.seat,
        hasRoster: this.hasRoster
      });
    }
    if (this.startAt && this.gathered) {
      this.fireReady({
        seed: this.seed,
        startAt: this.startAt,
        players: this.players,
        rules: this.rules,
        mode: this.mode,
        seats: this.seats,
        seat: this.seat,
        hasRoster: this.hasRoster,
        isHost: this.isHost(),
        serverTime: data.serverTime || Date.now()
      });
    }
    if (!wasGathered && this.gathered) {
      this.status(this.seats > 2
        ? S('人到齐了，准备开始', 'Players are here — get ready')
        : S('两人到齐，准备开始', 'Both players here — get ready'), 'ok');
      try { this.send(myStamp(this.name, this.tier)); } catch (e) {}   // 到齐后交换一次版本指纹
    }
  };

  /** 只有房主能定玩法；客人调了也不改自己的规则（服务端同样会拒）。 */
  Session.prototype.go = function (rules, mode) {
    if (!this.isHost() || this.started || this.closed) return;
    return Proto.prototype.go.call(this, rules, mode);
  };

  Session.prototype._go = function (rules, mode) {
    this.send({ t: 'go', rules: rules, mode: mode });
  };

  Session.prototype.schedulePoll = function (ms) {
    if (this.closed) return;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.poll(), ms == null ? POLL_MS : ms);
  };

  Session.prototype.poll = async function () {
    if (this.closed || this.polling) return;
    this.polling = true;
    try {
      const url = this.base + '/api/poll?playerId=' + encodeURIComponent(this.playerId)
        + '&token=' + encodeURIComponent(this.token) + '&since=' + this.seq;
      const data = await getJSON(url);
      this.applyState(data);
      if (data.messages && data.messages.length) {
        for (const m of data.messages) {
          if (m && m.t === 'ready') {        // 对面的版本指纹（协议 3 起才有这些字段）
            this.setPeer({ web: m.web, apk: m.apk, proto: m.proto, name: m.from || '', tier: m.tier });
            continue;
          }
          if (m && (m.t === 'state' || m.t === 'dead') && !this.hasRoster) this.applyPeerState(m);
          try { this.onMessage(m); } catch (e) {}
        }
      }
      if (typeof data.seq === 'number') this.seq = Math.max(this.seq, data.seq);
      if (this.reconnectingSince) {
        this.reconnectingSince = 0;
        this.status(S('重连成功', 'Reconnected'), 'ok');
      }
      this.polling = false;
      this.schedulePoll(POLL_MS);
    } catch (e) {
      this.polling = false;
      if (this.closed) return;
      if (!this.reconnectingSince) {
        this.reconnectingSince = Date.now();
        this.status(S('连接断了，重连中…', 'Disconnected — reconnecting…'), 'err');
      }
      if (Date.now() - this.reconnectingSince > RECONNECT_MS) {
        this.status(S('重连失败，退出联机', 'Reconnect failed — leaving the match'), 'err');
        try { this.onError(e); } catch (err) {}
        return;
      }
      this.connect().catch(() => {});
      this.schedulePoll(800);
    }
  };

  Session.prototype.send = function (msg) {
    if (this.closed || !this.playerId) return;
    postJSON(this.base + '/api/msg', {
      playerId: this.playerId,
      token: this.token,
      msg: msg
    }).catch(() => {});
  };

  Session.prototype.leave = function () {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    if (this.playerId) {
      postJSON(this.base + '/api/leave', { playerId: this.playerId, token: this.token }).catch(() => {});
    }
  };

  /* ================= 管道二：蓝牙 RFCOMM 直连 ================= */
  function BtSession(opts) {
    Proto.call(this, 'bt', opts);
    this.host = !!opts.host;
    this.mac = String(opts.mac || '');
    this.seed = opts.seed || ((Date.now() ^ Math.floor(Math.random() * 0xFFFFFFFF)) >>> 0);
    /* 蓝牙只有 2 人：名册就是「我 + 对手」两条，别人不存在。
       （3 人星型中继写好了但没真机验过，代码放在 archive/bt3，见 SPEC-BT3.md） */
    this.seats = 2;
    this.seat = 0;
    this.players = [
      { seat: 0, name: this.name, web: myWeb(), apk: myApk(), ready: true, score: 0, clears: 0, dead: false, host: this.host },
      { seat: 1, name: this.host ? '对手' : '房主', web: 0, apk: 0, ready: false, score: 0, clears: 0, dead: false, host: !this.host }
    ];
    this.timer = 0;
    this._helloSent = false;
    this._startIn = 2200;
    this._lastState = '';
  }
  BtSession.prototype = Object.create(Proto.prototype);
  BtSession.prototype.constructor = BtSession;

  BtSession.prototype.isHost = function () { return this.host; };

  /** 蓝牙只有对面一个人：改对面那一条名册，再通知游戏。 */
  BtSession.prototype._setOther = function (patch) {
    const p = this.players.filter(x => x.seat !== this.seat)[0];
    if (!p) return;
    for (const k in patch) if (patch[k] !== undefined) p[k] = patch[k];
    try { this.onPlayers(this.players, this.lobbyInfo()); } catch (e) {}
  };

  BtSession.prototype._bridge = function () {
    if (window.TetrisHost && typeof window.TetrisHost.btInfo === 'function') return window.TetrisHost;
    return null;
  };

  BtSession.prototype.start = function () {
    const h = this._bridge();
    if (!h) {
      this.status(S('这个安装包还不支持蓝牙，装一次 0.8.0', 'This build has no Bluetooth — install 0.8.0'), 'err');
      try { this.onError(new Error('no bt bridge')); } catch (e) {}
      return this;
    }
    let r;
    try {
      r = JSON.parse(this.host ? h.btHost() : h.btJoin(this.mac));
    } catch (e) {
      r = { ok: false, error: String(e) };
    }
    if (!r || !r.ok) {
      this.status((r && r.error) || S('蓝牙开不了', 'Bluetooth could not start'), 'err');
      try { this.onError(new Error((r && r.error) || 'bt start failed')); } catch (e) {}
      return this;
    }
    this.status(this.host ? S('蓝牙房主已开，等另一台手机连…', 'Bluetooth room open — waiting for the other phone…') : S('正在连蓝牙…', 'Connecting Bluetooth…'), 'wait');
    const self = this;
    this.timer = setTimeout(function () { self._poll(); }, 120);
    return this;
  };

  BtSession.prototype._sendRaw = function (obj) {
    const h = this._bridge();
    if (!h || typeof h.btSend !== 'function') return false;
    try {
      const r = JSON.parse(h.btSend(JSON.stringify(obj)));
      return !!(r && r.ok);
    } catch (e) { return false; }
  };

  BtSession.prototype.send = function (msg) {
    if (this.closed || !this.started) return;
    this._sendRaw(msg);
  };

  BtSession.prototype._poll = function () {
    if (this.closed) return;
    const h = this._bridge();
    if (!h) return;
    let info = null;
    try { info = JSON.parse(h.btInfo()); } catch (e) { info = null; }
    if (!info) {
      this._fail('读不到蓝牙状态');
      return;
    }
    if (info.state !== this._lastState) {
      this._lastState = info.state;
      if (info.state === 'connected') {
        this.status(S('蓝牙已连上', 'Bluetooth connected'), 'ok');
        if (this.host && !this._helloSent) {
          this._helloSent = true;
          this._sendRaw({
            t: 'btHello', seed: this.seed, rules: this.rules, mode: this.mode,
            startIn: this._startIn, name: this.name, tier: this.tier,
            web: myWeb(), apk: myApk(), proto: PROTO
          });
          this.status(S('等另一台手机准备…', 'Waiting for the other phone…'), 'wait');
        }
      } else if (info.state === 'connecting') {
        this.status(S('正在连蓝牙…', 'Connecting Bluetooth…'), 'wait');
      } else if (info.state === 'error') {
        this._retryBt(info.error || '蓝牙连接失败');
        return;
      } else if (info.state === 'closed' && this.started) {
        this.closed = true;
        clearTimeout(this.timer);
        try { this.onError(new Error('蓝牙断了')); } catch (e) {}
        return;
      }
    }

    let arr = [];
    try { arr = JSON.parse(h.btPoll()); } catch (e) { arr = []; }
    if (arr && arr.length) {
      for (let i = 0; i < arr.length; i++) {
        let m = null;
        try { m = JSON.parse(arr[i]); } catch (e) { m = null; }
        if (!m) continue;
        if (m.t === 'btHello' && !this.host) {
          if (m.seed) this.seed = m.seed >>> 0;
          this.rules = (m.rules === 'classic') ? 'classic' : 'debt';
          this.mode = (m.mode === 'lan_battle') ? 'lan_battle' : 'lan_parallel';
          this._startIn = Math.max(300, Math.min(5000, Number(m.startIn) || 2200));
          this.setPeer({ web: m.web, apk: m.apk, proto: m.proto, name: '房主', tier: m.tier });
          this._setOther({ name: String(m.name || '房主').slice(0, 8), web: m.web | 0, apk: m.apk | 0, ready: true });
          this._sendRaw({ t: 'btReady', web: myWeb(), apk: myApk(), proto: PROTO, tier: this.tier });
          this._enterLobby();
          continue;
        }
        if (m.t === 'btReady' && this.host) {
          this.setPeer({ web: m.web, apk: m.apk, proto: m.proto, name: '对手', tier: m.tier });
          this._setOther({ name: '对手', web: m.web | 0, apk: m.apk | 0, ready: true });
          this._enterLobby();
          continue;
        }
        if (m.t === 'go') {
          // 房主选完玩法才发 go：收到就按他选的规则开局
          this.rules = (m.rules === 'classic') ? 'classic' : 'debt';
          this.mode = (m.mode === 'lan_battle' && this.rules !== 'classic') ? 'lan_battle' : 'lan_parallel';
          this._startIn = Math.max(300, Math.min(5000, Number(m.startIn) || 2200));
          this._readyAt(Date.now() + this._startIn, false);
          continue;
        }
        if (this.started) {
          if (m.t === 'state' || m.t === 'dead') this.applyPeerState(m);
          try { this.onMessage(m); } catch (e) {}
        }
      }
    }
    const self = this;
    this.timer = setTimeout(function () { self._poll(); }, 100);
  };

  /** 蓝牙这边也是「连上先不开，等房主选玩法」。 */
  BtSession.prototype._enterLobby = function () {
    if (this.lobbyFired || this.closed) return;
    this.status(this.host ? S('对手已连上，选个玩法', 'Opponent connected — pick a mode') : S('等房主选玩法…', 'Waiting for the host to pick a mode'), 'ok');
    this.fireLobby(this.lobbyInfo());
  };

  /** 房主：把选好的玩法发过去，然后两边一起开局。 */
  BtSession.prototype.go = function (rules, mode) {
    if (!this.host || this.started || this.closed) return;
    return Proto.prototype.go.call(this, rules, mode);
  };

  BtSession.prototype._go = function (rules, mode) {
    this._sendRaw({ t: 'go', rules: rules, mode: mode, startIn: this._startIn });
    this._readyAt(Date.now() + this._startIn, true);
  };

  BtSession.prototype._readyAt = function (startAt, isHost) {
    if (this.readyFired || this.closed) return;
    this.offset = 0;
    this.startAt = startAt;
    this.status(S('准备好了，开局', 'Ready — starting'), 'ok');
    this.fireReady({
      seed: this.seed,
      startAt: startAt,
      rules: this.rules,
      mode: this.mode,
      isHost: isHost,
      players: this.players,
      serverTime: Date.now()
    });
  };

  BtSession.prototype._fail = function (msg) {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    const hint = this.host
      ? S('。让另一台手机在列表里点你的设备；两台都先系统配对、蓝牙打开。', '. Ask the other phone to tap your device; pair both phones with Bluetooth on.')
      : S('。对方是不是还没点「我是房主」？两台都配对了吗？', '. Did the other phone tap "I host"? Are both paired?');
    this.status((msg || S('蓝牙失败', 'Bluetooth failed')) + hint, 'err');
    try { this.onError(new Error(msg || 'bt error')); } catch (e) {}
  };

  /** 蓝牙连失败：先自己重试几次再报错（对方可能刚点「我是房主」，监听还没起来）。 */
  BtSession.prototype._retryBt = function (msg) {
    if (this.closed) return;
    const h = this._bridge();
    this._btTries = this._btTries || 0;
    if (!this.host && h && this._btTries < 3) {
      this._btTries += 1;
      this.status(S('连不上，正在重试 ' + this._btTries + '/3…', 'Retrying ' + this._btTries + '/3…'), 'wait');
      const self = this;
      setTimeout(function () {
        if (self.closed) return;
        try { h.btClose(); } catch (e) {}
        try { h.btJoin(self.mac); } catch (e) {}
        self._lastState = '';
        clearTimeout(self.timer);
        self.timer = setTimeout(function () { self._poll(); }, 400);
      }, 900);
      return;
    }
    this._fail(msg);
  };

  BtSession.prototype.leave = function () {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    if (this.started) this._sendRaw({ t: 'peerLeft' });
    const h = this._bridge();
    if (h && typeof h.btClose === 'function') {
      try { h.btClose(); } catch (e) {}
    }
  };

  /* ---------------- 附近的房间（UDP 广播） ----------------
     房主每秒喊一次「我在，房间码 xxxx」，想加入的那台只听着，把听到的攒成列表。
     省掉手输 IP；收不到就退回手动填地址。 */
  function beaconBridge() {
    return (window.TetrisHost && typeof window.TetrisHost.lanStart === 'function') ? window.TetrisHost : null;
  }

  window.TetrisNet = {
    normalizeBase: normalizeBase,
    proto: PROTO,
    discover: {
      supported: function () { return !!beaconBridge(); },
      // self 非空 = 我也开房，让别人找到我；空 = 只听
      start: function (self) {
        var h = beaconBridge();
        if (!h) return { ok: false, error: 'no bridge', supported: false };
        try {
          var r = JSON.parse(h.lanStart(self ? JSON.stringify(self) : ''));
          return r || { ok: false };
        } catch (e) { return { ok: false, error: String(e) }; }
      },
      poll: function () {
        var h = beaconBridge();
        if (!h) return [];
        try { return JSON.parse(h.lanPoll()) || []; } catch (e) { return []; }
      },
      stop: function () {
        var h = beaconBridge();
        if (!h) return;
        try { h.lanStop(); } catch (e) {}
      }
    },
    join: async function (opts) {
      const s = new Session(opts);
      await s.connect();
      return s;
    },
    /** 蓝牙：点对点，2 人。3 人星型那套写好了但没验，先放在 archive/bt3（见 SPEC-BT3.md）。 */
    bt: function (opts) {
      return new BtSession(opts).start();
    }
  };
})();
