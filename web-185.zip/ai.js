/* ai.js —— 打 AI 的落子决策
 *
 * 规则书 §17-B：枚举「旋转 × 列」，模拟落地，按
 *   -0.51×总高度 -0.36×洞数 -0.18×高低差 +0.76×消行数
 * 打分，避开顶部两行。难度只影响选点和落子速度。
 *
 * 浏览器挂 window.TetrisAI；Node 里 require 得到同一份。
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./engine.js'));
  else root.TetrisAI = factory(root.TetrisEngine);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (E) {
  'use strict';
  const C = E.CONST;

  function fullRows(board) {
    const rows = [];
    for (let y = 0; y < C.ROWS; y++) {
      let full = true;
      for (let x = 0; x < C.COLS; x++) if (!board[y][x]) { full = false; break; }
      if (full) rows.push(y);
    }
    return rows;
  }
  function copyBoard(b) { return b.map(function (r) { return r.slice(); }); }
  function clearRowsIn(board, rows) {
    const sorted = rows.slice().sort(function (a, b) { return b - a; });
    for (let i = 0; i < sorted.length; i++) board.splice(sorted[i], 1);
    for (let i = 0; i < rows.length; i++) board.unshift(new Array(C.COLS).fill(null));
  }
  function settle(board) {
    for (let x = 0; x < C.COLS; x++) {
      let write = C.ROWS - 1;
      for (let y = C.ROWS - 1; y >= 0; y--) {
        const c = board[y][x];
        if (!c) continue;
        if (write !== y) { board[write][x] = c; board[y][x] = null; }
        write -= 1;
      }
    }
  }

  function metrics(board) {
    let agg = 0, holes = 0, bump = 0, max = 0;
    const heights = [];
    for (let x = 0; x < C.COLS; x++) {
      let h = 0, seen = false;
      for (let y = 0; y < C.ROWS; y++) {
        if (board[y][x]) {
          if (!seen) { seen = true; h = C.ROWS - y; }
        } else if (seen) holes++;
      }
      heights.push(h);
      agg += h;
      if (h > max) max = h;
    }
    for (let i = 1; i < heights.length; i++) bump += Math.abs(heights[i] - heights[i - 1]);
    return { agg: agg, holes: holes, bump: bump, max: max };
  }

  function dropY(game, type, rot, x) {
    const p = { type: type, rot: rot, x: x, y: 0 };
    if (game.collides(p)) return -1;
    while (!game.collides({ type: type, rot: rot, x: x, y: p.y + 1 })) p.y++;
    return p.y;
  }

  function evalPlace(game, rot, x, opt) {
    const type = game.piece.type;
    const y = dropY(game, type, rot, x);
    if (y < 0) return null;
    const cells = game.pieceCells({ type: type, rot: rot, x: x, y: y });
    const board = copyBoard(game.board);
    let top = false;
    for (let i = 0; i < cells.length; i++) {
      const cx = cells[i][0], cy = cells[i][1];
      if (cy < 0 || cy >= C.ROWS || board[cy][cx]) return null;
      if (cy < 2) top = true;
      board[cy][cx] = { k: 'n', t: type };
    }
    const rows = fullRows(board);
    clearRowsIn(board, rows);
    const m = metrics(board);
    let score = -0.51 * m.agg - 0.36 * m.holes - 0.18 * m.bump + 0.76 * rows.length;
    // 合体债规则：每消一次会从底下顶 2 行合体块（约 20 格 + 2 个洞），
    // 所以 1~2 行消是亏的，只有 3~4 行才值得；把这块代价算进去，AI 才不会自杀式消行。
    // 但「危险」（场地快堆到顶）时这个代价会被 plan 压到 0——先保命再谈划不划算。
    if (rows.length && !game.classic) {
      const pen = (opt && opt.clearPenalty != null) ? opt.clearPenalty : 1.5;
      if (rows.length === 1) score -= pen;
      else if (rows.length === 2) score -= pen * 0.33;
    }
    // 快堆满时额外压高度，优先把场面压下来
    if (opt && opt.danger) score -= 1.4 * Math.max(0, m.max - (C.ROWS - 5));
    if (top) score -= 100; // 避开顶部两行
    return { type: 'piece', rot: rot, x: x, y: y, score: score, lines: rows.length };
  }

  function evalArrow(game, dir, x) {
    const p = { type: 'ARROW', dir: dir, rot: 0, x: x, y: 0 };
    if (game.collides(p)) return null;
    while (!game.collides({ type: 'ARROW', dir: dir, rot: 0, x: x, y: p.y + 1 })) p.y++;
    const cells = [];
    if (dir === 'up') for (let y = 0; y <= p.y; y++) cells.push([x, y]);
    else if (dir === 'down') for (let y = p.y; y < C.ROWS; y++) cells.push([x, y]);
    else if (dir === 'left') for (let cx = 0; cx <= x; cx++) cells.push([cx, p.y]);
    else for (let cx = x; cx < C.COLS; cx++) cells.push([cx, p.y]);
    const board = copyBoard(game.board);
    for (let i = 0; i < cells.length; i++) board[cells[i][1]][cells[i][0]] = null;
    settle(board);
    const rows = fullRows(board);
    clearRowsIn(board, rows);
    const m = metrics(board);
    const score = -0.51 * m.agg - 0.36 * m.holes - 0.18 * m.bump + 2.2 * rows.length;
    return { type: 'arrow', dir: dir, x: x, y: p.y, score: score, lines: rows.length };
  }

  // 思考温度：数字越大越接近最优解（0.3 更乱、1.0 更狠）
  const TEMP = { easy: 0.3, normal: 0.5, hard: 1.0 };

  function pickWeighted(moves, temp) {
    if (!moves.length) return null;
    let max = -Infinity;
    for (let i = 0; i < moves.length; i++) if (moves[i].score > max) max = moves[i].score;
    const weights = [];
    let sum = 0;
    for (let i = 0; i < moves.length; i++) {
      const w = Math.exp((moves[i].score - max) * temp);
      weights.push(w);
      sum += w;
    }
    let r = Math.random() * sum;
    for (let i = 0; i < moves.length; i++) {
      r -= weights[i];
      if (r <= 0) return moves[i];
    }
    return moves[moves.length - 1];
  }

  function choose(game, difficulty, plan) {
    if (!game || !game.piece) return null;
    // 温度只是相对值：乘 3 让「困难 1.0」接近贪心最优，「简单 0.3」才明显发散；
    // plan 是随时间爬的档位（见 planFor），有就用它，没有就按难度固定值。
    const baseTemp = (plan && plan.temp != null) ? plan.temp : (TEMP[difficulty] || TEMP.normal);
    const temp = baseTemp * 3;
    const mt = metrics(game.board);
    const danger = mt.max >= C.ROWS - 3;
    const opt = {
      clearPenalty: (plan && plan.clearPenalty != null) ? plan.clearPenalty : 1.5,
      danger: danger
    };
    if (game.piece.type === 'ARROW') {
      const moves = [];
      const dirs = ['up', 'down', 'left', 'right'];
      for (let d = 0; d < dirs.length; d++) {
        for (let x = 0; x < C.COLS; x++) {
          const m = evalArrow(game, dirs[d], x);
          if (m) moves.push(m);
        }
      }
      return pickWeighted(moves, temp);
    }

    const moves = [];
    const n = E.SHAPES[game.piece.type].n;
    for (let rot = 0; rot < 4; rot++) {
      for (let x = 0; x <= C.COLS - n; x++) {
        const m = evalPlace(game, rot, x, opt);
        if (m) moves.push(m);
      }
    }
    if (!moves.length) return null;
    if (difficulty === 'random') {
      return moves[Math.floor(Math.random() * moves.length)];
    }
    return pickWeighted(moves, temp);
  }

  function stepMs(difficulty) {
    // AI 落子间隔：2 / 3 / 5 秒一块（数字越大，给玩家留的消行时间越多）
    if (difficulty === 'easy') return 2000;
    if (difficulty === 'hard') return 5000;
    if (difficulty === 'random') return 600;
    return 3000;
  }

  /* 难度随时间往上爬：每 45 秒一级
   *   temp       越大越接近最优解（0.3 / 0.5 / 1.0 起步，最高 1.8）
   *   stepMs     越打落子越快（起步 2~5 秒，最低 0.7 秒）
   *   clearPenalty 越打越愿意单消救场（1.5 → 0.15）；危险时直接按 0 算
   * 想改节奏就改 RAMP_SEC 和这几个系数。
   */
  const RAMP_SEC = 45;
  function planFor(seconds, difficulty) {
    const base = TEMP[difficulty] || TEMP.normal;
    const t = Math.max(0, Number(seconds) || 0);
    const lv = Math.floor(t / RAMP_SEC);
    return {
      lv: lv,
      temp: Math.min(1.8, base + lv * 0.06),
      stepMs: Math.max(700, stepMs(difficulty) - lv * 130),
      clearPenalty: Math.max(0.15, 1.5 - lv * 0.13)
    };
  }

  function apply(game, move) {
    if (!game || !game.piece || !move) return false;
    const p = game.piece;
    p.rot = move.rot;
    p.x = move.x;
    p.y = move.y;
    if (p.type === 'ARROW') p.dir = move.dir;
    game.lockPiece();
    return true;
  }

  return { choose: choose, apply: apply, stepMs: stepMs, metrics: metrics, planFor: planFor };
});
