/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '1.41',
  code: 60,
  web: 145,
  date: '2026-11-19',
  title: '镜像慢就再试一次',
  titleEn: 'Retry when the mirror is slow',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单/普通/困难。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard."
    }
  ],
  log: [
    {
      "v": "1.41",
      "date": "2026-11-19",
      "title": "镜像慢就再试一次",
      "summary": "平板实测镜像能打开，但冷启动要 3~5 秒（DNS 1.5 秒 + TLS 2.5 秒），而安装包里的连接超时只有 3 秒，第一次检查经常被判超时、白说一句「检查失败」。现在网络类失败会自动重试两次（间隔 1.2 秒，DNS/TLS 都热了），中间不弹出失败提示。",
      "added": [
        "检查更新失败时自动重试（最多两次），重试途中不报错"
      ],
      "changed": [
        "「检查更新」的失败只在两次都失败后才提示"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.40",
      "date": "2026-11-19",
      "title": "删掉打不开的地址",
      "summary": "更新选项里原来还挂着 GitHub 原地址（手机上打不开），整个拿掉了：安装包弹窗和「怎么更新」只剩一个镜像复制按钮，内置更新源只保留两个镜像。壳里如果存着旧的原地址，启动时自动清掉——不再出现在「设置更新地址」里，也不再每次检查先白等一次超时。",
      "added": [],
      "changed": [
        "「怎么更新」和安装包弹窗：只留一个镜像复制按钮",
        "内置更新源只剩 gh-proxy / ghproxy.net 两个镜像",
        "壳里存的失效更新地址，启动时自动清掉"
      ],
      "balance": [],
      "removed": [
        "GitHub 原地址按钮、内置的 raw.githubusercontent 源"
      ]
    },
    {
      "v": "1.39",
      "date": "2026-11-19",
      "title": "下载默认走镜像",
      "summary": "手机复制 GitHub 原地址进不去（raw.githubusercontent 在国内被卡），所以默认改成镜像：「复制下载地址」和「怎么更新」里复制的都是 gh-proxy 镜像，GitHub 原地址留成一个小按钮。检查更新也把 GitHub 类源排到最后，不再先白白等一个 3 秒超时。",
      "added": [
        "下载地址默认走镜像（gh-proxy），GitHub 原地址留成按钮备选"
      ],
      "changed": [
        "检查更新：GitHub 类源排到最后，镜像先试",
        "「设置更新地址」的输入框提示改成当前镜像地址"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.38",
      "date": "2026-11-19",
      "title": "多人 2~4 人 · 昵称 · 去房间码",
      "summary": "Wi-Fi 对局从「两个人」扩到 2/3/4 个座位：房间有座位号、大厅能看到每个人和各自的网页包版本，人齐了房主点开始；不用再输房间码，快速匹配找到房间先让你确认「谁的房 / 几个人 / 什么版本」；每人一个昵称（默认 玩家417，只发给同房间）。",
      "added": [
        "Wi-Fi 2/3/4 人并行赛与干扰战（干扰战打座位往后的下一位）",
        "昵称：默认 玩家417，最多 8 字，只发给同一个房间",
        "大厅名册：几个人、谁没就位、谁的网页包偏旧一眼看到",
        "速配确认卡：房间主人 / 人数 / 版本，确认了才进",
        "3~4 人：出局后留在棋盘上等其他人，最后按分数排名"
      ],
      "changed": [
        "多人面板收成：昵称 / 人数 / 规则 / 模式 / 快速匹配，手动地址与房间码收进「高级」",
        "开局由房主点「开始对局」，不再等到齐自动开",
        "大厅里谁的网页包旧了直接拦住房主的开始按钮"
      ],
      "balance": [],
      "removed": [
        "开房那一排的「手动加入」入口（挪进「高级」）"
      ]
    },
    {
      "v": "1.37",
      "date": "2026-11-18",
      "title": "观战标题居中",
      "summary": "观战页只有一个返回键，标题被挤到右边；右侧补等宽占位后标题回中间。",
      "added": [],
      "changed": [
        "观战顶栏：标题居中"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.36",
      "date": "2026-11-18",
      "title": "观战居中 · 顶栏铺满",
      "summary": "观战页画布原来被键位留白推到右边、返回也缩在中间；现在观战居中、顶栏在所有模式里都铺满整宽（返回左上、暂停右上），观战比分改用紧凑写法不再压标题。",
      "added": [],
      "changed": [
        "观战：舞台留白归零、画布居中；比分紧凑，不压「第 1 局」",
        "所有模式：顶栏铺满整宽，返回固定左上、暂停固定右上"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.35",
      "date": "2026-11-17",
      "title": "去掉 v0.3 占位",
      "summary": "页面里写死的 v0.3 占位值全部去掉，改成「—」；以后再遇到脚本没加载，看到的是「—」而不是像版本号的 0.3，不会再误以为版本被回退。",
      "added": [],
      "changed": [
        "首页/更多页的版本占位从 v0.3 改为 —"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.34",
      "date": "2026-11-17",
      "title": "选择器根治",
      "summary": "上一版修选择器时误把 $ 变成 $$，界面脚本又断了（版本号回到 v0.3）。这次按规则重写：单 $ 调 forEach 一律改批量，并禁止出现 $$；打包前自检会拦。",
      "added": [],
      "changed": [
        "修复 $$ 误替换",
        "打包自检增加 $$ 与单 $ forEach 两条规则"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.33",
      "date": "2026-11-17",
      "title": "再修一处选择器",
      "summary": "1.32 又有一处单 $ 调用 forEach（手感按钮那行），会让界面脚本中断；这版修掉，并加了打包前自检，防止同类错误再上线。",
      "added": [],
      "changed": [
        "修复设置页手感按钮的选择器",
        "发布前检查所有 forEach 选择器是否都是批量查询"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.32",
      "date": "2026-11-17",
      "title": "多人页收成两键",
      "summary": "多人面板原来五个按钮平铺，新手不知道先点哪个；现在首屏只留「快速匹配」和「手动加入」，开房、复制链接、蓝牙发包、蓝牙配对、上次的对手都收进「高级」。",
      "added": [],
      "changed": [
        "多人页：开房/蓝牙/上次对手收进「高级 ▾」，默认折叠"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.31",
      "date": "2026-11-17",
      "title": "修 1.30 界面报错",
      "summary": "1.30 里设置页有个选择器写错（单 $ 却调用 forEach），报错导致首页版本号停在 v0.3、按钮也没反应；这一版修掉，界面恢复正常。",
      "added": [],
      "changed": [
        "修复设置页脚本错误：语言分组的选择器改回批量查询"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.30",
      "date": "2026-11-17",
      "title": "手感可调 · DAS/ARR",
      "summary": "设置 → 游戏里多了「手感」三档：标准 / 快 / 极快，调的是按住左右键后多久开始连移、连移多快；老玩家能按自己的习惯调，默认还是标准。",
      "added": [
        "设置 → 游戏 → 手感：标准 170/30ms、快 130/15ms、极快 105/8ms"
      ],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.29",
      "date": "2026-11-17",
      "title": "菜单合并 · 语言并组",
      "summary": "设置里「语言」不再单独开一个抽屉，并进「游戏」组末尾；入口标签同步改成「帧率 / 声音 / 材质 / 语言」。",
      "added": [],
      "changed": [
        "语言三选一移入游戏设置组，少一个入口"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.28",
      "date": "2026-11-17",
      "title": "联机走壳 · 手机也能连",
      "summary": "手机 WebView 是 file:// 页面，直接 fetch 局域网会被 Chromium 拦掉，所以两台安卓一直连不上；现在联机的 HTTP 全部改走安装包里的 Java 通道（1.6 壳），不用再靠浏览器。",
      "added": [],
      "changed": [
        "联机：加入房间 / 轮询 / 心跳改走壳的 lanGet / lanPost，file:// 页面不再被跨域拦",
        "房主版本探测也走壳，加入前能正常比对版本",
        "安装包升到 v1.6（壳 59）"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.27",
      "date": "2026-11-17",
      "title": "侧栏极简 · 大字不挤",
      "summary": "右侧数据栏原来是四行小字加两条 9px 注释，挤在一起；现在收成三条大字（等级 / 消行 / 最高）加一行状态，分数再长也不缩成蚂蚁字。",
      "added": [],
      "changed": [
        "侧栏：去掉重复的「结束欠 / 债已清 / 消行」小字，债放进底部状态行（债 -N 变红）",
        "字号：标签 11→12、数值 13→15，行距 22→26，行与行之间不再贴在一起",
        "长分数：先试 28px，塞不下就换紧凑写法（一百二十三万余），不再缩到 11px"
      ],
      "balance": [],
      "removed": []
    }
  ],
  logEn: [
    {
      "v": "1.41",
      "date": "2026-11-19",
      "title": "Retry when the mirror is slow",
      "summary": "Measured on the tablet, the mirror opens but needs 3-5 s cold (1.5 s DNS + 2.5 s TLS) while the APK only waits 3 s to connect, so the first check was often treated as a timeout and reported \"check failed\". Network failures now retry twice (1.2 s apart, by then DNS and TLS are warm) without flashing a failure message in between.",
      "added": [
        "Automatic retry (up to two) when the update check fails on the network, without a failure toast in between"
      ],
      "changed": [
        "The failure notice only appears if both retries fail"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.40",
      "date": "2026-11-19",
      "title": "Removed the dead download link",
      "summary": "The GitHub raw link was still offered in the update options even though it does not open on phones, so it is gone: the APK prompt and How-to-update now have a single mirror copy button, and the built-in update sources are just the two mirrors. A dead URL stored in the shell is cleared on startup, so it stops showing up in Set update URL and stops costing a timeout on every check.",
      "added": [],
      "changed": [
        "How-to-update and the APK prompt: one mirror copy button only",
        "Built-in update sources are only the gh-proxy / ghproxy.net mirrors",
        "A dead update URL stored in the shell is cleared on startup"
      ],
      "balance": [],
      "removed": [
        "The GitHub raw button and the built-in raw.githubusercontent source"
      ]
    },
    {
      "v": "1.39",
      "date": "2026-11-19",
      "title": "Mirror first for downloads",
      "summary": "The GitHub raw link fails to open on phones in China, so the mirror is now the default: the copy button in the update prompt and in How-to-update both hand out the gh-proxy link, and the GitHub link stays as a small fallback button. The update check also tries GitHub-style sources last instead of burning a 3-second timeout first.",
      "added": [
        "Download link defaults to the mirror (gh-proxy); the GitHub link is a fallback button"
      ],
      "changed": [
        "Update check: GitHub-style sources go last, mirror first",
        "The update-URL field now hints the current mirror address"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.38",
      "date": "2026-11-19",
      "title": "2-4 players, nicknames, no room codes",
      "summary": "Wi-Fi matches go from two players to 2/3/4 seats: seats get numbers, the lobby lists everyone with their web bundle version, and the host taps Start once everyone is in. No more typing room codes — Quick match finds a room and asks you to confirm host, player count and version first. Every player gets a nickname (default 玩家417, sent only to that room).",
      "added": [
        "Wi-Fi 2/3/4 player parallel and battle (battle hits the next seat)",
        "Nicknames: default 玩家417, up to 8 characters, only shared inside the room",
        "Lobby roster: who is here, who is not ready, whose bundle is older",
        "Quick-match confirm card: host, player count, version",
        "3-4 players: after you are out you wait on the board, then everyone is ranked by score"
      ],
      "changed": [
        "Multiplayer panel is now nickname / players / rules / mode / Quick match; address and room code moved into Advanced",
        "The host taps Start — no more auto-start when the room fills",
        "An older bundle on any seat blocks the host's Start button"
      ],
      "balance": [],
      "removed": [
        "The separate Join-by-hand row (now inside Advanced)"
      ]
    },
    {
      "v": "1.37",
      "date": "2026-11-18",
      "title": "Spectate title centred",
      "summary": "Spectate has only a Back button, so the title was pushed right; a matching spacer on the right centres it again.",
      "added": [],
      "changed": [
        "Spectate top bar: title centred"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.36",
      "date": "2026-11-18",
      "title": "Spectate centred, bar full width",
      "summary": "The spectate canvas used to be pushed right by the key-area padding and the Back button sat mid-screen; spectate is centred now, and the top bar spans the full width in every mode (Back top-left, Pause top-right). Spectate scores use the compact form so they no longer overlap the round title.",
      "added": [],
      "changed": [
        "Spectate: stage padding removed, canvas centred, compact scores",
        "All modes: top bar spans the full width, Back top-left / Pause top-right"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.35",
      "date": "2026-11-17",
      "title": "No more v0.3 placeholder",
      "summary": "The hardcoded v0.3 placeholders are gone (now a dash), so a script that fails to boot no longer looks like an ancient version.",
      "added": [],
      "changed": [
        "Home/More version placeholder changed from v0.3 to a dash"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.34",
      "date": "2026-11-17",
      "title": "Selectors fixed for good",
      "summary": "The previous fix turned $ into $$ by mistake, breaking the UI script again (version fell back to v0.3). Rewritten by rule: every forEach selector queries all nodes, and $$ is forbidden; the pre-release check blocks both.",
      "added": [],
      "changed": [
        "Fixed the $$ over-replacement",
        "Pre-release check now rejects $$ and single-$ forEach"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.33",
      "date": "2026-11-17",
      "title": "One more selector fix",
      "summary": "1.32 had another single-$ forEach (the handling buttons), which broke the settings script; fixed here, plus a pre-release check so this class of bug cannot ship again.",
      "added": [],
      "changed": [
        "Fixed the handling-button selector",
        "Pre-release check that every forEach selector queries all nodes"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.32",
      "date": "2026-11-17",
      "title": "Multiplayer tidied",
      "summary": "The multiplayer panel used to show five buttons at once; now it shows Quick match and Join by hand, with host, copy link, Bluetooth share, pairing and last opponent folded under Advanced.",
      "added": [],
      "changed": [
        "Multiplayer: host/Bluetooth/last opponent moved under Advanced, collapsed by default"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.31",
      "date": "2026-11-17",
      "title": "Fix 1.30 UI crash",
      "summary": "1.30 had a wrong selector in Settings (single $ calling forEach), which threw and left the home version at v0.3 and buttons dead. Fixed here.",
      "added": [],
      "changed": [
        "Fixed the settings script error: language group selector now queries all nodes"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.30",
      "date": "2026-11-17",
      "title": "Handling: DAS/ARR",
      "summary": "Settings → Game now has Handling: Standard / Fast / Instant, controlling how soon and how fast held left/right auto-repeats. Defaults to Standard.",
      "added": [
        "Settings → Game → Handling: Standard 170/30ms, Fast 130/15ms, Instant 105/8ms"
      ],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.29",
      "date": "2026-11-17",
      "title": "Settings merged",
      "summary": "Language no longer opens its own sheet; it now sits at the end of the Game group, and the entry label says Frame rate / Sound / Skin / Language.",
      "added": [],
      "changed": [
        "Language moved into the Game settings group — one less entry"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.28",
      "date": "2026-11-17",
      "title": "LAN through the shell",
      "summary": "The WebView page runs on file://, so plain fetch to the LAN is blocked by Chromium — that is why two Android devices could never connect. LAN HTTP now goes through the shell (APK 1.6).",
      "added": [],
      "changed": [
        "Multiplayer: join, polling and heartbeats go through the shell lanGet/lanPost instead of fetch",
        "Host version probing also goes through the shell, so the pre-join version check works",
        "APK is now v1.6 (shell 59)"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.27",
      "date": "2026-11-17",
      "title": "Cleaner HUD",
      "summary": "The side panel used to stack four small rows plus two 9px captions; it is now three larger rows (Level / Lines / Best) and a single status line, and long scores no longer shrink to ant-size.",
      "added": [],
      "changed": [
        "Panel: dropped the duplicate End-debt / Debt-paid / Lines captions; debt now lives in the bottom status line (Debt -N in red)",
        "Type: labels 11 to 12, values 13 to 15, row pitch 22 to 26 — rows no longer touch",
        "Long scores: try 28px first, then switch to the compact form instead of shrinking to 11px"
      ],
      "balance": [],
      "removed": []
    }
  ],




  };
})();
