/* net.js —— 联机客户端：协议一层，管道两套（Wi‑Fi 轮询 / 蓝牙 RFCOMM）
 *
 * 两个传输层只做一件事：把消息送到对面、把对面的消息收回来。
 * 「到齐进大厅、房主定玩法、开局时刻、版本指纹」这些规则只写在 Proto 里一份，
 * 以后加「再来一局」「断线重连」不用 Wi‑Fi 和蓝牙各改一遍。
 *
 * 用法（对外没变）：
 *   const s = await TetrisNet.join({base, room, name, onReady, onLobby, onPeer, onMessage, onStatus, onError});
 *   const b = TetrisNet.bt({host, mac, name, onReady, ...});
 *   s.send({t:'state', score, debt, clears});   s.go(rules, mode);   s.leave();
 */
(function () {
  'use strict';

  const POLL_MS = 250;
  const RECONNECT_MS = 8000;
  /* 联机协议的「网页包版本」。APK 不带它——协议只在 JS 里演进，
     这样联机永远不需要装新 APK，靠网页包自动同步就能对齐。 */
  const PROTO = 3;

  function myWeb() {
    return (window.TetrisVersion && window.TetrisVersion.web) || 0;
  }
  function myApk() {
    try {
      if (window.TetrisHost && typeof window.TetrisHost.apkInfo === 'function') {
        return JSON.parse(window.TetrisHost.apkInfo()).versionCode || 0;
      }
    } catch (e) {}
    return 0;
  }

  /** 我自己的版本指纹，用来和对面比（顺带报难度档，让对面能跟）。 */
  function myStamp(tier) {
    return { t: 'ready', web: myWeb(), apk: myApk(), proto: PROTO, name: '你', tier: tier || '' };
  }

  function normalizeBase(input) {
    let s = String(input || '').trim();
    if (!s) return '';
    if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
    s = s.replace(/\/+$/, '');
    try {
      const u = new URL(s);
      if (!u.port) u.port = '8788';
      return u.protocol + '//' + u.host;
    } catch (e) {
      return s;
    }
  }

  const REQ_MS = 6000;      // 单个 HTTP 请求最多等这么久，别让界面一直卡在「连接中」
  function EN() { return !!(window.TetrisI18n && window.TetrisI18n.lang === 'en'); }
  function S(zh, en) { return EN() ? en : zh; }

  async function timedFetch(url, opt) {
    if (typeof AbortController !== 'function') return fetch(url, opt);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), REQ_MS);
    try {
      return await fetch(url, Object.assign({}, opt, { signal: ctrl.signal }));
    } catch (e) {
      if (e && (e.name === 'AbortError' || /aborted/i.test(String(e.message)))) {
        const en = !!(window.TetrisI18n && window.TetrisI18n.lang === 'en');
        throw new Error(en ? 'Host did not respond (' + (REQ_MS / 1000) + 's timeout)' : '房主没响应（' + (REQ_MS / 1000) + ' 秒超时）');
      }
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  async function postJSON(url, body) {
    const res = await timedFetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify(body || {}),
      cache: 'no-store',
      credentials: 'omit'
    });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const err = new Error((data && data.error) || ('HTTP ' + res.status));
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  async function getJSON(url) {
    const res = await timedFetch(url, { cache: 'no-store', credentials: 'omit' });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const err = new Error((data && data.error) || ('HTTP ' + res.status));
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  /* ================= 协议层（Wi‑Fi / 蓝牙共用） =================
     管道负责连接和收发；这里只做四件事：
       1. 记版本指纹（peer）   2. 到齐只进一次大厅
       3. 房主定玩法 → 两边只开一次局   4. 开局后的消息转给游戏
  */
  function Proto(kind, opts) {
    opts = opts || {};
    this.kind = kind;                       // 'lan' | 'bt'
    this.rules = (opts.rules === 'classic') ? 'classic' : 'debt';
    this.mode = (opts.mode === 'lan_battle') ? 'lan_battle' : 'lan_parallel';
    this.name = String(opts.name || '玩家').slice(0, 10);
    this.tier = String(opts.tier || '');
    this.onReady = opts.onReady || function () {};
    this.onLobby = opts.onLobby || function () {};
    this.onPeer = opts.onPeer || function () {};
    this.onMessage = opts.onMessage || function () {};
    this.onStatus = opts.onStatus || function () {};
    this.onError = opts.onError || function () {};
    this.seed = opts.seed || 0;
    this.startAt = 0;
    this.offset = 0;                        // 服务端时间 - 本机时间（蓝牙恒为 0）
    this.players = [];
    this.peer = { web: 0, apk: 0, proto: 0, name: '', tier: '' };
    this.started = false;                   // 已经开局（onReady 发过）
    this.lobbyFired = false;
    this.readyFired = false;
    this.closed = false;
  }

  Proto.prototype.status = function (text, kind) {
    try { this.onStatus(text, kind || ''); } catch (e) {}
  };

  /** 谁当房主：两条管道各有各的判定，默认不是。 */
  Proto.prototype.isHost = function () { return false; };

  /** 对外的「我」和「对面」用的名字。 */
  Proto.prototype.lobbyInfo = function () {
    return { host: this.isHost(), rules: this.rules, mode: this.mode, players: this.players };
  };

  Proto.prototype.setPeer = function (stamp) {
    if (!stamp) return;
    const web = stamp.web | 0, apk = stamp.apk | 0, proto = stamp.proto | 0;
    if (!web && !apk && !proto && !stamp.tier) return;
    this.peer = { web: web, apk: apk, proto: proto, name: stamp.name || '', tier: String(stamp.tier || '') };
    try { this.onPeer(this.peer); } catch (e) {}
  };

  Proto.prototype.fireLobby = function (info) {
    if (this.lobbyFired || this.closed) return;
    this.lobbyFired = true;
    try { this.onLobby(info || this.lobbyInfo()); } catch (e) {}
  };

  Proto.prototype.fireReady = function (info) {
    if (this.readyFired || this.closed) return;
    this.readyFired = true;
    this.started = true;
    try { this.onReady(info); } catch (e) {}
  };

  /** 房主选好玩法：管道负责把 go 送出去 / 定开局时刻。 */
  Proto.prototype.go = function (rules, mode) {
    if (this.closed) return;
    this.rules = rules === 'classic' ? 'classic' : 'debt';
    this.mode = (mode === 'lan_battle' && this.rules !== 'classic') ? 'lan_battle' : 'lan_parallel';
    return this._go(this.rules, this.mode);
  };

  Proto.prototype._go = function () {};
  Proto.prototype.send = function () {};
  Proto.prototype.leave = function () { this.closed = true; };

  /* ================= 管道一：Wi‑Fi 轮询（电脑/手机房主共用） ================= */
  function Session(opts) {
    Proto.call(this, 'lan', opts);
    this.base = normalizeBase(opts.base);
    this.room = String(opts.room || '').replace(/\D/g, '').slice(0, 4);
    this.playerId = '';
    this.token = '';
    this.hostId = '';
    this.seq = 0;
    this.gathered = false;                  // 服务端说「两个人都在了」
    this.timer = 0;
    this.polling = false;
    this.reconnectingSince = 0;
  }
  Session.prototype = Object.create(Proto.prototype);
  Session.prototype.constructor = Session;

  Session.prototype.isHost = function () {
    return !!this.playerId && this.playerId === this.hostId;
  };

  Session.prototype.connect = async function () {
    if (!this.base) throw new Error(S('没有房主地址', 'No host address'));
    if (this.room.length !== 4) throw new Error(S('房间码要 4 位数字', 'Room code must be 4 digits'));
    const fresh = !this.playerId;
    this.status(S('连接房主…', 'Connecting to host…'), 'wait');
    const data = await postJSON(this.base + '/api/join', {
      room: this.room,
      name: this.name,
      rules: this.rules,
      playerId: this.playerId || undefined,
      token: this.token || undefined
    });
    this.applyState(data);
    if (fresh) this.seq = data.seq || 0;
    if (!this.reconnectingSince) this.status(this.gathered ? S('已就绪', 'Ready') : S('等另一个人进来…', 'Waiting for the other player…'), 'wait');
    this.offset = data.serverTime - Date.now();
    this.schedulePoll(0);
    try { this.send(myStamp(this.tier)); } catch (e) {}
    return this;
  };

  Session.prototype.applyState = function (data) {
    if (!data) return;
    if (data.playerId) this.playerId = data.playerId;
    if (data.token) this.token = data.token;
    if (typeof data.seed === 'number') this.seed = data.seed;
    if (data.startAt) this.startAt = data.startAt;
    if (data.players) this.players = data.players;
    if (data.rules) this.rules = (data.rules === 'classic') ? 'classic' : 'debt';
    if (data.mode) this.mode = (data.mode === 'lan_battle') ? 'lan_battle' : 'lan_parallel';
    if (data.host) this.hostId = String(data.host);
    if (data.serverTime) this.offset = data.serverTime - Date.now();
    const wasGathered = this.gathered;
    this.gathered = !!data.ready;
    // 到齐了先开「选玩法」的房间；老房主（自己会定 startAt）就直接开局，不硬等大厅
    if (this.gathered && !this.startAt) {
      this.fireLobby({
        players: this.players,
        host: this.isHost(),
        rules: this.rules,
        mode: this.mode
      });
    }
    if (this.startAt && this.gathered) {
      this.fireReady({
        seed: this.seed,
        startAt: this.startAt,
        players: this.players,
        rules: this.rules,
        mode: this.mode,
        isHost: this.isHost(),
        serverTime: data.serverTime || Date.now()
      });
    }
    if (!wasGathered && this.gathered) {
      this.status(S('两人到齐，准备开始', 'Both players here — get ready'), 'ok');
      try { this.send(myStamp(this.tier)); } catch (e) {}   // 到齐后交换一次版本指纹
    }
  };

  /** 只有房主能定玩法；客人调了也不改自己的规则（服务端同样会拒）。 */
  Session.prototype.go = function (rules, mode) {
    if (!this.isHost() || this.started || this.closed) return;
    return Proto.prototype.go.call(this, rules, mode);
  };

  Session.prototype._go = function (rules, mode) {
    this.send({ t: 'go', rules: rules, mode: mode });
  };

  Session.prototype.schedulePoll = function (ms) {
    if (this.closed) return;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.poll(), ms == null ? POLL_MS : ms);
  };

  Session.prototype.poll = async function () {
    if (this.closed || this.polling) return;
    this.polling = true;
    try {
      const url = this.base + '/api/poll?playerId=' + encodeURIComponent(this.playerId)
        + '&token=' + encodeURIComponent(this.token) + '&since=' + this.seq;
      const data = await getJSON(url);
      this.applyState(data);
      if (data.messages && data.messages.length) {
        for (const m of data.messages) {
          if (m && m.t === 'ready') {        // 对面的版本指纹（协议 3 起才有这些字段）
            this.setPeer({ web: m.web, apk: m.apk, proto: m.proto, name: m.from || '', tier: m.tier });
            continue;
          }
          try { this.onMessage(m); } catch (e) {}
        }
      }
      if (typeof data.seq === 'number') this.seq = Math.max(this.seq, data.seq);
      if (this.reconnectingSince) {
        this.reconnectingSince = 0;
        this.status(S('重连成功', 'Reconnected'), 'ok');
      }
      this.polling = false;
      this.schedulePoll(POLL_MS);
    } catch (e) {
      this.polling = false;
      if (this.closed) return;
      if (!this.reconnectingSince) {
        this.reconnectingSince = Date.now();
        this.status(S('连接断了，重连中…', 'Disconnected — reconnecting…'), 'err');
      }
      if (Date.now() - this.reconnectingSince > RECONNECT_MS) {
        this.status(S('重连失败，退出联机', 'Reconnect failed — leaving the match'), 'err');
        try { this.onError(e); } catch (err) {}
        return;
      }
      this.connect().catch(() => {});
      this.schedulePoll(800);
    }
  };

  Session.prototype.send = function (msg) {
    if (this.closed || !this.playerId) return;
    postJSON(this.base + '/api/msg', {
      playerId: this.playerId,
      token: this.token,
      msg: msg
    }).catch(() => {});
  };

  Session.prototype.leave = function () {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    if (this.playerId) {
      postJSON(this.base + '/api/leave', { playerId: this.playerId, token: this.token }).catch(() => {});
    }
  };

  /* ================= 管道二：蓝牙 RFCOMM 直连 ================= */
  function BtSession(opts) {
    Proto.call(this, 'bt', opts);
    this.host = !!opts.host;
    this.mac = String(opts.mac || '');
    this.seed = opts.seed || ((Date.now() ^ Math.floor(Math.random() * 0xFFFFFFFF)) >>> 0);
    this.players = ['你', this.host ? '对手' : '房主'];
    this.timer = 0;
    this._helloSent = false;
    this._startIn = 2200;
    this._lastState = '';
  }
  BtSession.prototype = Object.create(Proto.prototype);
  BtSession.prototype.constructor = BtSession;

  BtSession.prototype.isHost = function () { return this.host; };

  BtSession.prototype._bridge = function () {
    if (window.TetrisHost && typeof window.TetrisHost.btInfo === 'function') return window.TetrisHost;
    return null;
  };

  BtSession.prototype.start = function () {
    const h = this._bridge();
    if (!h) {
      this.status(S('这个安装包还不支持蓝牙，装一次 0.8.0', 'This build has no Bluetooth — install 0.8.0'), 'err');
      try { this.onError(new Error('no bt bridge')); } catch (e) {}
      return this;
    }
    let r;
    try {
      r = JSON.parse(this.host ? h.btHost() : h.btJoin(this.mac));
    } catch (e) {
      r = { ok: false, error: String(e) };
    }
    if (!r || !r.ok) {
      this.status((r && r.error) || S('蓝牙开不了', 'Bluetooth could not start'), 'err');
      try { this.onError(new Error((r && r.error) || 'bt start failed')); } catch (e) {}
      return this;
    }
    this.status(this.host ? S('蓝牙房主已开，等另一台手机连…', 'Bluetooth room open — waiting for the other phone…') : S('正在连蓝牙…', 'Connecting Bluetooth…'), 'wait');
    const self = this;
    this.timer = setTimeout(function () { self._poll(); }, 120);
    return this;
  };

  BtSession.prototype._sendRaw = function (obj) {
    const h = this._bridge();
    if (!h || typeof h.btSend !== 'function') return false;
    try {
      const r = JSON.parse(h.btSend(JSON.stringify(obj)));
      return !!(r && r.ok);
    } catch (e) { return false; }
  };

  BtSession.prototype.send = function (msg) {
    if (this.closed || !this.started) return;
    this._sendRaw(msg);
  };

  BtSession.prototype._poll = function () {
    if (this.closed) return;
    const h = this._bridge();
    if (!h) return;
    let info = null;
    try { info = JSON.parse(h.btInfo()); } catch (e) { info = null; }
    if (!info) {
      this._fail('读不到蓝牙状态');
      return;
    }
    if (info.state !== this._lastState) {
      this._lastState = info.state;
      if (info.state === 'connected') {
        this.status(S('蓝牙已连上', 'Bluetooth connected'), 'ok');
        if (this.host && !this._helloSent) {
          this._helloSent = true;
          this._sendRaw({
            t: 'btHello', seed: this.seed, rules: this.rules, mode: this.mode,
            startIn: this._startIn, name: this.name, tier: this.tier,
            web: myWeb(), apk: myApk(), proto: PROTO
          });
          this.status(S('等另一台手机准备…', 'Waiting for the other phone…'), 'wait');
        }
      } else if (info.state === 'connecting') {
        this.status(S('正在连蓝牙…', 'Connecting Bluetooth…'), 'wait');
      } else if (info.state === 'error') {
        this._fail(info.error || '蓝牙连接失败');
        return;
      } else if (info.state === 'closed' && this.started) {
        this.closed = true;
        clearTimeout(this.timer);
        try { this.onError(new Error('蓝牙断了')); } catch (e) {}
        return;
      }
    }

    let arr = [];
    try { arr = JSON.parse(h.btPoll()); } catch (e) { arr = []; }
    if (arr && arr.length) {
      for (let i = 0; i < arr.length; i++) {
        let m = null;
        try { m = JSON.parse(arr[i]); } catch (e) { m = null; }
        if (!m) continue;
        if (m.t === 'btHello' && !this.host) {
          if (m.seed) this.seed = m.seed >>> 0;
          this.rules = (m.rules === 'classic') ? 'classic' : 'debt';
          this.mode = (m.mode === 'lan_battle') ? 'lan_battle' : 'lan_parallel';
          this._startIn = Math.max(300, Math.min(5000, Number(m.startIn) || 2200));
          this.setPeer({ web: m.web, apk: m.apk, proto: m.proto, name: '房主', tier: m.tier });
          this._sendRaw({ t: 'btReady', web: myWeb(), apk: myApk(), proto: PROTO, tier: this.tier });
          this._enterLobby();
          continue;
        }
        if (m.t === 'btReady' && this.host) {
          this.setPeer({ web: m.web, apk: m.apk, proto: m.proto, name: '对手', tier: m.tier });
          this._enterLobby();
          continue;
        }
        if (m.t === 'go') {
          // 房主选完玩法才发 go：收到就按他选的规则开局
          this.rules = (m.rules === 'classic') ? 'classic' : 'debt';
          this.mode = (m.mode === 'lan_battle' && this.rules !== 'classic') ? 'lan_battle' : 'lan_parallel';
          this._startIn = Math.max(300, Math.min(5000, Number(m.startIn) || 2200));
          this._readyAt(Date.now() + this._startIn, false);
          continue;
        }
        if (this.started) {
          try { this.onMessage(m); } catch (e) {}
        }
      }
    }
    const self = this;
    this.timer = setTimeout(function () { self._poll(); }, 100);
  };

  /** 蓝牙这边也是「连上先不开，等房主选玩法」。 */
  BtSession.prototype._enterLobby = function () {
    if (this.lobbyFired || this.closed) return;
    this.status(this.host ? S('对手已连上，选个玩法', 'Opponent connected — pick a mode') : S('等房主选玩法…', 'Waiting for the host to pick a mode'), 'ok');
    this.fireLobby(this.lobbyInfo());
  };

  /** 房主：把选好的玩法发过去，然后两边一起开局。 */
  BtSession.prototype.go = function (rules, mode) {
    if (!this.host || this.started || this.closed) return;
    return Proto.prototype.go.call(this, rules, mode);
  };

  BtSession.prototype._go = function (rules, mode) {
    this._sendRaw({ t: 'go', rules: rules, mode: mode, startIn: this._startIn });
    this._readyAt(Date.now() + this._startIn, true);
  };

  BtSession.prototype._readyAt = function (startAt, isHost) {
    if (this.readyFired || this.closed) return;
    this.offset = 0;
    this.startAt = startAt;
    this.status(S('准备好了，开局', 'Ready — starting'), 'ok');
    this.fireReady({
      seed: this.seed,
      startAt: startAt,
      rules: this.rules,
      mode: this.mode,
      isHost: isHost,
      players: this.players,
      serverTime: Date.now()
    });
  };

  BtSession.prototype._fail = function (msg) {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    this.status(msg || S('蓝牙失败', 'Bluetooth failed'), 'err');
    try { this.onError(new Error(msg || 'bt error')); } catch (e) {}
  };

  BtSession.prototype.leave = function () {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    if (this.started) this._sendRaw({ t: 'peerLeft' });
    const h = this._bridge();
    if (h && typeof h.btClose === 'function') {
      try { h.btClose(); } catch (e) {}
    }
  };

  /* ---------------- 附近的房间（UDP 广播） ----------------
     房主每秒喊一次「我在，房间码 xxxx」，想加入的那台只听着，把听到的攒成列表。
     省掉手输 IP；收不到就退回手动填地址。 */
  function beaconBridge() {
    return (window.TetrisHost && typeof window.TetrisHost.lanStart === 'function') ? window.TetrisHost : null;
  }

  window.TetrisNet = {
    normalizeBase: normalizeBase,
    proto: PROTO,
    discover: {
      supported: function () { return !!beaconBridge(); },
      // self 非空 = 我也开房，让别人找到我；空 = 只听
      start: function (self) {
        var h = beaconBridge();
        if (!h) return { ok: false, error: 'no bridge', supported: false };
        try {
          var r = JSON.parse(h.lanStart(self ? JSON.stringify(self) : ''));
          return r || { ok: false };
        } catch (e) { return { ok: false, error: String(e) }; }
      },
      poll: function () {
        var h = beaconBridge();
        if (!h) return [];
        try { return JSON.parse(h.lanPoll()) || []; } catch (e) { return []; }
      },
      stop: function () {
        var h = beaconBridge();
        if (!h) return;
        try { h.lanStop(); } catch (e) {}
      }
    },
    join: async function (opts) {
      const s = new Session(opts);
      await s.connect();
      return s;
    },
    bt: function (opts) {
      return new BtSession(opts).start();
    }
  };
})();
