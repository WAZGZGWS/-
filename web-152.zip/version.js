/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '1.48',
  code: 61,
  web: 152,
  date: '2026-11-19',
  title: '流畅度也交给自动',
  titleEn: 'Frame rate is automatic too',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单/普通/困难。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard."
    }
  ],
  log: [
    {
      "v": "1.48",
      "date": "2026-11-19",
      "title": "流畅度也交给自动",
      "summary": "帧率那 5 个选项删了，改成读设备算力（核心数/内存/GPU/屏幕/pixel 各占权重算出来的 0~100 分）和屏幕刷新率自己定上限：算力 ≥70 跟随屏幕（最多 120），45~69 封顶 60，更弱封顶 45。设置里只剩一行结果，比如「本机 60Hz · 跟随屏幕 · 算力 79」。排障时可以在网址后面加 ?fps=60 手动压一档。",
      "added": [],
      "changed": [
        "设置 → 游戏：帧率 5 个选项 → 一行自动结果「流畅度（自动）」"
      ],
      "balance": [],
      "removed": [
        "手动选帧率（30/60/90/120）"
      ]
    },
    {
      "v": "1.47",
      "date": "2026-11-19",
      "title": "性能档只算不显示",
      "summary": "设置里「性能档（自动）」那行删了。它本来就是自动切的（按帧时间降毛玻璃/分辨率/帧率上限），玩家改不了；现在只在代码里算，需要排查时它跟着「复制这一版说明」一起复制出去，还带上 p95 帧时间。屏幕与设备的副标题也改成「方向 / 刷新率 / 安装包」。",
      "added": [],
      "changed": [
        "「复制这一版说明」里的性能档带上 p95 帧时间"
      ],
      "balance": [],
      "removed": [
        "设置 → 屏幕与设备的「性能档（自动）」一行"
      ]
    },
    {
      "v": "1.46",
      "date": "2026-11-19",
      "title": "统计并进存档页",
      "summary": "「更多 → 统计」那个按钮和弹层删了，统计搬进「存档管理」，跟着存档分组走、一个模式一行：合体债按当前档位显示，经典、常驻、禅各自一条，写法是「合体债·轻松 · 累计 5 局 · 3,200 分」。统计本身也改成按模式分别累计（老数据的总计还在）。",
      "added": [
        "统计按模式分开记，和「一个模式一个存档」对齐"
      ],
      "changed": [
        "存档管理页：每个模式下面多一行该模式的累计局数和最高分"
      ],
      "balance": [],
      "removed": [
        "更多页的「统计」按钮 + 弹层"
      ]
    },
    {
      "v": "1.45",
      "date": "2026-11-19",
      "title": "设备检测转后台",
      "summary": "设置里「设备（自动检测）」那三行（屏幕 / 游戏窗口 / 屏幕刷新率）和「重新检测」删了。检测本身照旧自动跑——启动时一次、每次进设置一次——测到的分辨率和刷新率只写进设置，「帧率」那行小字会用到。",
      "added": [],
      "changed": [
        "设备检测不再占设置界面，只在后台跑"
      ],
      "balance": [],
      "removed": [
        "「设备（自动检测）」三行 + 「重新检测」按钮"
      ]
    },
    {
      "v": "1.44",
      "date": "2026-11-19",
      "title": "静音自动改文字提示",
      "summary": "设置里那行「试听一声 / 听到了 / 没声音」删掉了。现在页面每 15 秒问一次壳的系统媒体音量：被拉到 0（或开了静音）就自动改用右上角文字提示，转场和危险提示都改文字；音量回来就自动切回去。设置里只剩一行只读的「系统音量 7/15」。没装新壳（1.8）的话，退回只看音效开关。",
      "added": [
        "读系统媒体音量：静音自动切文字提示（要 1.8 的壳）"
      ],
      "changed": [
        "设置 → 声音：删掉「试听一声」，改成一行只读的系统音量"
      ],
      "balance": [],
      "removed": [
        "「试听一声 / 听到了 / 没声音」这三行排障 UI"
      ]
    },
    {
      "v": "1.43",
      "date": "2026-11-19",
      "title": "去掉「高级」",
      "summary": "多人页那个「高级 ▾」里其实只剩「手动地址 / 房间码」有用：开房早就由快速匹配兜底，其他人也能在速配确认卡上点「自己开」。折叠去掉，改成一条小字「手动输入地址 ▾」，只在电脑当房主、或路由器挡住广播时用；「开房等人」按钮删掉。",
      "added": [],
      "changed": [
        "多人页：「高级」→「手动输入地址」（只留地址 + 房间码 + 加入）"
      ],
      "balance": [],
      "removed": [
        "「开房等人」按钮（快速匹配没人时会自动开房）"
      ]
    },
    {
      "v": "1.42",
      "date": "2026-11-19",
      "title": "蓝牙入口露出来",
      "summary": "多人页里「蓝牙」一直看不见：一段早期的样式在页面里写着「没打开高级就把这几个按钮藏掉」，它认的那个高级开关早就删了，于是蓝牙、上次的对手、复制下载链接、蓝牙发安装包全被永久隐藏。样式删掉了，蓝牙也提到外面单独一个「蓝牙对战（2 人）」按钮。",
      "added": [],
      "changed": [
        "多人页：蓝牙是一级按钮「蓝牙对战（2 人）」，不用先点高级"
      ],
      "balance": [],
      "removed": [
        "一段把蓝牙等按钮永久藏起来的早期样式"
      ]
    },
    {
      "v": "1.41",
      "date": "2026-11-19",
      "title": "镜像慢就再试一次",
      "summary": "平板实测镜像能打开，但冷启动要 3~5 秒（DNS 1.5 秒 + TLS 2.5 秒），而安装包里的连接超时只有 3 秒，第一次检查经常被判超时、白说一句「检查失败」。现在网络类失败会自动重试两次（间隔 1.2 秒，DNS/TLS 都热了），中间不弹出失败提示。",
      "added": [
        "检查更新失败时自动重试（最多两次），重试途中不报错"
      ],
      "changed": [
        "「检查更新」的失败只在两次都失败后才提示"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.40",
      "date": "2026-11-19",
      "title": "删掉打不开的地址",
      "summary": "更新选项里原来还挂着 GitHub 原地址（手机上打不开），整个拿掉了：安装包弹窗和「怎么更新」只剩一个镜像复制按钮，内置更新源只保留两个镜像。壳里如果存着旧的原地址，启动时自动清掉——不再出现在「设置更新地址」里，也不再每次检查先白等一次超时。",
      "added": [],
      "changed": [
        "「怎么更新」和安装包弹窗：只留一个镜像复制按钮",
        "内置更新源只剩 gh-proxy / ghproxy.net 两个镜像",
        "壳里存的失效更新地址，启动时自动清掉"
      ],
      "balance": [],
      "removed": [
        "GitHub 原地址按钮、内置的 raw.githubusercontent 源"
      ]
    },
    {
      "v": "1.39",
      "date": "2026-11-19",
      "title": "下载默认走镜像",
      "summary": "手机复制 GitHub 原地址进不去（raw.githubusercontent 在国内被卡），所以默认改成镜像：「复制下载地址」和「怎么更新」里复制的都是 gh-proxy 镜像，GitHub 原地址留成一个小按钮。检查更新也把 GitHub 类源排到最后，不再先白白等一个 3 秒超时。",
      "added": [
        "下载地址默认走镜像（gh-proxy），GitHub 原地址留成按钮备选"
      ],
      "changed": [
        "检查更新：GitHub 类源排到最后，镜像先试",
        "「设置更新地址」的输入框提示改成当前镜像地址"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.38",
      "date": "2026-11-19",
      "title": "多人 2~4 人 · 昵称 · 去房间码",
      "summary": "Wi-Fi 对局从「两个人」扩到 2/3/4 个座位：房间有座位号、大厅能看到每个人和各自的网页包版本，人齐了房主点开始；不用再输房间码，快速匹配找到房间先让你确认「谁的房 / 几个人 / 什么版本」；每人一个昵称（默认 玩家417，只发给同房间）。",
      "added": [
        "Wi-Fi 2/3/4 人并行赛与干扰战（干扰战打座位往后的下一位）",
        "昵称：默认 玩家417，最多 8 字，只发给同一个房间",
        "大厅名册：几个人、谁没就位、谁的网页包偏旧一眼看到",
        "速配确认卡：房间主人 / 人数 / 版本，确认了才进",
        "3~4 人：出局后留在棋盘上等其他人，最后按分数排名"
      ],
      "changed": [
        "多人面板收成：昵称 / 人数 / 规则 / 模式 / 快速匹配，手动地址与房间码收进「高级」",
        "开局由房主点「开始对局」，不再等到齐自动开",
        "大厅里谁的网页包旧了直接拦住房主的开始按钮"
      ],
      "balance": [],
      "removed": [
        "开房那一排的「手动加入」入口（挪进「高级」）"
      ]
    },
    {
      "v": "1.37",
      "date": "2026-11-18",
      "title": "观战标题居中",
      "summary": "观战页只有一个返回键，标题被挤到右边；右侧补等宽占位后标题回中间。",
      "added": [],
      "changed": [
        "观战顶栏：标题居中"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.36",
      "date": "2026-11-18",
      "title": "观战居中 · 顶栏铺满",
      "summary": "观战页画布原来被键位留白推到右边、返回也缩在中间；现在观战居中、顶栏在所有模式里都铺满整宽（返回左上、暂停右上），观战比分改用紧凑写法不再压标题。",
      "added": [],
      "changed": [
        "观战：舞台留白归零、画布居中；比分紧凑，不压「第 1 局」",
        "所有模式：顶栏铺满整宽，返回固定左上、暂停固定右上"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.35",
      "date": "2026-11-17",
      "title": "去掉 v0.3 占位",
      "summary": "页面里写死的 v0.3 占位值全部去掉，改成「—」；以后再遇到脚本没加载，看到的是「—」而不是像版本号的 0.3，不会再误以为版本被回退。",
      "added": [],
      "changed": [
        "首页/更多页的版本占位从 v0.3 改为 —"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.34",
      "date": "2026-11-17",
      "title": "选择器根治",
      "summary": "上一版修选择器时误把 $ 变成 $$，界面脚本又断了（版本号回到 v0.3）。这次按规则重写：单 $ 调 forEach 一律改批量，并禁止出现 $$；打包前自检会拦。",
      "added": [],
      "changed": [
        "修复 $$ 误替换",
        "打包自检增加 $$ 与单 $ forEach 两条规则"
      ],
      "balance": [],
      "removed": []
    }
  ],
  logEn: [
    {
      "v": "1.48",
      "date": "2026-11-19",
      "title": "Frame rate is automatic too",
      "summary": "The five frame-rate buttons are gone. The cap is now derived from a device score (cores, memory, GPU, screen, pixels) and the display refresh rate: score 70+ follows the screen (up to 120), 45-69 caps at 60, weaker caps at 45. Settings shows one result line such as \"60Hz screen · follows the screen · score 79\". For troubleshooting you can still add ?fps=60 to the URL.",
      "added": [],
      "changed": [
        "Settings → Game: five frame-rate choices became one automatic result line"
      ],
      "balance": [],
      "removed": [
        "Manual frame-rate selection (30/60/90/120)"
      ]
    },
    {
      "v": "1.47",
      "date": "2026-11-19",
      "title": "Quality tier is internal now",
      "summary": "The Quality (auto) row is gone from Settings. It always switched itself (blur, resolution and frame cap based on frame time) and was never user-settable; it now only lives in code, and Copy this version still reports it together with the p95 frame time. The Screen & device subtitle now reads Orientation / Refresh rate / APK.",
      "added": [],
      "changed": [
        "Copy this version now includes the p95 frame time next to the quality tier"
      ],
      "balance": [],
      "removed": [
        "The Quality (auto) row under Screen & device"
      ]
    },
    {
      "v": "1.46",
      "date": "2026-11-19",
      "title": "Stats live with saves now",
      "summary": "The Stats button and sheet under More are gone; stats moved into Saves and follow the save groups, one line per mode: Debt follows the selected tier, Classic / Casual / Zen each get a line like \"Debt · Easy · 5 games · 3,200 pts\". Stats are now counted per mode too (the old totals are still there).",
      "added": [
        "Stats counted per mode, matching the one-save-per-mode layout"
      ],
      "changed": [
        "Saves: each mode shows its own games-played and best score"
      ],
      "balance": [],
      "removed": [
        "The Stats button and sheet under More"
      ]
    },
    {
      "v": "1.45",
      "date": "2026-11-19",
      "title": "Device detection moved to the background",
      "summary": "The Device (auto) rows (screen / game window / refresh rate) and the Detect again button are gone. Detection still runs by itself — once at boot and once each time you open Settings — and only feeds the stored resolution and refresh rate used by the small line under Frame rate.",
      "added": [],
      "changed": [
        "Device detection no longer takes up space in Settings; it just runs in the background"
      ],
      "balance": [],
      "removed": [
        "The Device (auto) rows and the Detect again button"
      ]
    },
    {
      "v": "1.44",
      "date": "2026-11-19",
      "title": "Muted phones switch to text hints",
      "summary": "The Test sound / Heard it / No sound row is gone. Every 15 seconds the page asks the shell for the system media volume: if it is 0 (or the phone is silent) corner text hints take over for warnings and rotations, and they switch back when the volume returns. Settings now shows a read-only System volume line. Without the 1.8 shell it just follows the sound switch.",
      "added": [
        "Reads the system media volume: muted phones switch to text hints (needs the 1.8 shell)"
      ],
      "changed": [
        "Settings → Sound: the test row is replaced by a read-only system volume line"
      ],
      "balance": [],
      "removed": [
        "The Test sound / Heard it / No sound troubleshooting UI"
      ]
    },
    {
      "v": "1.43",
      "date": "2026-11-19",
      "title": "Advanced panel removed",
      "summary": "The Advanced drawer only had one useful thing: host address and room code. Hosting is already covered by Quick match, and the confirm card offers Host my own. The drawer is gone; a small Enter address line replaces it for the PC-host case or when the router blocks broadcast. The Host-a-room button is gone too.",
      "added": [],
      "changed": [
        "Multiplayer: Advanced → Enter address (address + room code + Join only)"
      ],
      "balance": [],
      "removed": [
        "The Host-a-room button (Quick match opens a room when nobody is hosting)"
      ]
    },
    {
      "v": "1.42",
      "date": "2026-11-19",
      "title": "Bluetooth entry is visible again",
      "summary": "Bluetooth was invisible in the multiplayer screen: an old style kept hiding several buttons unless an \"advanced\" class was on the body, but the switch that set it was deleted long ago. So Bluetooth, Last opponent, Copy download link and Send APK were hidden forever. The style is gone and Bluetooth is now its own first-level button.",
      "added": [],
      "changed": [
        "Multiplayer: Bluetooth is a first-level button (2 players), no need to open Advanced first"
      ],
      "balance": [],
      "removed": [
        "The old style that permanently hid the Bluetooth button and friends"
      ]
    },
    {
      "v": "1.41",
      "date": "2026-11-19",
      "title": "Retry when the mirror is slow",
      "summary": "Measured on the tablet, the mirror opens but needs 3-5 s cold (1.5 s DNS + 2.5 s TLS) while the APK only waits 3 s to connect, so the first check was often treated as a timeout and reported \"check failed\". Network failures now retry twice (1.2 s apart, by then DNS and TLS are warm) without flashing a failure message in between.",
      "added": [
        "Automatic retry (up to two) when the update check fails on the network, without a failure toast in between"
      ],
      "changed": [
        "The failure notice only appears if both retries fail"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.40",
      "date": "2026-11-19",
      "title": "Removed the dead download link",
      "summary": "The GitHub raw link was still offered in the update options even though it does not open on phones, so it is gone: the APK prompt and How-to-update now have a single mirror copy button, and the built-in update sources are just the two mirrors. A dead URL stored in the shell is cleared on startup, so it stops showing up in Set update URL and stops costing a timeout on every check.",
      "added": [],
      "changed": [
        "How-to-update and the APK prompt: one mirror copy button only",
        "Built-in update sources are only the gh-proxy / ghproxy.net mirrors",
        "A dead update URL stored in the shell is cleared on startup"
      ],
      "balance": [],
      "removed": [
        "The GitHub raw button and the built-in raw.githubusercontent source"
      ]
    },
    {
      "v": "1.39",
      "date": "2026-11-19",
      "title": "Mirror first for downloads",
      "summary": "The GitHub raw link fails to open on phones in China, so the mirror is now the default: the copy button in the update prompt and in How-to-update both hand out the gh-proxy link, and the GitHub link stays as a small fallback button. The update check also tries GitHub-style sources last instead of burning a 3-second timeout first.",
      "added": [
        "Download link defaults to the mirror (gh-proxy); the GitHub link is a fallback button"
      ],
      "changed": [
        "Update check: GitHub-style sources go last, mirror first",
        "The update-URL field now hints the current mirror address"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.38",
      "date": "2026-11-19",
      "title": "2-4 players, nicknames, no room codes",
      "summary": "Wi-Fi matches go from two players to 2/3/4 seats: seats get numbers, the lobby lists everyone with their web bundle version, and the host taps Start once everyone is in. No more typing room codes — Quick match finds a room and asks you to confirm host, player count and version first. Every player gets a nickname (default 玩家417, sent only to that room).",
      "added": [
        "Wi-Fi 2/3/4 player parallel and battle (battle hits the next seat)",
        "Nicknames: default 玩家417, up to 8 characters, only shared inside the room",
        "Lobby roster: who is here, who is not ready, whose bundle is older",
        "Quick-match confirm card: host, player count, version",
        "3-4 players: after you are out you wait on the board, then everyone is ranked by score"
      ],
      "changed": [
        "Multiplayer panel is now nickname / players / rules / mode / Quick match; address and room code moved into Advanced",
        "The host taps Start — no more auto-start when the room fills",
        "An older bundle on any seat blocks the host's Start button"
      ],
      "balance": [],
      "removed": [
        "The separate Join-by-hand row (now inside Advanced)"
      ]
    },
    {
      "v": "1.37",
      "date": "2026-11-18",
      "title": "Spectate title centred",
      "summary": "Spectate has only a Back button, so the title was pushed right; a matching spacer on the right centres it again.",
      "added": [],
      "changed": [
        "Spectate top bar: title centred"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.36",
      "date": "2026-11-18",
      "title": "Spectate centred, bar full width",
      "summary": "The spectate canvas used to be pushed right by the key-area padding and the Back button sat mid-screen; spectate is centred now, and the top bar spans the full width in every mode (Back top-left, Pause top-right). Spectate scores use the compact form so they no longer overlap the round title.",
      "added": [],
      "changed": [
        "Spectate: stage padding removed, canvas centred, compact scores",
        "All modes: top bar spans the full width, Back top-left / Pause top-right"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.35",
      "date": "2026-11-17",
      "title": "No more v0.3 placeholder",
      "summary": "The hardcoded v0.3 placeholders are gone (now a dash), so a script that fails to boot no longer looks like an ancient version.",
      "added": [],
      "changed": [
        "Home/More version placeholder changed from v0.3 to a dash"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.34",
      "date": "2026-11-17",
      "title": "Selectors fixed for good",
      "summary": "The previous fix turned $ into $$ by mistake, breaking the UI script again (version fell back to v0.3). Rewritten by rule: every forEach selector queries all nodes, and $$ is forbidden; the pre-release check blocks both.",
      "added": [],
      "changed": [
        "Fixed the $$ over-replacement",
        "Pre-release check now rejects $$ and single-$ forEach"
      ],
      "balance": [],
      "removed": []
    }
  ],




  };
})();
