/* engine.js —— 合体债 · 游戏本体逻辑
 *
 * 只做规则，不碰 DOM。浏览器里挂 window.TetrisEngine，Node 里 require 得到同一份。
 * 规则书：SPEC.md（第十一代的数值表在 CONST 里，改这里就够了）。
 *
 * 渲染层只读这些字段：
 *   board      10×10，格 null | {k:'n',t:'I'} | {k:'f',g:1,l:'T'} | {k:'p'}
 *   piece      {type,dir,rot,x,y} 或 null
 *   queue      接下来 5 个 {t,d}
 *   hold       {t,d} 或 null；canHold
 *   score lockLevel clears debt initialDebt grace pendingFusion
 *   rotTimer status carryDebt
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.TetrisEngine = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const CONST = {
    COLS: 10, ROWS: 10, CELL: 32,
    FALL_MS: 1000,          // 下落一格
    LOCK_MS: 1000,          // 落地后锁死
    LOCK_MOVE_RESET: 15,    // 最多重置次数
    DAS_MS: 170, ARR_MS: 30,
    SOFT_DROP_PER_SEC: 20,
    ROTATE_MS: 15000,       // 场地旋转周期
    ROTATE_WARN_MS: 1500,
    SCORE_PER_LINE: 600,
    SCORE_PER_CLEAR: 600,
    FUSION_ROWS: 2,
    FUSION_HOLES: [1, 2],
    FUSION_DELAY_MS: 1000,
    DEBT_PER_ROW: 100,
    DEBT_MAX_PER_CLEAR: 300,
    PERM_ROWS: 4,
    GRACE_CLEARS: 50,
    MORPH_AT_CLEARS: 100,
    ARROW_SCORE_GATE: 1000, // 分数到这个数才出方向块
    ARROW_EVERY: 8,         // 之后每 8 块掺 1 块
    SAVE_VERSION: 1
  };

  const TYPES = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];
  const DIRS = ['up', 'down', 'left', 'right'];

  /* n = 旋转用的方框边长；cells 是方框里的坐标 */
  const SHAPES = {
    I: { n: 4, cells: [[0, 1], [1, 1], [2, 1], [3, 1]] },
    O: { n: 2, cells: [[0, 0], [1, 0], [0, 1], [1, 1]] },
    T: { n: 3, cells: [[0, 0], [1, 0], [2, 0], [1, 1]] },
    S: { n: 3, cells: [[1, 0], [2, 0], [0, 1], [1, 1]] },
    Z: { n: 3, cells: [[0, 0], [1, 0], [1, 1], [2, 1]] },
    J: { n: 3, cells: [[0, 0], [0, 1], [1, 1], [2, 1]] },
    L: { n: 3, cells: [[2, 0], [0, 1], [1, 1], [2, 1]] },
    ARROW: { n: 1, cells: [[0, 0]] }
  };

  const COLORS = {
    I: '#3ee0c6', O: '#ffc857', T: '#b07cff', S: '#5bd75b',
    Z: '#ff5c6c', J: '#4f8cff', L: '#ff9f43', ARROW: '#f2f5ff'
  };

  /* ---------------- 小工具 ---------------- */

  function emptyRow(cols) { return new Array(cols || CONST.COLS).fill(null); }
  function emptyBoard(cols, rows) {
    const b = [];
    for (let y = 0; y < (rows || CONST.ROWS); y++) b.push(emptyRow(cols));
    return b;
  }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  function rotateCells(cells, n) {
    const out = [];
    for (let i = 0; i < cells.length; i++) {
      out.push([n - 1 - cells[i][1], cells[i][0]]);
    }
    return out;
  }

  /* mulberry32：同一个种子，出块顺序完全一样 */
  function Rng(seed) {
    this.a = (seed >>> 0);
  }
  Rng.prototype.next = function () {
    this.a = (this.a + 0x6D2B79F5) | 0;
    let t = Math.imul(this.a ^ (this.a >>> 15), 1 | this.a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };

  function fmtScore(n) {
    return n >= 1000 ? '999+' : String(n);
  }

  /* ---------------- 游戏 ---------------- */

  function Tetris(opts) {
    opts = opts || {};
    this.seed = (typeof opts.seed === 'number' && isFinite(opts.seed))
      ? (opts.seed >>> 0)
      : ((Date.now() ^ Math.floor(Math.random() * 0xFFFFFFFF)) >>> 0);
    this.rng = new Rng(this.seed);
    this.classic = !!opts.classic;
    this.cols = opts.cols || CONST.COLS;
    this.rows = opts.rows || (this.classic ? CONST.ROWS * 2 : CONST.ROWS);
    // 场地自动旋转（15 秒转 90°）：默认开，游戏里按设置关掉
    this.rotateEnabled = opts.rotate !== false && !this.classic;
    this.reset(Math.max(0, (opts.carryDebt | 0)));
  }

  Tetris.prototype.reset = function (carryDebt) {
    this.board = emptyBoard(this.cols, this.rows);
    this.score = 0;
    this.lockLevel = 0;
    this.clears = 0;
    this.level = 1;
    this.lines = 0;
    this.debt = this.classic ? 0 : Math.max(0, carryDebt | 0);
    this.initialDebt = this.debt;
    this.grace = 0;
    this.hold = null;
    this.canHold = true;
    this.bag = [];
    this.lastType = null;
    this.queue = [];
    this.piece = null;
    this.status = 'playing';
    this.reason = '';
    this.carryDebt = 0;

    this.time = 0;
    this.fallTimer = 0;
    this.softAcc = 0;
    this.lockTimer = 0;
    this.lockResets = 0;
    this.rotTimer = 0;
    this.rotWarned = false;
    this.softDrop = false;
    this.suppressFusion = false;
    this.noGravity = false;

    this.pendingFusion = 0;
    this.fusionTimer = 0;
    this.prevHoles = null;
    this.groupId = 0;

    this.arrowUnlocked = false;
    this.arrowCountdown = 0;
    this.debtHighFired = false;

    this.events = [];

    if (this.debt > 0) this.placePermStart();
    this.ensureQueue();
    this.spawnPiece();
  };

  /* ---------- 出块 ---------- */

  Tetris.prototype.drawType = function () {
    if (!this.bag.length) {
      const bag = TYPES.slice();
      for (let i = bag.length - 1; i > 0; i--) {
        const j = Math.floor(this.rng.next() * (i + 1));
        const t = bag[i]; bag[i] = bag[j]; bag[j] = t;
      }
      // 7-bag 跨袋时可能首尾同块；换掉第一张，保证不会连着来两个同样的块
      if (bag[0] === this.lastType) {
        const j = 1 + Math.floor(this.rng.next() * (bag.length - 1));
        const t = bag[0]; bag[0] = bag[j]; bag[j] = t;
      }
      this.bag = bag;
    }
    const t = this.bag.shift();
    this.lastType = t;
    return t;
  };

  Tetris.prototype.makeEntry = function () {
    const t = this.drawType();
    let e = { t: t, d: null };
    if (this.arrowUnlocked) {
      this.arrowCountdown -= 1;
      if (this.arrowCountdown <= 0) {
        e = { t: 'ARROW', d: DIRS[Math.floor(this.rng.next() * DIRS.length)] };
        this.arrowCountdown = 1 + Math.floor(this.rng.next() * CONST.ARROW_EVERY);
      }
    }
    return e;
  };

  Tetris.prototype.ensureQueue = function () {
    while (this.queue.length < 5) this.queue.push(this.makeEntry());
  };

  Tetris.prototype.spawnX = function (type) {
    if (type === 'I') return 3;
    if (type === 'O') return 4;
    if (type === 'ARROW') return 4;
    return 3;
  };

  Tetris.prototype.spawnPiece = function (entry) {
    if (this.status !== 'playing') return;
    let e = entry;
    if (!e) {
      e = this.queue.shift();
      this.ensureQueue();
    }
    if (!e) return;
    const p = (e.t === 'ARROW')
      ? { type: 'ARROW', dir: e.d || 'up', rot: 0, x: 4, y: 0 }
      : { type: e.t, dir: null, rot: 0, x: this.spawnX(e.t), y: 0 };
    if (this.collides(p)) { this.gameOver('blockout'); return; }
    this.piece = p;
    this.fallTimer = 0;
    this.softAcc = 0;
    this.lockTimer = 0;
    this.lockResets = 0;
    this.events.push({ type: 'spawn', piece: p.type });
  };

  /* ---------- 几何 ---------- */

  Tetris.prototype.pieceCells = function (p) {
    p = p || this.piece;
    if (!p) return [];
    const s = SHAPES[p.type];
    let cells = s.cells;
    let rot = ((p.rot || 0) % 4 + 4) % 4;
    for (let i = 0; i < rot; i++) cells = rotateCells(cells, s.n);
    const out = [];
    for (let i = 0; i < cells.length; i++) out.push([p.x + cells[i][0], p.y + cells[i][1]]);
    return out;
  };

  Tetris.prototype.collides = function (p) {
    const cells = this.pieceCells(p);
    for (let i = 0; i < cells.length; i++) {
      const x = cells[i][0], y = cells[i][1];
      if (x < 0 || x >= this.cols || y < 0 || y >= this.rows) return true;
      if (this.board[y][x]) return true;
    }
    return false;
  };

  Tetris.prototype.isGrounded = function () {
    if (!this.piece) return false;
    const p = this.piece;
    return this.collides({ type: p.type, rot: p.rot, x: p.x, y: p.y + 1 });
  };

  Tetris.prototype.stepDown = function (resetLock) {
    if (!this.piece) return false;
    const p = this.piece;
    if (this.collides({ type: p.type, rot: p.rot, x: p.x, y: p.y + 1 })) return false;
    p.y += 1;
    this.fallTimer = 0;
    this.softAcc = 0;
    if (resetLock !== false) {
      this.lockTimer = 0;
      this.lockResets = 0;
    }
    return true;
  };

  /* 玩家动一下：落地状态下重新计时，最多 15 次 */
  Tetris.prototype.afterAction = function () {
    if (!this.isGrounded()) return;
    if (this.lockResets < CONST.LOCK_MOVE_RESET) {
      this.lockTimer = 0;
      this.lockResets += 1;
    }
  };

  Tetris.prototype.move = function (dx) {
    if (this.status !== 'playing' || !this.piece || !dx) return false;
    const p = this.piece;
    if (this.collides({ type: p.type, rot: p.rot, x: p.x + dx, y: p.y })) return false;
    p.x += dx;
    this.afterAction();
    this.events.push({ type: 'move' });
    return true;
  };

  /* 顺时针 / 逆时针；墙踢：左右各一格，再往上一格 */
  Tetris.prototype.rotate = function (dir) {
    if (this.status !== 'playing' || !this.piece) return false;
    const p = this.piece;
    if (p.type === 'ARROW') return false; // 单格转了没意义
    const n = SHAPES[p.type].n;
    const rot = ((p.rot + (dir < 0 ? 3 : 1)) % 4 + 4) % 4;
    const kicks = [[0, 0], [-1, 0], [1, 0], [0, -1]];
    for (let i = 0; i < kicks.length; i++) {
      const x = p.x + kicks[i][0], y = p.y + kicks[i][1];
      if (x < 0 || x > this.cols - n || y < 0 || y > this.rows - n) continue;
      const cand = { type: p.type, rot: rot, x: x, y: y };
      if (!this.collides(cand)) {
        p.rot = rot; p.x = x; p.y = y;
        this.afterAction();
        this.events.push({ type: 'rotate' });
        return true;
      }
    }
    return false;
  };

  Tetris.prototype.setSoftDrop = function (on) {
    this.softDrop = !!on;
  };

  Tetris.prototype.hardDrop = function () {
    if (this.status !== 'playing' || !this.piece) return 0;
    let n = 0;
    while (this.stepDown(false)) n++;
    this.lockPiece();
    return n;
  };

  /* 暂存：一块只能换一次，落地后刷新 */
  Tetris.prototype.holdPiece = function () {
    if (this.status !== 'playing' || !this.piece || !this.canHold) return false;
    const cur = { t: this.piece.type, d: this.piece.dir || null };
    this.canHold = false;
    this.piece = null;
    if (this.hold) {
      const h = this.hold;
      this.hold = cur;
      this.spawnPiece(h);
    } else {
      this.hold = cur;
      this.spawnPiece();
    }
    this.events.push({ type: 'hold' });
    return true;
  };

  /* ---------- 锁定 ---------- */

  Tetris.prototype.lockPiece = function () {
    if (this.status !== 'playing' || !this.piece) return;
    const p = this.piece;

    if (p.type === 'ARROW') {
      this.applyArrow(p);
      this.piece = null;
      this.canHold = true;
      this.spawnPiece();
      this.events.push({ type: 'lock', arrow: true });
      return;
    }

    const cells = this.pieceCells(p);
    for (let i = 0; i < cells.length; i++) {
      const x = cells[i][0], y = cells[i][1];
      this.board[y][x] = { k: 'n', t: p.type };
    }
    this.piece = null;
    this.canHold = true;
    this.events.push({ type: 'place', piece: p.type });

    const rows = this.fullRows();
    if (rows.length) this.clearRows(rows);

    this.spawnPiece();
    this.events.push({ type: 'lock' });
  };

  /* 方向块：只抹箭头那一侧的一条线 */
  Tetris.prototype.applyArrow = function (p) {
    const cells = [];
    if (p.dir === 'up') {
      for (let y = 0; y <= p.y; y++) cells.push([p.x, y]);
    } else if (p.dir === 'down') {
      for (let y = p.y; y < this.rows; y++) cells.push([p.x, y]);
    } else if (p.dir === 'left') {
      for (let x = 0; x <= p.x; x++) cells.push([x, p.y]);
    } else {
      for (let x = p.x; x < this.cols; x++) cells.push([x, p.y]);
    }

    let touchedDebt = false;
    for (let i = 0; i < cells.length; i++) {
      const x = cells[i][0], y = cells[i][1];
      const c = this.board[y][x];
      if (c && (c.k === 'f' || c.k === 'p')) touchedDebt = true;
      this.board[y][x] = null;
    }
    this.settle(); // 抹一行，上面的照常往下掉

    this.events.push({ type: 'arrowWipe', dir: p.dir });

    // 方向块自己算一次消行动作：+600、等级 +1
    this.doClearAction({ lines: 0, debtRows: touchedDebt ? 1 : 0, event: { type: 'arrowClear', dir: p.dir } });

    // 抹完照常判新的满行
    if (this.status === 'playing') {
      const rows = this.fullRows();
      if (rows.length) this.clearRows(rows);
    }
  };

  /* ---------- 消行 ---------- */

  Tetris.prototype.fullRows = function () {
    const rows = [];
    for (let y = 0; y < this.rows; y++) {
      let full = true;
      for (let x = 0; x < this.cols; x++) { if (!this.board[y][x]) { full = false; break; } }
      if (full) rows.push(y);
    }
    return rows;
  };

  Tetris.prototype.countDebtRows = function (rows) {
    let n = 0;
    for (let i = 0; i < rows.length; i++) {
      const row = this.board[rows[i]];
      for (let x = 0; x < this.cols; x++) {
        const c = row[x];
        if (c && (c.k === 'f' || c.k === 'p')) { n++; break; }
      }
    }
    return n;
  };

  Tetris.prototype.clearRows = function (rows) {
    if (!rows || !rows.length || this.status !== 'playing') return;
    const debtRows = this.countDebtRows(rows);
    const lines = rows.length;

    const sorted = rows.slice().sort(function (a, b) { return b - a; });
    for (let i = 0; i < sorted.length; i++) this.board.splice(sorted[i], 1);
    for (let i = 0; i < lines; i++) this.board.unshift(emptyRow(this.cols));

    this.doClearAction({
      lines: lines,
      debtRows: debtRows,
      event: { type: 'lineClear', lines: lines, rows: rows.slice() }
    });
  };

  /* 一次消行动作的公共部分：分数、等级、债、奖励期、顶块排期 */
  Tetris.prototype.doClearAction = function (o) {
    const lines = o.lines || 0;
    const debtRows = o.debtRows || 0;
    const beforeDebt = this.debt;

    // 原版模式：标准计分（1/2/3/4 行 = 100/300/500/800 × 等级），没有债/合体块
    if (this.classic) {
      const table = [0, 100, 300, 500, 800];
      this.score += (table[lines] || 0) * this.level;
      this.lines += lines;
      this.level = 1 + Math.floor(this.lines / 10);
      this.events.push(o.event || { type: 'clear' });
      this.events.push({ type: 'score', score: this.score });
      return;
    }

    this.score += lines * CONST.SCORE_PER_LINE + CONST.SCORE_PER_CLEAR;
    this.lockLevel += 1;
    this.clears += 1;
    this.events.push(o.event || { type: 'clear' });
    this.events.push({ type: 'score', score: this.score });

    if (debtRows > 0 && this.debt > 0) {
      this.debt = Math.max(0,
        this.debt - Math.min(CONST.DEBT_MAX_PER_CLEAR, debtRows * CONST.DEBT_PER_ROW));
    }

    let justPaid = false;
    if (beforeDebt > 0 && this.debt === 0) {
      this.payOffDebt();
      justPaid = true;
    } else if (this.debt > 0 && this.permRows() === 0) {
      this.refillPerm();
    }

    if (this.status !== 'playing') return;

    if (this.grace > 0) {
      if (!justPaid) {
        this.grace -= 1;
        if (this.grace === 0) this.events.push({ type: 'graceOver' });
      }
    } else if (!this.suppressFusion) {
      // 还债期也顶块：常驻块钉在底下，新块从它上面塞进来
      this.pendingFusion += 1;
    }

    this.checkScoreGate();
  };

  Tetris.prototype.checkScoreGate = function () {
    if (this.classic) return;
    if (this.arrowUnlocked || this.score < CONST.ARROW_SCORE_GATE) return;
    this.arrowUnlocked = true;
    this.arrowCountdown = 1 + Math.floor(this.rng.next() * CONST.ARROW_EVERY);
    this.ensureQueue();
    const dir = DIRS[Math.floor(this.rng.next() * DIRS.length)];
    if (this.queue.length) this.queue[0] = { t: 'ARROW', d: dir };
    this.events.push({ type: 'arrowUnlock', dir: dir });
  };

  /* ---------- 债 / 常驻块 ---------- */

  Tetris.prototype.permRows = function () {
    let n = 0;
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        const c = this.board[y][x];
        if (c && c.k === 'p') { n++; break; }
      }
    }
    return n;
  };

  Tetris.prototype.liveFusionRows = function () {
    let n = 0;
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        const c = this.board[y][x];
        if (c && c.k === 'f') { n++; break; }
      }
    }
    return n;
  };

  Tetris.prototype.randomHoles = function (maxHoles, rows) {
    const count = 1 + Math.floor(this.rng.next() * maxHoles);
    const used = {};
    const holes = [];
    while (holes.length < count) {
      const x = Math.floor(this.rng.next() * this.cols);
      const y = Math.floor(this.rng.next() * rows);
      const key = x + ':' + y;
      if (used[key]) continue;
      used[key] = 1;
      holes.push([x, y]);
    }
    return holes;
  };

  function sameHoles(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    const ka = a.map(function (h) { return h[0] + ':' + h[1]; }).sort().join('|');
    const kb = b.map(function (h) { return h[0] + ':' + h[1]; }).sort().join('|');
    return ka === kb;
  }

  /* 顶上来的一块：普通 2 行 1~2 洞；第 100 次消行后是字母块 */
  Tetris.prototype.makeFusion = function () {
    const morph = this.clears >= CONST.MORPH_AT_CLEARS;
    const maxHoles = this.clears >= CONST.MORPH_AT_CLEARS * 2 ? 1 : 2;
    let letter = null;
    let nrows = CONST.FUSION_ROWS;
    let holes = null;
    let fixed = false;

    if (morph) {
      letter = TYPES[Math.floor(this.rng.next() * TYPES.length)];
      if (letter === 'I') {
        nrows = 1;
        holes = this.randomHoles(1, 1);
      } else if (letter === 'O') {
        nrows = 2;
        holes = [[4, 0], [5, 0], [4, 1], [5, 1]];
        fixed = true;
      } else {
        nrows = 2;
        holes = this.randomHoles(maxHoles, nrows);
      }
    } else {
      holes = this.randomHoles(2, 2);
    }

    // 相邻两次的洞要错开（O 是固定形状，不参与）
    if (!fixed) {
      for (let i = 0; i < 20 && sameHoles(holes, this.prevHoles); i++) {
        holes = this.randomHoles(morph && letter === 'I' ? 1 : maxHoles, nrows);
      }
    }
    this.prevHoles = holes;

    const gid = (this.groupId += 1);
    const rows = [];
    for (let y = 0; y < nrows; y++) {
      const row = [];
      for (let x = 0; x < this.cols; x++) row.push({ k: 'f', g: gid, l: letter });
      rows.push(row);
    }
    for (let i = 0; i < holes.length; i++) {
      const hx = holes[i][0], hy = holes[i][1];
      if (rows[hy] && hx >= 0 && hx < this.cols) rows[hy][hx] = null;
    }
    return { rows: rows, letter: letter, holes: holes };
  };

  Tetris.prototype.topBusy = function (n) {
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < this.cols; x++) if (this.board[y][x]) return true;
    }
    return false;
  };

  /* 把新行塞到底部，场上所有东西往上推 */
  Tetris.prototype.insertBottomRows = function (rows) {
    const n = rows.length;
    this.board = this.board.slice(n).concat(rows);
    if (this.piece) {
      this.piece.y -= n;
      if (this.piece.y < 0) this.piece.y = 0;
      if (this.collides(this.piece)) this.fitPiece();
    }
  };

  Tetris.prototype.spawnFusion = function () {
    if (this.status !== 'playing') return;
    const block = this.makeFusion();
    const n = block.rows.length;
    const topPerm = this.topPermRow();
    if (topPerm < n || this.topBusy(n)) { this.gameOver('topout'); return; }

    const next = emptyBoard();
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        const c = this.board[y][x];
        if (!c) continue;
        if (c.k === 'p') {
          next[y][x] = c;                 // 常驻块钉在原地
        } else if (y < topPerm) {
          if (y - n >= 0) next[y - n][x] = c;  // 上面的东西往上推
        } else {
          next[y][x] = c;                 // 常驻块洞里的方块不动
        }
      }
    }
    for (let i = 0; i < n; i++) next[topPerm - n + i] = block.rows[i];

    this.board = next;

    if (this.piece) {
      if (this.piece.y < topPerm) {
        this.piece.y -= n;
        if (this.piece.y < 0) this.piece.y = 0;
      }
      if (this.collides(this.piece)) this.fitPiece();
    }

    this.events.push({ type: 'fusion', letter: block.letter, rows: n });
  };

  Tetris.prototype.topPermRow = function () {
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        const c = this.board[y][x];
        if (c && c.k === 'p') return y;
      }
    }
    return this.rows;
  };

  Tetris.prototype.makePermRows = function (count) {
    const rows = [];
    for (let i = 0; i < count; i++) {
      const row = [];
      const holes = 1 + Math.floor(this.rng.next() * 2);
      const used = {};
      for (let x = 0; x < this.cols; x++) row.push({ k: 'p' });
      while (Object.keys(used).length < holes) {
        const x = Math.floor(this.rng.next() * this.cols);
        if (used[x]) continue;
        used[x] = 1;
        row[x] = null;
      }
      rows.push(row);
    }
    return rows;
  };

  Tetris.prototype.placePermStart = function () {
    const rows = this.makePermRows(CONST.PERM_ROWS);
    for (let i = 0; i < rows.length; i++) {
      this.board[this.rows - CONST.PERM_ROWS + i] = rows[i];
    }
  };

  Tetris.prototype.refillPerm = function () {
    if (this.debt <= 0) return;
    if (this.topBusy(CONST.PERM_ROWS)) { this.gameOver('topout'); return; }
    const rows = this.makePermRows(CONST.PERM_ROWS);
    this.insertBottomRows(rows);
    this.events.push({ type: 'permRefill' });
  };

  Tetris.prototype.payOffDebt = function () {
    this.debt = 0;
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        const c = this.board[y][x];
        if (c && c.k === 'p') this.board[y][x] = null;
      }
    }
    this.settle();
    this.grace = CONST.GRACE_CLEARS;
    this.events.push({ type: 'debtCleared' });
  };

  /* ---------- 落沙 / 转场 ---------- */

  /* 普通落沙（没有常驻块挡着） */
  Tetris.prototype.settle = function () {
    for (let x = 0; x < this.cols; x++) {
      let write = this.rows - 1;
      for (let y = this.rows - 1; y >= 0; y--) {
        const c = this.board[y][x];
        if (!c) continue;
        if (c.k === 'p') { write = y - 1; continue; }
        if (write !== y) {
          this.board[write][x] = c;
          this.board[y][x] = null;
        }
        write -= 1;
      }
    }
  };

  Tetris.prototype.segmentsOf = function (board, x) {
    const segs = [];
    let start = 0;
    for (let y = 0; y < this.rows; y++) {
      const c = board[y][x];
      if (c && c.k === 'p') {
        if (y > start) segs.push([start, y - 1]);
        start = y + 1;
      }
    }
    if (start < this.rows) segs.push([start, this.rows - 1]);
    return segs;
  };

  /* 场地顺时针转 90°，然后落沙；常驻块不转，压到它上面就停 */
  Tetris.prototype.rotateField = function () {
    if (this.status !== 'playing') return;
    const old = this.board.map(function (row) { return row.slice(); });
    const grid = emptyBoard();
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        const c = old[y][x];
        if (c && c.k !== 'p') grid[x][this.rows - 1 - y] = c;
      }
    }

    const next = emptyBoard();
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        const c = old[y][x];
        if (c && c.k === 'p') next[y][x] = c;
      }
    }

    for (let x = 0; x < this.cols; x++) {
      const segs = this.segmentsOf(old, x);
      const buckets = segs.map(function () { return []; });
      for (let y = 0; y < this.rows; y++) {
        const c = grid[y][x];
        if (!c) continue;
        let idx = -1;
        for (let i = 0; i < segs.length; i++) {
          if (y >= segs[i][0] && y <= segs[i][1]) { idx = i; break; }
        }
        if (idx < 0) {
          // 转到了常驻块的位置：往上找最近的空段
          let best = -1, bestEnd = -1;
          for (let i = 0; i < segs.length; i++) {
            if (segs[i][1] < y && segs[i][1] > bestEnd) { bestEnd = segs[i][1]; best = i; }
          }
          if (best < 0) {
            let bestStart = Infinity;
            for (let i = 0; i < segs.length; i++) {
              if (segs[i][0] > y && segs[i][0] < bestStart) { bestStart = segs[i][0]; best = i; }
            }
          }
          idx = Math.max(0, best);
        }
        buckets[idx].push({ y: y, c: c });
      }
      for (let i = 0; i < segs.length; i++) {
        const seg = segs[i];
        const list = buckets[i].slice().sort(function (a, b) { return b.y - a.y; });
        let row = seg[1];
        for (let j = 0; j < list.length; j++) {
          if (row < seg[0]) break;
          next[row][x] = list[j].c;
          row -= 1;
        }
      }
    }

    this.board = next;

    if (this.piece) {
      const p = this.piece;
      const n = SHAPES[p.type].n;
      const nx = clamp(this.rows - p.y - n, 0, this.cols - n);
      const ny = clamp(p.x, 0, this.rows - n);
      p.rot = (p.rot + 1) % 4;
      p.x = nx;
      p.y = ny;
      if (this.collides(p)) this.fitPiece();
      if (this.isGrounded()) this.afterAction();
    }

    this.events.push({ type: 'fieldRotate' });

    const rows = this.fullRows();
    if (rows.length) this.clearRows(rows);
  };

  /* 给当前块找个能放下的位置：先往上让，再左右让，最后全盘扫 */
  Tetris.prototype.fitsAt = function (rot, x, y) {
    if (!this.piece) return false;
    const n = SHAPES[this.piece.type].n;
    if (x < 0 || x > this.cols - n || y < 0 || y > this.rows - n) return false;
    return !this.collides({ type: this.piece.type, rot: rot, x: x, y: y });
  };

  Tetris.prototype.fitPiece = function () {
    if (!this.piece) return false;
    const p = this.piece;
    const n = SHAPES[p.type].n;
    const startX = clamp(p.x, 0, this.cols - n);
    const startY = clamp(p.y, 0, this.rows - n);
    for (let d = 0; d <= this.rows; d++) {
      const y = startY - d;
      const xs = [startX, startX - 1, startX + 1];
      for (let i = 0; i < xs.length; i++) {
        if (this.fitsAt(p.rot, xs[i], y)) { p.x = xs[i]; p.y = y; return true; }
      }
    }
    for (let y = 0; y <= this.rows - n; y++) {
      for (let x = 0; x <= this.cols - n; x++) {
        if (this.fitsAt(p.rot, x, y)) { p.x = x; p.y = y; return true; }
      }
    }
    this.gameOver('blockout');
    return false;
  };

  /* ---------- 时间推进 ---------- */

  Tetris.prototype.fallInterval = function () {
    if (!this.classic) return CONST.FALL_MS;
    return Math.max(80, 1000 - (this.level - 1) * 80);
  };

  Tetris.prototype.tick = function (dt) {
    if (this.status !== 'playing') return;
    dt = Math.max(0, Math.min(dt || 0, 1000));
    if (!dt) return;
    this.time += dt;

    // 15 秒转场（设置里可以关掉；关掉后 rotTimer 不推进）
    if (this.rotateEnabled) {
      this.rotTimer += dt;
      if (!this.rotWarned && this.rotTimer >= CONST.ROTATE_MS - CONST.ROTATE_WARN_MS) {
        this.rotWarned = true;
        this.events.push({ type: 'rotateSoon' });
      }
      if (this.rotTimer >= CONST.ROTATE_MS) {
        this.rotTimer -= CONST.ROTATE_MS;
        this.rotWarned = false;
        this.rotateField();
        if (this.status !== 'playing') return;
      }
    }

    // 排队的合体块：每 1 秒顶一块
    if (this.pendingFusion > 0) {
      this.fusionTimer += dt;
      while (this.pendingFusion > 0 && this.fusionTimer >= CONST.FUSION_DELAY_MS) {
        this.fusionTimer -= CONST.FUSION_DELAY_MS;
        this.pendingFusion -= 1;
        this.spawnFusion();
        if (this.status !== 'playing') return;
      }
    }

    if (!this.piece) return;
    if (this.noGravity) return;

    if (this.isGrounded()) {
      this.lockTimer += dt;
      if (this.lockTimer >= CONST.LOCK_MS) this.lockPiece();
    } else {
      this.lockTimer = 0;
      this.fallTimer += dt;
      let steps = Math.floor(this.fallTimer / this.fallInterval());
      while (steps > 0) {
        this.fallTimer -= this.fallInterval();
        if (!this.stepDown(true)) { this.fallTimer = 0; break; }
        steps -= 1;
      }
      if (this.status !== 'playing') return;
    }

    // 软降：每秒 20 格
    if (this.piece && this.softDrop) {
      this.softAcc += dt * CONST.SOFT_DROP_PER_SEC / 1000;
      while (this.softAcc >= 1) {
        this.softAcc -= 1;
        if (!this.stepDown(true)) { this.softAcc = 0; break; }
      }
    }

    // 危险的债：场地 60% 满了提醒一次
    if (!this.debtHighFired) {
      const pct = this.fieldFillPct();
      if (pct >= 60) {
        this.debtHighFired = true;
        this.events.push({ type: 'debtHigh', pct: pct });
      }
    }
  };

  Tetris.prototype.fieldFillPct = function () {
    let used = 0;
    for (let y = 0; y < this.rows; y++) {
      for (let x = 0; x < this.cols; x++) {
        if (this.board[y][x]) { used++; break; }
      }
    }
    return Math.round(used / this.rows * 100);
  };

  /* ---------- 结束 ---------- */

  Tetris.prototype.gameOver = function (reason) {
    if (this.status === 'over') return;
    this.status = 'over';
    this.reason = reason || 'topout';
    // 带走的账 = 还没还完的 + 场上还活着的合体块（每行 100）
    this.carryDebt = this.debt + this.liveFusionRows() * CONST.DEBT_PER_ROW;
    if (this.reason === 'topout') this.events.push({ type: 'topOut' });
    this.events.push({
      type: 'gameOver',
      debt: this.carryDebt,
      score: this.score,
      reason: this.reason
    });
  };

  Tetris.prototype.restart = function () {
    const carry = this.carryDebt;
    this.reset(carry);
  };

  Tetris.prototype.drainEvents = function () {
    const list = this.events;
    this.events = [];
    return list;
  };

  /* ---------- 存档 ---------- */

  Tetris.prototype.toJSON = function () {
    const board = this.board.map(function (row) {
      return row.map(function (c) {
        return c ? { k: c.k, t: c.t || null, g: c.g || 0, l: c.l || null } : null;
      });
    });
    return {
      version: CONST.SAVE_VERSION,
      classic: !!this.classic,
      cols: this.cols,
      rows: this.rows,
      level: this.level || 1,
      lines: this.lines || 0,
      seed: this.seed,
      rng: this.rng.a,
      bag: this.bag.slice(),
      lastType: this.lastType,
      board: board,
      piece: this.piece ? { type: this.piece.type, dir: this.piece.dir || null, rot: this.piece.rot, x: this.piece.x, y: this.piece.y } : null,
      queue: this.queue.map(function (e) { return { t: e.t, d: e.d || null }; }),
      hold: this.hold ? { t: this.hold.t, d: this.hold.d || null } : null,
      canHold: this.canHold,
      score: this.score,
      lockLevel: this.lockLevel,
      clears: this.clears,
      debt: this.debt,
      initialDebt: this.initialDebt,
      grace: this.grace,
      arrowUnlocked: this.arrowUnlocked,
      arrowCountdown: this.arrowCountdown,
      pendingFusion: this.pendingFusion,
      fusionTimer: this.fusionTimer,
      rotTimer: this.rotTimer,
      rotWarned: this.rotWarned,
      fallTimer: this.fallTimer,
      lockTimer: this.lockTimer,
      lockResets: this.lockResets,
      prevHoles: this.prevHoles,
      groupId: this.groupId,
      time: this.time,
      debtHighFired: this.debtHighFired
    };
  };

  /* 校验：version、盘面尺寸、格子形状。对不上就返回错误字符串 */
  function validateSave(data) {
    if (!data || typeof data !== 'object') return '不是存档对象';
    if (data.version !== CONST.SAVE_VERSION) return '存档版本不对';
    const cols = data.cols || CONST.COLS;
    const rows = data.rows || CONST.ROWS;
    if (!(cols >= 8 && cols <= 12) || !(rows >= 8 && rows <= 24)) return '盘面尺寸不对';
    if (!Array.isArray(data.board) || data.board.length !== rows) return '盘面行数不对';
    for (let y = 0; y < rows; y++) {
      const row = data.board[y];
      if (!Array.isArray(row) || row.length !== cols) return '盘面列数不对';
      for (let x = 0; x < cols; x++) {
        const c = row[x];
        if (c !== null && (typeof c !== 'object' || ['n', 'f', 'p'].indexOf(c.k) < 0)) return '格子不认识';
      }
    }
    if (typeof data.score !== 'number' || !isFinite(data.score)) return '分数不对';
    if (!data.piece || typeof data.piece.type !== 'string' || !SHAPES[data.piece.type]) return '当前块不对';
    return null;
  }

  Tetris.prototype.loadJSON = function (data) {
    const err = validateSave(data);
    if (err) return err;

    this.classic = !!data.classic;
    if (this.classic) this.rotateEnabled = false;
    this.cols = data.cols || CONST.COLS;
    this.rows = data.rows || CONST.ROWS;
    this.level = data.level || 1;
    this.lines = data.lines || 0;
    this.seed = data.seed >>> 0;
    this.rng.a = data.rng | 0;
    this.bag = Array.isArray(data.bag) ? data.bag.slice() : [];
    this.lastType = data.lastType || null;
    this.board = data.board.map(function (row) {
      return row.map(function (c) {
        return c ? { k: c.k, t: c.t || null, g: c.g || 0, l: c.l || null } : null;
      });
    });
    this.piece = data.piece ? {
      type: data.piece.type, dir: data.piece.dir || null,
      rot: data.piece.rot | 0, x: data.piece.x | 0, y: data.piece.y | 0
    } : null;
    this.queue = (data.queue || []).map(function (e) { return { t: e.t, d: e.d || null }; });
    this.hold = data.hold ? { t: data.hold.t, d: data.hold.d || null } : null;
    this.canHold = data.canHold !== false;
    this.score = data.score || 0;
    this.lockLevel = data.lockLevel || 0;
    this.clears = data.clears || 0;
    this.debt = data.debt || 0;
    this.initialDebt = data.initialDebt || this.debt;
    this.grace = data.grace || 0;
    this.arrowUnlocked = !!data.arrowUnlocked;
    this.arrowCountdown = data.arrowCountdown || 0;
    this.pendingFusion = data.pendingFusion || 0;
    this.fusionTimer = data.fusionTimer || 0;
    this.rotTimer = data.rotTimer || 0;
    this.rotWarned = !!data.rotWarned;
    this.fallTimer = data.fallTimer || 0;
    this.lockTimer = data.lockTimer || 0;
    this.lockResets = data.lockResets || 0;
    this.prevHoles = data.prevHoles || null;
    this.groupId = data.groupId || 0;
    this.time = data.time || 0;
    this.debtHighFired = !!data.debtHighFired;
    this.status = 'playing';
    this.reason = '';
    this.carryDebt = 0;
    this.softDrop = false;
    this.ensureQueue();
    return null;
  };

  return {
    Tetris: Tetris,
    CONST: CONST,
    SHAPES: SHAPES,
    COLORS: COLORS,
    TYPES: TYPES,
    DIRS: DIRS,
    fmtScore: fmtScore,
    validateSave: validateSave,
    rotateCells: rotateCells
  };
});
