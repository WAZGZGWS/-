/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '1.24',
  code: 58,
  web: 128,
  date: '2026-11-16',
  title: '浮层英文补齐 · 教程补画一帧',
  titleEn: 'Overlay English · tutorial repaint',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单/普通/困难。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard."
    }
  ],
  log: [
    {
      "v": "1.24",
      "date": "2026-11-16",
      "title": "浮层英文补齐 · 教程补画一帧",
      "summary": "英文模式下结算浮层（对局结束 / 债还不完，本局结束 / 重开 R）和对战条（你 / 对手 / 准备 / 我 / 决一死战）原来还是中文，现在补齐；继续上一局时标题里的「继续」也改了。教程打开时补画一帧，避免个别 WebView 首帧空白。",
      "added": [],
      "changed": [
        "教程打开后补画一帧 canvas（只影响首帧，不改画面内容）",
        "英文模式：结算浮层、对战条、决一死战、继续局标签（Resumed / Combo · resumed / Classic · resumed）全部英文化"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.23",
      "date": "2026-11-16",
      "title": "英文联机 · 中文漏译补全",
      "summary": "英文模式下「多人对战」抽屉里的副标题、快速匹配、附近的房间、开房提示、复制下载链接、蓝牙发安装包等一批文字原来还是中文，现在补齐；设置里的分组标题和存档说明也一并翻了。",
      "added": [],
      "changed": [
        "英文模式：多人对战抽屉（副标题/快速匹配/附近房间/开房与加入/复制链接/蓝牙发安装包/分享步骤/上次的对手/蓝牙配对）全部英文化",
        "英文模式：设置分组标题（帧率声音材质、屏幕与设备、方向刷新率性能、性能档自动）、存档说明、最近错误、复制这一版说明、怎么更新 同步英文化",
        "英文模式唯一的剩中文是标题 logo「合体债」（品牌名），下面是 FUSION DEBT"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.22",
      "date": "2026-11-16",
      "title": "本地统计 · 英文补齐",
      "summary": "「更多」里多了本地统计（局数/消行/最高/最长连击/累计还债，只存本机）；英文教程补齐到现在的规则，不再教已经删掉的东西；更新会优先走上次连上的源。",
      "added": [
        "更多 → 统计：局数、消行数、最高分、最长连击、累计还债，可一键清空（只存这台设备，不上传）"
      ],
      "changed": [
        "英文教程重写：删掉已移除的字母块页，转场改成「轻松不转、普通/困难每 15 秒转」，最后一页回到「怎么算死、怎么重开」",
        "英文帮助页的转场说明同步成现在的规则（不再写「设置里打开自动旋转」）",
        "更新优先用上次连上的源，被墙的源不再每次启动白等 3 秒超时"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.21",
      "date": "2026-11-16",
      "title": "坏包自愈 · 一键重装",
      "summary": "网页包万一坏到打不开（白屏、点不动、一开就退），启动时会自动退回上一版，也能在「怎么更新」里手动重装；手机上的方向键又放大一档。",
      "added": [
        "启动自检：网页脚本没起来就自动退回上一个能用的网页包",
        "「更多 → 版本与更新 → 怎么更新」新增「重装网页包（修坏包）」，同版本也重下，存档不受影响",
        "方向键放大：手机横屏 53→66px、平板 66→76px、大屏上限 96→104px；小屏先缩棋盘，不缩键位"
      ],
      "changed": [
        "安装包升到 v1.5（壳 58）：带自检回落与强制重装能力；网页包仍是自动更新"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.20",
      "date": "2026-11-16",
      "title": "记录错误 · 暂停省电",
      "summary": "页面出错会自动记下最近一条（设置里能看到，复制版本说明时也带上）；暂停时彻底停掉渲染循环，不再空转耗电。",
      "added": [
        "设置 → 屏幕与设备 多一行「最近错误」，复制版本说明时一并带上"
      ],
      "changed": [
        "暂停时停掉 requestAnimationFrame 循环，恢复时重启（原来暂停还在每秒空转）",
        "清理没用的翻译词条与残留开关"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.19",
      "date": "2026-11-16",
      "title": "长局减压 · 新手推荐",
      "summary": "每 15 次消行，下一块合体块只顶 1 行——长局不再只剩「越来越难」；轻松档标上「新手推荐」。",
      "added": [
        "长局减压：每 15 次消行，下一块合体块只顶 1 行（会弹提示）"
      ],
      "changed": [
        "轻松档的说明前面加了「新手推荐」，第一次玩更容易找到"
      ],
      "balance": [
        "删掉字母块后长局缺一个「逐渐变简单」的出口，用每 15 次消行的 1 行块补上"
      ],
      "removed": []
    },
    {
      "v": "1.18",
      "date": "2026-11-16",
      "title": "砍掉多余的",
      "summary": "删掉字母块、债务重组改成每局 -15%、常驻和计时合并、多人面板去掉重复选项、开场与提示各收一档；更新记录只留最近 15 条：version.js 从 106KB 瘦到 22KB，更新包（压缩后）从 161KB 降到 133KB。",
      "added": [],
      "changed": [
        "字母块删除：合体块始终是 2 行、1~2 个洞，不再变形",
        "债务重组：连续 3 局没还清减半 → 每局没还清自动消 15%",
        "常驻与计时（原禅模式）合并成一个面板：连击 / 计时 5·10 分钟",
        "多人面板：去掉「和谁玩」「操作」两个选项，「上次房间」「上次蓝牙」并成一个「上次的对手」",
        "设置：开场动画只留开/关，去掉「右上角提示」三档（固定自动）",
        "更新记录只保留最近 15 条，更早的看仓库 CHANGELOG.md"
      ],
      "balance": [],
      "removed": [
        "字母块（变形与字母绘制）",
        "「和谁玩」「操作」选项",
        "「右上角提示」三档"
      ]
    },
    {
      "v": "1.17",
      "date": "2026-11-16",
      "title": "键位再大一点 · 更新引导",
      "summary": "方向键在所有模式里再放大一档，并往屏幕中间收了一点（仍然不压棋盘）；版本页新增「怎么更新」，讲清网页包和安装包的区别。",
      "added": [
        "版本与更新页新增「怎么更新」：判断安装包新旧、三步说明、复制安装包地址/镜像、检查网页包更新"
      ],
      "changed": [
        "键位基准再上调（横屏 12%、竖屏 14%、大屏 9%），上限 66 / 78 / 96",
        "键位离边框的留白从约 2% 提到约 6%，整体往中间收一点",
        "小屏塞不下时仍会自动缩回去，不会压棋盘或出屏"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.16",
      "date": "2026-11-16",
      "title": "键位放大一档",
      "summary": "所有模式的方向键和暂存键都在原来基础上放大了一点，手指更好按；「不压棋盘、不出屏」的自动复核照旧兜底。",
      "added": [],
      "changed": [
        "横屏：基准从屏幕短边的 10% 提到 10.8%，上限 52 → 56",
        "竖屏：基准从宽度的 12% 提到 13%，上限 66 → 72",
        "大屏：上限 84 → 88（1080p 横屏约 86px）",
        "旋转/强制横屏的布局同步放大"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.15",
      "date": "2026-11-16",
      "title": "复制里补上下文",
      "summary": "复制出来的说明多了两行：上一版是什么、几个术语什么意思——这样模型不只答得出「这版改了什么」，还能答「跟上一版比改了什么」。",
      "added": [],
      "changed": [
        "复制内容加「上一版：v1.14 · 标题」",
        "复制内容加术语解释：合体块 / 债 / 网页包 / 安装包（壳）"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.14",
      "date": "2026-11-16",
      "title": "复制内容适合发给 AI",
      "summary": "「复制这一版说明」改成结构化文本：先一句这游戏是什么，再一行一个字段，最后带明确小节的更新记录；粘给任何模型都能直接读懂。",
      "added": [],
      "changed": [
        "复制内容：开头补一句玩法（10×10、消行顶合体块、债跨局），避免对方不知道这是什么游戏",
        "字段拆成一行一个：版本 / 网页包 / 安装包（壳）/ 设备；更新记录带「简介 / 新增 / 调整」小节"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.13",
      "date": "2026-11-16",
      "title": "一键复制这一版",
      "summary": "版本页多一个按钮：把「这一版是什么、改了什么」复制成一段纯文本，发给朋友或贴给排查都用得上。",
      "added": [
        "版本与更新页：「复制这一版说明」——版本号、网页包、壳版本、设备、性能档，加最新一条更新记录的正文",
        "走系统剪贴板桥，复制成功/失败都有提示"
      ],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.12",
      "date": "2026-11-16",
      "title": "复制改走系统剪贴板",
      "summary": "复制按钮不再依赖 WebView 的剪贴板 API（file:// 下它经常被拒），改走安装包里的系统剪贴板桥；网页包这边也只剩一份复制函数。需要装一次 1.4 安装包。",
      "added": [
        "安装包 1.4（versionCode 57）：给页面一个系统剪贴板接口，复制稳定了"
      ],
      "changed": [
        "下载弹窗：复制地址 / 换成镜像并复制 / 稍后，结果显示在弹窗里",
        "联机分享框的「复制下载链接」同样走系统剪贴板"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.11",
      "date": "2026-11-16",
      "title": "复制修好了",
      "summary": "更新弹窗里点「复制镜像地址」没反应：页面里有两份同名的复制函数，后一份直接谎报成功、还把回调炸掉。现在只剩一份，成不成功都如实写出来。",
      "added": [],
      "changed": [
        "下载安装包弹窗简化：复制地址 / 换成镜像并复制 / 稍后再看；复制结果直接显示在弹窗里",
        "联机分享框的「复制下载链接」也改成如实提示：复制失败就把地址显示出来"
      ],
      "balance": [],
      "removed": [
        "重复的那份 copyText（就是它让复制按钮看起来没反应）"
      ]
    },
    {
      "v": "1.10",
      "date": "2026-11-16",
      "title": "性能档",
      "summary": "按真实帧时间自动切画质：卡了降一档（关毛玻璃、降背板分辨率、收阴影），稳了再升回去；设置里多一行只读的「性能档」。",
      "added": [
        "性能档：高 / 中 / 低，按帧时间自动切；只影响画面，不动规则和种子",
        "低档：背板分辨率降到 1.5x、帧率上限 45、去掉毛玻璃和阴影",
        "「屏幕与设备」里显示当前性能档和帧时间 p95，卡的时候一眼能看出是设备还是代码"
      ],
      "changed": [
        "暂停和结算时不再每秒重画 60 次，画布停在最后一帧",
        "设置入口收成 3 个：声音并进「游戏」"
      ],
      "balance": [],
      "removed": []
    }
  ],
  logEn: [
    {
      "v": "1.24",
      "date": "2026-11-16",
      "title": "Overlay English · tutorial repaint",
      "summary": "In English the game-over overlay (Game over / Debt unpaid — run over / Restart R) and the versus bar (You / Opponent / Ready / Me / duel title) were still Chinese — translated now, along with the resume label.",
      "added": [],
      "changed": [
        "Tutorial repaints one extra frame on open (first frame only; artwork unchanged)",
        "English: game-over overlay, versus bar, duel title and resume labels (Resumed / Combo · resumed / Classic · resumed) translated"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.23",
      "date": "2026-11-16",
      "title": "English multiplayer complete",
      "summary": "In English mode the Multiplayer drawer still had Chinese subtitles, Quick match, Rooms nearby, hosting hints, Copy download link, Send APK over Bluetooth and more — all translated now, plus the settings group titles and save notes.",
      "added": [],
      "changed": [
        "English: the Multiplayer drawer is fully English (subtitle, Quick match, rooms nearby, host/join, share steps, last opponent, Bluetooth pairing)",
        "English: settings group titles (frame rate/sound/skin, screen & device, orientation/refresh/performance, quality auto), save notes, Last error, Copy this version note and How to update are translated",
        "The only Chinese left in English mode is the title logo “合体债” (the brand, with FUSION DEBT underneath)"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.22",
      "date": "2026-11-16",
      "title": "Local stats · English fixed",
      "summary": "More → Stats shows games, lines, best score, best combo and debt paid (this device only); the English tutorial now matches the current rules; updates try the last working source first.",
      "added": [
        "More → Stats: games, lines, best score, best combo, debt paid, with one-tap clear (stored locally, never uploaded)"
      ],
      "changed": [
        "English tutorial rewritten: the removed letter-block page is gone, rotation now says \u201cEasy never, Normal/Hard every 15s\u201d, and the last page is how you die / restart again",
        "English help no longer tells players to enable a removed auto-rotate setting",
        "Updater remembers the last working source, so blocked mirrors stop costing a 3s timeout every launch"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.21",
      "date": "2026-11-16",
      "title": "Self-heal · one-tap reinstall",
      "summary": "If a web bundle ever breaks badly (white screen, taps do nothing, closes on open), the app falls back to the previous working bundle at startup and can be reinstalled from How to update; the on-screen keys are a size bigger on phones.",
      "added": [
        "Startup self-check: falls back to the last working web bundle when the page scripts fail to boot",
        "How to update now has \u201cReinstall web bundle (repair)\u201d \u2014 same version re-downloads too; saves untouched",
        "Bigger on-screen keys: phone landscape 53 \u2192 66px, tablet 66 \u2192 76px, large-screen cap 96 \u2192 104px; on small screens the board shrinks first, not the keys"
      ],
      "changed": [
        "APK is now v1.5 (shell 58): includes the fallback and forced reinstall; the web bundle still updates itself"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Error log · pause saves power",
      "summary": "The last JS error is recorded (shown in Settings and included in the copied version note); pausing now stops the render loop instead of spinning.",
      "added": [
        "Screen & device shows the last error; the copied version note includes it"
      ],
      "changed": [
        "Pausing stops the requestAnimationFrame loop and resumes it on unpause",
        "Dropped unused translation entries and leftover switches"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Late-game relief · beginner pick",
      "summary": "Every 15 clears the next fusion block is only one row, so long runs are not just harder and harder; the Easy tier is now labelled as the beginner pick.",
      "added": [
        "Late-game relief: every 15 clears, the next fusion block is 1 row instead of 2 (with a toast)"
      ],
      "changed": [
        "The Easy tier now says Recommended for newcomers"
      ],
      "balance": [
        "Removing letter blocks took away the only late-game easing; the 1-row block every 15 clears puts a rhythm back"
      ],
      "removed": []
    },
    {
      "title": "Trim the fat",
      "summary": "Letter blocks removed, debt restructuring eased 15% per run, casual and zen merged, multiplayer panel de-duplicated, intro and hints simplified; the changelog keeps the last 15 entries, cutting the update bundle from 160KB to about 60KB.",
      "added": [],
      "changed": [
        "Letter blocks removed: fusion blocks are always 2 rows with 1-2 holes",
        "Debt restructuring: instead of halving after 3 unpaid runs, every unpaid run eases the debt by 15%",
        "Casual and Zen merged into one panel: Combo / Timed 5 or 10 minutes",
        "Multiplayer panel: Who-to-play and Action switches removed; last LAN room and last Bluetooth opponent merged into one button",
        "Settings: intro is on/off, the three-way top-right hint switch is gone (always auto)",
        "Changelog keeps the last 15 entries; older ones live in the repo CHANGELOG.md"
      ],
      "balance": [],
      "removed": [
        "Letter blocks (morph and glyph drawing)",
        "Who-to-play and Action switches",
        "Three-way hint switch"
      ]
    },
    {
      "title": "Bigger controls again · update guide",
      "summary": "Direction keys grow another step in every mode and sit a little further from the screen edges (still never covering the board); the version page gains a How to update guide.",
      "added": [
        "Version page: How to update — checks whether the APK is old, shows three steps, copies the APK or mirror link, and can check the web bundle"
      ],
      "changed": [
        "Larger key baseline (landscape 12%, portrait 14%, big screens 9%), caps 66 / 78 / 96",
        "Edge margin grows from about 2% to 6%, pulling the pads inward",
        "On very small screens the keys still shrink automatically instead of covering the board"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Bigger controls",
      "summary": "The direction and hold keys grow a little in every mode; the existing check that keeps them off the board and inside the screen still applies.",
      "added": [],
      "changed": [
        "Landscape baseline 10% → 10.8% of the short edge, cap 52 → 56",
        "Portrait baseline 12% → 13% of width, cap 66 → 72",
        "Large screens: cap 84 → 88 (about 86px at 1080p landscape)",
        "Rotated/forced-landscape layouts scale with the same numbers"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "More context in the copy",
      "summary": "The copied note gains two lines — what the previous version was and what the main terms mean — so a model can answer what changed compared with the last version, not just this version.",
      "added": [],
      "changed": [
        "Adds Previous: v1.14 with its title",
        "Adds a glossary: fusion block / debt / web bundle / APK shell"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy text is AI-friendly",
      "summary": "The copied version note is now structured: one line saying what the game is, one field per line, then the changelog entry with labelled sections — paste it into any model and it reads cleanly.",
      "added": [],
      "changed": [
        "The note opens with a one-line description (10×10, clearing lines pushes a fusion block, debt carries over)",
        "Fields are one per line: version / web bundle / APK shell / device; the changelog uses Summary, Added, Changed sections"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy this version note",
      "summary": "The version page gains one button that copies a plain-text note about this build and what changed — handy for sharing or troubleshooting.",
      "added": [
        "Version & updates: Copy this version note — version, web bundle, shell, device and performance tier plus the latest changelog entry",
        "Goes through the system clipboard bridge and reports success or failure"
      ],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy goes through Android clipboard",
      "summary": "The copy buttons no longer rely on the WebView clipboard API (often denied for file://); they use a clipboard bridge in the APK. Install the 1.4 shell once.",
      "added": [
        "APK 1.4 (versionCode 57): exposes the system clipboard to the page, so copying is reliable"
      ],
      "changed": [
        "Download dialog: Copy link / Switch to mirror and copy / Later, with the result shown in the dialog",
        "The share box Copy link uses the same path"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy fixed",
      "summary": "The mirror copy button in the update dialog did nothing: the page had two copyText functions and the later one lied about success and broke the callback. There is only one now, and it reports honestly.",
      "added": [],
      "changed": [
        "The APK dialog is simpler: Copy link / Switch to mirror and copy / Later, with the result shown inside the dialog",
        "The share box Copy link now tells the truth too: on failure it shows the URL"
      ],
      "balance": [],
      "removed": [
        "The duplicate copyText function that made the copy button look dead"
      ]
    },
    {
      "title": "Performance tiers",
      "summary": "Quality now adapts to real frame times: a sustained slowdown drops one tier (blur off, lower render scale, no shadows) and recovers when it is smooth again; Settings shows the current tier read-only.",
      "added": [
        "Performance tier: high / mid / low, chosen from measured frame times; visuals only, rules and seeds untouched",
        "Low tier: render scale 1.5x, frame cap 45, no blur or shadows",
        "Screen & device shows the current tier and frame-time p95 so a stutter can be traced to the device or the code"
      ],
      "changed": [
        "Pause and result screens no longer redraw 60 times a second; the canvas holds its last frame",
        "Settings entries are down to 3: sound moved into Game"
      ],
      "balance": [],
      "removed": []
    }
  ],




  };
})();
