/* update.js —— 自动更新（联网 / 局域网房主）
 *
 * 玩法：
 *   1) 启动后静默查一次：有新版就下载、校验、切换，然后自动重启到新版；
 *   2) 加入房间前先问房主 /update.json，房主比你新就从房主手机拉一份网页包，不用重装 APK；
 *   3) 「版本与更新」页有「检查更新」和「设置更新地址」。
 *
 * 更新源就是一个静态目录：update.json + web-<版本>.zip。
 * 联网源写在下面的 SOURCES 里（留空就不联网查）；也可以手动填。
 */
(function () {
  'use strict';

  // 内置的联网更新源（按顺序试）。留空就只从房主同步。
  // 仓库：https://github.com/WAZGZGWS/- （main 分支根目录放 update.json + web-<n>.zip）
  // 顺序是实测出来的：平板直连 raw 被墙（Failed to fetch），gh-proxy / ghproxy.net 能下；
  // raw 放最后给墙外的人兜底。raw 还有 CDN 缓存，刚发布几分钟内可能拿到旧清单。
  var SOURCES = [
    'https://gh-proxy.com/https://raw.githubusercontent.com/WAZGZGWS/-/main/',
    'https://ghproxy.net/https://raw.githubusercontent.com/WAZGZGWS/-/main/',
    'https://raw.githubusercontent.com/WAZGZGWS/-/main/'
  ];
  var state = { busy: false, pending: null, pendingCheck: null, running: null, manual: false, lastAt: 0 };
  var K_UPDATED = 'tetris.justUpdated';

  function host() { return window.TetrisHost || null; }
  function ui() { return window.TetrisUI || null; }
  function toast(msg) { var u = ui(); if (u && u.toast) u.toast(msg); }
  function $(id) { return document.getElementById(id); }
  function EN() { return !!(window.TetrisI18n && window.TetrisI18n.lang === 'en'); }
  function P(zh, en) { return EN() ? en : zh; }

  function info() {
    var h = host();
    if (!h || typeof h.updateInfo !== 'function') return null;
    try { return JSON.parse(h.updateInfo()); } catch (e) { return null; }
  }

  function storedUrl() {
    var h = host();
    try { return (h && h.getUpdateUrl && h.getUpdateUrl()) || ''; } catch (e) { return ''; }
  }

  var K_LASTSRC = 'tetris.lastSource';

  function allSources() {
    var out = [];
    var u = storedUrl();
    // 上次真正连上的源排第一：被墙的源不用每次都白等一个 3 秒超时
    try {
      var last = localStorage.getItem(K_LASTSRC);
      if (last && last !== u) out.push(last);
    } catch (e) {}
    if (u) out.push(u);
    for (var i = 0; i < SOURCES.length; i++) {
      if (SOURCES[i] && out.indexOf(SOURCES[i]) < 0) out.push(SOURCES[i]);
    }
    return out;
  }

  function setMsg(text) {
    var el = $('updMsg');
    if (el) el.textContent = text || '';
  }

  /* 首页底部那行小字：查更新/装更新的时候给个动静，平时不占地方 */
  function setState(text) {
    var foot = document.querySelector('.screen[data-screen="home"] .foot');
    if (!foot) return;
    var el = $('updState');
    if (!el) {
      el = document.createElement('div');
      el.id = 'updState';
      el.className = 'ver';
      el.style.cssText = 'opacity:.65;font-size:10px;margin-top:2px';
      foot.appendChild(el);
    }
    el.textContent = text || '';
  }

  /* 更新完重启后，首页给一条提示（进游戏就能看见） */
  function showUpdatedNotice(text) {
    var home = document.querySelector('.screen[data-screen="home"]');
    if (!home) return;
    var el = $('updNotice');
    if (!el) {
      el = document.createElement('div');
      el.id = 'updNotice';
      el.className = 'notice';
      el.style.cssText = 'margin:0 0 10px';
      var brand = home.querySelector('.brand');
      if (brand && brand.nextSibling) home.insertBefore(el, brand.nextSibling);
      else home.insertBefore(el, home.firstChild);
    }
    el.innerHTML = '<p></p>';
    el.querySelector('p').textContent = text;
    el.style.display = 'flex';
    setTimeout(function () { el.style.display = 'none'; }, 15000);
  }

  function markUpdated(r) {
    try {
      localStorage.setItem(K_UPDATED, JSON.stringify({
        version: r.version, web: r.web, notes: r.notes || [], at: Date.now()
      }));
    } catch (e) {}
  }

  function refresh() {
    var el = $('updVer');
    if (!el) return;
    var i = info();
    var v = (window.TetrisVersion && window.TetrisVersion.version) || '?';
    if (!i) { el.textContent = 'v' + v + P('（浏览器版）', ' (browser)'); return; }
    el.textContent = 'v' + i.version + P(' · 网页包 ', ' · web ') + i.web
      + (i.bundle ? P('（更新的）', ' (updated)') : P('（APK 自带）', ' (bundled with APK)'));
    var ur = storedUrl();
    setMsg(ur ? P('更新地址：', 'Update URL: ') + ur
      : (SOURCES.length ? P('联网源：', 'Online source: ') + SOURCES[0] : P('更新地址：没填（只能从房主同步）', 'Update URL: empty (host sync only)')));
  }

  var seq = 0;

  function check(manual, extra, only) {
    var h = host();
    if (!h || typeof h.checkUpdate !== 'function') {
      if (manual) { toast(P('这个版本不支持自动更新', 'This build does not support auto-update')); setMsg(P('不支持自动更新', 'Auto-update not supported')); }
      return false;
    }
    if (state.busy) {
      // 正在查：排到这次结束之后再查，别把「加入房间」的半路同步丢掉
      state.pendingCheck = { manual: !!manual, extra: extra || null, only: !!only };
      if (manual) setMsg(P('等这次检查结束…', 'Waiting for the current check…'));
      return true;
    }
    var list = [];
    if (extra) {
      for (var e = 0; e < extra.length; e++) {
        if (extra[e] && list.indexOf(extra[e]) < 0) list.push(extra[e]);
      }
    }
    if (!only) {
      var base = allSources();
      for (var i = 0; i < base.length; i++) {
        if (base[i] && list.indexOf(base[i]) < 0) list.push(base[i]);
      }
    }
    if (!list.length) {
      if (manual) { toast(P('没有可用的更新源', 'No update source available')); setMsg(P('没有可用的更新源', 'No update source available')); }
      return false;
    }
    state.busy = true;
    state.manual = !!manual;
    state.running = { lan: !!(extra && extra.length), manual: !!manual };
    seq += 1;
    var mine = seq;
    if (manual) { setMsg(P('检查中…', 'Checking…')); toast(P('检查更新…', 'Checking for updates…')); }
    else setState(P('检查更新…', 'Checking for updates…'));
    try { h.checkUpdate(JSON.stringify(list)); } catch (e) {
      state.busy = false;
      if (manual) setMsg(P('检查失败：', 'Check failed: ') + (e && e.message || e));
      return false;
    }
    // 主线程卡住或房主没响应：12 秒后解除忙碌，但不丢结果（结果回来还会处理）
    setTimeout(function () {
      if (state.busy && mine === seq) {
        state.busy = false;
        state.running = null;
        if (manual) setMsg(P('检查超时（网络或房主没响应）', 'Check timed out (network or host did not respond)'));
      }
    }, 12000);
    return true;
  }

  /**
   * 强制重装当前网页包（同号也重下）。网页包能打开但脚本坏了时，
   * 启动检查会一直以为「已最新」而不修——这条是手动出口。
   */
  function force() {
    var h = host();
    if (!h || typeof h.forceUpdate !== 'function') {
      toast(P('这个安装包还不支持强制重装', 'This APK cannot force-reinstall yet'));
      setMsg(P('要装 1.5 以上安装包才有这个按钮', 'Needs APK 1.5 or newer'));
      return false;
    }
    if (state.busy) {
      state.pendingCheck = { manual: true, force: true };
      setMsg(P('等这次检查结束…', 'Waiting for the current check…'));
      return true;
    }
    var list = allSources();
    if (!list.length) {
      toast(P('没有可用的更新源', 'No update source available'));
      setMsg(P('没有可用的更新源', 'No update source available'));
      return false;
    }
    state.busy = true;
    state.manual = true;
    state.running = { lan: false, manual: true };
    seq += 1;
    var mine = seq;
    setMsg(P('正在重新下载网页包…', 'Re-downloading the web bundle…'));
    toast(P('正在重新下载网页包…', 'Re-downloading the web bundle…'));
    try { h.forceUpdate(JSON.stringify(list)); } catch (e) {
      state.busy = false;
      setMsg(P('重装没能开始：', 'Reinstall could not start: ') + (e && e.message || e));
      return false;
    }
    setTimeout(function () {
      if (state.busy && mine === seq) {
        state.busy = false;
        state.running = null;
        setMsg(P('重装超时（网络没响应）', 'Reinstall timed out (no response)'));
      }
    }, 60000);
    return true;
  }

  function saveRejoin(addr, room) {
    try {
      localStorage.setItem('tetris.rejoin', JSON.stringify({
        addr: addr, room: room, at: Date.now()
      }));
    } catch (e) {}
  }

  function doRejoin() {
    var p = null;
    try { p = JSON.parse(localStorage.getItem('tetris.rejoin') || 'null'); } catch (e) {}
    if (!p || !p.addr || !p.room) return false;
    try { localStorage.removeItem('tetris.rejoin'); } catch (e) {}
    if (Date.now() - (p.at || 0) > 120000) return false;
    setTimeout(function () {
      var btnStart = $('btnStart');
      var btnMulti = $('btnMulti');
      if (btnStart) btnStart.click();
      if (btnMulti) btnMulti.click();
      var who = document.querySelector('#whoSeg [data-who="phone"]');
      var act = document.querySelector('#actSeg [data-mpact="join"]');
      if (who) who.click();
      if (act) act.click();
      var a = $('hostAddr');
      var r = $('roomInput');
      if (a) a.value = p.addr;
      if (r) r.value = p.room;
      var go = $('lanStart');
      if (go) go.click();
    }, 900);
    return true;
  }

  function handleResult(r, run) {
    if (!r) { setMsg(P('更新结果读不出来', 'Update result could not be read')); return; }
    if (r.ok && r.source) { try { localStorage.setItem(K_LASTSRC, r.source); } catch (e) {} }
    var isLan = !!(run && run.lan);
    var manual = !!(run && run.manual);

    if (r.ok && r.updated) {
      var msg = P('已更新到 v', 'Updated to v') + r.version;
      setMsg(msg);
      toast(msg);
      setState(P('更新完成，正在重启…', 'Update done — restarting…'));
      markUpdated(r);
      var p = isLan ? state.pending : null;
      state.pending = null;
      if (p) {
        saveRejoin(p.addr, p.room);
        toast(P('已同步到房主版本，正在重新进房间…', 'Synced to the host version — rejoining the room…'));
      }
      setTimeout(function () {
        try { host().restart(); } catch (e) {}
      }, 1200);
      return;
    }

    if (r.ok && r.upToDate) {
      // 清单可能被 CDN 缓存成旧版本号；说「已是最新」时用本机版本，别把人说糊涂
      var i2 = info();
      var cur = (i2 && i2.version) || r.version;
      if (manual) {
        var now = P('已是最新版 v', 'Up to date: v') + cur;
        setMsg(now);
        toast(now);
      } else {
        setState(P('已是最新版 v', 'Up to date: v') + cur);
        setTimeout(function () { setState(''); }, 3500);
      }
      // 只有这次就是「联机前那次检查」才继续加入；别让启动时的自动检查把 pending 吃掉
      if (isLan) {
        var pend = state.pending;
        state.pending = null;
        if (pend && pend.after) { try { pend.after(); } catch (e) {} }
      }
      return;
    }

    var err = (r && r.error) || P('未知错误', 'Unknown error');
    if (manual) {
      setMsg(P('检查失败：', 'Check failed: ') + err);
      toast(P('检查失败：', 'Check failed: ') + err);
    } else {
      setState(P('更新检查失败（照常玩）', 'Update check failed (play as usual)'));
      setTimeout(function () { setState(''); }, 5000);
    }
    if (isLan) {
      // 联机前同步失败：不要带着旧版本进房间，规则可能对不上
      var p2 = state.pending;
      state.pending = null;
      var failText = P('从房主同步失败：', 'Sync from host failed: ') + err;
      setMsg(failText);
      toast(failText);
      setState(P('同步失败，先更新再联机', 'Sync failed — update before playing online'));
      setTimeout(function () { setState(''); }, 6000);
      if (p2 && p2.fail) { try { p2.fail(err); } catch (e) {} }
    }
  }

  window.__tetrisUpdate = function (raw) {
    var r = null;
    try { r = JSON.parse(raw); } catch (e) { r = null; }
    var run = state.running;
    state.running = null;
    state.busy = false;
    var again = state.pendingCheck;
    state.pendingCheck = null;
    handleResult(r, run);
    if (again) {
      setTimeout(function () {
        if (again.force) force(); else check(again.manual, again.extra, again.only);
      }, 300);
    }
  };

  /** 问一个地址有没有更新清单；没有/超时就返回 null。 */
  function probe(base) {
    var b = base;
    try { if (window.TetrisNet && window.TetrisNet.normalizeBase) b = window.TetrisNet.normalizeBase(base); } catch (e) {}
    if (!b) return Promise.resolve(null);
    if (!/^https?:\/\//i.test(b)) b = 'http://' + b;
    b = b.replace(/\/+$/, '');
    var ctrl = typeof AbortController === 'function' ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 2500);
    return fetch(b + '/update.json?t=' + Date.now(), {
      cache: 'no-store',
      credentials: 'omit',
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (res) {
      clearTimeout(timer);
      if (!res.ok) return null;
      return res.json();
    }).then(function (j) {
      if (!j || j.app !== 'heti-debt' || !(j.web > 0)) return null;
      return j;
    }).catch(function () {
      clearTimeout(timer);
      return null;
    });
  }

  /**
   * 从房主同步。opts = {addr, room, after, onFail}
   * after：确认不用更新（房主其实不新）时，接着去加入房间。
   * onFail：更新失败时回调，调用方要把「加入中」状态清掉——失败就别进房。
   */
  function syncFrom(base, opts) {
    opts = opts || {};
    state.pending = {
      kind: 'lan',
      addr: opts.addr || '',
      room: opts.room || '',
      after: opts.after,
      fail: opts.onFail
    };
    var myPending = state.pending;
    setTimeout(function () {
      if (state.pending !== myPending) return;
      state.pending = null;
      state.busy = false;
      state.running = null;
      setMsg(P('从房主同步超时', 'Sync from host timed out'));
      toast(P('房主没响应，先更新再联机', 'Host did not respond — update before playing online'));
      setState(P('同步超时，先更新再联机', 'Sync timed out — update before playing online'));
      setTimeout(function () { setState(''); }, 6000);
      if (opts.onFail) { try { opts.onFail(P('房主没响应（超时）', 'Host did not respond (timeout)')); } catch (e) {} }
    }, 20000);
    toast(P('房主版本更新，正在同步…', 'Host runs a newer build — syncing…'));
    setMsg(P('正在从房主同步…', 'Syncing from host…'));
    if (!check(false, [base], true)) {
      state.pending = null;
      if (opts.onFail) { try { opts.onFail(P('更新没能开始', 'Update could not start')); } catch (e) {} }
      else if (opts.after) opts.after();
      return false;
    }
    return true;
  }

  function mount() {
    var head = $('aboutHead');
    if (!head || $('updBox')) return;
    var box = document.createElement('div');
    box.id = 'updBox';
    box.innerHTML =
      '<div class="row"><span>网页包</span><span class="k" id="updVer">—</span></div>' +
      '<button class="btn small" id="updCheck">检查更新</button>' +
      '<button class="btn small" id="updUrl">设置更新地址</button>' +
      '<div id="updEdit" style="display:none;flex-direction:column;gap:8px;margin-top:6px">' +
      '  <input id="updInput" type="url" inputmode="url" autocomplete="off" spellcheck="false" placeholder="https://example.com/tetris/" ' +
      '    style="width:100%;box-sizing:border-box;padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.16);' +
      '    background:rgba(255,255,255,.06);color:var(--ink,#eef2f7);font:inherit;font-size:13px;outline:none">' +
      '  <div style="display:flex;gap:8px">' +
      '    <button class="btn small" id="updSave" style="flex:1">保存</button>' +
      '    <button class="btn small" id="updCancel" style="flex:1">取消</button>' +
      '  </div>' +
      '</div>' +
      '<p class="label" id="updMsg" style="letter-spacing:0;text-align:center;line-height:1.5"></p>';
    head.parentNode.insertBefore(box, head.nextSibling);

    var edit = $('updEdit');
    var input = $('updInput');

    $('updCheck').addEventListener('click', function () { check(true); });
    $('updUrl').addEventListener('click', function () {
      // 不用 window.prompt：安卓 WebView 默认不弹框，会把整个页面卡死
      edit.style.display = edit.style.display === 'flex' ? 'none' : 'flex';
      if (edit.style.display === 'flex') {
        input.value = storedUrl();
        try { input.focus(); } catch (e) {}
      }
    });
    $('updCancel').addEventListener('click', function () {
      edit.style.display = 'none';
    });
    $('updSave').addEventListener('click', function () {
      var h = host();
      if (!h || typeof h.setUpdateUrl !== 'function') { toast('这个版本改不了'); return; }
      var v = (input.value || '').trim();
      try { h.setUpdateUrl(v); } catch (e) {}
      edit.style.display = 'none';
      refresh();
      toast(v ? '更新地址已保存' : '已清除更新地址');
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); $('updSave').click(); }
      e.stopPropagation();
    });
    refresh();
  }

  function boot() {
    refresh();

    // 刚更新过：进入游戏给一条提示
    var just = null;
    try { just = JSON.parse(localStorage.getItem(K_UPDATED) || 'null'); } catch (e) {}
    if (just) {
      try { localStorage.removeItem(K_UPDATED); } catch (e) {}
      if (Date.now() - (just.at || 0) < 300000) {
        var notes = (just.notes && just.notes.length) ? (' · ' + String(just.notes[0]).slice(0, 60)) : '';
        showUpdatedNotice(P('已自动更新到 v', 'Auto-updated to v') + just.version + notes);
      }
    }

    var rejoined = doRejoin();
    if (!rejoined) {
      setTimeout(function () {
        if (allSources().length) check(false);
      }, 900);
    }
  }

  window.TetrisUpdate = {
    check: check,
    force: force,
    probe: probe,
    syncFrom: syncFrom,
    refresh: refresh,
    sources: allSources
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
