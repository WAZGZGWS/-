/* i18n.js —— 语言切换（简体 / English / 跟随系统）
 * 先覆盖菜单、设置、游戏 HUD、暂停/结算；教程/帮助/旧更新记录暂保留中文。
 */
(function () {
  'use strict';

  const DICT = {
    /* 首页 / 玩法 */
    '开始': 'Start',
    '新手教程': 'Tutorial',
    '更多': 'More',
    '设置': 'Settings',
    '返回': 'Back',
    '主玩法': 'Main',
    '常驻': 'Casual',
    '多人对战': 'Multiplayer',
    '合体债 / 经典': 'Debt / Classic',
    '连击 · 轻松': 'Combo · Chill',
    '决斗 / 对打': 'Duel / Watch',
    '合体债': 'Debt',
    '原味': 'Original',
    '极简': 'Minimal',
    '现代': 'Modern',
    '像素': 'Pixel',
    '霓虹': 'Neon',
    '经典': 'Classic',
    '经典玩法': 'Classic',
    '打 AI': 'Versus AI',
    'AI 观战': 'AI Watch',
    '常驻 · 禅模式': 'Casual · Zen',
    '继续': 'Continue',
    '继续经典': 'Continue Classic',
    '继续常驻': 'Continue Casual',
    '继续禅': 'Continue Zen',
    '继续禅模式': 'Continue Zen',
    '版本与更新': 'Version & Updates',
    '存档管理': 'Saves',
    '玩法说明': 'How to Play',
    '关于': 'About',
    '语言': 'Language',
    '只换外观，不改规则；开局后生效。': 'Visuals only; applies next game.',
    '系统不转时，页面会自己转画面。': 'If the system does not rotate, the page rotates itself.',
    '音量、静音和提示方式。': 'Volume, mute and hint style.',
    '安装包、屏幕和刷新率。': 'APK, screen and refresh rate.',
    '菜单、设置和游戏内界面；教程/帮助下一步再翻。': 'Menu, settings and in-game UI; guides come next.',

    /* 设置入口 */
    '游戏': 'Game',
    '方块材质': 'Block Skin',
    '屏幕方向': 'Orientation',
    '设备信息': 'Device',

    /* 设置：游戏 */
    '流畅度（自动）': 'Smoothness (auto)',
    '正在测设备和屏幕…': 'Measuring the device and screen…',
    '自动': 'Auto',
    '关闭（默认）': 'Off (default)',
    '开启（挑战）': 'On (challenge)',
    '开场动画': 'Intro animation',
    '每次': 'Every time',
    '只看第一次': 'First only',
    '关闭': 'Off',
    '联机决斗开场不受影响；关掉后单机开局直接进棋盘。':
      'The online duel intro is unchanged; when off, solo games start directly.',

    /* 语言 */
    '简体中文': '简体中文',
    '跟随系统': 'Follow system',
    '语言 / Language': 'Language',
    '英文先做菜单、设置和游戏内界面；教程/帮助/旧更新记录下一步再翻。':
      'English preview: menus, settings and in-game HUD. Guides and old changelogs come next.',

    /* 设置：材质 */
    '方块材质（只换外观）': 'Block skin (visual only)',

    /* 设置：节日主题（逻辑在 theme.js） */
    '节日主题': 'Holiday themes',
    '跟随日期': 'Follow the date',
    '节日音乐': 'Holiday music',
    '四季背景（春分/夏至/秋分/冬至换季）': 'Seasonal backdrop (switches at the equinoxes and solstices)',
    '春': 'Spring', '夏': 'Summer', '秋': 'Autumn', '冬': 'Winter',
    '元旦': 'New Year',
    '春节': 'Spring Festival',
    '元宵': 'Lantern Festival',
    '端午': 'Dragon Boat',
    '中秋': 'Mid-Autumn',
    '国庆': 'National Day',
    '只做中国节日，而且只在节日当天出现：到日子自动换方块配色、一点材质和一段很轻的背景音乐，过了那天自己换回原来的样子。平时游戏里看不到也用不到这些包。':
      'Chinese holidays only, and only on the day itself: the block palette, a light material and a quiet background track switch in, then everything returns to normal the day after. Outside the holiday none of it is used.',
    '自己选': 'Manual',
    '系统选': 'Auto',
    '每次对局': 'Per game',
    '开局后生效，不改规则和分数。': 'Applies next game; rules and scoring are unchanged.',
    '「系统选」每局从五套里随机一套；点下面任意一套会切回「自己选」。':
      'Auto picks a random skin each game; tapping a skin switches back to Manual.',

    /* 设置：屏幕 */
    '当前方向': 'Current',
    '自动旋转': 'Auto rotate',
    '横屏': 'Landscape',
    '横屏反向': 'Landscape (reverse)',
    '竖屏': 'Portrait',

    /* 设置：声音 */
    '音效': 'Sound',
    '声音': 'Sound',
    '开': 'On',
    '关': 'Off',
    '右上角提示（静音时靠它）': 'Corner hints (for muted play)',
    '总是': 'Always',
    '系统音量': 'System volume',
    '音量跟着手机走：手机调小，游戏就小；手机静音时自动改用右上角文字提示。': 'Volume follows the phone: turn it down and the game gets quieter; mute it and corner text hints take over.',
    '先选规则；进入后还能在设置里调方向。': 'Pick a ruleset; orientation lives in Settings.',
    '手机静音时自动改用右上角文字提示。': 'When the phone is muted, corner text hints take over automatically.',
    '读不到（按音效开关算）': 'unknown (follows the switch)',
    '系统静音': 'System muted',
    '改用右上角文字提示': 'Text hints instead of sound',

    /* 设置：设备 */
    '安装包（壳）': 'APK (shell)',
    '屏幕': 'Screen',
    '复制新版 APK 下载地址': 'Copy latest APK link',
    '旧安装包': 'Old APK',

    /* 存档 */
    '单人玩法': 'Solo',
    '经典玩法': 'Classic',
    '常驻玩法': 'Casual',
    '禅模式': 'Zen',
    '禅': 'Zen',
    '时间到': 'Time up',
    '自动存档': 'Auto save',
    '空': 'Empty',
    '分': 'pts',
    '存': 'Save',
    '读': 'Load',
    '删': 'Del',

    /* 版本页 */
    '更新前先存档': 'Save before updating',
    '更新记录': 'Changelog',
    '玩法一览': 'Modes',
    '详细': 'Details',
    '新增': 'Added',
    '优化 / 调整': 'Changed',
    '平衡性调整': 'Balance',
    '删除': 'Delete',
    '暂无更新记录': 'No changelog yet',

    /* 游戏 HUD / 暂停 */
    '暂停': 'Pause',
    '重开': 'Restart',
    '退出到菜单': 'Exit to menu',
    '返回菜单': 'Back to menu',
    '每块落地自动存档。': 'Auto-saves after every lock.',
    '分数': 'Score',
    '等级': 'Level',
    '结束欠': 'Debt',
    '消行': 'Lines',
    '统计': 'Stats',
    '清空统计': 'Clear stats',
    '局数、消行、最高分、连击这些会归零；存档不动。': 'Games, lines, best score and combos reset to zero. Saves are untouched.',
    '累计还债': 'Debt paid',
    '还没有数据，先玩一局': 'No data yet — play a game',
    '只存在这台设备上，不上传': 'Stored on this device only',
    '最高': 'Best',
    '债已清': 'Debt paid',
    '变形': 'Morph',
    '连击': 'Combo',
    '倍数': 'Multiplier',
    '剩余': 'Time',
    '准备': 'Ready',
    '对手': 'Opponent',
    '你': 'You',
    '你赢': 'You win',
    '你输': 'You lose',
    '平局': 'Draw',
    '本局': 'Score',
    '带走': 'Carry',
    '按 R 重开': 'Press R to restart',
    '原版规则': 'Classic rules',
    '奖励期': 'Grace',
    '还债中': 'Paying debt',
    '顶块': 'Fusion in',
    '洞': 'holes',
    '最高连击': 'Max combo',
    '债': 'Debt',
    '债还不完，本局结束': 'Debt unpaid — run over',
    '常驻 · 连击': 'Casual · Combo',
    '禅 · 时间到': 'Zen · Time up',

    /* 模式提示 */
    '经典玩法提示': 'Classic',
    '10×20 标准盘，消 1/2/3/4 行按 100/300/500/800×等级计分；没有债、合体块、方向块。堆到顶就结束。':
      '10×20 standard board. Lines score 100/300/500/800 × level; no debt, fusion or arrow blocks. Top out to end.',
    '10×10，无债、无合体块；连续消行叠连击（最高 2.25 倍），连续 3 块没消就断。':
      '10×10, no debt or fusion. Consecutive clears build a combo up to 2.25×; 3 non-clears break it.',
    '10×12，5/10 分钟；不会死，堆满自动清掉底部 4 行；暂停会停表，剩余时间自动存档。':
      '10×12, 5/10 minutes. You cannot die; a full board auto-clears the bottom 4 rows. Pause stops the clock and saves the remainder.',
    '和 AI 同时开局，谁先死谁输；AI 也会算合体块，落子速度和你的节奏一样，玩得越久它越准。':
      'Start together with the AI; whoever tops out first loses. It drops at your pace and sharpens the longer you play.',
    '两个 AI 自己打，你只负责看；一局结束约 3.5 秒自动开下一局。':
      'Two AIs play each other; just watch. The next round starts about 3.5s later.',
    '知道了，开始': 'Got it, start',
    '点一下跳过': 'Tap to skip',
    '欠债还钱天经地义': 'Debts must be paid',
    '经典永不过时': 'Classics never age',
    '来！咱俩练练！': "Let's spar!",
    '不是你死就是他亡': 'Only one survives',

    /* 教程 */
    '跳过': 'Skip',
    '上一步': 'Back',
    '下一步': 'Next',
    '开始游戏': 'Start game',
    '填满一行 → 消': 'Clear a row →',
    '↓ 软降': '↓ soft drop',
    '↻ 转': 'Rotate',
    '旋转': 'Rotate',
    '空格 硬降': 'Space hard drop',
    '落沙': 'sand falls',
    '洞 1~2 个': '1–2 holes',
    '按债 1~4 行': '1–4 rows by debt',
    '消一行 -100': 'clear a row −100',
    '↑ 清上面整列': '↑ clear above',
    '↓ 清下面整列': '↓ clear below',
    '← / → 清左边 / 右边整行': '← / → clear sides',
    '第 40 次起': 'From the 40th clear',
    '洞越来越少': 'fewer holes over time',
    '连点「债」5 下清档': 'Tap Debt 5× to clear debt',

    /* 玩法说明页（英文整页替换） */
    '玩法说明': 'How to Play',
    '打开新手教程': 'Open tutorial',
    '玩法': 'How to play',
    '版本说明': 'Version notes',
    '知道了': 'Got it',
    '主玩法：合体债 / 经典 · 常驻：连击 / 禅 · AI：决斗 / 对打':
      'Main: Debt / Classic · Casual: Combo / Zen · AI: Duel / Watch',

    /* 首页 / 玩法页 */
    '第一次玩？先看 1 分钟新手教程——尤其是「方块会自己掉」和「R 要按两次」。':
      'First time? Take the 1-minute tutorial — especially “blocks fall on their own” and “R must be pressed twice”.',
    'AI': 'AI',
    '规则': 'Rules',
    '模式': 'Mode',
    '和谁玩': 'Opponent',
    '操作': 'Action',
    '并行赛': 'Parallel',
    '干扰战': 'Battle',
    '手机玩家': 'Phone',
    '电脑玩家': 'PC',
    '开房': 'Host',
    '加入': 'Join',
    '创建房间（这台手机当房主）': 'Create room (this phone hosts)',
    '房主地址': 'Host address',
    '房间码': 'Room code',
    '加入房间': 'Join room',
    '同一个 Wi-Fi，先选和谁玩，再开房或加入': 'On the same Wi-Fi: pick an opponent, then host or join',
    '蓝牙对打（无网）': 'Bluetooth duel (offline)',

    /* 存档页 */
    '单人玩法和经典玩法分开存；点某一项的「删除」只清那一档。':
      'Solo and Classic save separately; “Del” clears only that save.',
    '当前存档': 'Current save',
    '导出当前存档': 'Export current save',
    '导入存档': 'Import save',
    '导入': 'Import',
    '清空全部存档': 'Clear all saves',
    '存档': 'Saves',
    '无': 'None',

    /* 设置页静态说明 */
    '自动旋转不生效就选「横屏」：系统不转，画面也会自己转。':
      'If auto-rotate does not work, pick Landscape: the page rotates itself.',
    '开关': 'Toggles',
    '总是': 'Always',
    '屏幕': 'Screen',
    '英文先做菜单、设置和游戏内界面；教程/帮助/旧更新记录下一步再翻。':
      'English now covers menus, settings, gameplay, tutorial and help; old changelogs come next.',

    /* 玩法选择 / AI 面板 / 存档 */
    '先选规则；进入后还能在设置里调方向/音量。': 'Pick a ruleset; orientation and volume live in Settings.',
    '消行顶块 · 跨局还债': 'clears push up · debt carries over',
    '10×20 · 标准计分': '10×20 · standard scoring',
    '连击随时结束；禅模式 5/10 分钟，堆满自动整理、不会死。':
      'Combo ends whenever you top out; Zen runs 5/10 minutes, auto-tidies and never dies.',
    '禅模式时长': 'Zen duration',
    '5 分钟': '5 min',
    '10 分钟': '10 min',
    '堆满不会死，只清底 4 行并断连击；时间到结算。':
      'A full board will not kill you: it clears the bottom 4 rows and breaks the combo; the run ends when time is up.',
    '开始禅模式': 'Start Zen',
    '不用选难度：AI 会随你玩得越久越聪明（摆得更准、更会救场）。它落子的速度和你的节奏一直一样，不会比你快。':
      'No difficulty to pick: the AI sharpens the longer you play. It always drops at your own pace, never faster.',
    '越打越聪明，落子速度一直跟着你的节奏。': 'Sharper the longer you play; always drops at your pace.',
    '难度': 'Difficulty',
    '简单': 'Easy',
    '合体债': 'Debt',
    '合体债（跟着上面的档位）': 'Debt (follows the tier above)',
    '合体债三档用上面的按钮切；各档、各玩法的存档分开，点某一项的「删除」只清那一项。':
      'Only autosaves now: one per mode (plus three Debt tiers). Continue keeps playing, Delete clears just that one.',
    '帧率 / 声音 / 材质': 'Frame rate / Sound / Skin',
    '屏幕与设备': 'Screen & device',
    '方向 / 刷新率 / 安装包': 'Orientation / Refresh rate / APK',
    '简体中文': 'Simplified Chinese',
    '最近错误': 'Last error',
    '复制这一版说明': 'Copy this version note',
    '怎么更新': 'How to update',
    '对局结束': 'Game over',
    '决一死战': 'To the death',
    '我': 'Me',
    '消 0 · 活': 'Cleared 0 · Alive',
    '轻松': 'Easy',
    '计时': 'Timer',
    '难度（合体债）': 'Difficulty (Debt)',
    '附近的房间': 'Rooms nearby',
    '开始对局': 'Start',
    '复制下载链接': 'Copy download link',
    '复制安装包地址': 'Copy APK link',
    '新版下载地址（镜像）：': 'New download link (mirror):',
    '蓝牙发安装包': 'Send APK over Bluetooth',
    '蓝牙配对 / 换设备': 'Bluetooth pairing / devices',
    '上次的对手：—': 'Last opponent: —',
    '同一个 Wi-Fi，先选和谁玩，再开房或加入。': 'Same Wi-Fi: pick who you play with, then host or join.',
    '同一个 Wi-Fi 里自动找房间；没人开，就替你开一个': 'Finds a room on the same Wi-Fi; if none, hosts one for you',
    '昵称': 'Nickname',
    '快速匹配': 'Quick match',
    '2 人': '2 players',
    '没人开房。开一间：': 'Nobody is hosting. Open a room:',
    '3 人': '3 players',
    '4 人': '4 players',
    '手动输入地址 ▾': 'Enter address ▾',
    '加入这间': 'Join this one',
    '自己开': 'Host my own',
    '蓝牙对战（2 人）': 'Bluetooth 1v1 (2 players)',
    '蓝牙': 'Bluetooth',
    '加入房间': 'Join room',
    '玩家417': 'Player417',
    '对方：① 点「接受」 ② 点「安装」（可能要先允许未知来源） ③ 打开游戏 → 多人对战 → 快速匹配':
      'On their device: 1) tap Accept, 2) tap Install (you may need to allow unknown sources), 3) open the game → Multiplayer → Quick match',
    '普通': 'Normal',
    '困难': 'Hard',
    '地狱': 'Hell',
    '与 AI 决斗': 'Duel AI',
    'AI 对打（观战）': 'AI vs AI (watch)',
    '英文覆盖全部界面、教程、帮助和更新记录。': 'English covers every screen, the tutorial, help and the changelog.',
    '禅模式自动': 'Zen auto',
    '取消': 'Cancel',
    '删除存档': 'Delete save',
    '点一下检查更新': 'Tap to check for updates',
    '‹ 返回': '‹ Back',
    '单人': 'Solo',
    '局域网 · 并行赛': 'LAN · Parallel',
    '局域网 · 干扰战': 'LAN · Battle',
    '继续上一局': 'Continue last run',
    '覆盖安装一般保留存档，但更新会重启游戏；先在「更多 → 存档管理」保存或导出，再更新。':
      'Installing over it usually keeps saves, but updating restarts the game; save or export first from More → Saves.',
    '▼ 软降': '▼ Soft',
    '⤓ 硬降': '⤓ Hard',
    '重开 R': 'Restart R',
    '键盘：←→ 移动 · ↓ 软降 / 连点硬降 · ↑ 或 X 转 · Z 反转 · 空格 硬降 · P 暂停 · R 重开×2':
      'Keyboard: ←→ move · ↓ soft drop / double-tap hard drop · ↑ or X rotate · Z reverse · Space hard drop · P pause · R restart×2',

    /* 蓝牙 / 联机弹层 */
    '蓝牙对打': 'Bluetooth duel',
    '这个安装包还不支持蓝牙。': 'This build does not support Bluetooth.',
    '装一次最新 APK（0.8.0）再回来。': 'Install the latest APK (0.8.0) and come back.',
    '这台设备没有蓝牙。': 'This device has no Bluetooth.',
    '换个有蓝牙的安卓手机。': 'Use an Android phone with Bluetooth.',
    '蓝牙没开。': 'Bluetooth is off.',
    '开蓝牙': 'Turn on Bluetooth',
    '再检测': 'Check again',
    '需要蓝牙权限。': 'Bluetooth permission is required.',
    '允许蓝牙权限': 'Allow Bluetooth',
    '去系统设置': 'System settings',
    '没有已配对设备。先去系统蓝牙里把两台手机配对，再回来刷新。':
      'No paired devices. Pair both phones in system Bluetooth first, then refresh.',
    '不用 Wi-Fi/流量；两台手机先系统配对。': 'No Wi-Fi or data needed; pair both phones in system settings first.',
    '我是房主，等对方连': 'I host, wait for the other player',
    '已配对设备（点一个加入）': 'Paired devices (tap one to join)',
    '去系统蓝牙配对': 'Pair in system Bluetooth',
    '让手机搜到我（120 秒）': 'Make this phone discoverable (120s)',
    '刷新': 'Refresh',
    '本机': 'This device',
    '上次的对手': 'Last opponent',
  };

  const EN_HELP = ''
    + '<p class="h2">How to Play</p>'
    + '<button class="btn primary" id="btnHelpTutorial">Open tutorial</button>'
    + '<div class="rule"><b>Modes</b>　Main = <b>Debt</b> (10×10; clears push blocks up, debt carries across games) or <b>Classic</b> (10×20, standard scoring); Casual = Combo (10×10, chained multiplier) or Zen (10×12, 5/10 minutes, you cannot die); plus AI (duel/spectate) and multiplayer.</div>'
    + '<div class="rule"><b>Classic</b>　10×20; 1/2/3/4 lines = 100/300/500/800 × level, level up every 10 lines; no debt, fusion or arrow blocks.</div>'
    + '<div class="rule"><b>Score</b>　Below 10k shown as-is; above that as text + number like “10k / 12k”, the same in every mode.</div>'
    + '<div class="rule"><b>Saves</b>　Autosave only — one per mode (Debt also has three tiers). Continue or delete them under More → Saves, where you can also export a backup.</div>'
    + '<div class="rule"><b>Multiplayer</b>　Quick match on the same Wi-Fi (2–4 players), or paired Bluetooth (2 players); parallel compares scores only, battle pushes blocks to the opponent, and classic rules are parallel only.</div>'
    + '<div class="rule"><b>Install &amp; update</b>　The web bundle updates itself; you only reinstall the APK when a new shell ships — copy the mirror link from More → Version &amp; updates → How to update. Export saves first.</div>'
    + '<div class="rule"><b>More detail</b>　Fusion blocks, debt, rotation, arrow blocks, how you die and how to restart are all in the <b>tutorial</b> above (with pictures).</div>'
    + '<button class="btn small" data-back>Back</button>';

  let lang = 'zh';
  let watching = false;
  let applying = false;
  let scheduled = false;

  function resolve(setting) {
    if (setting === 'en') return 'en';
    if (setting === 'zh') return 'zh';
    var l = (navigator.language || 'zh').toLowerCase();
    return l.indexOf('zh') === 0 ? 'zh' : 'en';
  }

  function set(setting) {
    lang = resolve(setting);
    try { document.documentElement.lang = lang === 'en' ? 'en' : 'zh-CN'; } catch (e) {}
    localizeHelp(lang);
    if (lang === 'en') {
      if (document.body) {
        apply(document.body);
        watch();
      } else {
        document.addEventListener('DOMContentLoaded', function () { apply(document.body); watch(); }, { once: true });
      }
    }
    return lang;
  }

  var zhHelpHTML = null;
  function localizeHelp(now) {
    var sec = document.querySelector ? document.querySelector('.screen[data-screen="help"]') : null;
    if (!sec) return;
    if (zhHelpHTML === null) zhHelpHTML = sec.innerHTML;
    if (now === 'en') {
      if (sec.innerHTML !== EN_HELP) sec.innerHTML = EN_HELP;
    } else if (sec.innerHTML !== zhHelpHTML) {
      sec.innerHTML = zhHelpHTML;
    }
  }

  const CN_DIGIT = '零一二三四五六七八九';
  const CN_UNIT = ['', '十', '百', '千'];
  function cn4(n) {
    let s = '', zero = false;
    const d = [Math.floor(n / 1000) % 10, Math.floor(n / 100) % 10, Math.floor(n / 10) % 10, n % 10];
    for (let i = 0; i < 4; i++) {
      const v = d[i];
      if (!v) { if (s) zero = true; continue; }
      if (zero) { s += '零'; zero = false; }
      s += CN_DIGIT[v] + CN_UNIT[3 - i];
    }
    return s;
  }
  /* 中文分数用汉字写：12345 → 一万二千三百四十五；0 仍写 0 */
  function cnNumber(n) {
    n = Math.max(0, Math.floor(n || 0));
    if (n === 0) return '0';
    if (n < 10000) return cn4(n);
    const groups = [];
    let rest = n;
    while (rest > 0) { groups.push(rest % 10000); rest = Math.floor(rest / 10000); }
    const BIG = ['', '万', '亿', '万亿'];
    let out = '';
    for (let i = groups.length - 1; i >= 0; i--) {
      const grp = groups[i];
      if (!grp) { if (out && !/零$/.test(out)) out += '零'; continue; }
      if (out && grp < 1000 && !/零$/.test(out)) out += '零';
      let part = cn4(grp);
      if (i === groups.length - 1 && grp >= 10 && grp < 20) part = part.replace(/^一十/, '十');
      out += part + BIG[i];
    }
    return out.replace(/零+$/, '');
  }

  /* 面板很窄：最高分用紧凑写法（一百二十三万余），完整写法留给结算 */
  function cnCompact(n) {
    n = Math.max(0, Math.floor(n || 0));
    if (n < 10000) return cn4(n);
    if (n < 100000000) {
      const w = Math.floor(n / 10000);
      return cn4(w) + '万' + ((n % 10000) ? '余' : '');
    }
    const y = Math.floor(n / 100000000);
    return cn4(y) + '亿' + ((n % 100000000) ? '余' : '');
  }

  function fmtScoreLang(n, short) {
    n = Math.max(0, Math.floor(n || 0));
    if (lang !== 'en') return short ? cnCompact(n) : cnNumber(n);
    if (n < 10000) return String(n);
    if (n < 1000000) {
      var v = n / 1000;
      return (v >= 100 ? String(Math.round(v)) : String(Math.round(v * 10) / 10)).replace(/\.0$/, '') + 'k';
    }
    var mm = n / 1000000;
    return (mm >= 100 ? String(Math.round(mm)) : String(Math.round(mm * 10) / 10)).replace(/\.0$/, '') + 'M';
  }

  function t(s) {
    if (lang !== 'en' || s == null) return s;
    var key = String(s).trim();
    return DICT[key] || s;
  }

  function apply(root) {
    if (lang !== 'en' || !root || applying) return;
    applying = true;
    var scope = root.nodeType === 9 ? root.body : root;
    if (!scope) { applying = false; return; }
    var walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, null);
    var nodes = [], n;
    while ((n = walker.nextNode())) nodes.push(n);
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      var p = node.parentElement;
      if (!p) continue;
      if (p.closest('script,style,canvas,#tut,.screen[data-screen="help"],.logo')) continue;
      var raw = node.nodeValue || '';
      var key = raw.trim();
      if (!key) continue;
      var val = DICT[key];
      if (key === '关闭') val = p.closest('.seg') ? 'Off' : 'Close';
      if (!val) continue;
      node.nodeValue = raw.replace(key, val);
    }
    var attrs = scope.querySelectorAll ? scope.querySelectorAll('[placeholder],[title]') : [];
    for (var j = 0; j < attrs.length; j++) {
      var el = attrs[j];
      ['placeholder', 'title'].forEach(function (a) {
        var v = el.getAttribute(a);
        if (v && DICT[v.trim()]) el.setAttribute(a, DICT[v.trim()]);
      });
    }
    applying = false;
  }

  function watch() {
    if (watching || !document.body) return;
    watching = true;
    new MutationObserver(function () {
      if (lang !== 'en' || applying || scheduled) return;
      scheduled = true;
      requestAnimationFrame(function () {
        scheduled = false;
        apply(document.body);
      });
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  window.TetrisI18n = {
    set: set,
    t: t,
    apply: apply,
    fmtScore: fmtScoreLang,
    get lang() { return lang; }
  };
})();

/* game.js —— 合体债 · 画面 / 输入 / 存档 / 提示
 *
 * 规则全在 engine.js；这里只负责把状态画出来、把手感做出来。
 * 入口：window.TetrisGame.start({mode, seed, settings})
 *   mode: 'solo' | 'resume'（ai / lan 还没做，返回 false 让菜单提示）
 */
(function () {
  'use strict';

  const E = window.TetrisEngine;
  if (!E) { console.error('[tetris] engine.js 没加载'); return; }
  const C = E.CONST;
  const SHAPES = E.SHAPES;
  const COLORS = E.COLORS;
  const fmtScore = (window.TetrisI18n && window.TetrisI18n.fmtScore) || E.fmtScore;
  function T(s) { return window.TetrisI18n ? window.TetrisI18n.t(s) : s; }
  function EN() { return !!(window.TetrisI18n && window.TetrisI18n.lang === 'en'); }
  function unit(n, one, many) { return String(n) === '1' ? one : many; }
  function lineCount(n) { return n + ' ' + unit(n, 'line', 'lines'); }

  /* 方块材质：只改画法，不改规则。尺寸按 32px 格设计，其他格子按比例缩。 */
  const SKINS = [
    { id: 'solid', name: '原味', pad: 2, radius: 6, line: 1, glow: 12 },
    { id: 'minimal', name: '极简', pad: 3, radius: 7, line: 1, glow: 3 },
    { id: 'modern', name: '现代', pad: 2, radius: 8, line: 1, glow: 8 },
    { id: 'pixel', name: '像素', pad: 1, radius: 0, line: 1, glow: 4 },
    { id: 'neon', name: '霓虹', pad: 2, radius: 7, line: 2, glow: 0 },
    /* 节日材质：不进「方块材质」那排（hidden），只在节日生效，由 theme.js 指定。
       base = 用哪套基础画法，deco = 在上面加的那点装饰。 */
    { id: 'h-newyear', name: '元旦', hidden: true, base: 'modern', deco: 'spark', pad: 2, radius: 8, line: 1, glow: 10 },
    { id: 'h-spring', name: '春节', hidden: true, base: 'solid', deco: 'gold', pad: 2, radius: 5, line: 1, glow: 14 },
    { id: 'h-lantern', name: '元宵', hidden: true, base: 'modern', deco: 'lamp', pad: 2, radius: 9, line: 1, glow: 12 },
    { id: 'h-dragon', name: '端午', hidden: true, base: 'minimal', deco: 'leaf', pad: 3, radius: 6, line: 1, glow: 6 },
    { id: 'h-moon', name: '中秋', hidden: true, base: 'modern', deco: 'moon', pad: 2, radius: 10, line: 1, glow: 12 },
    { id: 'h-national', name: '国庆', hidden: true, base: 'solid', deco: 'star', pad: 2, radius: 3, line: 1, glow: 10 },
    { id: 'h-longtou', name: '龙抬头', hidden: true, base: 'minimal', deco: 'leaf', pad: 3, radius: 6, line: 1, glow: 6 },
    { id: 'h-qingming', name: '清明', hidden: true, base: 'minimal', deco: 'rain', pad: 3, radius: 7, line: 1, glow: 5 },
    { id: 'h-qixi', name: '七夕', hidden: true, base: 'modern', deco: 'lamp', pad: 2, radius: 9, line: 1, glow: 11 },
    { id: 'h-zhongyuan', name: '中元', hidden: true, base: 'minimal', deco: 'moon', pad: 3, radius: 8, line: 1, glow: 5 },
    { id: 'h-chongyang', name: '重阳', hidden: true, base: 'solid', deco: 'gold', pad: 2, radius: 6, line: 1, glow: 10 },
    { id: 'h-laba', name: '腊八', hidden: true, base: 'solid', deco: 'spark', pad: 2, radius: 6, line: 1, glow: 9 },
    { id: 'h-dongzhi', name: '冬至', hidden: true, base: 'modern', deco: 'ember', pad: 2, radius: 10, line: 1, glow: 9 }
  ];
  const SKIN_ALIAS = { glass: 'modern', matte: 'minimal' };
  /* noOverride：查「基础材质」时必须带上，否则节日材质会一直盖着自己，递归死循环 */
  function skinDef(id, noOverride) {
    let ov = '';
    if (!noOverride && window.TetrisTheme && typeof window.TetrisTheme.skinOverride === 'function') {
      try { ov = window.TetrisTheme.skinOverride() || ''; } catch (e) { ov = ''; }
    }
    const raw = ov || id || (settings && settings.skin) || 'solid';
    const key = SKIN_ALIAS[raw] || raw;
    for (let i = 0; i < SKINS.length; i++) if (SKINS[i].id === key) return SKINS[i];
    return SKINS[0];
  }
  function randomSkin(exclude) {
    let id = SKINS[Math.floor(Math.random() * SKINS.length)].id;
    let guard = 0;
    while (id === exclude && guard++ < 8) {
      id = SKINS[Math.floor(Math.random() * SKINS.length)].id;
    }
    return id;
  }
  function hexRgb(hex) {
    if (!/^#[0-9a-f]{6}$/i.test(hex || '')) return null;
    return {
      r: parseInt(hex.slice(1, 3), 16),
      g: parseInt(hex.slice(3, 5), 16),
      b: parseInt(hex.slice(5, 7), 16)
    };
  }
  function shade(hex, amt) {
    const c = hexRgb(hex);
    if (!c) return hex;
    const t = amt >= 0 ? 255 : 0, p = Math.min(1, Math.abs(amt));
    return 'rgb(' + Math.round(c.r + (t - c.r) * p) + ','
      + Math.round(c.g + (t - c.g) * p) + ','
      + Math.round(c.b + (t - c.b) * p) + ')';
  }
  function tint(hex, a) {
    const c = hexRgb(hex);
    return c ? 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',' + a + ')' : hex;
  }
  const LS = {
    auto: 'tetris.auto',
    autoClassic: 'tetris.auto.classic',
    autoCasual: 'tetris.casual.auto',
    zenAuto: 'tetris.zen.auto',
    carry: 'tetris.carry',
    high: 'tetris.high',
    highClassic: 'tetris.high.classic',
    highCasual: 'tetris.high.casual',
    zenHigh5: 'tetris.zen.high.5',
    zenHigh10: 'tetris.zen.high.10'
  };

  const SAVE_NAME = { normal: '单人玩法', classic: '经典玩法', casual: '常驻玩法' };

  /* 难度三档：合体债的存档、最高分、债、连续没还清的计数，全部按档分开。
     困难沿用老 key（tetris.auto / tetris.slot1 / tetris.carry / tetris.high），
     所以老玩家升级后看到的就是原来那一档，什么都没丢。 */
  const TIERS = ['easy', 'normal', 'hard'];
  const TIER_ZH = { easy: '轻松', normal: '普通', hard: '困难' };
  const TIER_EN = { easy: 'Easy', normal: 'Normal', hard: 'Hard' };
  function curTier() {
    const t = settings && settings.tier;
    return TIERS.indexOf(t) >= 0 ? t : 'normal';
  }
  function tierName(t) {
    t = TIERS.indexOf(t) >= 0 ? t : 'normal';
    return (EN() ? TIER_EN : TIER_ZH)[t];
  }
  function tierOf(g) {
    return (g && g.rules && g.rules.id) || curTier();
  }
  function tierKey(base, t) {
    return (t || 'normal') === 'hard' ? base : base + '.' + (t || 'normal');
  }

  let W = 480, H = 320, BOARD = 320, PX = 328, PW = 144, BW = 320;

  // 棋盘尺寸跟着引擎走：合体债 10×10（32px 格），原版 10×20（16px 格，盘面更高）
  function layoutFor(g) {
    const classic = !!(g && g.classic);
    C.CELL = classic ? 16 : 32;
    const cols = g ? g.cols : C.COLS;
    const rows = g ? g.rows : C.ROWS;
    BW = C.CELL * cols;
    H = C.CELL * rows;
    BOARD = H;
    PX = BW + 8;
    W = PX + PW + 8;
  }
  const FONT = 'system-ui,-apple-system,"Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif';

  let root = null, canvas = null, ctx = null, stageEl = null;
  let pauseLayer = null, skinsBox = null, overBar = null, toastEl = null;
  let fileInput = null, modeEl = null;
  let built = false;
  let running = false;
  let raf = 0, lastFrame = 0;
  let game = null;
  let paused = false;
  let over = false;
  let overInfo = null;
  let effects = [];
  let dasDir = 0, dasT = 0, arrT = 0;
  let touchAct = null;
  let lastDownTap = 0;
  let taps = { n: 0, t: 0 };
  let toastTimer = 0;
  let uiFitTimer = 0;
  let highScore = 0;
  let settings = { sound: true, fps: '60', skin: 'solid', intro: 'every' };

  // 统一入口：按设置决定场地要不要自己转
  function highKey() {
    if (game && game.zen) return game.zenMinutes === 10 ? LS.zenHigh10 : LS.zenHigh5;
    if (game && game.casual) return LS.highCasual;
    if (game && game.classic) return LS.highClassic;
    return tierKey(LS.high, (game && game.rules && game.rules.id) || curTier());
  }

  /* ---------------- 性能档（质量） ----------------
     不是认机型，是量帧时间：连续卡就降一档画质，稳了再升回去。
     三档只动「画」的东西（毛玻璃/粒子/背板分辨率/帧率上限），不碰规则。 */
  const Q_ORDER = ['low', 'mid', 'high'];
  const QUALITY = { tier: 'high', p95: 0, win: [], cooldownUntil: 0, budget: 16.7 };
  function qDprCap() { return QUALITY.tier === 'low' ? 1.5 : 2; }
  function qFpsCap() {
    const user = fpsCap || 0;                 // 0 = 自动
    if (QUALITY.tier === 'low') return user ? Math.min(user, 45) : 45;
    return user;
  }
  function setQuality(t, quiet) {
    if (Q_ORDER.indexOf(t) < 0) return;
    const changed = QUALITY.tier !== t;
    QUALITY.tier = t;
    const de = document.documentElement;
    de.classList.toggle('q-low', t === 'low');
    de.classList.toggle('q-mid', t === 'mid');
    try { localStorage.setItem('tetris.quality', t); } catch (e) {}
    if (canvas) {
      fit();
      if (game && (paused || over)) render(performance.now());   // 暂停/结算时换档别留白
    }
    if (changed && !quiet) dispatch('tetris-quality', qualityInfo());
  }
  function qualityInit() {
    let t = '';
    try { t = localStorage.getItem('tetris.quality') || ''; } catch (e) {}
    if (Q_ORDER.indexOf(t) < 0) {
      let s = 60;
      try { if (window.TetrisPerf) s = window.TetrisPerf.score(); } catch (e) {}
      t = s >= 55 ? 'high' : (s >= 35 ? 'mid' : 'low');
    }
    setQuality(t, true);
  }
  function qualityInfo() {
    let score = 0;
    try { if (window.TetrisPerf) score = window.TetrisPerf.score(); } catch (e) {}
    return { tier: QUALITY.tier, p95: Math.round(QUALITY.p95), score: score };
  }
  function qualitySample(dt) {
    const cap = qFpsCap();
    QUALITY.budget = cap ? 1000 / cap : 1000 / 60;
    QUALITY.win.push(dt);
    if (QUALITY.win.length > 240) QUALITY.win.shift();
    if (QUALITY.win.length < 60) return;
    const s = QUALITY.win.slice().sort(function (a, b) { return a - b; });
    QUALITY.p95 = s[Math.floor(s.length * 0.95)];
    if (QUALITY.win.length % 120 !== 0) return;
    qualityTick();
  }
  function qualityTick() {
    const now = performance.now();
    if (now < QUALITY.cooldownUntil) return;
    const budget = QUALITY.budget || 16.7;
    const bad = QUALITY.p95 > budget * 1.45;
    const good = QUALITY.p95 < budget * 1.15;   // 稳在目标帧率就算好，不必富余
    const idx = Q_ORDER.indexOf(QUALITY.tier);
    if (bad && idx > 0) {
      setQuality(Q_ORDER[idx - 1]);
      QUALITY.cooldownUntil = now + 20000;
      QUALITY.win = [];
    } else if (good && idx < Q_ORDER.length - 1) {
      setQuality(Q_ORDER[idx + 1]);
      QUALITY.cooldownUntil = now + 30000;
      QUALITY.win = [];
    }
  }
  window.TetrisQuality = { info: qualityInfo, set: setQuality, init: qualityInit };
  function mk(opts) {
    opts = Object.assign({}, opts || {});
    // 合体债按当前档位建引擎；经典/常驻/禅不看档位
    if (!opts.ruleset && !opts.classic && !opts.casual) opts.ruleset = curTier();
    const g = new E.Tetris(opts);
    return g;
  }
  let startSeed = null;
  let modeLabel = '单人';
  let fpsCap = 60;
  let frameAcc = 0;
  let restartArmed = 0;
  let lastInputAt = 0;
  let idleHintShown = false;
  let net = null;
  let multi = null;
  let modeIntro = null;
  let introStamp = 0;
  let clockEl = null, clockTimer = 0;
  let spectate = null;
  let aiMode = false;
  let aiState = null;
  /* 累计游玩时长：AI 的聪明程度就按它涨（难度选项已经砍掉）。
     每玩满 1.5 分钟涨一点，最多 24 点；中途退出也算，写进 localStorage。 */
  const PLAY_KEY = 'tetris.playMs';
  let playMs = 0, playMsSavedAt = 0;
  try { playMs = parseInt(localStorage.getItem(PLAY_KEY) || '0', 10) || 0; } catch (e) {}
  function addPlayMs(dt) {
    if (!(dt > 0) || dt > 250) return;            // 从后台切回来那种大跳不算
    playMs += dt;
    const now = Date.now();
    if (now - playMsSavedAt > 5000) {
      playMsSavedAt = now;
      try { localStorage.setItem(PLAY_KEY, String(playMs | 0)); } catch (e) {}
    }
  }
  function aiLevelFromPlay() {
    return Math.max(0, Math.min(24, Math.floor(playMs / 90000)));
  }
  /* AI 自适应节流：v = 当前压力系数（1~2.4），cost = 决策耗时的指数平均 */
  const AIPACE = { v: 1, cost: 0 };
  /* 玩家自己的落子节奏：最近 8 块之间的间隔（毫秒）。AI 的速度只能贴着它走，
     不许比玩家快过 5% —— 哥 2026-11-24 定的规矩。 */
  let plyLocks = [];
  let resultEl = null, vsEl = null, vsYou = null, vsOpp = null, vsState = null;
  let vsDefaultHTML = '';
  let lbListEl = null, lbStateEl = null;

  /* ---------------- 联机名册（2/3/4 人共用一套） ---------------- */
  function normRoster(raw) {
    if (!Array.isArray(raw)) return [];
    const out = [];
    for (const it of raw) {
      if (!it) continue;
      if (typeof it === 'string') {
        out.push({ seat: out.length, name: it, score: 0, clears: 0, dead: false, host: false });
      } else {
        out.push({
          seat: it.seat | 0, name: String(it.name || ''), score: it.score | 0, clears: it.clears | 0,
          dead: !!it.dead, host: !!it.host, ready: !!it.ready, web: it.web | 0, apk: it.apk | 0
        });
      }
    }
    return out;
  }
  function rosterAll() { return (multi && multi.roster) ? multi.roster : []; }
  function otherRows() { return rosterAll().filter(p => p.seat !== multi.mySeat); }
  function isBigMatch() { return !!(multi && multi.seats > 2); }
  function escHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---------------- 小工具 ---------------- */

  function $(sel) { return root ? root.querySelector(sel) : null; }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function readJSON(key) {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : null; } catch (e) { return null; }
  }
  function writeJSON(key, obj) {
    try { localStorage.setItem(key, JSON.stringify(obj)); return true; } catch (e) { return false; }
  }
  function readCarry(tier) {
    try { const n = parseInt(localStorage.getItem(tierKey(LS.carry, tier || curTier())) || '0', 10); return isFinite(n) && n > 0 ? n : 0; } catch (e) { return 0; }
  }
  function setCarry(n, tier) {
    try { localStorage.setItem(tierKey(LS.carry, tier || curTier()), String(Math.max(0, n | 0))); } catch (e) {}
  }
  /* 每局没还清就消 15%：比「连输 3 局减半」直观，也不跟三档难度打架。 */
  function restructureDebt(debt) {
    const n = Math.max(0, debt | 0);
    if (n <= 0) return 0;
    const next = Math.round(n * 0.85);
    if (next < n) {
      toast(EN()
        ? 'Unpaid — debt eased 15%: -' + n + ' -> -' + next
        : '没还清，债消 15%：-' + n + ' → -' + next);
    }
    return next;
  }  function dispatch(name, detail) {
    try { document.dispatchEvent(new CustomEvent(name, { detail: detail })); } catch (e) {}
  }
  function toast(msg) {
    if (!toastEl) return;
    msg = T(msg);
    toastEl.textContent = msg;
    toastEl.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('on'); }, 2200);
  }
  function cue(name, data) {
    if (!window.Cues) return;
    try { window.Cues.cue(name, data); } catch (e) {}
  }

  function applyFps() {
    const v = settings.fps;
    if (v === 'auto') fpsCap = 0;
    else fpsCap = clamp(parseInt(v, 10) || 60, 30, 144);
    frameAcc = 0;
    updatePauseNote();
  }

  function updatePauseNote() {
    const el = $('#tgNote');
    if (!el) return;
    let dev = '';
    if (window.TetrisDevice) {
      try {
        const d = window.TetrisDevice.info();
        dev = '屏幕 ' + d.width + '×' + d.height + (d.hz ? ' · ' + d.hz + 'Hz' : '') + ' · ';
      } catch (e) {}
    }
    if (EN()) {
      let devEn = '';
      if (window.TetrisDevice) {
        try {
          const d = window.TetrisDevice.info();
          devEn = 'Screen ' + d.width + '×' + d.height + (d.hz ? ' · ' + d.hz + 'Hz' : '') + ' · ';
        } catch (e) {}
      }
      el.textContent = devEn + 'FPS ' + (fpsCap ? ('cap ' + fpsCap) : 'auto')
        + '. Auto-saves after every lock.';
      return;
    }
    el.textContent = dev + '帧率' + (fpsCap ? ('上限 ' + fpsCap + ' 帧') : '跟随屏幕')
      + '。每块落地自动存档。';
  }

  /* R / 暂停里的「重开」都走这里：第一次只提醒，3 秒内再来一次才真的重开 */
  function requestRestart() {
    if (!game) return;
    if (multi) { toast(EN() ? 'Cannot restart mid-match — exit to menu and start a new game' : '联机中不能重开，返回菜单再开一局'); return; }
    if (aiMode) { toast(EN() ? 'Cannot restart against the AI — exit to menu and start a new game' : '打 AI 中不能重开，返回菜单再开一局'); return; }
    if (over) { restartGame(); return; }
    const now = performance.now();
    if (restartArmed && now - restartArmed < 3000) {
      restartArmed = 0;
      restartGame();
      return;
    }
    restartArmed = now;
    toast(EN() ? 'Press R again / tap Restart again to confirm' : '再按一次 R / 再点一次「重开」确认');
    const b = $('#tgRestart');
    if (b) {
      b.textContent = EN() ? 'Tap again to confirm' : '再点一次确认';
      if (b._armTimer) clearTimeout(b._armTimer);
      b._armTimer = setTimeout(function () { b.textContent = T('重开'); }, 3000);
    }
  }

  function resetRestartButton() {
    restartArmed = 0;
    const b = $('#tgRestart');
    if (b) {
      b.textContent = T('重开');
      if (b._armTimer) clearTimeout(b._armTimer);
    }
  }

  /* ---------------- DOM / CSS ---------------- */

  const CSS = `
  #tg{
    /* 键位尺寸由 game.js 的 uiFit() 每次进游戏现算，这里只是没算之前的兜底值 */
    --tg-btn:44px;--tg-gap:6px;--tg-edge:12px;--tg-font:13px;--tg-thumb:16px;
    --tg-stage-pl:170px;--tg-stage-pr:90px;--tg-rot-w:160px;
    --tg-board-w:560px;--tg-hud-h:38px;
    position:fixed;inset:0;z-index:50;display:none;flex-direction:column;align-items:center;
    gap:8px;padding:calc(env(safe-area-inset-top) + 8px) 10px calc(env(safe-area-inset-bottom) + 8px);
    background:radial-gradient(120% 70% at 50% -12%,rgba(62,224,198,.10),transparent 55%),#08090d;
    color:#e9edf6;font-family:${FONT};user-select:none;-webkit-user-select:none;
    overflow:hidden;touch-action:manipulation;
  }
  #tg.on{display:flex}
  /* AI 观战：只留画布和返回，其他操作全藏掉 */
  #tg.is-spectate .tg-pad,
  #tg.is-spectate .tg-keys,
  #tg.is-spectate .tg-vs,
  #tg.is-spectate .tg-over,
  #tg.is-spectate [data-cmd="pause"]{display:none!important}
  /* 大屏（电视/电脑浏览器/横屏平板）才用得到：棋盘铺满、顶栏也放大。
     手机上这些规则一条都不生效，class 由 uiFit() 加。 */
  html.big .tg-bar{height:var(--tg-hud-h)}
  html.big .tg-btn{
    height:var(--tg-hud-h);font-size:calc(var(--tg-hud-h) * .32);
    padding:0 calc(var(--tg-hud-h) * .34);border-radius:calc(var(--tg-hud-h) * .28);
  }
  html.big .tg-title{font-size:calc(var(--tg-hud-h) * .28);letter-spacing:.22em}
  html.big .tg-vs{height:calc(var(--tg-hud-h) * .72);font-size:calc(var(--tg-hud-h) * .28)}
  html.big .tg-vs b{font-size:calc(var(--tg-hud-h) * .33)}
  html.big .tg-over-tip{font-size:calc(var(--tg-hud-h) * .32)}
  html.big .tg-over-btns button{height:calc(var(--tg-hud-h) * 1.15);font-size:calc(var(--tg-hud-h) * .36)}
  html.big .tg-toast{font-size:calc(var(--tg-hud-h) * .34);padding:calc(var(--tg-hud-h) * .26) calc(var(--tg-hud-h) * .4)}
  .tg-bar{width:100%;max-width:100%;padding:0 10px;height:38px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex:0 0 auto}

  #tg.is-spectate .tg-bar{max-width:100%;padding:0 10px}
  /* 观战只有一个返回键，右侧补一个等宽占位，标题才居中 */
  #tg.is-spectate .tg-bar::after{content:'';width:56px;height:38px;flex:none}
  .tg-pause-head{display:flex;align-items:baseline;justify-content:space-between;gap:10px}
  .tg-pause-clock{
    font:600 12px/1 ui-monospace,SFMono-Regular,Consolas,"Noto Sans SC",monospace;
    color:#79839a;letter-spacing:.04em;font-variant-numeric:tabular-nums;white-space:nowrap;
  }
  .tg-btn{
    height:38px;padding:0 14px;border-radius:11px;border:1px solid #232838;background:#12141b;color:#e9edf6;
    font:inherit;font-size:13px;cursor:pointer;transition:.15s;
  }
  .tg-btn:active{transform:scale(.96)}
  .tg-title{font-size:11px;letter-spacing:.28em;color:#79839a;white-space:nowrap}
  .tg-vs{
    display:none;width:100%;max-width:min(100%,var(--tg-board-w,560px));height:24px;flex:0 0 auto;
    align-items:center;justify-content:center;gap:12px;font-size:11px;color:#79839a;
  }
  .tg-vs b{color:#e9edf6;font-size:13px;font-variant-numeric:tabular-nums}
  .tg-vs-state{margin-left:auto;color:#5b6479;font-size:10px}
  .tg-vs-list{display:flex;align-items:center;justify-content:center;gap:10px;flex:1 1 auto;min-width:0;flex-wrap:wrap}
  .tg-vs-list b{color:#8f99ad;font-size:11px;font-weight:600;font-variant-numeric:tabular-nums;white-space:nowrap;letter-spacing:.02em}
  .tg-vs-list b.me{color:#e9edf6;font-weight:800}
  .tg-vs-list b.out{color:#4c5568;text-decoration:line-through}
  .tg-rank-me{color:#3ee0c6;font-weight:700}
  #tg.is-wait .tg-over-btns{display:none}
  #tg.is-wait .tg-over-tip{color:#ffd479}
  #tg.is-ai .tg-keys{display:none}
  /* 打 AI / 多人：比分只放在棋盘左侧的窄排行榜里，顶上那条比分条不再显示 */
  #tg.is-ai .tg-vs,#tg.is-multi .tg-vs{display:none}
  .tg-lb{display:none;position:absolute;left:10px;
    top:calc(env(safe-area-inset-top) + 14px + var(--tg-hud-h,38px));
    width:112px;flex-direction:column;gap:5px;z-index:6}
  #tg.is-ai .tg-lb,#tg.is-multi .tg-lb{display:flex}
  .tg-lb-head{font:600 10px/1.2 ui-monospace,SFMono-Regular,Consolas,monospace;color:#5b6479;
    letter-spacing:.08em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .tg-lb-list{display:flex;flex-direction:column;gap:5px}
  .tg-lb-row{padding:4px 7px 5px;border-radius:8px;background:rgba(15,18,25,.92);border:1px solid #1b2030}
  .tg-lb-row.me{border-color:#2a514b;background:rgba(16,24,32,.94)}
  .tg-lb-row.out{opacity:.5}
  .tg-lb-top{display:flex;align-items:baseline;gap:4px;font-size:10px;color:#8f99ad;min-width:0}
  .tg-lb-n{flex:0 0 auto;font:700 10px/1 ui-monospace,SFMono-Regular,Consolas,monospace;color:#5b6479}
  .tg-lb-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .tg-lb-row.me .tg-lb-name{color:#3ee0c6;font-weight:700}
  .tg-lb-sc{display:block;font:700 15px/1.15 ui-monospace,SFMono-Regular,Consolas,monospace;color:#e9edf6;
    font-variant-numeric:tabular-nums}
  .tg-lb-sub{display:block;font-size:9px;color:#5b6479;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}  .tg-result{
    position:absolute;inset:0;z-index:6;display:none;align-items:center;justify-content:center;
    padding:18px;background:rgba(4,5,8,.78);backdrop-filter:blur(6px);
  }
  .tg-result.on{display:flex}
  #tg.is-result .tg-pad,#tg.is-result .tg-keys{display:none}
  .tg-result .tg-btn{margin-top:4px}
  .tg-stage{flex:1 1 auto;min-height:0;width:100%;display:flex;align-items:center;justify-content:center;gap:10px}
  /* 联机开局：双方握手，然后进入棋盘 */
  .tg-intro{
    position:absolute;inset:0;z-index:60;display:none;flex-direction:column;
    align-items:center;justify-content:center;gap:6px;
    background:rgba(5,6,10,.86);backdrop-filter:blur(5px);
  }
  #tg.is-intro #tgIntro,#tgIntro.show{display:flex}
  #tg.is-mode-intro #tgModeIntro,#tgModeIntro.show{display:flex}
  .tg-intro{transition:opacity .32s ease}
  .tg-intro.out{opacity:0}
  .tg-duel-stage{position:relative;width:min(92vw,520px);height:180px;margin:0 0 2px}
  .tg-duel-side{
    position:absolute;top:50%;left:50%;font-size:72px;font-weight:800;line-height:1;
    will-change:transform,opacity;font-family:ui-monospace,"Noto Sans SC","Microsoft YaHei",monospace;
  }
  .tg-duel-side.you{color:#3ee0c6;text-shadow:4px 4px 0 rgba(0,0,0,.6);animation:duelYou 1.5s cubic-bezier(.2,.8,.3,1) both}
  .tg-duel-side.me{color:#ffc857;text-shadow:4px 4px 0 rgba(0,0,0,.6);animation:duelMe 1.5s cubic-bezier(.2,.8,.3,1) both}
  .tg-duel-burst{position:absolute;top:50%;left:50%;width:0;height:0;pointer-events:none}
  .tg-duel-burst i{
    position:absolute;left:0;top:0;width:var(--w,6px);height:var(--h,6px);
    margin:calc(var(--h,6px) / -2) 0 0 calc(var(--w,6px) / -2);
    background:var(--c,#3ee0c6);opacity:0;border-radius:1px;
    will-change:transform,opacity;
    animation:duelBurst .62s cubic-bezier(.15,.75,.25,1) .3s both;
  }
  .tg-duel-spark{
    position:absolute;top:50%;left:50%;width:12px;height:12px;margin:-6px 0 0 -6px;
    border-radius:50%;border:2px solid rgba(233,237,246,.45);opacity:0;pointer-events:none;
    animation:duelSpark .4s ease-out .3s both;
  }
  .tg-duel-title{
    position:absolute;top:50%;left:50%;white-space:nowrap;
    transform:translate(-50%,-50%);opacity:0;will-change:transform,opacity;
    animation:duelTitle 1.04s cubic-bezier(.32,.06,.4,1) .5s both;
  }
  .tg-duel-title span{
    display:inline-block;font-size:42px;font-weight:800;letter-spacing:.18em;color:#e9edf6;
    text-shadow:3px 3px 0 #1b2430,0 0 16px rgba(62,224,198,.16);
    animation:duelPop .2s ease-out .5s both;
  }
  .tg-mode-stage{position:relative;width:min(92vw,620px);height:210px;display:flex;align-items:center;justify-content:center}
  .tg-mode-text{
    font-size:clamp(28px,5.4vw,46px);font-weight:800;letter-spacing:.14em;color:#e9edf6;
    white-space:nowrap;will-change:transform,opacity,filter;
    text-shadow:3px 3px 0 #1b2430,0 0 18px rgba(62,224,198,.14);
  }
  .tg-mode-intro.shatter .tg-mode-text{animation:modeShatter 1.02s cubic-bezier(.2,.8,.3,1) both}
  .tg-mode-intro.retire .tg-mode-text{animation:modeRetire 1.02s cubic-bezier(.3,.8,.3,1) both}
  .tg-mode-skip{font-size:11px;color:#5b6479;letter-spacing:.14em;margin-top:8px}
  .tg-intro h3,.tg-intro p{display:none}
  #tg .tg-stage{transition:opacity .3s ease,transform .3s ease}
  #tg.is-intro .tg-stage,#tg.is-mode-intro .tg-stage{opacity:.3;transform:scale(.97)}
  @keyframes duelYou{
    0%{transform:translate(-50%,-50%) translateX(-210px) scale(.82);opacity:0}
    10%{opacity:1}
    20%{transform:translate(-50%,-50%) translateX(-30px) scale(1.06)}
    25%{transform:translate(-50%,-50%) translateX(-30px) scale(1)}
    29%{transform:translate(-50%,-50%) translateX(-48px) scale(1.2);opacity:.9}
    33%,100%{transform:translate(-50%,-50%) translateX(-76px) scale(1.42);opacity:0}
  }
  @keyframes duelMe{
    0%{transform:translate(-50%,-50%) translateX(210px) scale(.82);opacity:0}
    10%{opacity:1}
    20%{transform:translate(-50%,-50%) translateX(30px) scale(1.06)}
    25%{transform:translate(-50%,-50%) translateX(30px) scale(1)}
    29%{transform:translate(-50%,-50%) translateX(48px) scale(1.2);opacity:.9}
    33%,100%{transform:translate(-50%,-50%) translateX(76px) scale(1.42);opacity:0}
  }
  @keyframes duelBurst{
    0%{opacity:0;transform:translate(0,0) scale(.8) rotate(0)}
    6%{opacity:1}
    55%{opacity:.7}
    100%{opacity:0;transform:translate(var(--dx,60px),var(--dy,0)) scale(1) rotate(var(--r,90deg))}
  }
  @keyframes duelSpark{
    0%{opacity:.55;transform:scale(.35)}
    100%{opacity:0;transform:scale(7)}
  }
  @keyframes duelTitle{
    0%{opacity:0;transform:translate(-50%,-50%) translate(0,0) scale(.96)}
    8%{opacity:1}
    14%{transform:translate(-50%,-50%) translate(-10px,0) rotate(-2.2deg)}
    20%{transform:translate(-50%,-50%) translate(10px,0) rotate(2.2deg)}
    26%{transform:translate(-50%,-50%) translate(-8px,0) rotate(-1.6deg)}
    32%{transform:translate(-50%,-50%) translate(8px,0) rotate(1.6deg)}
    38%{transform:translate(-50%,-50%) translate(-6px,0) rotate(-1.2deg)}
    44%{transform:translate(-50%,-50%) translate(6px,0) rotate(1.2deg)}
    50%{transform:translate(-50%,-50%) translate(0,0) rotate(0)}
    56%{transform:translate(-50%,-50%) translate(0,-9px) scale(1.05)}
    64%{opacity:1;transform:translate(-50%,-50%) translate(0,0) scale(1)}
    90%{opacity:1;transform:translate(-50%,-50%) translate(0,150px) scale(.8) rotate(3.5deg)}
    100%{opacity:0;transform:translate(-50%,-50%) translate(0,214px) scale(.7) rotate(5deg)}
  }
  @keyframes duelPop{
    0%{opacity:0;transform:scale(.62)}
    100%{opacity:1;transform:scale(1)}
  }
  @keyframes modeShatter{
    0%{opacity:0;transform:scale(.9)}
    10%{opacity:1;transform:scale(1.02)}
    24%{transform:scale(1)}
    32%{transform:scale(1.05)}
    37%{opacity:1;transform:scale(1.16)}
    49%,100%{opacity:0;transform:scale(1.44)}
  }
  @keyframes modeRetire{
    0%{opacity:0;transform:translateY(18px) scale(.96)}
    12%{opacity:1;transform:translateY(0) scale(1)}
    55%{opacity:1;transform:translateY(0) scale(1)}
    100%{opacity:0;transform:translateY(-54px) scale(.8);filter:blur(1.5px)}
  }
  #tgCanvas{
    max-width:min(100%,var(--tg-board-w,560px));max-height:100%;width:auto;height:auto;border-radius:12px;display:block;
    box-shadow:0 22px 60px -26px #000,0 0 0 1px rgba(62,224,198,.09);
    touch-action:none;
  }
  .tg-pad{
    /* 竖屏：贴屏幕左右两边，离底边留一点拇指高度（横屏见下面的 html.land 规则） */
    width:100%;max-width:none;display:flex;justify-content:space-between;align-items:flex-end;
    gap:var(--tg-gap);flex:0 0 auto;touch-action:none;
    padding:0 var(--tg-edge);margin:0 0 var(--tg-thumb) 0;
  }
  .pad-side{display:grid;gap:var(--tg-gap)}
  /* 2026-11-24 哥定的：← → 贴左边、↻ ↓ 贴右边，拇指不用横跨屏幕；暂存删掉 */
  .pad-left{width:auto;grid-template-columns:repeat(2,var(--tg-btn));grid-auto-rows:var(--tg-btn)}
  .pad-right{width:auto;grid-template-columns:var(--tg-btn);grid-auto-rows:var(--tg-btn)}
  .tg-pad button{
    height:100%;min-height:0;border-radius:13px;border:1px solid #232838;background:linear-gradient(180deg,#171a23,#101219);
    color:#e9edf6;font:inherit;font-size:var(--tg-font);font-weight:600;cursor:pointer;touch-action:none;
    transition:transform .06s,background .12s,border-color .12s;
  }
  .tg-pad button:active{transform:scale(.97);background:#1c2029;border-color:rgba(62,224,198,.4)}
  .tg-keys{font-size:9px;line-height:1.6;color:#5b6479;text-align:center;letter-spacing:.02em;flex:0 0 auto;padding:0 4px}
  .tg-over{display:none;width:100%;max-width:min(100%,var(--tg-board-w,560px));flex-direction:column;gap:8px;flex:0 0 auto}
  #tg.is-over .tg-pad,#tg.is-over .tg-keys{display:none}
  #tg.is-over .tg-over{display:flex}
  .tg-over-tip{font-size:12px;color:#ff8b96;text-align:center;letter-spacing:.1em}
  .tg-over-btns{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .tg-over-btns button,.tg-cmds button,.tg-ghost{
    height:52px;border-radius:13px;border:1px solid #232838;background:#12141b;color:#e9edf6;
    font:inherit;font-size:15px;font-weight:600;cursor:pointer;
  }
  .tg-over-btns button:first-child{border-color:rgba(62,224,198,.42);color:#c9fff6;background:linear-gradient(180deg,rgba(62,224,198,.14),rgba(62,224,198,.04))}
  .tg-pause{
    position:absolute;inset:0;z-index:5;display:none;align-items:center;justify-content:center;
    padding:18px;background:rgba(4,5,8,.76);backdrop-filter:blur(6px);
  }
  .tg-pause.on{display:flex}
  .tg-card{
    width:100%;max-width:380px;max-height:calc(100% - 12px);overflow-y:auto;scrollbar-width:none;
    background:#12141b;border:1px solid #232838;border-radius:18px;padding:18px;
    display:flex;flex-direction:column;gap:10px;box-shadow:0 30px 80px -30px #000;
  }
  .tg-card::-webkit-scrollbar{display:none}
  .tg-card h3{margin:0;font-size:17px;letter-spacing:.08em}
  .tg-note{margin:0;font-size:11px;line-height:1.6;color:#79839a}
  .tg-cmds{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .tg-cmds button{height:46px;font-size:13px;font-weight:500}
  .tg-skin-label{font-size:10px;letter-spacing:.14em;color:#5b6479;margin:2px 0 -2px}
  .tg-skins{display:grid;grid-template-columns:repeat(5,1fr);gap:6px}
  .tg-skin{
    display:flex;flex-direction:column;align-items:center;gap:4px;padding:6px 2px;
    border:1px solid #232838;border-radius:11px;background:#0d0f16;color:#79839a;
    font:inherit;font-size:10px;cursor:pointer;transition:.15s;
  }
  .tg-skin canvas{width:40px;height:40px;display:block}
  .tg-skin.on{border-color:rgba(62,224,198,.55);background:rgba(62,224,198,.1);color:#bff7ee}
  .tg-ghost{height:42px;font-size:13px;font-weight:400;color:#79839a;background:transparent}
  .tg-toast{
    position:absolute;left:50%;bottom:calc(env(safe-area-inset-bottom) + 22px);z-index:8;
    transform:translate(-50%,14px);opacity:0;pointer-events:none;transition:.2s;
    background:#181c26;border:1px solid #232838;color:#e9edf6;font-size:13px;
    padding:10px 16px;border-radius:12px;white-space:nowrap;
  }
  .tg-toast.on{opacity:1;transform:translate(-50%,0)}

  /* 横屏（含强制旋转）：左右手各占一边，棋盘在中间。
     尺寸全部走 --tg-* 变量，由 uiFit() 按当前屏幕算；
     同时留着 env(safe-area-inset) —— 刘海/圆角那边也不许压上去。 */
  html.land .tg-pad{
    position:fixed;left:0;right:0;bottom:calc(env(safe-area-inset-bottom) + var(--tg-thumb,16px));
    max-width:none;padding:0;margin:0;display:block;pointer-events:none;
  }
  html.land .pad-side{position:absolute;bottom:0;pointer-events:auto;width:auto;gap:var(--tg-gap)}
  html.land .pad-left{left:calc(env(safe-area-inset-left) + var(--tg-edge));grid-template-columns:repeat(2,var(--tg-btn));grid-auto-rows:var(--tg-btn);width:auto}
  html.land .pad-right{right:calc(env(safe-area-inset-right) + var(--tg-edge));grid-template-columns:var(--tg-btn);grid-auto-rows:var(--tg-btn);width:auto}
  html.land .tg-pad button{height:100%;min-height:0;font-size:var(--tg-font)}
  html.land .tg-stage{padding:0 var(--tg-stage-pr) 0 var(--tg-stage-pl)}
  html.land #tg.is-spectate .tg-stage{padding:0 8px}
  html.land #tg.is-spectate .tg-stage{padding:0 8px;display:flex;align-items:center;justify-content:center}
  html.land #tg.is-spectate canvas#tgCanvas{margin:0 auto}
  html.land .tg-keys{display:none}
  html.land .tg-toast{bottom:calc(env(safe-area-inset-bottom) + 120px)}
  /* 内容自己转 90° 时，把按键条放到物理屏幕的底边：
     正转（cw）时内容右边=物理下边，反转（ccw）时内容左边=物理下边 */
  html.rot .tg-pad{
    position:fixed;top:0;bottom:0;left:auto;right:0;width:var(--tg-rot-w);
    display:flex;flex-direction:column-reverse;justify-content:center;gap:10px;
    padding:8px;margin:0;max-width:none;pointer-events:none;
  }
  html.rot.rot-ccw .tg-pad{left:0;right:auto;flex-direction:column}
  html.rot .pad-side{position:static;width:100%;grid-template-columns:1fr 1fr;gap:var(--tg-gap)}
  html.rot .pad-left{width:100%;grid-template-columns:repeat(2,1fr);grid-auto-rows:var(--tg-btn)}
  html.rot .pad-right{width:100%;grid-template-columns:1fr;grid-auto-rows:var(--tg-btn)}
  html.rot .tg-pad button{height:100%;font-size:var(--tg-font)}
  html.rot .tg-stage{padding:0 var(--tg-rot-w)}
  html.rot #tgCanvas{max-width:min(80vw,640px)}

  /* 性能档：中档关毛玻璃（最贵的一层），低档再收阴影和碎屑动画 */
  html.q-mid *{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
  html.q-mid .tg-pause,html.q-mid .tg-result,html.q-mid .tg-intro{background:rgba(4,5,8,.92)!important}
  html.q-low .tg-duel-spark{display:none!important}
  html.q-low .tg-toast,html.q-low .tg-card,html.q-low .tg-card{box-shadow:none!important}
  html.q-low .tg-intro .tg-duel-hand{filter:none!important}

  /* 小屏只是把键位说明藏了，尺寸交给 JS 现算 */
  @media (max-width: 820px), (max-height: 640px){
    .tg-keys{display:none}
  }
  `;

  const HTML = `
    <div class="tg-bar">
      <button class="tg-btn" data-cmd="exit">返回</button>
      <div class="tg-title" id="tgMode">合体债 · 单人</div>
      <button class="tg-btn" data-cmd="pause">暂停</button>
    </div>
    <div class="tg-vs">
      <span>你 <b id="vsYou">0</b></span>
      <span>对手 <b id="vsOpp">0</b></span>
      <span class="tg-vs-state" id="vsState">准备</span>
    </div>
    <div class="tg-stage"><div class="tg-lb" id="tgLB"><div class="tg-lb-head" id="lbState">排行</div><div class="tg-lb-list" id="lbList"></div></div><canvas id="tgCanvas" width="480" height="320"></canvas></div>
    <div class="tg-pad">
      <div class="pad-side pad-left">
        <button data-act="left" aria-label="${T('左')}">←</button>
        <button data-act="right" aria-label="${T('右')}">→</button>
      </div>
      <div class="pad-side pad-right">
        <button data-act="cw" aria-label="${T('旋转')}">↻</button>
        <button data-act="down" aria-label="${T('下')}">↓</button>
      </div>
    </div>
    <div class="tg-keys">${T('键盘：←→ 移动 · ↓ 软降 / 连点硬降 · ↑ 或 X 转 · Z 反转 · 空格 硬降 · P 暂停 · R 重开×2')}</div>
    <div class="tg-over">
      <div class="tg-over-tip">债还不完，本局结束</div>
      <div class="tg-over-btns">
        <button data-cmd="restart">重开 R</button>
        <button data-cmd="exit">返回</button>
      </div>
    </div>
    <div class="tg-result" id="tgResult">
      <div class="tg-card">
        <h3 id="resTitle">对局结束</h3>
        <p class="tg-note" id="resText"></p>
        <button class="tg-btn" data-cmd="exit">返回菜单</button>
      </div>
    </div>
    <div class="tg-pause" id="tgPause">
      <div class="tg-card">
        <div class="tg-pause-head">
          <h3>暂停</h3>
          <span class="tg-pause-clock" id="tgClock">--:--</span>
        </div>
        <div class="tg-cmds">
          <button data-cmd="resume">继续</button>
          <button data-cmd="restart" id="tgRestart">重开</button>
        </div>
        <button class="tg-ghost" data-cmd="exit">退出到菜单</button>
      </div>
    </div>
    <div class="tg-intro" id="tgIntro">
      <div class="tg-duel-stage">
        <span class="tg-duel-side you">你</span>
        <span class="tg-duel-side me">我</span>
        <div class="tg-duel-burst" aria-hidden="true">
          <i style="--dx:-96px;--dy:-56px;--r:70deg;--c:#3ee0c6;--w:9px;--h:9px"></i>
          <i style="--dx:-64px;--dy:-80px;--r:130deg;--c:#3ee0c6;--w:7px;--h:7px"></i>
          <i style="--dx:-118px;--dy:8px;--r:200deg;--c:#3ee0c6;--w:9px;--h:9px"></i>
          <i style="--dx:-52px;--dy:58px;--r:250deg;--c:#3ee0c6;--w:10px;--h:10px"></i>
          <i style="--dx:-18px;--dy:-104px;--r:300deg;--c:#7fb4ff;--w:7px;--h:7px"></i>
          <i style="--dx:88px;--dy:-66px;--r:40deg;--c:#ffc857;--w:10px;--h:10px"></i>
          <i style="--dx:62px;--dy:-94px;--r:100deg;--c:#ffc857;--w:7px;--h:7px"></i>
          <i style="--dx:112px;--dy:4px;--r:190deg;--c:#ffc857;--w:9px;--h:9px"></i>
          <i style="--dx:46px;--dy:62px;--r:260deg;--c:#ffc857;--w:10px;--h:10px"></i>
          <i style="--dx:16px;--dy:-108px;--r:320deg;--c:#e9edf6;--w:7px;--h:7px"></i>
          <i style="--dx:-78px;--dy:34px;--r:160deg;--c:#ffc857;--w:6px;--h:6px"></i>
          <i style="--dx:78px;--dy:38px;--r:80deg;--c:#3ee0c6;--w:6px;--h:6px"></i>
          <i style="--dx:-34px;--dy:76px;--r:220deg;--c:#7fb4ff;--w:7px;--h:7px"></i>
          <i style="--dx:34px;--dy:78px;--r:300deg;--c:#ffc857;--w:7px;--h:7px"></i>
          <i style="--dx:0;--dy:-66px;--r:10deg;--c:#3ee0c6;--w:6px;--h:6px"></i>
          <i style="--dx:0;--dy:66px;--r:350deg;--c:#e9edf6;--w:6px;--h:6px"></i>
          <i style="--dx:-138px;--dy:-18px;--r:110deg;--c:#3ee0c6;--w:4px;--h:16px"></i>
          <i style="--dx:138px;--dy:-12px;--r:70deg;--c:#ffc857;--w:4px;--h:16px"></i>
          <i style="--dx:-60px;--dy:-40px;--r:30deg;--c:#3ee0c6;--w:13px;--h:6px"></i>
          <i style="--dx:64px;--dy:-36px;--r:25deg;--c:#ffc857;--w:13px;--h:6px"></i>
        </div>
        <b class="tg-duel-spark"></b>
        <div class="tg-duel-title"><span id="duelTitle">决一死战</span></div>
      </div>
    </div>
    <div class="tg-intro tg-mode-intro" id="tgModeIntro">
      <div class="tg-mode-stage">
        <div class="tg-mode-text" id="tgModeText"></div>
        <div class="tg-duel-burst" id="tgModeBurst" aria-hidden="true"></div>
      </div>
      <div class="tg-mode-skip">点一下跳过</div>
    </div>
    <div class="tg-toast" id="tgToast"></div>
    <input id="tgFile" type="file" accept="application/json,.json" hidden>
  `;

  function build() {
    if (built) return;
    const style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);

    root = document.createElement('div');
    root.id = 'tg';
    root.innerHTML = HTML;
    document.body.appendChild(root);
    if (window.TetrisI18n) window.TetrisI18n.apply(root);

    canvas = $('#tgCanvas');
    ctx = canvas.getContext('2d');
    stageEl = root.querySelector('.tg-stage');
    pauseLayer = $('#tgPause');
    skinsBox = $('#tgSkins');
    buildPauseSkins();
    toastEl = $('#tgToast');
    fileInput = $('#tgFile');
    modeEl = $('#tgMode');
    overBar = root.querySelector('.tg-over');
    resultEl = $('#tgResult');
    /* 决斗过场那句「决一死战」在节日期间换成节日祝福 */
    const dTitle = $('#duelTitle');
    if (dTitle) {
      const TH = window.TetrisTheme;
      if (TH && TH.active && TH.active()) {
        dTitle.textContent = TH.greeting(dTitle.textContent);
        if (TH.accent) dTitle.style.color = TH.accent();
      }
    }
    vsEl = root.querySelector('.tg-vs');
    vsYou = $('#vsYou');
    vsOpp = $('#vsOpp');
    vsState = $('#vsState');
    if (vsEl) vsDefaultHTML = vsEl.innerHTML;
    lbListEl = $('#lbList');
    lbStateEl = $('#lbState');
    clockEl = $('#tgClock');
    tickClock();
    if (clockTimer) clearInterval(clockTimer);
    clockTimer = setInterval(tickClock, 1000);

    root.addEventListener('click', onClick);
    root.addEventListener('pointerdown', onPadDown);
    root.addEventListener('pointerup', onPadUp);
    root.addEventListener('pointercancel', onPadUp);
    const modeOverlay = $('#tgModeIntro');
    if (modeOverlay) modeOverlay.addEventListener('pointerdown', skipModeIntro);
    canvas.addEventListener('pointerdown', onCanvasDown);
    fileInput.addEventListener('change', onImportFile);

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('resize', fit);
    window.addEventListener('resize', function () { uiFitSoon(120); });
    window.addEventListener('orientationchange', function () {
      uiFitSoon(180);
      setTimeout(function () { uiFit(false); }, 520);
    });
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', function () { uiFitSoon(120); });
    }
    document.addEventListener('visibilitychange', function () {
      if (document.hidden && running && !paused && !over && !modeIntro) togglePause(true);
      if (!document.hidden) uiFitSoon(80);
    });

    built = true;
  }

  /* ---------------- 启动 / 退出 ---------------- */

  function endDuelIntro() {
    if (!multi || multi.introOut) return;
    multi.introOut = true;
    const intro = $('#tgIntro');
    if (!root || !intro) {
      if (root) root.classList.remove('is-intro');
      return;
    }
    intro.classList.add('show');
    intro.classList.add('out');
    root.classList.remove('is-intro');
    setTimeout(function () {
      intro.classList.remove('out');
      intro.classList.remove('show');
    }, 380);
  }

  const MODE_INTRO_TEXT = {
    solo: '欠债还钱天经地义',
    classic: '经典永不过时',
    ai: '来！咱俩练练！',
    spectate: '不是你死就是他亡'
  };

  function fillModeBurst(box) {
    if (!box) return;
    const colors = ['#3ee0c6', '#ffc857', '#e9edf6', '#7fb4ff'];
    box.innerHTML = '';
    for (let i = 0; i < 24; i++) {
      const ang = Math.random() * Math.PI * 2;
      const dist = 70 + Math.random() * 120;
      const w = 4 + Math.random() * 6;
      const h = Math.random() < 0.3 ? w * (1.8 + Math.random()) : w;
      const el = document.createElement('i');
      el.style.setProperty('--dx', (Math.cos(ang) * dist).toFixed(0) + 'px');
      el.style.setProperty('--dy', (Math.sin(ang) * dist * 0.6).toFixed(0) + 'px');
      el.style.setProperty('--r', (Math.random() * 240 - 120).toFixed(0) + 'deg');
      el.style.setProperty('--c', colors[i % colors.length]);
      el.style.setProperty('--w', w.toFixed(0) + 'px');
      el.style.setProperty('--h', h.toFixed(0) + 'px');
      box.appendChild(el);
    }
  }

  function shouldShowModeIntro() {
    return (settings.intro || 'every') !== 'off';
  }

  function showModeIntro(kind) {
    const text = MODE_INTRO_TEXT[kind];
    const el = $('#tgModeIntro');
    if (!text || !el) return;
    introStamp += 1;
    modeIntro = null;
    const txt = $('#tgModeText');
    const TH = window.TetrisTheme;
    if (txt) {
      /* 节日期间：过场第一句换成节日祝福，再接玩法那句 */
      txt.textContent = (TH && TH.decorate) ? TH.decorate(T(text)) : T(text);
      if (TH && TH.accent) txt.style.color = TH.accent();
    }
    el.classList.remove('out', 'show', 'shatter', 'retire');
    const burst = $('#tgModeBurst');
    if (burst) burst.innerHTML = '';
    void el.offsetWidth;
    el.classList.add('show');
    el.classList.add(kind === 'classic' ? 'retire' : 'shatter');
    if (burst && kind !== 'classic') fillModeBurst(burst);
    if (root) {
      root.classList.remove('is-intro');
      root.classList.add('is-mode-intro');
    }
    const now = performance.now();
    modeIntro = { kind: kind, fadeAt: now + 820, endAt: now + 1150, fading: false };
  }

  function endModeIntro() {
    if (!modeIntro || modeIntro.fading) return;
    modeIntro.fading = true;
    const intro = $('#tgModeIntro');
    if (!intro || !root) return;
    intro.classList.add('out');
    root.classList.remove('is-mode-intro');
    const stamp = ++introStamp;
    setTimeout(function () {
      if (introStamp === stamp && !modeIntro) intro.classList.remove('show', 'out');
    }, 360);
  }

  function skipModeIntro() {
    if (!modeIntro) return;
    modeIntro.fadeAt = 0;
    modeIntro.endAt = 0;
  }

  function dayPart(h) {
    if (h < 5) return '凌晨';
    if (h < 9) return '早上';
    if (h < 11) return '上午';
    if (h < 13) return '中午';
    if (h < 18) return '下午';
    return '晚上';
  }

  function tickClock() {
    if (!clockEl) return;
    let text = '';
    try {
      if (window.TetrisHost && typeof window.TetrisHost.timeText === 'function') {
        text = window.TetrisHost.timeText();
      }
    } catch (e) {}
    if (!text) {
      try {
        text = new Date().toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
      } catch (e) {
        const d = new Date();
        text = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
      }
    }
    if (EN()) {
      var en = String(text)
        .replace(/凌晨|早上|上午/g, 'AM')
        .replace(/中午|下午|傍晚|晚上/g, 'PM')
        .trim();
      var ampm = en.match(/^(AM|PM)\s*(.+)$/i);
      if (ampm) en = ampm[2].trim() + ' ' + ampm[1].toUpperCase();
      clockEl.textContent = en;
      return;
    }
    // 系统 12 小时制会自带「上午/下午」或 AM/PM；前缀用更细的时段，先去掉旧的再拼
    text = String(text).replace(/凌晨|早上|上午|中午|下午|傍晚|晚上|A\.?M\.?|P\.?M\.?/gi, '').trim();
    clockEl.textContent = dayPart(new Date().getHours()) + ' ' + text;
  }

  /* ---------------- AI 模块（ai.js） ----------------
   * 打 AI 全在本机算，不联网：ai.js 和页面同目录，file:// 也读得到。
   * 但它是单独一个 <script>，更新包缺文件、或者网页版弱网把这一次请求断了，
   * window.TetrisAI 就没了 —— 老代码会立刻把 AI 判成「已死」，一格不下。
   * 这里补一次动态加载，并且模块缺失时绝不把 AI 判死。 */
  let aiModuleLoads = 0;
  function aiModuleReady() {
    return !!(window.TetrisAI && typeof window.TetrisAI.choose === 'function');
  }
  function aiModuleLoad(then) {
    if (aiModuleReady()) { if (then) then(true); return; }
    if (aiModuleLoads >= 2) { if (then) then(false); return; }
    aiModuleLoads += 1;
    let s = null;
    try {
      s = document.createElement('script');
      s.src = 'ai.js';
      s.async = false;
      s.onload = function () { if (then) then(aiModuleReady()); };
      s.onerror = function () { if (then) then(false); };
      (document.head || document.body || document.documentElement).appendChild(s);
    } catch (e) { if (then) then(false); }
  }
  function aiModuleMissingText() {
    return EN() ? 'AI module missing — reopen the game' : 'AI 模块没加载上：重进一次，或重装';
  }

  function start(payload) {
    payload = payload || {};
    const mode = payload.mode || 'solo';
    build();
    qualityInit();
    settings = Object.assign({ sound: true, fps: '60', skin: 'solid', intro: 'every', tier: 'normal' }, payload.settings || {});
    if (payload.tier && TIERS.indexOf(payload.tier) >= 0) settings.tier = payload.tier;
    if (TIERS.indexOf(settings.tier) < 0) settings.tier = 'normal';
    settings.skin = skinDef(settings.skin).id;
    applyFps();
    if (typeof payload.seed === 'number' && isFinite(payload.seed)) startSeed = payload.seed >>> 0;
    net = payload.net || null;
    if (mode === 'spectate') return startSpectate();

    aiMode = (mode === 'ai');
    aiState = null;
    multi = net ? {
      mode: mode,
      /* 名册是联机时的唯一真相：谁在场、谁多少分、谁死了都在这儿。
         2 人就是两条，3~4 人就是三、四条；老房主不发名册时退回「一个对手」。 */
      roster: normRoster(payload.roster),
      mySeat: (typeof payload.seat === 'number' && payload.seat >= 0) ? payload.seat : 0,
      seats: Math.max(2, Math.min(4, Number(payload.seats) || 2)),
      hasRoster: !!payload.hasRoster,
      seenOthers: false,
      meDead: false,
      started: false,
      settled: false,
      result: null,
      startAtLocal: 0,
      introOut: false,
      introFadeAt: 0,
      lastState: 0
    } : null;
    if (multi) {
      multi.seenOthers = otherRows().length > 0;
      multi.opponent = { score: 0, clears: 0, debt: 0, dead: false, name: (otherRows()[0] && otherRows()[0].name) || payload.opponentName || '对手' };
    }

    const labelMap = EN() ? {
      solo: 'Solo', casual: 'Casual · Combo', zen: 'Zen', resume: 'Continue',
      resumeCasual: 'Continue Casual', resumeZen: 'Continue Zen',
      lan_parallel: 'Parallel', lan_battle: 'Battle', ai: 'Versus AI', classic: 'Classic'
    } : {
      solo: '单人', casual: '常驻 · 连击', zen: '禅模式', resume: '继续',
      resumeCasual: '继续常驻', resumeZen: '继续禅模式',
      lan_parallel: '并行赛', lan_battle: '干扰战', ai: '打 AI', classic: '原版'
    };
    modeLabel = labelMap[mode] || (EN() ? 'Solo' : '单人');
    if (payload.bt) modeLabel = EN()
      ? (mode === 'lan_battle' ? 'Bluetooth · Battle' : 'Bluetooth · Parallel')
      : (mode === 'lan_battle' ? '蓝牙 · 干扰战' : '蓝牙 · 并行赛');
    if (mode === 'ai') {
      /* 难度选项已经砍掉：这里只写「它现在几级」，等级跟着累计游玩时长涨 */
      modeLabel += EN() ? (' · Lv ' + aiLevelFromPlay()) : (' · 第 ' + aiLevelFromPlay() + ' 级');
    }
    if (modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel;
    }

    try { highScore = parseInt(localStorage.getItem(tierKey(LS.high, curTier())) || '0', 10) || 0; } catch (e) { highScore = 0; }

    if (window.Cues) {
      try {
        window.Cues.setSound(!!settings.sound);
        window.Cues.selfCheck();
      } catch (e) {}
    }

    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    taps = { n: 0, t: 0 };
    dasDir = 0;

    if (multi) {
      const classicRules = payload.rules === 'classic';
      game = classicRules
        ? new E.Tetris({ seed: (payload.seed >>> 0) || 1, classic: true, cols: 10, rows: 20 })
        : mk({ seed: (payload.seed >>> 0) || 1, carryDebt: 0 });
      game.suppressFusion = (mode === 'lan_battle' && !classicRules);
      net.onMessage = onNetMessage;
      net.onPlayers = onRoster;
      net.onError = function () {
        if (multi && !multi.settled) settleMulti('disconnect');
      };
      const delay = Math.max(0, (payload.startAt || 0) - (Date.now() + (net.offset || 0)));
      multi.startAtLocal = performance.now() + delay;
      multi.started = delay <= 0;
      paused = !multi.started;
    } else if (aiMode) {
      const seed = (payload.seed >>> 0) || 1;
      game = mk({ seed: seed, carryDebt: 0 });
      aiState = {
        game: mk({ seed: seed, carryDebt: 0 }),
        difficulty: 'normal',
        nextStep: performance.now() + 600,
        seedBase: seed,
        bankedSc: 0,
        bankedCl: 0,
        revives: 0,
        lv: 0,
        dead: false,
        blocked: false,
        moduleTried: false,
        moduleWarned: false
      };
      aiState.game.noGravity = true;
      plyLocks = [];   // 新的一局：玩家的节奏从零开始量
      paused = false;
      // 网络好坏都不该影响打 AI：模块本机就能读到，缺了就当场补一次
      if (!aiModuleReady()) {
        aiModuleLoad(function (ok) {
          if (!ok && !aiState.moduleWarned) {
            aiState.moduleWarned = true;
            toast(aiModuleMissingText());
          }
        });
      }
    } else if (mode === 'classic') {
      // 原版：10×20，标准计分，没有债/合体块/旋转/方向块
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({ seed: seed, classic: true, cols: 10, rows: 20 });
      paused = false;
    } else if (mode === 'casual') {
      // 常驻：10×10，没有债/合体块，连续消行叠连击倍数
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({ seed: seed, casual: true, cols: 10, rows: 10 });
      paused = false;
    } else if (mode === 'zen') {
      // 禅模式：10×12，5/10 分钟倒计时，堆满自动整理，不会死
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({
        seed: seed, zen: true,
        zenMinutes: payload.zenMinutes === 10 ? 10 : 5,
        cols: 10, rows: 12
      });
      paused = false;
    } else {
      let resumed = false;
      if (mode === 'resume') resumed = loadAutoIntoGame(!!payload.classic, false, false, settings.tier);
      if (mode === 'resumeCasual') resumed = loadAutoIntoGame(false, true, false, settings.tier);
      if (mode === 'resumeZen') resumed = loadAutoIntoGame(false, false, true, settings.tier);
      if (!resumed) {
        if (mode === 'resumeCasual') game = new E.Tetris({ seed: (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0, casual: true, cols: 10, rows: 10 });
        else if (mode === 'resumeZen') game = new E.Tetris({ seed: (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0, zen: true, zenMinutes: 5, cols: 10, rows: 12 });
        else game = makeGame(readCarry(payload.tier || curTier()), payload.tier || curTier());
        if (mode === 'resume' || mode === 'resumeCasual' || mode === 'resumeZen') toast(EN() ? 'Save could not be read — starting a new run' : '存档读不了，先开新局');
      }
    }

    if (game && game.zen && modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + T('禅模式') + ' · ' + game.zenMinutes + (EN() ? ' min' : ' 分钟');
    }

    try {
      highScore = parseInt(localStorage.getItem(highKey()) || '0', 10) || 0;
    } catch (e) { highScore = 0; }
    if ((mode === 'resume' || mode === 'resumeCasual' || mode === 'resumeZen') && modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeLabel = game.zen ? (EN() ? 'Zen · ' + game.zenMinutes + ' min' : '禅模式 · ' + game.zenMinutes + ' 分钟')
        : (game.casual ? (EN() ? 'Combo · resumed' : '继续常驻')
          : (game.classic ? (EN() ? 'Classic · resumed' : '经典玩法')
            : (EN() ? 'Resumed' : '继续')));
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel;
    }
    if (multi && modeEl && game && game.classic) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeLabel = EN()
        ? 'Classic · ' + (multi.mode === 'lan_battle' ? 'Battle' : 'Parallel')
        : '经典 · ' + (multi.mode === 'lan_battle' ? '干扰战' : '并行赛');
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel;
    }

    if (game && !game.classic && !game.casual && modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel + ' · ' + tierName(tierOf(game));
    }
    root.classList.add('on');
    root.classList.remove('is-over', 'is-wait', 'is-result');
    // 3~4 人的比分条把 vs 那一行换过 innerHTML：下一局不管是几个人都先还原
    if (vsEl && vsEl.dataset.big === '1') {
      vsEl.dataset.big = '';
      vsEl.innerHTML = vsDefaultHTML;
      vsYou = $('#vsYou');
      vsOpp = $('#vsOpp');
      vsState = $('#vsState');
    }
    
    root.classList.remove('is-mode-intro');
    const oldModeIntro = $('#tgModeIntro');
    if (oldModeIntro) oldModeIntro.classList.remove('show', 'out', 'shatter', 'retire');
    modeIntro = null;
    if (multi && !multi.started) {
      const introEl = $('#tgIntro');
      if (introEl) introEl.classList.remove('out', 'show');
      root.classList.add('is-intro');
      const leftMs = multi.startAtLocal - performance.now();
      multi.introFadeAt = performance.now() + Math.max(320, Math.min(1500, leftMs - 700));
      const sub = $('#tgIntroSub');
      if (sub) sub.textContent = EN() ? 'Opponent: ' + (multi.opponent.name || 'Opponent') + ' · both connected' : '对手：' + (multi.opponent.name || '对手') + ' · 双方已握手';
    } else {
      root.classList.remove('is-intro');
    }
    root.classList.toggle('is-multi', !!multi);
    root.classList.toggle('is-ai', !!aiMode);
    root.classList.toggle('is-classic', !!(game && game.classic));
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    if (multi || aiMode) updateVs();
    resetRestartButton();
    frameAcc = 0;
    lastInputAt = performance.now();
    idleHintShown = false;
    layoutFor(game);
    fit();
    uiFit(true);
    uiFitSoon(320);
    // 打 AI 不看开局动画：一进来就开打，AI 立刻开始落子
    if (!multi && !aiMode && MODE_INTRO_TEXT[mode] && shouldShowModeIntro()) showModeIntro(mode);
    lastFrame = 0;
    running = true;
    cancelAnimationFrame(raf);
    startLoop();
    return true;
  }

  /* ---------------- AI 观战：两个随机 AI 自己打 ---------------- */

  function spectateSeed() {
    return (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
  }

  function makeSpectateEngine() {
    const g = new E.Tetris({ seed: spectateSeed(), carryDebt: 0 });
    g.noGravity = true;          // 由 AI 直接落子
    g.rotateEnabled = false;     // 观战不转场，画面稳一点
    return g;
  }

  function resetSpectate() {
    spectate = spectate || { round: 0 };
    spectate.a = makeSpectateEngine();
    spectate.b = makeSpectateEngine();
    spectate.accA = 0;
    spectate.accB = 0;
    spectate.over = false;
    spectate.winner = '';
    spectate.nextAt = 0;
    spectate.round = (spectate.round || 0) + 1;
  }

  function startSpectate() {
    build();
    multi = null;
    aiMode = false;
    aiState = null;
    game = null;
    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    resetSpectate();
    modeLabel = T('AI 观战');
    if (modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel;
    }
    root.classList.add('on');
    root.classList.remove('is-over', 'is-result', 'is-multi', 'is-ai', 'is-classic');
    root.classList.add('is-spectate');
    root.classList.remove('is-mode-intro');
    const oldModeIntro = $('#tgModeIntro');
    if (oldModeIntro) oldModeIntro.classList.remove('show', 'out', 'shatter', 'retire');
    modeIntro = null;
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    W = 520;
    H = 360;
    BW = W;
    BOARD = H;
    PX = W;
    if (canvas) { canvas.width = 1; canvas.height = 1; }
    fit();
    uiFit(true);
    uiFitSoon(320);
    if (shouldShowModeIntro()) showModeIntro('spectate');
    lastFrame = 0;
    running = true;
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
    return true;
  }

  function AI_step(g, diff) {
    if (!g || g.status !== 'playing') return;
    const AI = window.TetrisAI;
    if (!AI) return;
    const mv = AI.choose(g, diff || 'normal');
    if (mv) AI.apply(g, mv);
    else g.gameOver('blockout');
  }

  function stepSpectate(dt) {
    const sp = spectate;
    if (!sp) return;
    const now = performance.now();
    if (sp.over) {
      if (now >= sp.nextAt) resetSpectate();
      return;
    }
    sp.accA += dt;
    sp.accB += dt;
    if (sp.accA >= 500) { sp.accA = 0; AI_step(sp.a, 'hard'); }
    if (sp.accB >= 500) { sp.accB = 0; AI_step(sp.b, 'hard'); }
    const aDead = sp.a.status === 'over';
    const bDead = sp.b.status === 'over';
    if (aDead || bDead) {
      sp.over = true;
      if (aDead && bDead) sp.winner = sp.a.score === sp.b.score ? '平局' : (sp.a.score > sp.b.score ? 'AI-1' : 'AI-2');
      else sp.winner = aDead ? 'AI-2' : 'AI-1';
      sp.nextAt = now + 3500;
    }
  }

  /* 分数现在可能是很长的汉字：按可用宽度自动缩字号（观战/HUD 共用） */
  function fitFont(text, maxW, maxPx, weight) {
    let px = maxPx;
    ctx.font = (weight || '700') + ' ' + px + 'px ' + FONT;
    while (px > 11 && ctx.measureText(text).width > maxW) {
      px -= 1;
      ctx.font = (weight || '700') + ' ' + px + 'px ' + FONT;
    }
    return px;
  }

  function drawSpectateBoard(g, x, y, cell, name, accent) {
    const bw = cell * 10;
    ctx.save();
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = accent;
    ctx.font = '700 13px ' + FONT;
    ctx.fillText(name, x, y - 34);
    ctx.fillStyle = '#e9edf6';
    const specScore = fmtScore(g.score, true);
    fitFont(specScore, bw - 40, 20, '700');
    ctx.textAlign = 'right';
    ctx.fillText(specScore, x + bw, y - 34);
    ctx.textAlign = 'left';

    ctx.fillStyle = '#0a0c12';
    ctx.fillRect(x, y, bw, bw);
    ctx.strokeStyle = 'rgba(255,255,255,.04)';
    ctx.lineWidth = 1;
    for (let i = 1; i < 10; i++) {
      ctx.beginPath(); ctx.moveTo(x + i * cell + 0.5, y); ctx.lineTo(x + i * cell + 0.5, y + bw); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x, y + i * cell + 0.5); ctx.lineTo(x + bw, y + i * cell + 0.5); ctx.stroke();
    }
    for (let yy = 0; yy < g.rows; yy++) {
      for (let xx = 0; xx < g.cols; xx++) {
        const c = g.board[yy][xx];
        if (!c) continue;
        const px = x + xx * cell, py = y + yy * cell;
        let col = '#39415a';
        if (c.k === 'p') col = '#4a2630';
        else if (c.k === 'n') col = cellColor(c.t);
        paintCellOn(ctx, px, py, cell, col);
      }
    }
    if (g.piece && g.status === 'playing') {
      const cells = g.pieceCells();
      const col = g.piece.type === 'ARROW' ? '#f2f5ff' : cellColor(g.piece.type);
      for (let i = 0; i < cells.length; i++) {
        const px = x + cells[i][0] * cell, py = y + cells[i][1] * cell;
        paintCellOn(ctx, px, py, cell, col);
      }
    }
    ctx.strokeStyle = 'rgba(255,255,255,.10)';
    ctx.strokeRect(x + 0.5, y + 0.5, bw - 1, bw - 1);

    ctx.fillStyle = '#79839a';
    ctx.font = '11px ' + FONT;
    ctx.fillText(EN() ? g.clears + ' lines · Lv ' + g.lockLevel + (g.debt > 0 ? ' · debt -' + g.debt : ' · debt 0')
      : '消 ' + g.clears + ' · 等级 ' + g.lockLevel + (g.debt > 0 ? ' · 债 -' + g.debt : ' · 债 0'), x, y + bw + 18);
    ctx.restore();
  }

  function drawSpectate(now) {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#08090d';
    ctx.fillRect(0, 0, W, H);

    const cell = 18;
    const bw = cell * 10;
    const gap = 42;
    const x0 = Math.round((W - (bw * 2 + gap)) / 2);
    const y0 = 96;
    drawSpectateBoard(spectate.a, x0, y0, cell, EN() ? 'AI-1 · random' : 'AI-1 · 随机', '#3ee0c6');
    drawSpectateBoard(spectate.b, x0 + bw + gap, y0, cell, EN() ? 'AI-2 · random' : 'AI-2 · 随机', '#ff9f43');

    ctx.save();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#5b6479';
    ctx.font = '700 12px ' + FONT;
    ctx.fillText('VS', W / 2, y0 + 84);
    ctx.fillStyle = '#ffd479';
    ctx.font = '700 22px ' + FONT;
    ctx.fillText(EN() ? 'Round ' + spectate.round : '第 ' + spectate.round + ' 局', W / 2, 42);
    if (spectate.over) {
      ctx.fillStyle = '#fff';
      ctx.font = '700 18px ' + FONT;
      ctx.fillText(EN() ? spectate.winner + ' wins' : spectate.winner.replace('AI-', 'AI-') + ' 赢', W / 2, y0 + bw + 62);
      ctx.fillStyle = '#79839a';
      ctx.font = '11px ' + FONT;
      ctx.fillText(EN() ? 'Next round in 3s' : '3 秒后自动下一局', W / 2, y0 + bw + 82);
    } else {
      ctx.fillStyle = '#79839a';
      ctx.font = '11px ' + FONT;
      ctx.fillText(EN() ? 'Two random AIs play · sit back and watch' : '两个随机 AI 自己打 · 双手可以歇着', W / 2, y0 + bw + 62);
    }
    ctx.restore();
  }

  function makeGame(carry, tier) {
    const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
    return mk({ seed: seed, carryDebt: Math.max(0, carry | 0), ruleset: tier || curTier() });
  }

  function loadAutoIntoGame(wantClassic, wantCasual, wantZen, wantTier) {
    const key = wantZen ? LS.zenAuto
      : (wantCasual ? LS.autoCasual : (wantClassic ? LS.autoClassic : tierKey(LS.auto, wantTier || curTier())));
    const data = readJSON(key);
    if (!data) return false;
    const g = data.classic
      ? new E.Tetris({ seed: (data.seed >>> 0) || 1, classic: true, cols: data.cols || 10, rows: data.rows || 20 })
      : (data.zen
        ? new E.Tetris({ seed: (data.seed >>> 0) || 1, zen: true, zenMinutes: data.zenMinutes || 5, cols: data.cols || 10, rows: data.rows || 12 })
        : (data.casual
          ? new E.Tetris({ seed: (data.seed >>> 0) || 1, casual: true, cols: data.cols || 10, rows: data.rows || 10 })
          : mk({ seed: (data.seed >>> 0) || 1, ruleset: (wantTier || data.tier || curTier()) })));
    if (g.loadJSON(data)) return false;
    game = g;
    return true;
  }

  function exitToMenu() {
    if (game && game.status === 'playing' && !over) saveAuto();
    spectate = null;
    if (root) root.classList.remove('is-spectate');
    if (multi) {
      if (net) { try { net.leave(); } catch (e) {} }
      net = null;
      multi = null;
    }
    aiMode = false;
    aiState = null;
    modeIntro = null;
    introStamp += 1;
    running = false;
    cancelAnimationFrame(raf);
    raf = 0;
    if (root) {
      root.classList.remove('on');
      root.classList.remove('is-over');
      root.classList.remove('is-multi');
      root.classList.remove('is-ai');
      root.classList.remove('is-result', 'is-wait');
      root.classList.remove('is-intro');
      root.classList.remove('is-mode-intro');
      const mi = $('#tgModeIntro');
      if (mi) mi.classList.remove('show', 'out', 'shatter', 'retire');
    }
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    paused = false;
    dispatch('tetris-exit');
    dispatch('tetris-save-change');
  }

  function restartGame() {
    const wasClassic = !!(game && game.classic);
    const wasZen = !!(game && game.zen);
    const wasCasual = !!(game && game.casual && !wasZen);
    const carry = over ? (game.carryDebt || 0)
      : (game && game.debt > 0 ? game.debt : readCarry((game && game.rules && game.rules.id) || curTier()));
    if (settings.skinMode === 'auto') settings.skin = randomSkin(settings.skin);
    if (wasClassic || wasCasual || wasZen) {
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = wasClassic
        ? new E.Tetris({ seed: seed, classic: true, cols: 10, rows: 20 })
        : (wasZen
          ? new E.Tetris({ seed: seed, zen: true, zenMinutes: game.zenMinutes, cols: 10, rows: 12 })
          : new E.Tetris({ seed: seed, casual: true, cols: 10, rows: 10 }));
    } else {
      game = makeGame(carry, (game && game.rules && game.rules.id) || curTier());
    }
    layoutFor(game);
    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    taps = { n: 0, t: 0 };
    dasDir = 0;
    frameAcc = 0;
    resetRestartButton();
    lastInputAt = performance.now();
    idleHintShown = false;
    if (root) root.classList.remove('is-over');
    if (pauseLayer) pauseLayer.classList.remove('on');
    lastFrame = 0;
    if (!running) {
      running = true;
      raf = requestAnimationFrame(frame);
    }
  }

  function togglePause(force) {
    if (!running || over || !game || modeIntro) return;
    if (multi) { toast(EN() ? 'Cannot pause during a match' : '联机中不能暂停'); return; }
    paused = (force === undefined) ? !paused : !!force;
    if (paused) {
      dasDir = 0;
      if (game) game.setSoftDrop(false);
      saveAuto();
      updatePauseSkins();
      tickClock();
      updatePauseNote();
      resetRestartButton();
      dispatch('tetris-save-change');
    } else {
      frameAcc = 0;
      lastInputAt = performance.now();
      resetRestartButton();
      startLoop();
    }
    if (pauseLayer) pauseLayer.classList.toggle('on', paused);
  }

  /* ---------------- 主循环 ---------------- */

  function startLoop() {
    if (raf) cancelAnimationFrame(raf);   // 已经在跑就换一条，避免重复循环
    lastFrame = 0;
    raf = requestAnimationFrame(frame);
  }

  function frame(t) {
    if (!running) return;
    window.__frames = (window.__frames || 0) + 1;   // 调试用：确认暂停时循环真的停了
    raf = 0;
    /* 多人开局前那 2 秒多是「倒计时」，不是「暂停」：这时 paused=true，但循环必须继续跑，
       否则倒计时永远走不完（它是在 frame 里判断的）。3.2 之前这里直接把循环停死，
       现象就是点开始对局后整块棋盘黑的、按键全没反应。
       真暂停（自己按暂停 / 单机）仍然彻底停 rAF，省电。 */
    if (paused && !(multi && !multi.started)) return;
    raf = requestAnimationFrame(frame);

    let dt = lastFrame ? (t - lastFrame) : 16;
    lastFrame = t;
    if (!isFinite(dt) || dt < 0) dt = 0;
    if (dt > 120) dt = 120;

    // 帧率上限：默认 60；「自动」= 不限，跟屏幕 rAF 走
    frameAcc += dt;
    if (frameAcc > 200) frameAcc = 0;
    if (!paused && !over) qualitySample(dt);
    if (!paused && !over) addPlayMs(dt);
    const capNow = qFpsCap();
    const gap = capNow ? 1000 / capNow : 0;
    if (gap && frameAcc < gap - 1.5) return;
    const step = Math.min(frameAcc, 120);
    frameAcc = gap ? Math.max(0, frameAcc - step) : 0;

    if (modeIntro) {
      const nowMs = performance.now();
      if (nowMs >= modeIntro.fadeAt) endModeIntro();
      if (nowMs >= modeIntro.endAt) {
        modeIntro = null;
        lastInputAt = nowMs;
      } else {
        render(nowMs);
        return;
      }
    }

    if (spectate) {
      stepSpectate(step);
      render(performance.now());
      return;
    }

    if (multi && !multi.started) {
      const nowMs = performance.now();
      if (multi.introFadeAt && nowMs >= multi.introFadeAt) endDuelIntro();
      if (nowMs >= multi.startAtLocal) {
        multi.started = true;
        paused = false;
        lastInputAt = nowMs;
        endDuelIntro();
        toast(EN() ? 'Go!' : '开始');
      } else {
        if (game) render(nowMs);
        return;
      }
    }
    if (multi && multi.settled) {
      if (game) render(performance.now());
      return;
    }

    if (!paused && !over && game) {
      game.tick(step);
      updateDAS(step);
      pumpEvents();

      if (aiMode) stepAI(step);

      if (multi && !multi.settled) {
        const nowMs = performance.now();
        if (nowMs - multi.lastState >= 250 && game.status === 'playing') {
          multi.lastState = nowMs;
          if (net) net.send({ t: 'state', score: game.score, debt: game.debt, clears: (game.classic ? game.lines : game.clears), dead: false });
        }
        updateVs();
      } else if (game.score > highScore) {
        highScore = game.score;
        try { localStorage.setItem(highKey(), String(highScore)); } catch (e) {}
      }
      if (game.status === 'over' && !over) {
        onGameOver({ debt: game.carryDebt, score: game.score, reason: game.reason });
      }
      if (!multi && !idleHintShown && game.status === 'playing' && (game.classic ? game.lines : game.clears) === 0
          && performance.now() - lastInputAt > 6000) {
        idleHintShown = true;
        toast(EN() ? 'Blocks fall on their own: ← → to move, Space to drop' : '方块会自己往下掉：← → 移动，空格直接落到底');
      }
    }

    const now = performance.now();
    effects = effects.filter(function (e) { return e.until > now; });
    if (game && !paused && !over) render(now);   // 暂停/结算时画布停在最后一帧，别再 60fps 空画
  }

  function updateDAS(dt) {
    if (!game || game.status !== 'playing' || paused || over) return;
    if (dasDir === 0) return;
    dasT += dt;
    if (dasT < C.DAS_MS) return;
    arrT += dt;
    while (arrT >= C.ARR_MS) {
      arrT -= C.ARR_MS;
      if (!game.move(dasDir)) break;
    }
  }

  /* 玩家刚落下一块：记下跟上一次的间隔。超过 8 秒当他在发呆/暂停，直接重开一轮，
     免得一个长时间停顿把 AI 拖成慢动作。 */
  function notePlayerLock(now) {
    const last = plyLocks.length ? plyLocks[plyLocks.length - 1].at : 0;
    if (last && now - last > 8000) plyLocks = [];
    plyLocks.push({ at: now });
    if (plyLocks.length > 9) plyLocks.shift();
  }

  /* 玩家最近的落子间隔（中位数，抗一次手滑的长时间停顿）。样本不够就返回 0。 */
  function playerIvMs() {
    if (plyLocks.length < 4) return 0;
    const gaps = [];
    for (let i = 1; i < plyLocks.length; i++) gaps.push(plyLocks[i].at - plyLocks[i - 1].at);
    gaps.sort(function (a, b) { return a - b; });
    const mid = gaps[gaps.length >> 1];
    if (!(mid > 0)) return 0;
    return Math.max(250, Math.min(6000, mid));
  }

  /* AI 一方的时间推进：转场/合体块照走，落子由 AI 直接给。
     AI 先死（顶死/被堵死）要结算，不能把玩家一个人晾在那儿。 */
  function stepAI(step) {
    if (!aiMode || !aiState || aiState.dead) return;
    const ag = aiState.game;
    if (!ag) return;
    const nowMs = performance.now();
    ag.tick(step);
    if (!aiModuleReady()) {
      // 模块还没到：先别判死，补一次，界面上说清楚
      if (!aiState.moduleTried) {
        aiState.moduleTried = true;
        aiModuleLoad(function (ok) {
          if (!ok && aiState && !aiState.moduleWarned) {
            aiState.moduleWarned = true;
            toast(aiModuleMissingText());
          }
        });
      }
      ag.drainEvents();
      if (vsState) vsState.textContent = aiState.moduleWarned
        ? (EN() ? 'AI module missing' : 'AI 模块缺失')
        : (EN() ? 'AI loading…' : 'AI 加载中…');
      return;
    }
    const AI = window.TetrisAI;
    /* 聪明程度只看「你一共玩了多久」：玩得越久它越准、越会救场，速度始终跟你一样。 */
    const lv = aiLevelFromPlay();
    const plan = (AI && AI.planFor) ? AI.planFor(lv, 'normal') : null;
    if (plan && plan.lv !== aiState.lv) aiState.lv = plan.lv;
    /* 速度：目标 = 玩家自己的节奏（他多久落一块，AI 就多久落一块），
       再乘一个「压力系数」：帧时间一紧张就按比例放慢，优先保证手机不卡。
       差的是「摆哪儿」，不是手速。 */
    const iv = playerIvMs();
    const base = iv > 0 ? iv : (plan ? plan.stepMs : 1000);
    AIPACE.v = (AI && AI.paceFor) ? AI.paceFor(QUALITY.p95, QUALITY.budget, AIPACE.v) : 1;
    let stepNext = Math.round(base * AIPACE.v);
    /* 成本地板：AI 自己的决策耗时不许吃掉间隔的四分之一以上 */
    const costFloor = Math.round((AIPACE.cost || 0) * 4);
    if (costFloor > stepNext) stepNext = costFloor;
    aiState.lastStep = stepNext;   // 给真机验证看：这一块实际隔了多少毫秒
    aiState.pace = AIPACE.v;
    aiState.aiCostMs = AIPACE.cost;
    if (ag.status === 'over') {
      reviveAI();
    } else if (nowMs >= aiState.nextStep) {
      const t0 = (window.performance && performance.now) ? performance.now() : 0;
      const mv = AI.choose(ag, aiState.difficulty, plan);
      if (!mv) {
        reviveAI();
      } else {
        AI.apply(ag, mv);
        aiState.nextStep = nowMs + (stepNext > 0 ? stepNext : 1000);
        if (ag.status === 'over') reviveAI();
      }
      if (t0) {
        const cost = performance.now() - t0;
        AIPACE.cost = AIPACE.cost ? (AIPACE.cost * 0.75 + cost * 0.25) : cost;
      }
    }
    ag.drainEvents();
    updateVs();
  }

  /* AI 顶死/被堵死：不结算、不换你下场，给它换一块空盘接着打，分数继续累计。
     这样它永远在陪你玩，难度还在一路往上爬。 */
  function reviveAI() {
    if (!aiMode || !aiState || aiState.dead) return;
    const old = aiState.game;
    aiState.bankedSc += old ? (old.score | 0) : 0;
    aiState.bankedCl += old ? ((old.classic ? old.lines : old.clears) | 0) : 0;
    aiState.revives += 1;
    const seed = (((aiState.seedBase || 1) + aiState.revives * 7919) >>> 0) || 1;
    let g = null;
    try { g = mk({ seed: seed, carryDebt: 0 }); } catch (e) { g = null; }
    if (!g) return;
    g.noGravity = true;
    aiState.game = g;
    aiState.nextStep = performance.now() + 500;
    if (aiState.revives === 1) {
      toast(EN() ? 'AI cleared its board — it keeps going' : 'AI 顶爆了，换块空板接着打');
    }
  }

  function aiScoreNow() {
    if (!aiState) return 0;
    return (aiState.bankedSc | 0) + (aiState.game ? (aiState.game.score | 0) : 0);
  }
  function aiClearsNow() {
    if (!aiState) return 0;
    const g = aiState.game;
    return (aiState.bankedCl | 0) + (g ? ((g.classic ? g.lines : g.clears) | 0) : 0);
  }


  /* 你顶死了：跟 AI 比累计分，出结算（AI 自己顶死不算输，它会换板继续） */
  function settleAI() {
    if (!aiMode || !aiState || aiState.settled) return;
    aiState.settled = true;
    aiState.dead = true;
    paused = true;
    dasDir = 0;
    if (game) game.setSoftDrop(false);
    const ys = game ? (game.score | 0) : 0;
    const as = aiScoreNow();
    const winner = ys > as ? 'you' : (ys < as ? 'opp' : 'draw');
    if (resultEl) {
      const title = $('#resTitle');
      const text = $('#resText');
      if (title) title.textContent = winner === 'you' ? T('你赢') : (winner === 'opp' ? T('你输') : T('平局'));
      if (text) text.textContent = EN() ? ('You ' + ys + ' : AI ' + as) : ('你 ' + ys + ' ： AI ' + as);
      resultEl.classList.add('on');
    }
    if (root) root.classList.add('is-result');
    updateVs();
  }

  function pumpEvents() {
    if (!game) return;
    const evs = game.drainEvents();
    const now = performance.now();
    for (let i = 0; i < evs.length; i++) {
      const ev = evs[i];
      switch (ev.type) {
        case 'lock':
          if (aiMode) notePlayerLock(now);
          saveAuto();
          break;
        case 'lineClear':
          cue('lineClear', { lines: ev.lines });
          effects.push({ type: 'rows', rows: ev.rows || [], until: now + 260 });
          if (multi && multi.mode === 'lan_battle' && net) {
            net.send({ t: 'clear', lines: ev.lines, to: (net.battleTarget ? net.battleTarget() : undefined) });
          }
          break;
        case 'rotateSoon':
          cue('rotateSoon');
          break;
        case 'fieldRotate':
          effects.push({ type: 'flash', until: now + 420 });
          break;
        case 'fusion':
          effects.push({ type: 'fusion', until: now + 460 });
          break;
        case 'arrowWipe':
          effects.push({ type: 'arrow', until: now + 360 });
          break;
        case 'arrowClear':
          cue('lineClear', { lines: 1 });
          if (multi && multi.mode === 'lan_battle' && net) {
            net.send({ t: 'clear', lines: 1, to: (net.battleTarget ? net.battleTarget() : undefined) });
          }
          break;
        case 'debtHigh':
          cue('debtHigh', { pct: ev.pct });
          break;
        case 'thinReady':
          toast(EN() ? '15 clears — the next fusion block is only 1 row' : '第 15 次消行：下一块只顶 1 行');
          break;
        case 'debtCleared':
          cue('debtCleared');
          setCarry(0, tierOf(game));
          break;
        case 'zenRescue':
          toast(EN() ? 'Board full — tidied up · combo broken' : '堆满了，整理一下 · 连击断了');
          effects.push({ type: 'flash', until: now + 360 });
          break;
        case 'arrowUnlock':
          cue('arrowUnlock');
          break;
        case 'topOut':
          cue('topOut');
          break;
        case 'gameOver':
          onGameOver(ev);
          break;
      }
    }
  }

  /* ---------- 本地统计（不联网、不上传，只给玩家自己看） ----------
     按模式分开记，和存档一一对应：合体债的三档各一条、经典、常驻、禅各一条，
     外加一份总计（老数据的字段就是它）。 */
  const STATS_KEY = 'tetris.stats';
  function readStats() {
    try { return JSON.parse(localStorage.getItem(STATS_KEY) || '{}') || {}; } catch (e) { return {}; }
  }
  /** 这一局算什么模式（和存档的 key 对齐） */
  function statModeKey() {
    if (!game) return '';
    if (game.classic) return 'classic';
    if (game.zen) return 'zen';
    if (game.casual) return 'casual';
    return 'debt_' + ((game.rules && game.rules.id) || 'normal');
  }
  function bumpStats(info) {
    const s = readStats();
    const add = function (o) {
      o.games = (o.games | 0) + 1;
      o.lines = (o.lines | 0) + (info.lines | 0);
      o.best = Math.max(o.best | 0, info.score | 0);
      o.maxCombo = Math.max(o.maxCombo | 0, info.maxCombo | 0);
      o.debtPaid = (o.debtPaid | 0) + (info.paid | 0);
      o.updated = Date.now();
      return o;
    };
    add(s);                                   // 总计（老字段保持原意）
    s.modes = s.modes || {};
    const k = statModeKey();
    if (k) s.modes[k] = add(s.modes[k] || {});
    try { localStorage.setItem(STATS_KEY, JSON.stringify(s)); } catch (e) {}
  }
  window.TetrisStats = {
    get: readStats,
    clear: function () { try { localStorage.removeItem(STATS_KEY); } catch (e) {} }
  };

  function onGameOver(ev) {
    if (over) return;
    over = true;
    overInfo = ev || { debt: 0, score: game.score, reason: 'topout' };
    if (game) {
      const paid = Math.max(0, (game.initialDebt | 0) - ((overInfo.debt | 0)));
      bumpStats({ lines: game.lines, score: game.score, maxCombo: game.maxCombo, paid: paid });
    }
    paused = false;
    dasDir = 0;
    if (game) game.setSoftDrop(false);
    if (multi) {
      multi.meDead = true;
      if (net) net.send({ t: 'dead', score: game.score });
      if (isBigMatch()) {
        const alive = otherRows().filter(p => !p.dead).length;
        if (alive >= 2 && multi.seenOthers) {
          // 还有两个以上在打：先出局等着，别把整局结算掉
          if (root) {
            root.classList.add('is-over', 'is-wait');
            const tip = root.querySelector('.tg-over-tip');
            if (tip) tip.textContent = EN() ? 'You are out — waiting for the others' : '你出局了 · 等其他人打完';
          }
          updateVs();
          maybeSettle();
          return;
        }
      }
      settleMulti('youDead');
      return;
    }
    if (aiMode) {
      settleAI();
      return;
    }
    if (game) {
      try {
        localStorage.removeItem(game.zen ? LS.zenAuto
          : (game.casual ? LS.autoCasual
            : (game.classic ? LS.autoClassic : tierKey(LS.auto, game.rules.id))));
      } catch (e) {}
    }
    if (game && !game.classic && !game.casual && !game.zen) {
      const before = overInfo.debt || 0;
      const nextDebt = restructureDebt(before);
      overInfo.debt = nextDebt;
      if (game) game.carryDebt = nextDebt;
      setCarry(nextDebt, tierOf(game));
    }
    if (game && game.score > highScore) {
      highScore = game.score;
      try { localStorage.setItem(highKey(), String(highScore)); } catch (e) {}
    }
    if (root) {
      const tip = root.querySelector('.tg-over-tip');
      if (tip) {
        if (game && game.zen) tip.textContent = EN() ? 'Time up — run over' : '时间到，本局结束';
        else if (game && game.classic) tip.textContent = EN() ? 'Stacked out — run over' : '堆到顶了，本局结束';
        else if (game && game.casual) tip.textContent = EN() ? 'Three misses in a row — run over' : '连着 3 块没消，本局结束';
        else tip.textContent = EN() ? 'Debt unpaid — run over' : '债还不完，本局结束';
      }
    }
    if (root) root.classList.add('is-over');
    if (pauseLayer) pauseLayer.classList.remove('on');
    resetRestartButton();
    if (ev && ev.reason !== 'topout' && !(game && game.zen)) cue('gameOver', { debt: overInfo.debt });
    dispatch('tetris-save-change');
  }

  /* ---------------- 联机 ---------------- */

  /** 名册变了（分数/死活/掉线）：2 人还是老样子，3~4 人换成一条小比分条。 */
  function onRoster(list) {
    if (!multi) return;
    multi.roster = normRoster(list);
    if (otherRows().length) multi.seenOthers = true;
    const first = otherRows()[0];
    if (first) {
      multi.opponent.score = first.score | 0;
      multi.opponent.clears = first.clears | 0;
      if (first.name) multi.opponent.name = first.name;
      if (first.dead) multi.opponent.dead = true;
    }
    updateVs();
    maybeSettle();
  }

  /* 排行榜一行：打 AI 是「你 / AI」，多人模式按名册来 */
  function lbEntries() {
    const out = [];
    if (aiMode && aiState) {
      const ag = aiState.game;
      out.push({
        me: true, name: EN() ? 'You' : '你',
        sc: game ? (game.score | 0) : 0,
        cl: game ? ((game.classic ? game.lines : game.clears) | 0) : 0,
        lv: game ? (game.lockLevel | 0) : 0,
        dead: false
      });
      out.push({
        me: false,
        name: 'AI',
        sc: aiScoreNow(),
        cl: aiClearsNow(),
        lv: ag ? (ag.lockLevel | 0) : 0,
        dead: !!aiState.dead,
        tag: (EN() ? 'smart ' : '聪明 ') + (aiState.lv | 0)
          + (aiState.revives ? (EN() ? ' · board ' : ' · 换板 ') + aiState.revives : '')
      });
      return out;
    }
    if (multi) {
      const rows = rosterAll();
      for (let i = 0; i < rows.length; i++) {
        const p = rows[i];
        const me = p.seat === multi.mySeat;
        out.push({
          me: me,
          name: p.name || (EN() ? 'P' + ((p.seat | 0) + 1) : '玩家' + ((p.seat | 0) + 1)),
          sc: me ? (game ? (game.score | 0) : 0) : (p.score | 0),
          cl: me ? (game ? ((game.classic ? game.lines : game.clears) | 0) : 0) : (p.clears | 0),
          lv: me && game ? (game.lockLevel | 0) : 0,
          dead: !!p.dead
        });
      }
    }
    return out;
  }

  /* 只换文本、不加过渡动画；内容没变就不碰 DOM（不拖累 AI 的模拟） */
  function renderLB(stateText) {
    if (lbStateEl && stateText != null && lbStateEl.textContent !== stateText) lbStateEl.textContent = stateText;
    if (!lbListEl) return;
    const rows = lbEntries();
    rows.sort(function (a, b) { return (b.sc - a.sc) || (b.cl - a.cl) || (a.me ? -1 : 1); });
    let html = '';
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const tail = (EN() ? 'Lv ' + r.lv : '等级 ' + r.lv) + ' · '
        + (EN() ? r.cl + 'L' : '消 ' + r.cl) + (r.dead ? (EN() ? ' · out' : ' · 出局') : '')
        + (r.tag ? ' · ' + r.tag : '');
      html += '<div class="tg-lb-row' + (r.me ? ' me' : '') + (r.dead ? ' out' : '') + '">'
        + '<div class="tg-lb-top"><b class="tg-lb-n">' + (i + 1) + '</b>'
        + '<span class="tg-lb-name">' + escHtml(r.name) + '</span></div>'
        + '<b class="tg-lb-sc">' + String(r.sc | 0) + '</b>'
        + '<span class="tg-lb-sub">' + tail + '</span>'
        + '</div>';
    }
    if (lbListEl.dataset.html !== html) {
      lbListEl.innerHTML = html;
      lbListEl.dataset.html = html;
    }
  }

  function updateVs() {
    if (aiMode && aiState) {
      const ag = aiState.game;
      const ys = game ? (game.score | 0) : 0;
      const as = aiScoreNow();
      const yc = game ? ((game.classic ? game.lines : game.clears) | 0) : 0;
      const ac = aiClearsNow();
      if (vsYou) vsYou.textContent = fmtScore(ys);
      if (vsOpp) vsOpp.textContent = fmtScore(as);
      if (vsState) {
        vsState.textContent = aiState.dead
          ? (EN() ? 'AI dead' : 'AI 已死')
          : (EN() ? 'AI cleared ' + ac : 'AI 消 ' + ac + ' 行');
      }
      // 实时排行榜：只换文本，不做过渡/动画，也不碰 AI 的模拟
      renderLB(aiState.dead ? (EN() ? 'VS AI · over' : '打 AI · 已结束')
        : (EN() ? 'VS AI · live' : '打 AI · 进行中'));
      return;
    }
    if (!multi) { renderLB(null); return; }
    const aliveN = otherRows().filter(function (p) { return !p.dead; }).length + (multi.meDead ? 0 : 1);
    renderLB(multi.settled ? (EN() ? 'Match over' : '本局结束')
      : (!multi.started ? (EN() ? 'Ready' : '准备中')
        : (EN() ? aliveN + ' alive' : aliveN + ' 人活着')));
    if (!vsEl) return;
    // 3~4 人：整条重画成「你 / 别人」的小比分；2 人：还是原来那三格
    if (isBigMatch() && !aiMode) {
      if (vsEl.dataset.big !== '1') {
        vsEl.dataset.big = '1';
        vsEl.innerHTML = '<span class="tg-vs-list" id="vsList"></span><span class="tg-vs-state" id="vsState"></span>';
        vsState = $('#vsState');
      }
      const list = $('#vsList');
      if (list) {
        const rows = rosterAll().slice().sort(function (a, b) {
          if (a.seat === b.seat) return 0;
          return a.seat - b.seat;
        });
        list.innerHTML = rows.map(function (p) {
          const me = p.seat === multi.mySeat;
          const score = me ? (game ? game.score : 0) : p.score;
          return '<b class="' + (me ? 'me' : '') + (p.dead ? ' out' : '') + '">'
            + escHtml(p.name || (EN() ? '?' : '?')) + ' ' + fmtScore(score, true) + (p.dead ? (EN() ? ' ✕' : ' 死') : '') + '</b>';
        }).join('');
      }
      if (vsState) {
        const alive = otherRows().filter(p => !p.dead).length + (multi.meDead ? 0 : 1);
        if (!multi.started) vsState.textContent = EN() ? 'Ready' : '准备';
        else if (multi.settled) vsState.textContent = EN() ? 'Done' : '结束';
        else if (multi.meDead) vsState.textContent = EN() ? 'Out · ' + alive + ' left' : '你出局 · 还剩 ' + alive + ' 人';
        else vsState.textContent = EN() ? alive + ' alive' : alive + ' 人活着';
      }
      return;
    }
    if (vsYou) vsYou.textContent = fmtScore(game ? game.score : 0);
    if (vsOpp) vsOpp.textContent = fmtScore(multi.opponent.score || 0);
    if (vsState) {
      if (!multi.started) vsState.textContent = EN() ? 'Ready' : '准备';
      else if (multi.opponent.dead) vsState.textContent = EN() ? 'Opponent dead' : '对手已死';
      else vsState.textContent = EN() ? 'Opponent ' + lineCount(multi.opponent.clears || 0)
        : '对手消 ' + (multi.opponent.clears || 0) + ' 行';
    }
  }

  function onNetMessage(m) {
    if (!multi || !m) return;
    // 有名册的时候分数/死活都从名册来（onRoster 处理），这里只接老房主那种点对点消息
    if (m.t === 'state') {
      if (multi.hasRoster) return;
      multi.opponent.score = m.score | 0;
      multi.opponent.debt = m.debt | 0;
      multi.opponent.clears = m.clears | 0;
      if (m.dead) multi.opponent.dead = true;
      updateVs();
      if (m.dead && !multi.settled) settleMulti('oppDead');
      return;
    }
    if (m.t === 'dead') {
      if (multi.hasRoster) return;
      multi.opponent.score = m.score | 0;
      multi.opponent.dead = true;
      updateVs();
      if (!multi.settled) settleMulti('oppDead');
      return;
    }
    if (m.t === 'clear') {
      if (multi.mode === 'lan_battle' && game && game.status === 'playing') {
        game.pendingFusion += 1;
        toast(isBigMatch()
          ? (EN() ? 'A fusion block from ' + (m.from || 'someone') : (m.from || '对手') + ' 送来一块合体块')
          : (EN() ? 'Opponent sent a fusion block' : '对手送来一块合体块'));
      }
      return;
    }
    if (m.t === 'peerLeft') {
      if (multi.hasRoster) {
        // 名册会自己少一条；这里只报一句，剩几个人由 maybeSettle 决定
        if (!multi.settled) toast(EN() ? (m.from || 'Someone') + ' left' : (m.from || '有人') + ' 掉线了');
        maybeSettle();
        return;
      }
      multi.opponent.dead = true;
      updateVs();
      toast(EN() ? 'Opponent disconnected' : '对手掉线了');
      if (!multi.settled) settleMulti('oppLeft');
    }
  }

  /** 只剩一个人活着（或都没了）才结算；2 人时对面死/走就算完。 */
  function maybeSettle() {
    if (!multi || multi.settled) return;
    // 老房主没有名册（只发名字），谁是「我」都认不准：那种连接靠点对点 state/dead/peerLeft 自己结算
    if (!multi.hasRoster) return;
    const others = otherRows();
    const othersAlive = others.filter(p => !p.dead);
    const meAlive = !multi.meDead && !(game && game.status === 'over');
    if (!isBigMatch()) {
      if (!others.length && multi.seenOthers) { settleMulti(meAlive ? 'oppLeft' : 'disconnect'); return; }
      if (others.length && !othersAlive.length) { settleMulti('oppDead'); }
      return;
    }
    const alive = othersAlive.length + (meAlive ? 1 : 0);
    if (multi.seenOthers && alive <= 1) settleMulti(meAlive ? 'lastStanding' : 'done');
  }

  function settleMulti(reason) {
    if (!multi || multi.settled) return;
    multi.settled = true;
    paused = true;
    dasDir = 0;
    if (game) game.setSoftDrop(false);

    const youDead = !!(multi.meDead || (game && game.status === 'over'));
    const ys = game ? (game.score | 0) : 0;
    const title = $('#resTitle');
    const text = $('#resText');

    // 3~4 人：按分数排个名次，赢家只有一个
    if (isBigMatch()) {
      let rows = rosterAll().map(function (p) {
        return {
          seat: p.seat, name: p.name || (EN() ? 'Player' : '玩家'),
          score: p.seat === multi.mySeat ? ys : (p.score | 0),
          dead: !!p.dead, me: p.seat === multi.mySeat
        };
      });
      if (!rows.length) rows = [{ seat: multi.mySeat, name: (multi.opponent && multi.opponent.name) || (EN() ? 'You' : '你'), score: ys, dead: youDead, me: true }];
      rows.sort(function (a, b) { return b.score - a.score || a.seat - b.seat; });
      let rank = 0, lastScore = null;
      rows.forEach(function (r, i) {
        if (lastScore === null || r.score !== lastScore) rank = i + 1;
        r.rank = rank;
        lastScore = r.score;
      });
      const mine = rows.filter(function (r) { return r.me; })[0] || { rank: rows.length, score: ys };
      multi.result = { rank: mine.rank, total: rows.length, rows: rows, you: ys, reason: reason };
      updateVs();
      if (title) {
        title.textContent = mine.rank === 1
          ? (EN() ? 'You win' : '你赢')
          : (EN() ? '#' + mine.rank + ' of ' + rows.length : '第 ' + mine.rank + ' 名');
      }
      if (text) {
        text.innerHTML = rows.map(function (r) {
          return '<span class="' + (r.me ? 'tg-rank-me' : '') + '">'
            + r.rank + '. ' + escHtml(r.name) + ' ' + fmtScore(r.score)
            + (r.dead ? ' ✕' : '') + '</span>';
        }).join('<br>');
      }
      if (resultEl) resultEl.classList.add('on');
      if (root) { root.classList.add('is-result'); root.classList.remove('is-wait'); }
      return;
    }

    const oppDead = !!(multi.opponent.dead || reason === 'oppDead'
      || reason === 'oppLeft' || reason === 'disconnect');
    const os = multi.opponent.score || 0;
    let winner;
    if (youDead && oppDead) winner = ys > os ? 'you' : (ys < os ? 'opp' : 'draw');
    else if (youDead) winner = ys > os ? 'you' : 'opp';
    else if (oppDead) winner = ys > os ? 'you' : (ys === os ? 'you' : 'opp');
    else winner = 'draw';

    multi.result = { winner: winner, you: ys, opp: os, reason: reason };
    updateVs();

    if (resultEl) {
      if (title) title.textContent = winner === 'you' ? T('你赢') : (winner === 'opp' ? T('你输') : T('平局'));
      if (text) {
        let why = '';
        if (reason === 'oppLeft') why = EN() ? ' · opponent left' : ' · 对手掉线';
        else if (reason === 'disconnect') why = EN() ? ' · disconnected' : ' · 连接断了';
        text.textContent = EN()
          ? ('You ' + ys + ' : Opponent ' + os + why + (winner === 'you' && youDead ? ' · higher score wins' : ''))
          : ('你 ' + ys + ' ： 对手 ' + os + why + (winner === 'you' && youDead ? ' · 死的人分高也算赢' : ''));
      }
      resultEl.classList.add('on');
    }
    if (root) { root.classList.add('is-result'); root.classList.remove('is-wait'); }
  }

  function drawCountdown(now) {
    const left = Math.max(0, multi.startAtLocal - now);
    const n = Math.ceil(left / 1000);
    ctx.save();
    ctx.fillStyle = 'rgba(5,6,10,.62)';
    ctx.fillRect(0, 0, BW, H);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e9edf6';
    ctx.font = '800 64px ' + FONT;
    ctx.fillText(n > 0 ? String(n) : (EN() ? 'Go!' : '开始'), BW / 2, 140);
    ctx.fillStyle = '#3ee0c6';
    ctx.font = '600 14px ' + FONT;
    ctx.fillText(multi.mode === 'lan_battle' ? (EN() ? 'Battle' : '干扰战') : (EN() ? 'Parallel' : '并行赛'), BW / 2, 200);
    ctx.fillStyle = '#79839a';
    ctx.font = '11px ' + FONT;
    const names = otherRows().map(function (p) { return p.name || '?'; }).join('、');
    ctx.fillText(isBigMatch()
      ? (EN() ? (rosterAll().length) + ' players · ' + names : rosterAll().length + ' 人 · ' + names)
      : (EN() ? 'Opponent: ' + (multi.opponent.name || 'Opponent') : '对手：' + (multi.opponent.name || '对手')), BW / 2, 222);
    ctx.restore();
  }

  /* ---------------- 输入 ---------------- */

  function onKeyDown(e) {
    if (!running) return;
    if (modeIntro) return;
    if (spectate) {
      if (e.key === 'Escape') { e.preventDefault(); exitToMenu(); }
      return;
    }
    lastInputAt = performance.now();
    const k = e.key;

    if (k === 'Escape' || k === 'p' || k === 'P') {
      e.preventDefault();
      if (!over) togglePause();
      return;
    }
    if (k === 'r' || k === 'R') {
      e.preventDefault();
      if (!e.repeat) requestRestart();
      return;
    }
    if (paused || over || !game) return;

    switch (k) {
      case 'ArrowLeft':
        e.preventDefault();
        if (!e.repeat) { dasDir = -1; dasT = 0; arrT = 0; game.move(-1); }
        break;
      case 'ArrowRight':
        e.preventDefault();
        if (!e.repeat) { dasDir = 1; dasT = 0; arrT = 0; game.move(1); }
        break;
      case 'ArrowDown':
        e.preventDefault();
        game.setSoftDrop(true);
        touchAct = 'down';
        break;
      case 'ArrowUp':
      case 'x':
      case 'X':
        e.preventDefault();
        game.rotate(1);
        break;
      case 'z':
      case 'Z':
        e.preventDefault();
        game.rotate(-1);
        break;
      case ' ':
      case 'Spacebar':
        e.preventDefault();
        game.hardDrop();
        break;
      default:
        break;
    }
  }

  function onKeyUp(e) {
    if (!running) return;
    const k = e.key;
    if (k === 'ArrowLeft' && dasDir === -1) dasDir = 0;
    if (k === 'ArrowRight' && dasDir === 1) dasDir = 0;
    if (k === 'ArrowDown' && game) game.setSoftDrop(false);
  }

  function onPadDown(e) {
    const b = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!b || !running || paused || over || !game) return;
    e.preventDefault();
    lastInputAt = performance.now();
    const act = b.dataset.act;
    touchAct = act;
    try { b.setPointerCapture(e.pointerId); } catch (err) {}
    if (act === 'left') { dasDir = -1; dasT = 0; arrT = 0; game.move(-1); }
    else if (act === 'right') { dasDir = 1; dasT = 0; arrT = 0; game.move(1); }
    else if (act === 'down') {
      const now = performance.now();
      if (now - lastDownTap < 320) {
        lastDownTap = 0;
        game.setSoftDrop(false);
        game.hardDrop();
      } else {
        lastDownTap = now;
        game.setSoftDrop(true);
      }
    }
    else if (act === 'cw') { game.rotate(1); }
    else if (act === 'ccw') { game.rotate(-1); }
    else if (act === 'drop') { game.hardDrop(); }
  }

  function onPadUp() {
    if (touchAct === 'left' || touchAct === 'right') dasDir = 0;
    if (touchAct === 'down' && game) game.setSoftDrop(false);
    touchAct = null;
  }

  function onCanvasDown(e) {
    if (!over || !game) return;
    const r = canvas.getBoundingClientRect();
    const x = (e.clientX - r.left) * W / r.width;
    const y = (e.clientY - r.top) * H / r.height;
    if (x < 8 || x > 82 || y < 246 || y > 312) return;
    const now = performance.now();
    if (now - taps.t > 1400) taps.n = 0;
    taps.t = now;
    taps.n += 1;
    if (taps.n >= 5) {
      taps.n = 0;
      game.carryDebt = 0;
      if (overInfo) overInfo.debt = 0;
      setCarry(0, tierOf(game));
      toast(EN() ? 'Cleared — next game carries no debt' : '档清了，下一局不用还');
    }
  }

  function onClick(e) {
    const b = e.target.closest ? e.target.closest('button') : null;
    if (!b) return;
    const cmd = b.dataset.cmd;
    if (cmd) {
      if (cmd === 'exit') exitToMenu();
      else if (cmd === 'pause') togglePause();
      else if (cmd === 'resume') togglePause(false);
      else if (cmd === 'restart') requestRestart();
      return;
    }
  }

  /* ---------------- 存档 ---------------- */

  function saveAuto() {
    if (!game || multi || aiMode || game.status !== 'playing' || over) return;
    const data = game.toJSON();
    data.savedAt = Date.now();
    const ok = writeJSON(game.zen ? LS.zenAuto
      : (game.casual ? LS.autoCasual
        : (game.classic ? LS.autoClassic : tierKey(LS.auto, tierOf(game)))), data);
    if (ok) dispatch('tetris-save-change', { score: game.score, classic: !!game.classic, casual: !!game.casual });
  }

  function exportSave() {
    if (!game) { toast(EN() ? 'No run started yet' : '还没开局'); return; }
    const data = game.toJSON();
    data.savedAt = new Date().toISOString();
    const text = JSON.stringify(data, null, 2);
    try {
      const blob = new Blob([text], { type: 'application/json' });
      const a = document.createElement('a');
      const d = new Date();
      const pad = function (v) { return v < 10 ? '0' + v : '' + v; };
      a.download = (game.classic ? (EN() ? 'classic' : '经典玩法') : (EN() ? 'solo' : '单人玩法')) + '-save-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate())
        + '-' + pad(d.getHours()) + pad(d.getMinutes()) + '.json';
      a.href = URL.createObjectURL(blob);
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      toast(EN() ? 'Save exported' : '存档已导出');
    } catch (e) {
      toast(EN() ? 'Export failed' : '导出失败');
    }
  }

  function onImportFile() {
    const f = fileInput && fileInput.files && fileInput.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = function () {
      try {
        const data = JSON.parse(String(reader.result || ''));
        const err = E.validateSave(data);
        if (err) { toast(EN() ? 'This file is invalid: ' + err : '这个文件不对：' + err); return; }
        const g = data.classic
          ? new E.Tetris({ seed: (data.seed >>> 0) || 1, classic: true, cols: data.cols || 10, rows: data.rows || 20 })
          : mk({ seed: (data.seed >>> 0) || 1 });
        if (g.loadJSON(data)) { toast(EN() ? 'Could not load it' : '读不进去'); return; }
        game = g;
        layoutFor(game);
        over = false;
        overInfo = null;
        paused = false;
        effects = [];
        if (root) root.classList.remove('is-over');
        if (pauseLayer) pauseLayer.classList.remove('on');
        lastFrame = 0;
        saveAuto();
        toast(EN() ? 'Save imported' : '存档导入成功');
        running = true; startLoop();
      } catch (e) {
        toast(EN() ? 'Not a JSON file' : '不是 JSON 文件');
      }
    };
    reader.readAsText(f);
    fileInput.value = '';
  }

  /* ---------------- 画 ---------------- */

  function fit() {
    if (!canvas) return;
    const dpr = Math.min(qDprCap(), window.devicePixelRatio || 1);
    /* 棋盘 CSS 尺寸由 uiFit() 算好写进 --tg-board-w；这里只负责两件事：
       1) 按舞台高度再兜一次上限（换玩法会改棋盘比例，10×10 / 10×20 / 10×12 不一样）
       2) 背板分辨率跟着屏幕上实际多大走——大屏（1900×1080 / 电视 / 电脑浏览器）
          棋盘会被拉到 1000+ CSS px，还按 480 逻辑像素画就会被整张拉糊。 */
    const want = parseFloat(root.style.getPropertyValue('--tg-board-w')) || 560;
    // 排行榜改成绝对定位（返回下面那一小块），棋盘不再让宽度
    let cssW = Math.max(140, want);
    const sr = stageEl && stageEl.getBoundingClientRect ? stageEl.getBoundingClientRect() : null;
    if (sr && sr.width > 0) {
      const maxByW = Math.max(140, Math.floor(sr.width - 4));
      if (cssW > maxByW) cssW = maxByW;
    }
    if (sr && sr.height > 0) {
      const maxW = Math.floor(sr.height * (W / H));
      if (maxW > 0 && cssW > maxW) cssW = maxW;
    }
    canvas.style.width = cssW + 'px';
    const scale = Math.max(1, cssW / W) * dpr;
    const w = Math.round(W * scale), h = Math.round(H * scale);
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    if (ctx) ctx.setTransform(scale, 0, 0, scale, 0, 0);
  }

  /* ---------------- 键位自适应 ----------------
     一局只适配一次：进游戏时量屏幕、算尺寸、真量 DOM 复核（重叠/出屏就再收两像素）。
     之后只有「视口尺寸或横竖屏真的变了」才重算——同一尺寸绝不重复应用，
     免得界面自己抖来抖去。尺寸只写 --tg-* 变量，CSS 里不再写死像素。 */
  let uiFitKey = '';
  let uiFitBtn = 0;
  let uiFitW = 0, uiFitH = 0, uiFitLand = false, uiFitRot = false;

  function uiFit(force) {
    if (!root) return;
    const de = document.documentElement;
    const vw = Math.round(window.innerWidth || de.clientWidth || 0);
    const vh = Math.round(window.innerHeight || de.clientHeight || 0);
    if (!vw || !vh) return;
    const land = de.classList.contains('land');
    const rot = de.classList.contains('rot');
    // 同一个屏幕只算一次。小于 12px 的变化（状态栏/手势条抖动）当没变，
    // 否则界面会跟着一抖一抖；真的转屏/改窗口才重算。
    if (!force && uiFitBtn && land === uiFitLand && rot === uiFitRot &&
        Math.abs(vw - uiFitW) < 12 && Math.abs(vh - uiFitH) < 12) return;

    const short = Math.min(vw, vh);
    /* 大屏：电视 / 电脑浏览器 / 横过来的大平板。手机和现在这台平板（1138×712）
       走原来的尺寸，一点不变——只在够大的横屏上把棋盘铺开、键位放大。 */
    const big = land && vw >= 1200 && vh >= 640;
    /* 键位再放大一档（所有模式共用）：手机/平板都能一眼按到，但 bad() 那道
       「不能压棋盘、不能出屏」的复核照旧兜底——真塞不下会自动缩回去。 */
    let base;
    if (rot) base = Math.round(short * 0.12);
    else if (land) base = Math.round(Math.min(vh, vw * 0.55) * 0.15);
    else base = Math.round(vw * 0.17);   // 竖屏：按钮再大一点，拇指按得实（2026-11-24）
    let hi = land ? 84 : 92;
    if (big) hi = Math.max(76, Math.min(104, Math.round(vh * 0.10)));
    base = Math.max(40, Math.min(hi, base));

    const padL = root.querySelector('.pad-left');
    const padR = root.querySelector('.pad-right');

    function apply(b) {
      const gap = b >= 50 ? 8 : 6;
      // 往屏幕中间收一点（离边框留白），但不许压到棋盘：舞台留白按真实宽度算
      const edge = Math.max(18, Math.min(56, Math.round(short * 0.06)));
      /* 左边 ← →（两列），右边 ↻ / ↓ 竖着排（一列）。暂存删掉后不用再留那块宽度。 */
      const pl = 2 * b + gap;
      const pr = b;
      root.style.setProperty('--tg-btn', b + 'px');
      root.style.setProperty('--tg-gap', gap + 'px');
      root.style.setProperty('--tg-edge', edge + 'px');
      /* 底边留一点拇指高度：完全贴底的话，握持时大拇指会被手掌压住按不实 */
      root.style.setProperty('--tg-thumb', Math.max(14, Math.round(short * 0.028)) + 'px');
      root.style.setProperty('--tg-font', Math.max(11, Math.round(b * 0.3)) + 'px');
      root.style.setProperty('--tg-stage-pl', (edge + pl + 8) + 'px');
      root.style.setProperty('--tg-stage-pr', (edge + pr + 8) + 'px');
      root.style.setProperty('--tg-rot-w', (pl + 20) + 'px');
      /* 棋盘目标尺寸：小屏保持 560 不动；大屏按「左右让开键位 + 上面让开顶栏」
         能塞多大就多大，最多 1600。 */
      let boardW = 560, hudH = 38;
      const availW = vw - (edge * 2 + pl + pr + 16);
      if (big) {
        hudH = Math.max(44, Math.min(68, Math.round(vh * 0.045)));
        const availH = vh - hudH - 30;
        const aspect = W / H;
        boardW = Math.floor(Math.min(availW, availH * aspect));
        boardW = Math.max(420, Math.min(1600, boardW));
      } else if (land && !rot && availW < 560) {
        /* 手机横屏塞不下 560 的棋盘时，让棋盘收一点、把地方留给方向键：
           宁可格子小两成，也别把键位缩回去——手按不准比看得小更难受。 */
        boardW = Math.max(360, Math.floor(availW));
      }
      root.style.setProperty('--tg-board-w', boardW + 'px');
      root.style.setProperty('--tg-hud-h', hudH + 'px');
      de.classList.toggle('big', big);
      fit();                     // 棋盘尺寸变了，立刻重算背板，别等下一帧
    }

    // 真的量：键位跟棋盘相交，或者键位出屏，都算不合格
    function bad() {
      const c = canvas ? canvas.getBoundingClientRect() : null;
      const boxes = [padL, padR];
      for (let i = 0; i < boxes.length; i++) {
        const el = boxes[i];
        if (!el || !el.getClientRects().length) continue;
        const r = el.getBoundingClientRect();
        if (!r.width || !r.height) continue;
        if (r.left < -1 || r.right > vw + 1 || r.bottom > vh + 1 || r.top < -1) return true;
        if (!c || !c.width) continue;
        if (r.left < c.right && r.right > c.left && r.top < c.bottom && r.bottom > c.top) return true;
      }
      return false;
    }

    let b = base;
    apply(b);
    for (let i = 0; i < 6 && bad(); i++) {
      if (b <= 34) break;
      b -= 2;
      apply(b);
    }
    // 收完再确认一次：还不行就说明这局没救了，保持最小号不再折腾
    uiFitKey = vw + 'x' + vh + (land ? 'L' : 'P') + (rot ? 'R' : '-');
    uiFitBtn = b;
    uiFitW = vw;
    uiFitH = vh;
    uiFitLand = land;
    uiFitRot = rot;
    root.dataset.uibtn = String(b);
    root.dataset.uimode = rot ? 'rot' : (land ? 'land' : 'port');
  }

  function uiFitSoon(delay) {
    if (uiFitTimer) return;
    uiFitTimer = setTimeout(function () {
      uiFitTimer = 0;
      uiFit(false);
    }, typeof delay === 'number' ? delay : 60);
  }

  function rrOn(c, x, y, w, h, r) {
    c.beginPath();
    if (c.roundRect) { c.roundRect(x, y, w, h, r); return; }
    const rad = Math.max(0, Math.min(r, w / 2, h / 2));
    c.moveTo(x + rad, y);
    c.arcTo(x + w, y, x + w, y + h, rad);
    c.arcTo(x + w, y + h, x, y + h, rad);
    c.arcTo(x, y + h, x, y, rad);
    c.arcTo(x, y, x + w, y, rad);
    c.closePath();
  }
  function rr(x, y, w, h, r) {
    rrOn(ctx, x, y, w, h, r);
  }

  function render(now) {
    if (!ctx) return;
    if (spectate) { drawSpectate(now); return; }
    if (!game) return;
    ctx.clearRect(0, 0, W, H);

    ctx.fillStyle = '#08090d';
    ctx.fillRect(0, 0, W, H);

    drawBoard(now);
    drawPanel(now);
    if (multi && !multi.started && !multi.introOut && !root.classList.contains('is-intro')) drawCountdown(now);
  }

  /* 打 AI 不再画那块 96×96 的小盘（每帧重绘、还带过渡），改成排行榜文本 */
  function cellColor(type) { return COLORS[type] || '#8b95a8'; }

  function paintCellOn(c, px, py, size, fill, opts, skinId) {
    opts = opts || {};
    const sk = skinDef(skinId);
    const base = sk.base ? skinDef(sk.base, true) : sk;   // 节日材质 = 基础画法 + 装饰
    const k = size / 32;
    const extra = opts.ghost ? 2 * k : 0;
    const pad = Math.max(1, sk.pad * k + extra);
    const r = Math.max(0, sk.radius * k);
    const x = px + pad, y = py + pad, s = Math.max(2, size - pad * 2);
    c.save();
    if (opts.alpha !== undefined) c.globalAlpha = opts.alpha;

    if (opts.ghost) {
      c.globalAlpha = 0.16;
      rrOn(c, x, y, s, s, r);
      c.fillStyle = fill;
      c.fill();
      c.restore();
      return;
    }

    if (base.id === 'pixel') {
      const ix = Math.round(x), iy = Math.round(y), is = Math.round(s);
      const lw = Math.max(1, Math.round(2 * k));
      c.fillStyle = fill;
      c.fillRect(ix, iy, is, is);
      c.fillStyle = 'rgba(255,255,255,.38)';
      c.fillRect(ix, iy, is, lw);
      c.fillRect(ix, iy, lw, is);
      c.fillStyle = 'rgba(0,0,0,.28)';
      c.fillRect(ix, iy + is - lw, is, lw);
      c.fillRect(ix + is - lw, iy, lw, is);
      c.strokeStyle = opts.stroke || 'rgba(0,0,0,.55)';
      c.lineWidth = 1;
      c.strokeRect(ix + 0.5, iy + 0.5, is - 1, is - 1);
    } else if (base.id === 'modern') {
      const grad = c.createLinearGradient(0, y, 0, y + s);
      grad.addColorStop(0, shade(fill, 0.3));
      grad.addColorStop(0.52, fill);
      grad.addColorStop(1, shade(fill, -0.16));
      rrOn(c, x, y, s, s, r);
      c.fillStyle = grad;
      c.fill();
      c.strokeStyle = opts.stroke || 'rgba(0,0,0,.24)';
      c.lineWidth = Math.max(1, sk.line * k);
      c.stroke();
      rrOn(c, x + 1.5 * k, y + 1.5 * k, s - 3 * k, s - 3 * k, Math.max(1, r - 1.5 * k));
      c.strokeStyle = 'rgba(255,255,255,.10)';
      c.lineWidth = 1;
      c.stroke();
      c.beginPath();
      c.moveTo(x + 3 * k, y + 1.5 * k);
      c.lineTo(x + s - 3 * k, y + 1.5 * k);
      c.strokeStyle = 'rgba(255,255,255,.48)';
      c.lineWidth = Math.max(1, 1.1 * k);
      c.stroke();
    } else if (base.id === 'minimal') {
      rrOn(c, x, y, s, s, r);
      c.fillStyle = fill;
      c.fill();
      c.strokeStyle = opts.stroke || 'rgba(255,255,255,.18)';
      c.lineWidth = Math.max(1, sk.line * k);
      c.stroke();
    } else if (base.id === 'neon') {
      rrOn(c, x, y, s, s, r);
      c.fillStyle = '#0b0e14';
      c.fill();
      const rim = opts.stroke || fill;
      c.save();
      c.strokeStyle = rim;
      c.lineWidth = Math.max(2, 2.2 * k);
      c.shadowColor = tint(fill, 0.6);
      c.shadowBlur = 8 * k;
      c.stroke();
      c.restore();
      rrOn(c, x + 2.5 * k, y + 2.5 * k, s - 5 * k, s - 5 * k, Math.max(1, r - 2 * k));
      c.fillStyle = tint(fill, 0.3);
      c.fill();
    } else {
      rrOn(c, x, y, s, s, r);
      c.fillStyle = fill;
      c.fill();
      c.strokeStyle = opts.stroke || 'rgba(0,0,0,.28)';
      c.lineWidth = Math.max(1, sk.line * k);
      c.stroke();
      c.beginPath();
      c.moveTo(x + 3 * k, y + 1.5 * k);
      c.lineTo(x + s - 3 * k, y + 1.5 * k);
      c.strokeStyle = 'rgba(255,255,255,.28)';
      c.lineWidth = Math.max(1, 1 * k);
      c.stroke();
    }
    if (sk.deco) { try { paintDeco(c, sk.deco, x, y, s, r, k, fill); } catch (e) {} }
    c.restore();
  }

  /* 节日材质上叠的那点装饰：都画得很淡，主要是不想让方块变得难认。
     想更淡就调这里的 alpha，别去动配色。 */
  function starPath(c, cx, cy, rad) {
    c.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + i * Math.PI / 5;
      const rr = i % 2 ? rad * 0.44 : rad;
      const px = cx + Math.cos(a) * rr, py = cy + Math.sin(a) * rr;
      if (i) c.lineTo(px, py); else c.moveTo(px, py);
    }
    c.closePath();
  }
  function paintDeco(c, deco, x, y, s, r, k, fill) {
    c.save();
    if (deco === 'gold') {                    // 春节：一圈很淡的金边 + 右上一点金
      rrOn(c, x + 0.5 * k, y + 0.5 * k, s - k, s - k, Math.max(1, r - 0.5 * k));
      c.strokeStyle = 'rgba(255,214,120,.34)';
      c.lineWidth = Math.max(1, 1.1 * k);
      c.stroke();
      c.beginPath();
      c.arc(x + s - 3.2 * k, y + 3.2 * k, Math.max(1, 1.4 * k), 0, Math.PI * 2);
      c.fillStyle = 'rgba(255,236,180,.36)';
      c.fill();
    } else if (deco === 'lamp') {             // 元宵：上沿一层很淡的暖光
      const g = c.createLinearGradient(0, y, 0, y + s * 0.55);
      g.addColorStop(0, 'rgba(255,225,170,.22)');
      g.addColorStop(1, 'rgba(255,225,170,0)');
      rrOn(c, x, y, s, s, r);
      c.fillStyle = g;
      c.fill();
    } else if (deco === 'leaf') {             // 端午：一道斜的叶脉
      c.beginPath();
      c.moveTo(x + s * 0.24, y + s * 0.76);
      c.lineTo(x + s * 0.76, y + s * 0.24);
      c.strokeStyle = 'rgba(230,255,230,.17)';
      c.lineWidth = Math.max(1, 1.2 * k);
      c.stroke();
    } else if (deco === 'moon') {             // 中秋：底边一弯月牙
      c.beginPath();
      c.arc(x + s / 2, y + s + 0.16 * s, s * 0.42, Math.PI * 1.15, Math.PI * 1.85);
      c.strokeStyle = 'rgba(255,242,200,.30)';
      c.lineWidth = Math.max(1, 1.3 * k);
      c.stroke();
    } else if (deco === 'star') {             // 国庆：左下角一颗很小的星
      starPath(c, x + s * 0.27, y + s * 0.73, s * 0.10);
      c.fillStyle = 'rgba(255,226,120,.34)';
      c.fill();
    } else if (deco === 'rain') {             // 清明：两道很淡的斜雨
      c.strokeStyle = 'rgba(200,225,255,.20)';
      c.lineWidth = Math.max(1, 1.1 * k);
      c.beginPath();
      c.moveTo(x + s * 0.30, y + s * 0.62);
      c.lineTo(x + s * 0.22, y + s * 0.86);
      c.moveTo(x + s * 0.62, y + s * 0.44);
      c.lineTo(x + s * 0.54, y + s * 0.68);
      c.stroke();
    } else if (deco === 'ember') {            // 冬至：底下一点暖光
      const g2 = c.createLinearGradient(0, y + s * 0.55, 0, y + s);
      g2.addColorStop(0, 'rgba(255,206,150,0)');
      g2.addColorStop(1, 'rgba(255,206,150,.20)');
      rrOn(c, x, y, s, s, r);
      c.fillStyle = g2;
      c.fill();
    } else if (deco === 'spark') {            // 元旦：两个角上的小亮点
      c.fillStyle = 'rgba(230,245,255,.26)';
      const pts = [[0.25, 0.25], [0.75, 0.75]];
      for (let i = 0; i < pts.length; i++) {
        c.beginPath();
        c.arc(x + s * pts[i][0], y + s * pts[i][1], Math.max(0.8, 1.1 * k), 0, Math.PI * 2);
        c.fill();
      }
    }
    c.restore();
  }

  function drawBlock(px, py, fill, opts) {
    paintCellOn(ctx, px, py, C.CELL, fill, opts);
  }

  function drawBoard(now) {
    // 底
    ctx.fillStyle = '#0a0c12';
    ctx.fillRect(0, 0, BW, H);

    // 格线
    ctx.strokeStyle = 'rgba(255,255,255,.035)';
    ctx.lineWidth = 1;
    for (let i = 1; i < game.cols; i++) {
      ctx.beginPath(); ctx.moveTo(i * C.CELL + 0.5, 0); ctx.lineTo(i * C.CELL + 0.5, H); ctx.stroke();
    }
    for (let i = 1; i < game.rows; i++) {
      ctx.beginPath(); ctx.moveTo(0, i * C.CELL + 0.5); ctx.lineTo(BW, i * C.CELL + 0.5); ctx.stroke();
    }

    // 场上
    for (let y = 0; y < game.rows; y++) {
      for (let x = 0; x < game.cols; x++) {
        const c = game.board[y][x];
        if (!c) continue;
        const px = x * C.CELL, py = y * C.CELL;
        if (c.k === 'f') {
          drawBlock(px, py, '#39415a', { stroke: 'rgba(160,178,210,.5)' });
        } else if (c.k === 'p') {
          drawBlock(px, py, '#4a2630', { stroke: 'rgba(255,77,94,.55)' });
          ctx.save();
          ctx.strokeStyle = 'rgba(255,120,135,.28)';
          ctx.beginPath();
          ctx.moveTo(px + 9, py + 16); ctx.lineTo(px + 23, py + 16);
          ctx.moveTo(px + 16, py + 9); ctx.lineTo(px + 16, py + 23);
          ctx.stroke();
          ctx.restore();
        } else {
          drawBlock(px, py, cellColor(c.t));
        }
      }
    }


    // 顶块预警：最后 0.9 秒 / 顶上两行已经有东西，直接把危险画在盘面上
    if (!game.classic && game.pendingFusion > 0) {
      const danger = game.topBusy(2);
      const warn = game.fusionWarned || danger;
      ctx.save();
      ctx.fillStyle = danger ? 'rgba(255,77,94,.14)' : 'rgba(255,200,80,.07)';
      ctx.fillRect(0, 0, BW, 2 * C.CELL);
      ctx.strokeStyle = danger ? 'rgba(255,77,94,.85)' : 'rgba(255,200,80,.45)';
      ctx.lineWidth = warn ? 2 : 1;
      ctx.strokeRect(1, 1, BW - 2, 2 * C.CELL - 2);
      ctx.restore();
    }

    // 消行闪光
    for (let i = 0; i < effects.length; i++) {
      const e = effects[i];
      if (e.type !== 'rows') continue;
      const k = clamp((e.until - now) / 260, 0, 1);
      ctx.save();
      ctx.fillStyle = 'rgba(255,255,255,' + (0.55 * k) + ')';
      for (let r = 0; r < e.rows.length; r++) ctx.fillRect(0, e.rows[r] * C.CELL, BW, C.CELL);
      ctx.restore();
    }

    // 落点预览 + 当前块
    if (game.piece && game.status === 'playing') {
      drawGhost();
      drawActive();
    }

    // 转场闪白
    for (let i = 0; i < effects.length; i++) {
      const e = effects[i];
      if (e.type === 'flash') {
        const k = clamp((e.until - now) / 420, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(255,255,255,' + (0.16 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
      if (e.type === 'fusion') {
        const k = clamp((e.until - now) / 460, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(62,224,198,' + (0.13 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
      if (e.type === 'arrow') {
        const k = clamp((e.until - now) / 360, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(255,255,255,' + (0.18 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
    }

    // 边框 + 转场预警
    const muted = document.documentElement.classList.contains('cues-muted');
    ctx.strokeStyle = muted ? 'rgba(62,224,198,.35)' : 'rgba(255,255,255,.08)';
    ctx.lineWidth = 1;
    ctx.strokeRect(0.5, 0.5, BW - 1, H - 1);
    if (muted) {
      // 没有声音的时候，边框常亮，替声音告诉你“局还在”
      ctx.save();
      ctx.strokeStyle = 'rgba(62,224,198,.22)';
      ctx.strokeRect(2.5, 2.5, BW - 5, H - 5);
      ctx.restore();
    }

    if (game.status === 'playing' && game.rotateEnabled !== false) {
      const rem = C.ROTATE_MS - game.rotTimer;
      if (rem <= C.ROTATE_WARN_MS) {
        const k = 1 - rem / C.ROTATE_WARN_MS;
        const pulse = 0.5 + 0.5 * Math.sin(now / 90);
        ctx.save();
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.18 + 0.55 * k * pulse) + ')';
        ctx.lineWidth = 2;
        ctx.strokeRect(1, 1, BW - 2, H - 2);
        ctx.restore();
        drawSpin(now, k);
      }
    }
  }

  function drawSpin(now, k) {
    ctx.save();
    ctx.translate(300, 20);
    ctx.rotate((now / 260) % (Math.PI * 2));
    ctx.strokeStyle = 'rgba(255,255,255,' + (0.45 + 0.45 * k) + ')';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 9, -Math.PI * 0.75, Math.PI * 0.75);
    ctx.stroke();
    // 箭头
    ctx.beginPath();
    ctx.moveTo(0, -12);
    ctx.lineTo(-4.5, -6.5);
    ctx.lineTo(4.5, -6.5);
    ctx.closePath();
    ctx.fillStyle = 'rgba(255,255,255,' + (0.55 + 0.4 * k) + ')';
    ctx.fill();
    ctx.restore();
  }

  function ghostY() {
    const p = game.piece;
    if (!p) return 0;
    let y = p.y;
    while (!game.collides({ type: p.type, rot: p.rot, x: p.x, y: y + 1 })) y++;
    return y;
  }

  function drawGhost() {
    const p = game.piece;
    if (!p) return;
    const gy = ghostY();
    if (gy === p.y) return;
    const cells = game.pieceCells({ type: p.type, rot: p.rot, x: p.x, y: gy });
    const color = p.type === 'ARROW' ? '#f2f5ff' : cellColor(p.type);
    for (let i = 0; i < cells.length; i++) {
      const px = cells[i][0] * C.CELL, py = cells[i][1] * C.CELL;
      paintCellOn(ctx, px, py, C.CELL, color, { ghost: true });
    }
  }

  function drawActive() {
    const p = game.piece;
    if (!p) return;
    const cells = game.pieceCells();
    const isArrow = p.type === 'ARROW';
    const color = isArrow ? '#f2f5ff' : cellColor(p.type);
    const sk = skinDef(settings.skin);
    ctx.save();
    if (sk.id !== 'neon') {
      ctx.shadowColor = isArrow ? 'rgba(255,255,255,.85)' : color;
      ctx.shadowBlur = Math.max(4, sk.glow);
    }
    for (let i = 0; i < cells.length; i++) {
      const px = cells[i][0] * C.CELL, py = cells[i][1] * C.CELL;
      drawBlock(px, py, color, sk.id === 'neon' ? {} : {
        stroke: sk.id === 'minimal' ? 'rgba(255,255,255,.22)' : 'rgba(255,255,255,.4)'
      });
    }
    ctx.restore();
    if (isArrow) {
      const glyph = { up: '↑', down: '↓', left: '←', right: '→' }[p.dir] || '↑';
      ctx.save();
      ctx.fillStyle = '#08090d';
      ctx.font = '700 22px ' + FONT;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(glyph, p.x * C.CELL + 16, p.y * C.CELL + 17);
      ctx.restore();
    }
  }

  function drawPreview(entry, x, y, size) {
    ctx.save();
    rr(x, y, size, size, 9);
    ctx.fillStyle = '#10131b';
    ctx.fill();
    ctx.strokeStyle = '#232838';
    ctx.lineWidth = 1;
    ctx.stroke();

    if (entry) {
      if (entry.t === 'ARROW') {
        const glyph = { up: '↑', down: '↓', left: '←', right: '→' }[entry.d] || '↑';
        ctx.fillStyle = '#f2f5ff';
        ctx.font = '700 ' + Math.round(size * 0.5) + 'px ' + FONT;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(glyph, x + size / 2, y + size / 2 + 1);
      } else {
        const shape = SHAPES[entry.t];
        let minx = 9, maxx = -9, miny = 9, maxy = -9;
        for (let i = 0; i < shape.cells.length; i++) {
          minx = Math.min(minx, shape.cells[i][0]); maxx = Math.max(maxx, shape.cells[i][0]);
          miny = Math.min(miny, shape.cells[i][1]); maxy = Math.max(maxy, shape.cells[i][1]);
        }
        const bw = maxx - minx + 1, bh = maxy - miny + 1;
        const u = size / 4.6;
        const ox = (size - bw * u) / 2 - minx * u;
        const oy = (size - bh * u) / 2 - miny * u;
        for (let i = 0; i < shape.cells.length; i++) {
          const cx = x + ox + shape.cells[i][0] * u;
          const cy = y + oy + shape.cells[i][1] * u;
          paintCellOn(ctx, cx, cy, u, cellColor(entry.t));
        }
      }
    }
    ctx.restore();
  }

  function drawPanel(now) {
    ctx.save();
    rr(PX, 0, PW, H, 12);
    ctx.fillStyle = '#0d0f16';
    ctx.fill();
    ctx.strokeStyle = '#1c2130';
    ctx.lineWidth = 1;
    ctx.stroke();

    const L = PX + 8, R = PX + PW - 8;

    // NEXT
    label('NEXT', L, 14);
    for (let i = 0; i < 3; i++) {
      drawPreview(game.queue[i] || null, L + i * 44, 20, 40);
    }

    // HOLD
    label('HOLD', L, 77);
    drawPreview(game.hold || null, L, 83, 40);

    // 分数（太长就用紧凑汉字，不缩成蚂蚁字）
    label(T('分数'), L, 141);
    ctx.fillStyle = '#e9edf6';
    let scoreTxt = fmtScore(game.score);
    ctx.font = '700 28px ' + FONT;
    if (ctx.measureText(scoreTxt).width > PW - 10) scoreTxt = fmtScore(game.score, true);
    fitFont(scoreTxt, PW - 10, 28, '700');
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(scoreTxt, L, 172);

    // 数据：三条大的 + 一行状态（原来四条小字 + 两条 9px，挤）
    const projected = game.projectedDebt ? game.projectedDebt() : game.debt;
    const rows = [];
    if (game.zen) {
      const left = Math.max(0, game.zenTimeLeft || 0);
      const mm = Math.floor(left / 60000), ss = Math.floor(left % 60000 / 1000);
      rows.push([T('剩余'), mm + ':' + (ss < 10 ? '0' : '') + ss, left < 30000 ? '#ff5c6c' : '#3ee0c6']);
      rows.push([T('连击'), game.combo > 0 ? game.combo + 'x' : '0', game.combo > 0 ? '#ffc857' : '#c6cdda']);
      rows.push([T('最高'), fmtScore(highScore, true), '#79839a']);
    } else if (game.casual) {
      const mult = 1 + Math.min(Math.max(0, game.combo - 1), 5) * 0.25;
      rows.push([T('连击'), game.combo > 0 ? game.combo + 'x' : '0', game.combo > 0 ? '#ffc857' : '#c6cdda']);
      rows.push([T('倍数'), 'x' + mult.toFixed(2).replace(/\.?0+$/, ''), '#ffc857']);
      rows.push([T('最高'), fmtScore(highScore, true), '#79839a']);
    } else {
      rows.push([T('等级'), String(game.classic ? game.level : game.lockLevel), '#c6cdda']);
      rows.push([T('消行'), String(game.classic ? game.lines : game.clears), '#c6cdda']);
      rows.push([T('最高'), fmtScore(highScore, true), '#79839a']);
    }
    rows.forEach(function (r, i) { statBig(r[0], r[1], 204 + i * 26, r[2]); });

    // 底部只留一行状态
    let status = '', statusColor = '#5b6479';
    if (game.zen) {
      status = EN() ? 'Zen · ' + game.zenMinutes + ' min' : '禅 · ' + game.zenMinutes + ' 分钟';
    } else if (game.casual) {
      status = EN() ? 'Max combo ' + (game.maxCombo || 0) + 'x' : '最高连击 ' + (game.maxCombo || 0) + 'x';
    } else if (game.classic) {
      status = 'SEED ' + game.seed;
    } else if (game.pendingFusion > 0) {
      const left = Math.max(0, ((E.CONST ? E.CONST.FUSION_DELAY_MS : 2500) - game.fusionTimer) / 1000);
      status = (EN() ? 'Rise in ' : '顶块 ') + left.toFixed(1) + 's';
      statusColor = '#ff8b96';
    } else if (game.grace > 0) {
      status = T('奖励期') + ' ' + game.grace + (EN() ? 'x' : ' 次');
      statusColor = '#3ee0c6';
    } else if (projected > 0) {
      status = (EN() ? 'Debt -' : '债 -') + projected;
      statusColor = '#ff5c6c';
    } else {
      status = T('债已清');
    }
    ctx.textAlign = 'left';
    ctx.font = '600 12px ' + FONT;
    ctx.fillStyle = statusColor;
    ctx.fillText(status, L, 292);

    ctx.restore();

    function label(t, x, y) {
      ctx.fillStyle = '#5b6479';
      ctx.font = '600 9px ' + FONT;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
      ctx.fillText(t, x, y);
    }
    function statBig(k, v, y, color) {
      ctx.textAlign = 'left';
      ctx.font = '12px ' + FONT;
      ctx.fillStyle = '#79839a';
      ctx.fillText(k, L, y);
      const kw = ctx.measureText(k).width;
      fitFont(v, Math.max(40, (R - L) - kw - 8), 15, '600');
      ctx.textAlign = 'right';
      ctx.fillStyle = color;
      ctx.fillText(v, R, y);
    }

    ctx.restore();
  }

  /* ---------------- 对外 ---------------- */

  function paintSkinSwatch(canvas, id) {
    if (!canvas) return;
    const dpr = Math.min(qDprCap(), window.devicePixelRatio || 1);
    const size = 40;
    canvas.width = Math.round(size * dpr);
    canvas.height = Math.round(size * dpr);
    const c = canvas.getContext('2d');
    if (!c) return;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, size, size);
    paintCellOn(c, 1, 1, size - 2, COLORS.I, {}, id);
  }

  function updatePauseSkins() {
    if (!skinsBox) return;
    for (let i = 0; i < skinsBox.children.length; i++) {
      const b = skinsBox.children[i];
      b.classList.toggle('on', b.dataset.skin === settings.skin);
    }
  }

  function buildPauseSkins() {
    if (!skinsBox) return;
    skinsBox.innerHTML = '';
    SKINS.filter(function (s) { return !s.hidden; }).forEach(function (sk) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'tg-skin';
      b.dataset.skin = sk.id;
      const cv = document.createElement('canvas');
      b.appendChild(cv);
      const span = document.createElement('span');
      span.textContent = T(sk.name);
      b.appendChild(span);
      b.addEventListener('click', function (ev) {
        ev.stopPropagation();
        applySkin(sk.id);
      });
      skinsBox.appendChild(b);
      paintSkinSwatch(cv, sk.id);
    });
    updatePauseSkins();
  }

  function applySkin(id) {
    settings.skin = id;
    settings.skinMode = 'manual';
    try {
      const st = JSON.parse(localStorage.getItem('tetris.settings') || '{}');
      st.skin = id;
      st.skinMode = 'manual';
      st.lastSkin = id;
      localStorage.setItem('tetris.settings', JSON.stringify(st));
    } catch (e) {}
    updatePauseSkins();
    if (game) render(performance.now());
    toast(EN() ? 'Skin: ' + T(skinDef(id).name) : '方块材质：' + skinDef(id).name);
    dispatch('tetris-skin', { skin: id, mode: 'manual' });
  }

  function previewSkin(canvas, id) {
    if (!canvas) return;
    const dpr = Math.min(qDprCap(), window.devicePixelRatio || 1);
    const cw = 132, ch = 40;
    const pw = Math.round(cw * dpr), ph = Math.round(ch * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    const c = canvas.getContext('2d');
    if (!c) return;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, cw, ch);
    c.fillStyle = '#0a0c12';
    c.fillRect(0, 0, cw, ch);
    const cols = ['#3ee0c6', '#ffc857', '#b07cff', '#5bd75b'];
    const size = 26, gap = 6;
    const total = cols.length * size + gap * (cols.length - 1);
    const x0 = (cw - total) / 2, y0 = (ch - size) / 2;
    for (let i = 0; i < cols.length; i++) {
      paintCellOn(c, x0 + i * (size + gap), y0, size, cols[i], {}, id);
    }
  }

  window.TetrisGame = {
    start: start,
    stop: exitToMenu,
    skins: function () {
      return SKINS.filter(function (s) { return !s.hidden; }).map(function (s) { return { id: s.id, name: s.name }; });
    },
    previewSkin: previewSkin,
    isRunning: function () { return running; },
    // 给控制台 / 测试用的把手，不参与游戏逻辑
    _state: function () { return game; },
    _skin: function () { return settings.skin; },
    _aiState: function () { return aiState; },
    _spectate: function () { return spectate; },
    _spectateStep: function (ms) {
      if (!spectate) return;
      stepSpectate(Math.max(0, ms || 16));
      render(performance.now());
    },
    _stepForTest: function (ms) {
      if (!game || over) return;
      const step = Math.max(0, Math.min(ms || 16, 120));
      game.tick(step);
      updateDAS(step);
      pumpEvents();
      if (aiMode) stepAI(step);
      render(performance.now());
    }
  };
})();