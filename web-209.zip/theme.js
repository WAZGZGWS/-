/* theme.js —— 节日主题（只做中国节日）
 *
 * 一个节日 = 一套方块配色 + 一套方块材质（材质在 game.js 的 SKINS 里，id 以 h- 开头）
 *          + 主界面强调色 + 开场白 + 一段背景音乐（全部代码合成，不带音频文件）
 *
 * 规矩（哥 2026-11-25 定的）：节日包只在节日当天出现，平时游戏里看不到也用不到；
 * 设置里只有「跟随日期 / 关闭」和节日音乐开关，没有试穿、没有节日清单可选。
 *
 * 为什么农历写死一张表：
 *   运行时算不出来。JS 自带的 ICU 农历在 2027（除夕应该是 2/5，它算成 2/6）和 2030 上
 *   都差了一天，不敢用。下面是 2024–2036 的对照表（春节、元宵、龙抬头、端午、七夕、
 *   中元、中秋、重阳、腊八），已和公开农历对照表核对过。
 *   清明、冬至按节气算，用国内历书常用的那条近似公式（2000–2099 有效）。
 */
(function (global) {
  'use strict';

  /* ---------------- 农历对照表 ----------------
   * 每年九个：[春节, 元宵, 龙抬头, 端午, 七夕, 中元, 中秋, 重阳, 腊八]（月-日）
   * 腊八多在公历 1 月、属于上一个农历年，这里按「节日所在的公历年」归行。
   */
  const LUNAR = {
    2024: ['02-10', '02-24', '03-11', '06-10', '08-10', '08-18', '09-17', '10-11', '01-07'],
    2025: ['01-29', '02-12', '03-01', '05-31', '08-29', '09-06', '10-06', '10-29', '01-26'],
    2026: ['02-17', '03-03', '03-20', '06-19', '08-19', '08-27', '09-25', '10-18', '01-15'],
    2027: ['02-06', '02-20', '03-09', '06-09', '08-08', '08-16', '09-15', '10-08', '01-04'],
    2028: ['01-26', '02-09', '02-26', '05-28', '08-26', '09-03', '10-03', '10-26', '01-22'],
    2029: ['02-13', '02-27', '03-16', '06-16', '08-16', '08-24', '09-22', '10-16', '01-11'],
    2030: ['02-03', '02-17', '03-05', '06-05', '08-05', '08-13', '09-12', '10-05', '01-01'],
    2031: ['01-23', '02-06', '02-22', '06-24', '08-24', '09-01', '10-01', '10-24', '01-20'],
    2032: ['02-11', '02-25', '03-13', '06-12', '08-12', '08-20', '09-19', '10-12', '01-08'],
    2033: ['01-31', '02-14', '03-02', '06-01', '08-01', '08-09', '09-08', '10-01', '01-27'],
    2034: ['02-19', '03-05', '03-21', '06-20', '08-20', '08-28', '09-27', '10-20', '01-16'],
    2035: ['02-08', '02-22', '03-11', '06-10', '08-10', '08-18', '09-16', '10-09', '01-05'],
    2036: ['01-28', '02-11', '02-28', '05-30', '08-28', '09-05', '10-04', '10-27', '01-23']
  };
  const LUNAR_KEYS = ['spring', 'lantern', 'longtou', 'dragon', 'qixi', 'zhongyuan', 'moon', 'chongyang', 'laba'];

  /* 节气：国内历书常用的近似式，2000–2099 有效（个别年份差一天的例外不在本区间） */
  function termDay(year, a) {
    const Y = year % 100;
    return Math.floor(Y * 0.2422 + a) - Math.floor(Y / 4);
  }

  /* ---------------- 调色板 / 音乐的小工具（省得每条都写全） ---------------- */
  function pal(a) {
    return { I: a[0], O: a[1], T: a[2], S: a[3], Z: a[4], J: a[5], L: a[6], ARROW: a[7] || '#f4f8ff' };
  }
  const PENTA = [0, 2, 4, 7, 9];        // 宫调五声：宫 商 角 徵 羽
  const YU = [0, 3, 5, 7, 10];          // 羽调五声
  const MAJOR = [0, 2, 4, 5, 7, 9, 11];

  /* 六段旋律动机，每个节日挑一段 + 换调换速度，听感就不一样了
   * 记谱：1 = 根音，越往上越大（6 起是高八度），'-' 延长，'.' 休止；一行四拍 */
  const MOTIF = [
    ['5 3 5 6', '6 5 3 2', '3 5 6 8', '6 5 3 -', '5 3 5 6', '8 6 5 3', '3 2 1 -', '2 3 5 -'],
    ['3 5 6 5', '3 - 2 -', '1 2 3 5', '6 - 5 -', '3 5 6 8', '6 5 3 -', '2 3 5 3', '2 - 1 -'],
    ['1 - 3 2', '1 - 5 -', '3 2 1 -', '3 5 3 2', '1 - 3 2', '1 - 5 -', '6 5 3 2', '1 - - -'],
    ['5 - - 3', '2 - 1 -', '3 - 5 -', '6 - 5 -', '2 - 3 5', '3 - 2 -', '1 - - -', '5 - - -'],
    ['1 1 5 5', '6 6 5 -', '3 3 2 2', '1 - - 5', '1 1 5 5', '6 6 8 -', '6 5 3 2', '1 - - -'],
    ['6 - 5 3', '5 - 3 -', '6 - 8 6', '5 - 3 -', '5 6 8 -', '6 5 3 -', '2 3 5 -', '6 - - -']
  ];
  const BASS = [
    ['1 - 5 -', '1 - 5 -', '1 - 5 -', '2 - 5 -'],
    ['1 - - -', '1 - - -', '5 - - -', '1 - - -'],
    ['1 - 1 -', '5 - 5 -', '1 - 1 -', '3 - 5 -']
  ];
  const PERC = [
    ['k . s k', 's . k .', 'k . s k', 's . k .'],
    ['k . . s', 'k . . .', 'k . . s', 'k . . .'],
    ['k s k s', 'k s k .', 'k s k s', 's k . .'],
    ['. . . .', 's . . .', '. . . .', 's . . .']
  ];
  /* 配器：不同节日用不同「乐队」，比只换音阶更像那个节日
   *   suona 唢呐（春节/重阳）：锯齿波 + 颤音，亮、冲
   *   drum  鼓（端午/龙抬头）：闷鼓为主，旋律短促
   *   bell  铃铎（元宵/七夕/腊八/冬至/元旦）：正弦 + 不和谐分音，清
   *   flute 箫笛（清明/中元/中秋）：正弦 + 轻颤音，慢
   *   brass 铜管（国庆）：锯齿 + 低通，进行曲
   */
  const INST = {
    suona: { mel: 'sawtooth', vib: 0.012, bell: 0, gong: 1, bright: 1 },
    drum: { mel: 'triangle', vib: 0, bell: 0, gong: 1, bright: 0 },
    bell: { mel: 'sine', vib: 0, bell: 1, gong: 0, bright: 0 },
    flute: { mel: 'sine', vib: 0.005, bell: 0, gong: 0, bright: 0 },
    brass: { mel: 'sawtooth', vib: 0, bell: 0, gong: 0, bright: 1 }
  };
  function mus(m, bpm, root, scale, inst, gain, bass, perc) {
    return {
      bpm: bpm, root: root, scale: scale, inst: inst,
      wave: (INST[inst] || INST.bell).mel,
      bassWave: inst === 'brass' ? 'sawtooth' : (inst === 'suona' ? 'triangle' : 'sine'),
      gain: gain, mel: MOTIF[m], bass: BASS[bass == null ? 0 : bass], perc: PERC[perc == null ? 0 : perc]
    };
  }

  /* ---------------- 节日表 ----------------
   * accent/accentRgb 主界面强调色；bg 主界面底色；skin 方块材质；greet 开场那句
   * 顺序只影响列表，不影响命中。
   */
  const HOLIDAYS = [
    {
      id: 'newyear', name: '元旦', en: 'New Year', accent: '#7fd8ff', accentRgb: '127,216,255', bg: '#060b14',
      skin: 'h-newyear', greet: '新年好', greetEn: 'Happy New Year',
      colors: pal(['#7fd8ff', '#ffd166', '#a8b8ff', '#6ee7c8', '#ff8fa3', '#5b8cff', '#c9d6ff']),
      music: mus(5, 112, 60, PENTA, 'bell', 0.055, 1, 1)
    },
    {
      id: 'spring', name: '春节', en: 'Spring Festival', accent: '#ff5a5a', accentRgb: '255,90,90', bg: '#150609',
      skin: 'h-spring', greet: '新年快乐', greetEn: 'Happy New Year',
      colors: pal(['#ff5c5c', '#ffd166', '#ff86b3', '#6fd76f', '#e63946', '#5b8cff', '#ffb03a', '#fff1cf']),
      music: mus(0, 108, 62, PENTA, 'suona', 0.058, 0, 0)
    },
    {
      id: 'lantern', name: '元宵', en: 'Lantern Festival', accent: '#ff9f68', accentRgb: '255,159,104', bg: '#140b06',
      skin: 'h-lantern', greet: '元宵快乐', greetEn: 'Happy Lantern Festival',
      colors: pal(['#ff9f68', '#ffe08a', '#ffa8d8', '#ffd36e', '#ff7b8a', '#c98bff', '#ffc857', '#fff6e0']),
      music: mus(1, 100, 64, PENTA, 'bell', 0.06, 1, 1)
    },
    {
      id: 'longtou', name: '龙抬头', en: 'Longtaitou', accent: '#6fd6a0', accentRgb: '111,214,160', bg: '#06120c',
      skin: 'h-longtou', greet: '龙抬头', greetEn: 'Longtaitou',
      colors: pal(['#6fd6a0', '#e8d17a', '#a8e6c0', '#3fbf7a', '#d98f5a', '#4f9bb8', '#c9d65a', '#eafff0']),
      music: mus(2, 106, 60, PENTA, 'drum', 0.05, 2, 0)
    },
    {
      id: 'qingming', name: '清明', en: 'Qingming', accent: '#9fc7e8', accentRgb: '159,199,232', bg: '#080d12',
      skin: 'h-qingming', greet: '清明', greetEn: 'Qingming',
      colors: pal(['#9fc7e8', '#cfd8b0', '#b8c9e0', '#8fbfae', '#c9a0a8', '#7d9fc4', '#d8cf9a', '#eef4fa']),
      music: mus(3, 84, 57, YU, 'flute', 0.055, 1, 3)
    },
    {
      id: 'dragon', name: '端午', en: 'Dragon Boat Festival', accent: '#4fbf7a', accentRgb: '79,191,122', bg: '#06120c',
      skin: 'h-dragon', greet: '端午安康', greetEn: 'Happy Dragon Boat Festival',
      colors: pal(['#4fbf7a', '#d9c26a', '#7fd1a8', '#2f9e6b', '#d96a4a', '#3f8f8f', '#a8c95a', '#eafbe6']),
      music: mus(2, 118, 57, YU, 'drum', 0.045, 2, 2)
    },
    {
      id: 'qixi', name: '七夕', en: 'Qixi', accent: '#c9a8ff', accentRgb: '201,168,255', bg: '#0a0814',
      skin: 'h-qixi', greet: '七夕快乐', greetEn: 'Happy Qixi',
      colors: pal(['#c9a8ff', '#ffd7e8', '#e0c0ff', '#a8d8ff', '#ff9ecb', '#8f7bff', '#ffc2d8', '#f8f2ff']),
      music: mus(1, 96, 65, PENTA, 'bell', 0.058, 1, 3)
    },
    {
      id: 'zhongyuan', name: '中元', en: 'Zhongyuan', accent: '#a8b8c8', accentRgb: '168,184,200', bg: '#08090c',
      skin: 'h-zhongyuan', greet: '中元', greetEn: 'Zhongyuan',
      colors: pal(['#a8b8c8', '#d8c9a0', '#b0b8d8', '#9fb8a8', '#b08f8f', '#7f8fa8', '#c9b88f', '#e8ecf2']),
      music: mus(3, 76, 55, YU, 'flute', 0.052, 1, 3)
    },
    {
      id: 'moon', name: '中秋', en: 'Mid-Autumn Festival', accent: '#ffcf5a', accentRgb: '255,207,90', bg: '#0d0b06',
      skin: 'h-moon', greet: '中秋团圆', greetEn: 'Happy Mid-Autumn',
      colors: pal(['#ffe9a8', '#ffcf5a', '#c9b6ff', '#8fd6c8', '#ff9a8a', '#7aa2ff', '#ffd98a', '#fff8e6']),
      music: mus(3, 72, 62, YU, 'flute', 0.062, 1, 3)
    },
    {
      id: 'chongyang', name: '重阳', en: 'Chongyang', accent: '#e8b45a', accentRgb: '232,180,90', bg: '#100c06',
      skin: 'h-chongyang', greet: '重阳安康', greetEn: 'Happy Chongyang',
      colors: pal(['#e8b45a', '#ffdf9a', '#d8a06a', '#bfa84f', '#c47a5a', '#9f8f5a', '#e8c87a', '#fff4e0']),
      music: mus(0, 88, 60, PENTA, 'suona', 0.05, 0, 3)
    },
    {
      id: 'laba', name: '腊八', en: 'Laba', accent: '#d99a5a', accentRgb: '217,154,90', bg: '#0f0a06',
      skin: 'h-laba', greet: '腊八', greetEn: 'Laba Festival',
      colors: pal(['#d99a5a', '#e8c07a', '#c98a6a', '#b8a35a', '#c46a4a', '#8f9a6a', '#d8b06a', '#fdf2e0']),
      music: mus(1, 92, 59, PENTA, 'bell', 0.055, 1, 1)
    },
    {
      id: 'dongzhi', name: '冬至', en: 'Winter Solstice', accent: '#a8c8e8', accentRgb: '168,200,232', bg: '#070a10',
      skin: 'h-dongzhi', greet: '冬至安康', greetEn: 'Happy Winter Solstice',
      colors: pal(['#a8c8e8', '#e8dcc0', '#c0d0e8', '#a8d8c8', '#d8a8a8', '#7f9fc8', '#d8c8a0', '#f0f6fc']),
      music: mus(5, 80, 58, YU, 'bell', 0.058, 1, 3)
    },
    {
      id: 'national', name: '国庆', en: 'National Day', accent: '#ff4d4d', accentRgb: '255,77,77', bg: '#140607',
      skin: 'h-national', greet: '国庆快乐', greetEn: 'Happy National Day',
      colors: pal(['#ff4d4d', '#ffd700', '#ff8c42', '#ffd166', '#d62828', '#2f6fdd', '#ffb703', '#fff2cc']),
      music: mus(4, 120, 62, MAJOR, 'brass', 0.042, 0, 0)
    }
  ];

  /* ---------------- 日期小工具 ---------------- */
  function p2(n) { return (n < 10 ? '0' : '') + n; }
  function isoOf(d) { return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
  function parseIso(s) {
    const p = String(s).split('-');
    return new Date(+p[0], +p[1] - 1, +p[2], 12, 0, 0, 0);
  }
  function addDays(s, n) {
    const d = parseIso(s);
    d.setDate(d.getDate() + n);
    return isoOf(d);
  }
  function solsticeIso(y, month, a) {
    return y + '-' + p2(month) + '-' + p2(termDay(y, a));
  }

  /* ---------------- 哪些天算哪个节日 ----------------
   * 春节：除夕 ~ 正月初六（8 天）      国庆：10/1 ~ 10/7      其余：当天
   */
  let INDEX = null;
  function buildIndex() {
    INDEX = {};
    const put = function (from, to, id) {
      let s = from, guard = 0;
      while (guard++ < 40) {
        INDEX[s] = id;
        if (s === to) break;
        s = addDays(s, 1);
      }
    };
    const one = function (iso, id) { put(iso, iso, id); };
    /* 先铺公历的，再铺农历的 —— 同一天撞上时农历那个更要紧
       （2031-10-01 正好中秋撞国庆，那天按中秋算）。 */
    for (let y = 2020; y <= 2040; y++) {
      one(y + '-01-01', 'newyear');
      put(y + '-10-01', y + '-10-07', 'national');
      if (y >= 2000 && y <= 2099) {
        one(solsticeIso(y, 4, 4.81), 'qingming');     // 清明
        one(solsticeIso(y, 12, 21.94), 'dongzhi');    // 冬至
      }
    }
    Object.keys(LUNAR).forEach(function (y) {
      const row = LUNAR[y];
      const spIso = y + '-' + row[0];
      put(addDays(spIso, -1), addDays(spIso, 5), 'spring');
      for (let i = 1; i < LUNAR_KEYS.length; i++) one(y + '-' + row[i], LUNAR_KEYS[i]);
    });
  }
  function holidayById(id) {
    for (let i = 0; i < HOLIDAYS.length; i++) if (HOLIDAYS[i].id === id) return HOLIDAYS[i];
    return null;
  }

  /* ---------------- 设置（独立存，比主设置早加载） ---------------- */
  const KEY = 'tetris.theme';
  /* 节日主题和四季背景都没有开关：节日跟着日期走，四季跟着节气走。
     界面里只在「游戏」设置下面留一行小字说明。 */
  let CFG = { mode: 'auto', bgm: true, seasons: true };
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || '{}');
    if (raw && typeof raw === 'object') {
      CFG.mode = 'auto';
      if (raw.bgm === false) CFG.bgm = false;
      /* 四季现在没有开关了，一律当开（老设置里存过 false 也忽略） */
      CFG.seasons = true;
    }
  } catch (e) {}
  function saveCfg() {
    try { localStorage.setItem(KEY, JSON.stringify(CFG)); } catch (e) {}
  }

  /* ================= 时间校准 =================
   * 节日最容易出的洋相就是在不该出现的那天出现。三个来源，从可信到不可信：
   *   1) 网络校过的偏差 —— 能读到响应头的 Date 就用它算「本机差了多久」，存 6 小时；
   *   2) 本机时钟，但一律按北京时间（UTC+8）归日 —— 设备时区设错了也不会差一天；
   *   3) 本机时钟比这一版的编译时间还早一天半以上 —— 说明设备时间明显错了，
   *      那就不上节日主题：宁可不出现，也不出现错的那天。
   */
  const TZ_MS = 8 * 3600 * 1000;
  const SKEW_KEY = 'tetris.clockSkew';
  const SKEW_TTL = 6 * 3600 * 1000;
  let skew = 0, skewAt = 0;
  try {
    const raw = JSON.parse(localStorage.getItem(SKEW_KEY) || '{}');
    if (raw && isFinite(raw.skew) && isFinite(raw.at)) { skew = Math.round(raw.skew); skewAt = Math.round(raw.at); }
  } catch (e) {}
  function localNow() { return Date.now(); }
  function netNow() { return localNow() + skew; }
  function bjIso(ms) { return new Date(ms + TZ_MS).toISOString().slice(0, 10); }
  function builtAtMs() {
    const v = global.TetrisVersion;
    const s = v && (v.builtAt || v.date);
    const t = s ? Date.parse(s) : NaN;
    return isFinite(t) ? t : 0;
  }
  /* 比编译时间早了 36 小时以上 = 本机时间不可信（编译完就不可能回到过去） */
  function clockTrusted(ms) {
    const b = builtAtMs();
    if (!b) return true;
    return ms >= b - 36 * 3600 * 1000;
  }
  function calibrate() {
    if (!global.fetch) return;
    const stale = !skewAt || (localNow() - skewAt) > SKEW_TTL;
    if (!stale) return;
    const src = 'https://raw.githubusercontent.com/WAZGZGWS/-/main/update.json';
    let ctl = null, timer = 0;
    try {
      if (global.AbortController) ctl = new AbortController();
      timer = setTimeout(function () { if (ctl) try { ctl.abort(); } catch (e) {} }, 6000);
    } catch (e) {}
    try {
      fetch(src, { method: 'GET', cache: 'no-store', signal: ctl ? ctl.signal : undefined })
        .then(function (r) {
          const h = (r.headers && r.headers.get) ? r.headers.get('date') : '';
          const t = h ? Date.parse(h) : NaN;
          if (isFinite(t)) {
            skew = t - localNow();
            skewAt = localNow();
            try { localStorage.setItem(SKEW_KEY, JSON.stringify({ skew: skew, at: skewAt })); } catch (e) {}
          }
          return 0;
        })
        .catch(function () {})
        .then(function () { if (timer) clearTimeout(timer); });
    } catch (e) {}
  }

  /* ---------------- 今天穿哪套 ---------------- */
  let overrideDay = '';
  function today() {
    if (overrideDay) return overrideDay;
    if (!clockTrusted(netNow())) return '1970-01-01';   // 时间不可信：当它没有任何节日
    return bjIso(netNow());
  }
  let curHoliday = null;
  function computeActive() {
    if (CFG.mode === 'off') return null;
    if (!overrideDay && !clockTrusted(netNow())) return null;
    if (!INDEX) buildIndex();
    const id = INDEX[today()];
    return id ? holidayById(id) : null;
  }
  function active() { return curHoliday; }

  /* ---------------- 配色替换（方块七色） ---------------- */
  const ENGINE = global.TetrisEngine;
  const BASE_COLORS = Object.assign({}, (ENGINE && ENGINE.COLORS) || {});
  function setPalette(colors) {
    if (!ENGINE || !ENGINE.COLORS) return;
    Object.keys(BASE_COLORS).forEach(function (k) {
      ENGINE.COLORS[k] = (colors && colors[k]) || BASE_COLORS[k];
    });
  }

  /* ---------------- 应用 / 撤销 ---------------- */
  let applied = null;
  function apply() {
    curHoliday = computeActive();
    const h = curHoliday;
    const html = document.documentElement;
    if (html) {
      if (h) {
        html.setAttribute('data-holiday', h.id);
        html.style.setProperty('--accent', h.accent);
        html.style.setProperty('--accent-rgb', h.accentRgb);
      } else {
        html.removeAttribute('data-holiday');
        html.style.setProperty('--accent', BASE_COLORS.I || '#3ee0c6');
        html.style.setProperty('--accent-rgb', '62,224,198');
      }
    }
    setPalette(h ? h.colors : null);
    if (document.body) document.body.style.background = h ? h.bg : '';
    applied = h ? h.id : null;
    Bgm.follow(h);
    applySeasons();
    return applied;
  }

  /* ================= 四季底噪（默认关） =================
   * 只做两层：一层极淡的底色 + 一层粒子。方块材质、配色、BGM、图标一概不动，
   * 所以它不会抢画面，也不影响方块辨识度。
   * 换季点是春分 / 夏至 / 秋分 / 冬至（节气按上面同一套近似式算），一年换四次。
   */
  const SEASONS = [
    { id: 'spring', name: '春', en: 'Spring', tint: 'rgba(120,200,150,.055)', color: '255,182,205', kind: 'petal', count: 24, vy: 0.20, vx: 0.16, size: 3.4, spin: 0.7 },
    { id: 'summer', name: '夏', en: 'Summer', tint: 'rgba(90,170,220,.055)', color: '255,232,150', kind: 'glow', count: 20, vy: -0.10, vx: 0.05, size: 2.2, spin: 0 },
    { id: 'autumn', name: '秋', en: 'Autumn', tint: 'rgba(220,150,70,.06)', color: '240,170,90', kind: 'leaf', count: 22, vy: 0.28, vx: 0.26, size: 4.4, spin: 1.0 },
    { id: 'winter', name: '冬', en: 'Winter', tint: 'rgba(150,190,235,.065)', color: '235,245,255', kind: 'snow', count: 30, vy: 0.24, vx: 0.08, size: 2.4, spin: 0.25 }
  ];
  function seasonById(id) {
    for (let i = 0; i < SEASONS.length; i++) if (SEASONS[i].id === id) return SEASONS[i];
    return null;
  }
  /* 四个换季点（节气） */
  function seasonPoints(year) {
    return [
      { iso: year + '-03-' + p2(termDay(year, 20.646)), id: 'spring' },   // 春分
      { iso: year + '-06-' + p2(termDay(year, 21.37)), id: 'summer' },    // 夏至
      { iso: year + '-09-' + p2(termDay(year, 23.042)), id: 'autumn' },   // 秋分
      { iso: year + '-12-' + p2(termDay(year, 21.94)), id: 'winter' }     // 冬至
    ];
  }
  /* 某天属于哪个季节：取「最近一个已经过去的换季点」 */
  function seasonFor(iso) {
    const y = parseInt(String(iso).slice(0, 4), 10);
    if (!(y > 1900)) return null;
    const pts = seasonPoints(y - 1).concat(seasonPoints(y));
    let cur = null;
    for (let i = 0; i < pts.length; i++) {
      if (pts[i].iso <= iso) cur = pts[i].id; else break;
    }
    return seasonById(cur || 'winter');
  }

  /* ---------- 画面：一层底色 + 一层粒子（都在 #app 下面） ---------- */
  const LAYER = { tint: null, canvas: null, ctx: null, raf: 0, dots: [], cur: null, dpr: 1, w: 0, h: 0, last: 0 };
  function layerEls() {
    if (!document.body || typeof document.createElement !== 'function') return null;
    if (!LAYER.tint) {
      const d = document.createElement('div');
      d.id = 'seasonTint';
      d.setAttribute('aria-hidden', 'true');
      d.style.cssText = 'position:fixed;inset:0;z-index:1;pointer-events:none;display:none;transition:background .8s ease';
      document.body.appendChild(d);
      LAYER.tint = d;
    }
    if (!LAYER.canvas) {
      const c = document.createElement('canvas');
      c.id = 'seasonFx';
      c.setAttribute('aria-hidden', 'true');
      c.style.cssText = 'position:fixed;inset:0;z-index:1;pointer-events:none;display:none';
      document.body.appendChild(c);
      LAYER.canvas = c;
      LAYER.ctx = c.getContext('2d');
    }
    return LAYER;
  }
  function resizeLayer() {
    const L = layerEls();
    if (!L || !L.canvas) return;
    const dpr = Math.min(global.devicePixelRatio || 1, 2);
    L.dpr = dpr;
    L.w = global.innerWidth || 360;
    L.h = global.innerHeight || 640;
    L.canvas.width = Math.round(L.w * dpr);
    L.canvas.height = Math.round(L.h * dpr);
    L.canvas.style.width = L.w + 'px';
    L.canvas.style.height = L.h + 'px';
  }
  function seedDots(season) {
    const L = LAYER;
    L.dots = [];
    const n = season.count || 20;
    for (let i = 0; i < n; i++) {
      L.dots.push({
        x: Math.random() * L.w,
        y: Math.random() * L.h,
        r: (season.size || 3) * (0.6 + Math.random() * 0.8),
        a: 0.35 + Math.random() * 0.5,
        spin: (Math.random() * 2 - 1) * (season.spin || 0.4),
        t: Math.random() * Math.PI * 2,
        k: 0.7 + Math.random() * 0.6
      });
    }
  }
  function drawDots(dt) {
    const L = LAYER;
    const c = L.ctx, s = L.cur;
    if (!c || !s) return;
    c.setTransform(L.dpr, 0, 0, L.dpr, 0, 0);
    c.clearRect(0, 0, L.w, L.h);
    const step = Math.min(dt, 48);
    for (let i = 0; i < L.dots.length; i++) {
      const d = L.dots[i];
      d.y += s.vy * d.k * step * 0.06;
      d.x += Math.sin(d.t) * s.vx * step * 0.02;
      d.t += 0.012 * (s.spin || 0.3);
      if (d.y > L.h + 12) { d.y = -12; d.x = Math.random() * L.w; }
      if (d.y < -12) { d.y = L.h + 12; d.x = Math.random() * L.w; }
      c.globalAlpha = d.a * 0.9;
      if (s.kind === 'snow') {
        c.fillStyle = 'rgba(' + s.color + ',1)';
        c.beginPath(); c.arc(d.x, d.y, d.r * 0.5, 0, Math.PI * 2); c.fill();
      } else if (s.kind === 'leaf' || s.kind === 'petal') {
        c.save();
        c.translate(d.x, d.y);
        c.rotate(d.t);
        c.fillStyle = 'rgba(' + s.color + ',1)';
        c.beginPath();
        c.ellipse(0, 0, d.r, d.r * 0.55, 0, 0, Math.PI * 2);
        c.fill();
        c.restore();
      } else {
        c.fillStyle = 'rgba(' + s.color + ',1)';
        c.beginPath(); c.arc(d.x, d.y, d.r * 0.55, 0, Math.PI * 2); c.fill();
      }
    }
    c.globalAlpha = 1;
  }
  function tickLayer(ts) {
    LAYER.raf = 0;
    if (!LAYER.cur) return;
    const dt = LAYER.last ? (ts - LAYER.last) : 16;
    LAYER.last = ts;
    drawDots(dt);
    LAYER.raf = global.requestAnimationFrame(tickLayer);
  }
  function startLayer(season) {
    const L = layerEls();
    if (!L || !L.canvas) return;
    L.cur = season;
    L.tint.style.display = 'block';
    L.tint.style.background = 'radial-gradient(120% 80% at 50% 0%, ' + season.tint + ', transparent 60%)';
    L.canvas.style.display = 'block';
    resizeLayer();
    seedDots(season);
    if (!L.raf) { L.last = 0; L.raf = global.requestAnimationFrame(tickLayer); }
  }
  function stopLayer() {
    const L = LAYER;
    L.cur = null;
    if (L.raf) { try { global.cancelAnimationFrame(L.raf); } catch (e) {} L.raf = 0; }
    if (L.tint) L.tint.style.display = 'none';
    if (L.canvas) { L.canvas.style.display = 'none'; if (L.ctx) L.ctx.clearRect(0, 0, L.canvas.width, L.canvas.height); }
  }
  /* 开关 + 每天重算一次；帧率吃紧（低画质）时粒子减半 */
  function applySeasons() {
    if (!CFG.seasons) { stopLayer(); return null; }
    if (global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches) { stopLayer(); return null; }
    const s = seasonFor(today());
    if (!s) { stopLayer(); return null; }
    const L = layerEls();
    if (!L) return s;
    if (LAYER.cur !== s) startLayer(s);
    return s;
  }
  if (global.addEventListener) {
    global.addEventListener('resize', function () {
      if (!CFG.seasons || !LAYER.cur) return;
      resizeLayer();
      seedDots(LAYER.cur);
    });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) {
        if (LAYER.raf) { try { global.cancelAnimationFrame(LAYER.raf); } catch (e) {} LAYER.raf = 0; }
      } else if (CFG.seasons && LAYER.cur && !LAYER.raf) {
        LAYER.last = 0;
        LAYER.raf = global.requestAnimationFrame(tickLayer);
      }
    });
  }

  /* ================= 背景音乐 =================
   * 全部现场合成：一个振荡器加包络就是一件乐器，节拍器每 60ms 往前看 0.2 秒排音符。
   */
  const Bgm = (function () {
    let ctx = null, bus = null, gain = null;
    let timer = null, nextT = 0, beat = 0, playing = false;
    let spec = null, totalBeats = 0, bars = [];
    let noiseBuf = null;

    function ensure() {
      if (!global.Cues || typeof global.Cues.ensure !== 'function') return null;
      const c = global.Cues.ensure();
      if (!c) return null;
      if (c !== ctx) { ctx = c; bus = global.Cues.bus(); gain = null; }
      return ctx;
    }
    function musicGain() {
      if (gain || !ctx || !bus) return gain;
      gain = ctx.createGain();
      gain.gain.value = 0;
      gain.connect(bus);
      return gain;
    }
    function noise() {
      if (noiseBuf || !ctx) return noiseBuf;
      const len = Math.floor(ctx.sampleRate * 0.5);
      noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      return noiseBuf;
    }
    function midi(d) { return 440 * Math.pow(2, (d - 69) / 12); }
    function degreeToMidi(deg, root, scale, octShift) {
      const idx = (deg - 1) % scale.length;
      const oct = Math.floor((deg - 1) / scale.length);
      return root + scale[idx] + oct * 12 + (octShift || 0) * 12;
    }
    function toneAt(t, midiNote, dur, wave, peak, vib) {
      if (!ctx || !musicGain()) return;
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = wave || 'sine';
      o.frequency.setValueAtTime(midi(midiNote), t);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(peak, t + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      o.connect(g); g.connect(musicGain());
      if (vib > 0) {
        /* 颤音：一个 5Hz 的 LFO 推 detune，唢呐/箫的「人味」就来自这里 */
        const lfo = ctx.createOscillator(), lg = ctx.createGain();
        lfo.frequency.value = 5.2; lg.gain.value = vib * 1200;
        lfo.connect(lg); lg.connect(o.detune);
        lfo.start(t); lfo.stop(t + dur + 0.06);
      }
      o.start(t); o.stop(t + dur + 0.06);
    }
    /* 铃/铎：基音 + 一个不和谐的高分音，衰减快 */
    function bellAt(t, midiNote, dur, peak) {
      toneAt(t, midiNote, Math.min(dur, 2.2), 'sine', peak, 0);
      toneAt(t, midiNote + 17.5, Math.min(dur * 0.55, 0.8), 'sine', peak * 0.34, 0);
    }
    function noteAt(t, midiNote, dur, wave, peak, instName) {
      const prof = INST[instName] || INST.bell;
      if (prof.bell) { bellAt(t, midiNote, dur, peak); return; }
      toneAt(t, midiNote, dur, wave || prof.mel, peak, prof.vib);
    }
    /* 锣：噪声 + 低频，长长地散掉（春节/端午那一下） */
    function gong(t) {
      if (!ctx || !musicGain()) return;
      const s = ctx.createBufferSource(); s.buffer = noise();
      const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 900; f.Q.value = 0.8;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.5, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
      s.connect(f); f.connect(g); g.connect(musicGain());
      s.start(t); s.stop(t + 1.2);
      toneAt(t, 45, 1.0, 'sine', 0.22, 0);
    }
    function kick(t) {
      if (!ctx) return;
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sine';
      o.frequency.setValueAtTime(150, t);
      o.frequency.exponentialRampToValueAtTime(46, t + 0.14);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.5, t + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
      o.connect(g); g.connect(musicGain());
      o.start(t); o.stop(t + 0.24);
    }
    function wood(t) {
      if (!ctx) return;
      const s = ctx.createBufferSource();
      s.buffer = noise();
      const f = ctx.createBiquadFilter();
      f.type = 'bandpass'; f.frequency.value = 1750; f.Q.value = 1.6;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.26, t + 0.004);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.09);
      s.connect(f); f.connect(g); g.connect(musicGain());
      s.start(t); s.stop(t + 0.12);
    }
    function parseLines(lines) {
      const out = [];
      lines.forEach(function (bar) {
        String(bar).trim().split(/\s+/).forEach(function (tk) { if (tk) out.push(tk); });
      });
      return out;
    }
    function setSpec(s) {
      const same = (spec && s && spec.id === s.id) || (!spec && !s);
      spec = s ? Object.assign({ id: s.id || 'x' }, s) : null;
      if (spec) {
        bars = parseLines(spec.mel || []);
        totalBeats = bars.length || 32;
        spec._bass = parseLines(spec.bass || []);
        spec._perc = parseLines(spec.perc || []);
      }
      if (!same) { const was = playing; stop(); if (was) play(); }
    }
    function schedule() {
      if (!ctx || !spec || !playing) return;
      if (ctx.state !== 'running') return;
      const spb = 60 / spec.bpm;
      while (nextT < ctx.currentTime + 0.2) {
        const i = beat % totalBeats;
        const tk = bars[i];
        if (tk && tk !== '-' && tk !== '.') {
          const deg = parseInt(tk, 10);
          if (deg >= 1 && deg <= 10) {
            let hold = 1;
            for (let k = 1; k < totalBeats; k++) {
              const nx = bars[(i + k) % totalBeats];
              if (nx === '-') hold++; else break;
            }
            noteAt(nextT, degreeToMidi(deg, spec.root, spec.scale), hold * spb * 0.92, spec.wave, spec.gain, spec.inst);
          }
        }
        if (spec._bass.length) {
          const bt = spec._bass[i % spec._bass.length];
          if (bt && bt !== '-' && bt !== '.') {
            const bd = parseInt(bt, 10);
            if (bd >= 1 && bd <= 10) {
              noteAt(nextT, degreeToMidi(bd, spec.root - 24, spec.scale), spb * 0.95, spec.bassWave || 'sine', (spec.gain || 0.06) * 1.25, 'flute');
            }
          }
        }
        if (spec._perc.length) {
          const pt = spec._perc[i % spec._perc.length];
          if (pt === 'k') kick(nextT);
          else if (pt === 's') wood(nextT);
        }
        nextT += spb;
        beat = (beat + 1) % totalBeats;
      }
    }
    function play() {
      if (playing || !CFG.bgm || !spec) return;
      if (!ensure() || !musicGain()) return;
      playing = true;
      beat = 0;
      nextT = ctx.currentTime + 0.08;
      const g = musicGain();
      const now = ctx.currentTime;
      try {
        g.gain.cancelScheduledValues(now);
        g.gain.setValueAtTime(0.0001, now);
        g.gain.exponentialRampToValueAtTime(1, now + 1.4);
      } catch (e) {}
      timer = setInterval(schedule, 60);
      schedule();
    }
    function stop() {
      playing = false;
      if (timer) { clearInterval(timer); timer = null; }
      if (ctx && gain) {
        try {
          const now = ctx.currentTime;
          gain.gain.cancelScheduledValues(now);
          gain.gain.setValueAtTime(gain.gain.value || 0.0001, now);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.5);
        } catch (e) {}
      }
    }
    return {
      follow: function (h) {
        setSpec(h ? Object.assign({ id: h.id }, h.music) : null);
        if (h && CFG.bgm) play(); else stop();
      },
      play: play,
      stop: stop,
      playing: function () { return playing; },
      enabled: function () { return !!CFG.bgm; },
      setEnabled: function (v) {
        CFG.bgm = !!v; saveCfg();
        if (CFG.bgm) play(); else stop();
      },
      kick: function () { if (CFG.bgm && spec && !playing) play(); },
      state: function () {
        return {
          playing: playing, enabled: !!CFG.bgm, spec: spec && spec.id ? spec.id : null,
          ctx: ctx ? ctx.state : 'none', gain: gain ? gain.gain.value : 0
        };
      }
    };
  })();

  /* ---------------- 节日音效（在原有音效上叠一层，平时完全不响） ---------------- */
  let cueWrapped = false;
  function wrapCue() {
    const cues = global.Cues;
    if (cueWrapped || !cues || typeof cues.cue !== 'function') return;
    cueWrapped = true;
    const orig = cues.cue;
    cues.cue = function (name, data) {
      try { orig.call(cues, name, data); } catch (e) { return; }
      try { extra(name); } catch (e) {}
    };
  }
  function extra(name) {
    const h = active();
    if (!h || !CFG.bgm) return;
    const c = global.Cues && global.Cues.ctx && global.Cues.ctx();
    const bus = global.Cues && global.Cues.bus && global.Cues.bus();
    if (!c || !bus || c.state !== 'running') return;
    const t = c.currentTime + 0.02;
    const root = h.music.root;
    const sc = h.music.scale;
    const deg = function (d) { return root + sc[(d - 1) % sc.length] + 12 * Math.floor((d - 1) / sc.length); };
    const tone = function (f, dur, wave, peak, when) {
      const o = c.createOscillator(), g = c.createGain();
      o.type = wave; o.frequency.setValueAtTime(f, when || t);
      g.gain.setValueAtTime(0.0001, when || t);
      g.gain.exponentialRampToValueAtTime(peak, (when || t) + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, (when || t) + dur);
      o.connect(g); g.connect(bus);
      o.start(when || t); o.stop((when || t) + dur + 0.05);
    };
    const prof = INST[h.music.inst] || INST.bell;
    const f = function (d) { return 440 * Math.pow(2, (deg(d) - 69) / 12); };
    if (name === 'lineClear') {
      /* 消行：按配器给不同的「好」——铃是两声清响，鼓是闷鼓点，唢呐/铜管是短促上行 */
      if (prof.bell) {
        tone(f(6), 0.6, 'sine', 0.05); tone(f(6) * 2.76, 0.3, 'sine', 0.018);
        tone(f(8), 0.5, 'sine', 0.035, t + 0.08); tone(f(8) * 2.76, 0.24, 'sine', 0.012, t + 0.08);
      } else if (prof.gong) {
        tone(f(5), 0.16, 'triangle', 0.05); tone(f(8), 0.12, 'triangle', 0.03, t + 0.05);
        tone(f(10), 0.1, 'triangle', 0.022, t + 0.11);
      } else if (prof.bright) {
        tone(f(5), 0.3, 'sawtooth', 0.03); tone(f(8), 0.26, 'sawtooth', 0.022, t + 0.06);
      } else {
        tone(f(6), 0.5, 'sine', 0.04); tone(f(8), 0.44, 'sine', 0.028, t + 0.07);
      }
    } else if (name === 'topOut' || name === 'gameOver') {
      if (prof.gong) { tone(f(1) / 2, 1.2, 'sine', 0.11); tone(f(2) / 2, 0.9, 'triangle', 0.05, t + 0.05); }
      else if (prof.bell) { tone(f(2), 1.4, 'sine', 0.06); tone(f(2) * 2.76, 0.7, 'sine', 0.02); }
      else tone(440 * Math.pow(2, ((root - 24) - 69) / 12), 1.1, 'sine', 0.09);
    } else if (name === 'rotate') {
      if (prof.bell) tone(1568, 0.09, 'sine', 0.02);
      else if (prof.gong) tone(320, 0.08, 'triangle', 0.03);
      else tone(1400, 0.06, 'sine', 0.02);
    }
  }

  /* ---------------- 对外 ---------------- */
  const THEME = {
    list: function () {
      return HOLIDAYS.map(function (h) { return { id: h.id, name: h.name, en: h.en }; });
    },
    active: active,
    id: function () { const h = active(); return h ? h.id : ''; },
    apply: apply,
    today: today,
    /* 过场动画用：把节日祝福塞进去（没有节日就原样返回） */
    decorate: function (text) {
      const h = active();
      if (!h) return text;
      const g = THEME.greeting('');
      return g ? (g + ' · ' + text) : text;
    },
    /* 过场动画用的强调色（没有节日就是原来那个青） */
    accent: function () {
      const h = active();
      return h ? h.accent : (BASE_COLORS.I || '#3ee0c6');
    },
    greeting: function (fallback) {
      const h = active();
      if (!h) return fallback || '';
      const en = global.TetrisI18n && typeof global.TetrisI18n.lang === 'function' && global.TetrisI18n.lang() === 'en';
      return en ? (h.greetEn || h.greet) : h.greet;
    },
    skinOverride: function () {
      const h = active();
      return h ? h.skin : '';
    },
    /* 只有「跟随日期 / 关闭」两种。以前还能指定某个节日试穿，
       哥 2026-11-25 说节日包不许在平时出现，那个入口已经砍了。 */
    mode: function (v) {
      if (v === undefined) return CFG.mode;
      CFG.mode = (v === 'off') ? 'off' : 'auto';
      saveCfg();
      return apply();
    },
    bgm: Bgm,
    /* 四季底噪：默认关，和节日无关，一年四次换季 */
    seasons: {
      enabled: function () { return !!CFG.seasons; },
      current: function () { return CFG.seasons ? seasonFor(today()) : null; },
      list: function () { return SEASONS.map(function (s) { return { id: s.id, name: s.name, en: s.en }; }); },
      set: function (v) {
        CFG.seasons = !!v;
        saveCfg();
        applySeasons();
        return CFG.seasons;
      }
    },
    __seasonFor: function (iso) { const s = seasonFor(iso); return s ? s.id : ''; },
    kick: function () { Bgm.kick(); },
    /* 测试用：假装今天是哪天（传空串恢复正常） */
    __setToday: function (s) { overrideDay = s || ''; return apply(); },
    /* 测试用：假装某天是某个节日（界面里没有任何入口） */
    __preview: function (id) {
      const h = id ? holidayById(id) : null;
      overrideDay = '';
      curHoliday = h;
      if (!h) return apply();
      const html = document.documentElement;
      if (html) {
        html.setAttribute('data-holiday', h.id);
        html.style.setProperty('--accent', h.accent);
        html.style.setProperty('--accent-rgb', h.accentRgb);
      }
      setPalette(h.colors);
      if (document.body) document.body.style.background = h.bg;
      applied = h.id;
      Bgm.follow(h);
      return applied;
    },
    __clock: function () {
      const ms = netNow();
      return {
        local: new Date(localNow()).toISOString(),
        net: new Date(ms).toISOString(),
        bjDate: bjIso(ms),
        skewMs: skew,
        skewAgeMs: skewAt ? (localNow() - skewAt) : -1,
        builtAt: builtAtMs() ? new Date(builtAtMs()).toISOString() : '',
        trusted: clockTrusted(ms)
      };
    },
    calibrate: calibrate,
    /* 测试用：拿某个节日的配器/谱子，检查数据齐全（真出声还得上真机听） */
    __music: function (id) {
      const h = holidayById(id || (active() && active().id) || 'spring');
      if (!h) return null;
      return { inst: h.music.inst, bpm: h.music.bpm, mel: h.music.mel.length, bass: h.music.bass.length, perc: h.music.perc.length, scale: h.music.scale.length };
    },
    __status: function () {
      const ids = Object.keys(LUNAR);
      return {
        today: today(), mode: CFG.mode, active: THEME.id(), applied: applied,
        bgm: Bgm.state(), count: HOLIDAYS.length,
        firstYear: ids[0], lastYear: ids[ids.length - 1]
      };
    }
  };

  global.TetrisTheme = THEME;

  /* ---------------- 启动顺序 ---------------- */
  apply();
  wrapCue();
  /* 启动后顺手校一次时间（读得到响应头就用，读不到就算了），之后每小时再看一眼 */
  setTimeout(calibrate, 3000);
  setInterval(calibrate, 60 * 60 * 1000);
  let kicked = false;
  const kickOnce = function () {
    if (kicked) return;
    kicked = true;
    try { THEME.kick(); } catch (e) {}
  };
  document.addEventListener('pointerdown', kickOnce, { passive: true });
  document.addEventListener('touchstart', kickOnce, { passive: true });
  document.addEventListener('keydown', kickOnce, { passive: true });

  /* ---------------- 节日过完自动换回默认 ----------------
   * 应用常驻后台好几天很正常，所以不能只在启动时判断一次：每分钟对一次日期，
   * 跨过零点就重算；从后台切回来也立刻重算。换的时候发 tetris-theme 事件。
   */
  let lastDay = today();
  function recheck() {
    const d = today();
    lastDay = d;
    const before = applied;
    apply();
    if (applied !== before) {
      try {
        document.dispatchEvent(new CustomEvent('tetris-theme', { detail: { id: applied } }));
      } catch (e) {}
    }
    return applied !== before;
  }
  setInterval(recheck, 60 * 1000);
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) recheck();
  });
  THEME.recheck = recheck;
  THEME.lastDay = function () { return lastDay; };
})(window);
