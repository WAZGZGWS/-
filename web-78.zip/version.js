/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '0.9.18',
  code: 46,
  web: 78,
  date: '2026-11-15',
  title: '移除震动',
  titleEn: 'Vibration removed',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单/普通/困难。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard."
    }
  ],
  log: [
    {
      "v": "0.9.18",
      "date": "2026-11-15",
      "title": "移除震动",
      "summary": "震动收益太低：去掉设置里的震动开关、VIBRATE 权限和所有 haptic 调用；声音设置收成「声音」。",
      "added": [],
      "changed": [
        "设置「声音与震动」改名「声音」，只留音效开关和音量",
        "开局摘要只显示音效；所有按钮和事件不再触发震动"
      ],
      "balance": [],
      "removed": [
        "VIBRATE 权限、TetrisHost.vibrate、navigator.vibrate 调用",
        "设置里的震动开关"
      ]
    },
    {
      "v": "0.9.17",
      "date": "2026-11-15",
      "title": "导入导出与震动",
      "summary": "存档导入/导出在 Android 上修好：导出写到下载目录，导入走系统文件选择；震动改走系统 Vibrator，并补 VIBRATE 权限。",
      "added": [
        "更多 → 导入存档：调系统文件选择，读 JSON 后覆盖对应模式的自动存档",
        "导出当前存档直接写到系统 Downloads（Android 10+）",
        "TetrisHost.vibrate() + VIBRATE 权限；WebView 不支持时回退 navigator.vibrate"
      ],
      "changed": [
        "不再依赖 WebView 的 blob 下载（旧版会静默失败）",
        "导入前若该模式已有自动存档，会先弹确认再覆盖"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.16",
      "date": "2026-11-15",
      "title": "正式签名",
      "summary": "APK 从 debug 签名换成 release 签名；以后所有安装包用同一把密钥，才能覆盖更新并保留存档。",
      "added": [
        "release.keystore，固定别名 fusiondebt，证书 CN=Fusion Debt",
        "构建脚本改用 release 签名，密码只从本机加密文件或环境变量读取"
      ],
      "changed": [
        "APK 证书从 CN=Android Debug 换成 CN=Fusion Debt",
        "首次安装 release 包需要卸载旧 debug 包；本机已先备份并恢复 localStorage 存档"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.15",
      "date": "2026-11-15",
      "title": "暂停只留时间和存档",
      "summary": "暂停卡片去掉分辨率 / 刷新率 / FPS 说明和材质选择，只保留时间、存档槽、继续 / 重开 / 退出。",
      "added": [],
      "changed": [
        "暂停界面不再显示屏幕分辨率、刷新率、帧率上限和“每块落地自动存档”长句",
        "暂停界面不再放方块材质切换；材质仍可在设置里改"
      ],
      "balance": [],
      "removed": [
        "暂停卡片的设备摘要和材质选择"
      ]
    },
    {
      "v": "0.9.14",
      "date": "2026-11-15",
      "title": "玩法子页改右侧",
      "summary": "玩法列表保持不动，子页和存档从右侧抽屉展示；点表头有存档打开右侧，没存档直接开局，箭头可开可关。",
      "added": [
        "玩法子页改为右侧滑出，列表不再被撑开"
      ],
      "changed": [
        "模式选择 / 继续 / 多人面板整体移到右侧抽屉，关闭后自动归位"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.13",
      "date": "2026-11-15",
      "title": "玩法抽屉",
      "summary": "玩法页改成抽屉：点玩法有存档就展开、没存档直接开局；右侧箭头可独立拉开/收回。",
      "added": [
        "玩法行右侧加箭头，可像抽屉一样展开 / 收回",
        "有存档时点玩法名展开子页；没有存档直接开局"
      ],
      "changed": [
        "原来的右侧大抽屉改成玩法列表内联展开，主玩法 / 常驻 / AI / 多人都在原位",
        "多人面板收进“多人对战”抽屉里；主玩法优先高亮"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.12",
      "date": "2026-11-15",
      "title": "存档收进模式子页",
      "summary": "玩法页只留主玩法 / 常驻 / AI / 多人；各模式的“继续”挪进对应子页，和模式选择放在一起。",
      "added": [
        "主玩法子页：合体债、经典各自的“继续”按钮，带分数",
        "常驻子页：常驻、禅各自的“继续”按钮，禅额外显示剩余时间"
      ],
      "changed": [
        "玩法页不再被 4 个“继续”占掉一半高度；没有存档时子页不显示继续按钮",
        "“继续”仍读各模式自己的自动存档，和存档管理页一致"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.11",
      "date": "2026-11-15",
      "title": "英文提示条",
      "summary": "游戏右上角的提示条（转场、危险、消行、债清、方向块、结算）和联机状态都改成英文；顺手修正奖励期 50→18 的旧文案。",
      "added": [],
      "changed": [
        "cues.js 的事件提示按语言输出：Rotating / Debt 80% / 2 lines / Debt paid / Arrow blocks / Debt unpaid 等",
        "net.js 的联机状态（连接房主、等待对手、断线重连、蓝牙状态）和错误信息支持英文",
        "「债清了」提示里的奖励期从旧的 50 次改为实际的 18 次"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.10",
      "date": "2026-11-15",
      "title": "英文画布排版",
      "summary": "教程画布和结算页的英文标注不再顶边或重叠：缩短箭头/消行标签，重排 Debt、分数和重开提示。",
      "added": [],
      "changed": [
        "教程第 1 页「Clear a row →」、第 6 页箭头标签缩短，不再被画布右边缘裁掉",
        "教程第 8 页的 Debt 与分数/重开提示错开，不再叠字",
        "结算页英文改为顶部大 DEBT + 分数/带走/重开三行；右下提示改为「Tap Debt 5× to clear debt」"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.9",
      "date": "2026-11-15",
      "title": "英文细节修正",
      "summary": "英文首页不再把「合体债」翻成 Debt；修正规则条数、单复数和暂停时钟；首次引导改为只弹一次。",
      "added": [
        "首次引导改为整个安装只弹一次（不再每个网页包都弹）"
      ],
      "changed": [
        "英文首页品牌名固定为「合体债」，不再被翻译成 Debt",
        "暂停时钟跟随系统 12/24 小时制；英文单复数修正（1 line / 1 pt）",
        "更新记录里玩法说明的条数从 15 改为 13"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.8",
      "date": "2026-11-15",
      "title": "英文名 FUSION DEBT",
      "summary": "去掉首页的 TETRIS 字样，英文品牌改为 FUSION DEBT；中文名、包名、存档和更新路径都不变。",
      "added": [
        "英文副标 FUSION DEBT（替换 TETRIS · DEBT）"
      ],
      "changed": [
        "版本页与 README 的英文名同步；中文名仍为「合体债」"
      ],
      "balance": [],
      "removed": [
        "首页 logo 的 TETRIS 字样（避免商标风险）"
      ]
    },
    {
      "v": "0.9.7",
      "date": "2026-11-15",
      "title": "更新记录英文版",
      "summary": "英文模式补齐全部 33 个版本的更新记录：标题、摘要、新增/调整/平衡/删除逐条翻译，版本页不再中英混排。",
      "added": [
        "全部 33 个版本的更新记录英文版（含本版）",
        "版本页分节标题（新增 / 优化 / 平衡 / 删除）和「详细」也走英文"
      ],
      "changed": [
        "英文模式下版本页整页英文；中文模式的历史记录保持原样"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "0.9.6",
      "date": "2026-11-15",
      "title": "教程 / 帮助英文版",
      "titleEn": "Tutorial & help in English",
      "summary": "英文模式补齐 8 页教程、整套玩法说明，以及模式选择 / 存档 / 联机 / 蓝牙弹层；英文下分数用 k / M。",
      "summaryEn": "English mode now covers the 8-page tutorial, the full How to Play page and the mode / save / LAN / Bluetooth sheets; scores use k / M.",
      "added": [
        "新手教程 8 页英文版：标题、正文、画布标注、按钮全部英文",
        "玩法说明整页英文版（13 条规则），和中文版同样的结构",
        "模式选择、AI、存档管理、联机、蓝牙、更新提示等弹层和 toast 英文文案"
      ],
      "addedEn": [
        "All 8 tutorial pages in English: titles, body, canvas labels and buttons",
        "The whole How to Play page in English (13 rules), same structure as Chinese",
        "Mode pickers, AI, saves, LAN, Bluetooth and update dialogs/toasts in English"
      ],
      "changed": [
        "英文模式分数改用 k / M 缩写（10k / 12k），中文仍用万 / 亿",
        "英文模式下设置里“语言”说明改为“英文已覆盖菜单、设置、游戏、教程与帮助”",
        "弹层和动态文案不再等 MutationObserver，改为生成时就翻译，避免闪一行中文"
      ],
      "changedEn": [
        "English scores use k / M (10k / 12k); Chinese keeps its ten-thousand / hundred-million units",
        "The language description now says English covers menus, settings, gameplay, tutorial and help",
        "Sheets and dynamic text are translated as they are built instead of waiting for the observer"
      ],
      "removed": []
    },
    {
      "v": "0.9.5",
      "date": "2026-11-15",
      "title": "英文预览 · 跟随系统",
      "summary": "设置加语言：简体中文 / English / 跟随系统；英文先覆盖菜单、设置、游戏 HUD、暂停/结算。",
      "added": [
        "语言选项：简体中文、English、跟随系统（系统非中文时自动用英文）",
        "英文菜单/设置/模式提示/游戏 HUD/暂停/结算/更新提示"
      ],
      "changed": [
        "教程、玩法说明、旧版本更新记录暂时保留中文，下一轮再翻"
      ],
      "removed": []
    },
    {
      "v": "0.9.4",
      "date": "2026-11-15",
      "title": "债务重组",
      "summary": "连续 3 局结束时还没还清，下一局欠款减半；还清或没欠款会清零计数。",
      "added": [
        "债务重组：连续 3 局没还清，欠款减半（向下取整），并提示「连续 3 局没还清，债务重组」"
      ],
      "changed": [
        "经典、常驻、禅模式结束不再清掉合体债的旧欠款；只有合体债结算才处理债务"
      ],
      "removed": []
    },
    {
      "v": "0.9.3",
      "date": "2026-11-15",
      "title": "开场可关 · 分模式提示",
      "summary": "设置可关开场动画或只看第一次，开场加「点一下跳过」；经典/常驻/禅/AI/观战第一次进各有玩法提示。",
      "added": [
        "开场动画设置：每次 / 只看第一次 / 关闭；模式开场角落有「点一下跳过」",
        "首次进入经典、常驻、禅、AI、观战各弹一页关键规则（联机决斗开场不受影响）"
      ],
      "changed": [
        "只看第一次按每次启动算：重启后第一段单机开场仍会放一次"
      ],
      "removed": []
    },
    {
      "v": "0.9.2",
      "date": "2026-11-15",
      "title": "材质精简 · 时钟进暂停",
      "summary": "方块材质改为原味/极简/现代/像素/霓虹，旧玻璃/哑光自动映射；时间显示从顶栏移到暂停界面。",
      "added": [
        "极简：纯色平板、细亮边、无高光",
        "现代：不透明纵向渐变 + 内亮线，比玻璃更干净"
      ],
      "changed": [
        "原味保留原来的圆角 + 顶部高光；像素、霓虹继续保留",
        "所有模式不再在左上角显示时间，暂停卡片右上角显示系统时间（12/24 小时制 + 早中晚凌晨）"
      ],
      "removed": [
        "顶栏的时间显示",
        "玻璃和哑光两套旧材质（旧设置自动换成现代/极简）"
      ]
    },
    {
      "v": "0.9.1",
      "date": "2026-11-15",
      "title": "版本号即更新",
      "summary": "去掉版本页的「网页包 / 检查更新 / 设置更新地址」；点首页版本号直接检查并更新。",
      "added": [
        "首页版本号可点，点一下检查更新；有新版自动下载并重启"
      ],
      "changed": [
        "版本与更新页只留更新记录和玩法一览，不再显示网页包和更新按钮"
      ],
      "removed": [
        "版本页的「网页包」「检查更新」「设置更新地址」和地址输入框"
      ]
    },
    {
      "v": "0.9.0",
      "date": "2026-11-15",
      "title": "开场与材质",
      "summary": "各模式开场字、系统时钟与时段、五套方块材质、暂停换材质、版本页对齐；联机开场加粒子。",
      "added": [
        "各模式开场字：合体债「欠债还钱天经地义」、经典「经典永不过时」、AI「来！咱俩练练！」、AI 观战「不是你死就是他亡」；除经典外碎成粒子",
        "五套方块材质：实心/像素/玻璃/哑光/霓虹，设置里带预览，合体债/经典/常驻/禅/AI 对打/AI 小盘/NEXT 统一画法",
        "左上角系统时间：12/24 小时制跟随系统，前面标凌晨/早上/上午/中午/下午/晚上"
      ],
      "changed": [
        "联机开场「你 / 我」相撞碎成粒子，「决一死战」震动后坠落，随后棋盘浮现",
        "每次对局可选「自己选」固定一套，或「系统选」每局随机（避开上一局）",
        "暂停界面直接换方块材质，立即生效，不用退出对局",
        "版本与更新页统一卡片宽度和头部栅格，日期靠右、标题另起一行，长日志不再排歪"
      ],
      "removed": [
        "暂停界面的导出/导入按钮（存档管理页仍有）"
      ]
    },
    {
      "v": "0.8.1",
      "date": "2026-11-14",
      "title": "蓝牙修复",
      "summary": "蓝牙连接安全优先、不加密兜底；开房/加入的状态和失败原因直接显示在抽屉里。",
      "added": [
        "蓝牙房主/加入抽屉保留打开，实时显示「已开房/连接中/失败原因」",
        "连接失败会显示具体原因，不用只看一个没反应的按钮"
      ],
      "changed": [
        "安全连接优先，失败回退不加密，兼容更多手机的配对状态",
        "「玩法说明」补全：主玩法/常驻连击/禅模式/经典/AI/蓝牙/独立存档/分数写法",
        "AI 新增「自动」：按本机算力（核数/内存/GPU/刷新率/分辨率）选简单/普通/困难，抽屉里显示分数",
        "多人记住上次蓝牙对手和上次局域网房间，面板上出现一键继续",
        "联机就绪后先放双方握手动画，下面写「决斗开始」，再进棋盘",
        "握手改成像素风：两只手从左右冲进中间，带小火花和轻微回弹，不用刺眼闪白"
      ],
      "removed": []
    },
    {
      "v": "0.8.0",
      "date": "2026-11-14",
      "title": "蓝牙对打",
      "summary": "多人加蓝牙直连：两台安卓系统配对后，无网 1v1 并行/干扰。",
      "added": [
        "蓝牙经典 RFCOMM 直连，不需要 Wi-Fi/流量；房主/加入两种",
        "多人面板加「蓝牙对打」，列出已配对设备；权限/蓝牙开关有入口"
      ],
      "changed": [
        "蓝牙开局用本机倒计时，不依赖两边系统时钟一致"
      ],
      "removed": []
    },
    {
      "v": "0.7.9",
      "date": "2026-11-14",
      "title": "覆盖更新",
      "summary": "覆盖安装新 APK 不再丢存档；更新前提醒先存/导出；首页只显示版本号。",
      "added": [
        "APK 覆盖安装时自动把新自带的网页包同步到 files/web，不卸载、不清 localStorage",
        "更新前提示：先在「存档管理」保存/导出，覆盖安装一般保数据，但别赌"
      ],
      "changed": [
        "首页只显示版本号，更新内容去「版本与更新」看",
        "首次进首页弹 3 秒玩法引导，列出主玩法/常驻/禅/AI 入口"
      ],
      "removed": []
    },
    {
      "v": "0.7.8",
      "date": "2026-11-14",
      "title": "禅模式",
      "summary": "常驻抽屉加禅模式 5/10 分钟；堆满自动整理、不会死；可暂停并存剩余时间。",
      "added": [
        "系统死活不肯转屏时，页面把画面自己转 90°：选「横屏」一定横过来",
        "新增「横屏反向」：往另一边转，适合另一只手拿平板",
        "「自动旋转」增加重力兜底：系统方向锁着，只要把平板横过来画面也会跟着转",
        "遇到旧安装包会弹提示，并把新版 APK 下载地址复制到剪贴板，去浏览器粘贴就能装",
        "存档管理：单人玩法/经典玩法分开列，自动存档和槽位 1~3 可单独删除，清空全部保留二次确认",
        "更新检查带时间戳，绕开镜像/CDN 缓存，旧清单不会再把新补丁挡住"
      ],
      "changed": [
        "兜底转屏时菜单、游戏、弹层、提示一起转，不会只有一半是歪的",
        "横屏游戏布局改为按实际可用高度排，转出来的横屏也放得下",
        "「版本与更新」每个版本先给一句摘要，详细内容点开再看；返回键固定在顶部",
        "分数显示改成「1.2万」这种文字+数字，所有模式统一，不再 999+",
        "顶块改 2.5 秒倒计时：最后 0.9 秒顶部两行闪红，并预览下一块的洞位",
        "常驻块按欠款摆 1~4 行，债务封顶 800；HUD 显示「结束欠」实时投影",
        "方向块 4000 分才出、每 12 块 1 块，只清堆积不直接还债",
        "还清后奖励期 18 次；字母块第 40 次起变形，每 40 次进化一次",
        "横屏版本条目改为左对齐，不再被 space-between 推到两边",
        "提示音总线从 0.55×0.9 提高到 0.9×3.2，并加压缩器；蓝牙耳机不用开到最大也听得见",
        "设置新增音量「小 / 中 / 大」",
        "玩法页收成「主玩法 / 常驻 / AI / 多人」；主玩法侧边抽屉里再选合体债或经典",
        "新增常驻模式：10×10、不背债、不顶合体块，连续消行叠连击倍数，3 块没消才断",
        "AI 收进侧边抽屉：先选简单/普通/困难，再选与 AI 决斗或 AI 对打",
        "常驻也能独立存档：自动存档 + 槽位 1~3，和单人/经典分开",
        "存档管理增加「常驻玩法」分组，可单独删；主页面多一个「继续常驻」",
        "设置页也收成四个入口：游戏（帧率/转场）、屏幕方向、声音与震动、设备信息，点开右侧抽屉调",
        "常驻抽屉新增禅模式：5/10 分钟、10×12、堆满自动清底 4 行不会死；暂停/后台停表，自动存档带剩余时间",
        "禅模式最高分按 5/10 分钟分开存，存档管理多一个「禅模式」自动档"
      ],
      "removed": []
    },
    {
      "v": "0.7.7",
      "date": "2026-11-14",
      "title": "固定横屏",
      "added": [
        "屏幕方向新增「横屏」：直接请求固定横屏，不依赖系统自动旋转",
        "设置里显示「当前方向（请求 …）」，能看出系统到底有没有给横屏"
      ],
      "changed": [
        "自动旋转不生效时，改选「横屏」再试；旧安装包仍会红字提示"
      ],
      "removed": []
    },
    {
      "v": "0.7.6",
      "date": "2026-11-14",
      "title": "分清两个版本",
      "added": [
        "设置里显示「安装包（壳）」的版本号——网页包会自动更新，安装包不会",
        "旧安装包会红字提示：改屏幕方向要手动装一次最新 APK，并给出原因"
      ],
      "changed": [
        "「版本与更新」的版本号是网页包；看安装包去 设置 → 安装包（壳）"
      ],
      "removed": []
    },
    {
      "v": "0.7.5",
      "date": "2026-11-14",
      "title": "屏幕方向",
      "added": [
        "设置里新增「屏幕方向」：跟随系统 / 自动旋转 / 竖屏",
        "默认「自动旋转」：手机横过来就横屏，不受系统方向锁影响"
      ],
      "changed": [
        "旧版写死竖屏、系统转了也不动；现在由 APK 主动设置方向，并记住你的选择"
      ],
      "removed": []
    },
    {
      "v": "0.7.4",
      "date": "2026-11-14",
      "title": "AI 会算代价",
      "added": [],
      "changed": [
        "AI 把「每消一次会顶 2 行合体块」的代价算进评分：1~2 行消不再抢着消，3~4 行才值得"
      ],
      "balance": [
        "AI 观战双方仍然困难温度 1.0、0.5 秒一步，但现在会算合体块代价",
        "10 个种子实测：困难 AI 平均活 115 步、35 次消行，不再抢着消 1~2 行把自己顶死"
      ],
      "removed": []
    },
    {
      "v": "0.7.3",
      "date": "2026-11-14",
      "title": "AI 平衡",
      "added": [
        "更新包现在带更新说明，更新完首页提示会顺带显示这次改了什么"
      ],
      "changed": [
        "AI 观战双方改用困难温度（1.0）、每 0.5 秒一步，不再随机乱放等死"
      ],
      "balance": [
        "打 AI 思考温度：简单 0.3 / 普通 0.5 / 困难 1.0（越大越接近最优）",
        "打 AI 落子间隔：简单 2 秒 / 普通 3 秒 / 困难 5 秒一块",
        "AI 观战：双方困难温度 1.0、0.5 秒一步，会主动消行、压高度、避免顶部堆死"
      ],
      "removed": []
    },
    {
      "v": "0.7.2",
      "date": "2026-11-14",
      "title": "AI 温度",
      "added": [
        "AI 决斗加入思考温度：简单 0.3 / 普通 0.5 / 困难 1.0，数字越大越接近最优落点",
        "AI 落子间隔按难度改为 2 / 3 / 5 秒一块，不再抢在玩家前面把局打完",
        "AI 观战不再是纯随机：A 用普通温度 0.5、B 用困难温度 1.0，会主动消行和堆低"
      ],
      "changed": [
        "温度用 softmax 在合法「旋转×列」里按分数加权抽样，而不是只取最高分"
      ],
      "removed": []
    },
    {
      "v": "0.7.1",
      "date": "2026-11-14",
      "title": "AI 观战",
      "added": [
        "玩法页新增「AI 观战 · 随机对打」：两个随机 AI 自己下，玩累了可以解放双手看",
        "一局结束 3.5 秒自动开下一局，能一直挂着看",
        "观战画面显示两边棋盘、分数、消行、等级、债"
      ],
      "changed": [
        "随机 AI 每 0.6 秒落一步，只从合法旋转×列里随机挑，不是按分数挑"
      ],
      "removed": []
    },
    {
      "v": "0.7.0",
      "date": "2026-11-14",
      "title": "联机选规则",
      "added": [
        "多人对战多了「规则」选择：合体债 / 经典（10×20）",
        "房间会记住房主选的规则，加入的人自动按房主规则开局，不一致会提示",
        "经典规则联机只开并行赛——没有合体块，干扰战按钮会灰掉"
      ],
      "changed": [
        "联机比分里的「消行」按规则取数：经典用总消行，合体债还是消行次数",
        "电脑房主 server.mjs 和手机房主 NetServer.java 都会把 rules 存进房间、重连保持"
      ],
      "removed": []
    },
    {
      "v": "0.6.9",
      "date": "2026-11-14",
      "title": "两套存档",
      "added": [
        "原版模式也有自己的存档：自动存档 + 3 个槽，名字是「经典玩法1/2/3」",
        "合体债的存档改名「单人玩法1/2/3」；两套存档互相独立，不会覆盖",
        "玩法页有两个「继续」：继续单人玩法1 / 继续经典玩法1，各读各的",
        "最高分也分模式记录，原版的最高分不会盖掉合体债的"
      ],
      "changed": [
        "存档导入导出按当前模式命名（单人玩法-存档.json / 经典玩法-存档.json）",
        "存档里记录了模式、棋盘尺寸、等级和消行，10×10 和 10×20 都能读回"
      ],
      "removed": [
        "删除了「原版模式不写存档、不能导入导出」的限制"
      ]
    },
    {
      "v": "0.6.8",
      "date": "2026-11-14",
      "title": "原版模式",
      "added": [
        "玩法里新增「原版 · 经典玩法」：10×20 棋盘、标准计分（1/2/3/4 行 = 100/300/500/800 × 等级）",
        "每消 10 行升一级，下落速度随等级加快（1000ms → 最低 80ms）",
        "原版模式没有合体块、债、常驻块、场地旋转、方向块、字母块，就是纯经典俄罗斯方块"
      ],
      "changed": [
        "棋盘渲染按模式自适应：原版 16px 格子、10×20，合体债还是 32px、10×10",
        "原版模式不写自动存档和槽位，免得分不清两套棋盘"
      ],
      "removed": []
    },
    {
      "v": "0.6.7",
      "date": "2026-11-14",
      "title": "手机键位",
      "added": [
        "竖屏键位改成手机玩家最常用的两拇指布局：左手 ◀ ▶ / 软降，右手 转 / 硬降 / 暂存",
        "横屏时左右手各占一边、棋盘居中，两个拇指都够得到，不用跨半个屏幕",
        "「转」按钮加大（竖屏 64px、横屏整行），硬降和暂存放在下面一排"
      ],
      "changed": [
        "横屏不再把所有键塞到右边一列；棋盘两侧留出按键区，不会被手挡住"
      ],
      "removed": []
    },
    {
      "v": "0.6.6",
      "date": "2026-11-14",
      "title": "旋转可选 / 横屏",
      "added": [
        "设置里新增「场地自动旋转」开关，默认关闭——不会再莫名其妙转一下",
        "喜欢挑战的可以在设置里打开：每 15 秒顺时针 90°、落沙、1.5 秒预警",
        "横屏布局：棋盘在左，方向键和操作键在右，不再上下挤成一团",
        "菜单也做了横屏适配（按钮压扁、标题缩小），横着拿也能点",
        "APK 允许横竖屏切换，跟随系统自动旋转（想锁竖屏就在系统里锁）"
      ],
      "changed": [
        "关掉旋转后不再画转场预警圈，也不会突然转场",
        "教程和玩法说明里的转场改成「默认关闭，可开」"
      ],
      "removed": [
        "删除了「每 15 秒必定自动转场」的旧默认行为"
      ]
    },
    {
      "v": "0.6.5",
      "date": "2026-11-14",
      "title": "加入不再卡灰",
      "added": [
        "联机加入看门狗：20 秒没连上就自动停下、恢复按钮，不再一直灰着按不动",
        "联机请求单独限时 6 秒，超时直接提示「房主没响应」，不会无限等",
        "从房主同步超过 20 秒会中止并提示，可重新点「加入房间」"
      ],
      "changed": [
        "「加入房间」忙碌时显示「加入中…」，看得见在干什么",
        "按返回或退出多人面板会自动复位加入状态"
      ],
      "removed": [
        "删除了「加入按钮可能一直是灰的、只能杀进程」的旧行为"
      ]
    },
    {
      "v": "0.6.4",
      "date": "2026-11-14",
      "title": "联机版本闸门",
      "added": [
        "联机版本闸门：房主的网页包比你新时，加入前先自动同步房主那一版（含代码/规则改动）",
        "同步失败就不进房间，并提示「先更新再联机」——不会带着旧规则跟新版房主打",
        "联机面板会显示房主版本和你自己的版本（web 号），一眼看出差多少"
      ],
      "changed": [
        "房主比你旧时明确提醒「规则可能对不上，让房主先联网更新」，不再默默开局"
      ],
      "removed": []
    },
    {
      "v": "0.6.3",
      "date": "2026-11-14",
      "title": "静默更新",
      "added": [
        "静默自动更新：启动时自己查、自己下、自己校 sha256、自己重启，不用点任何按钮",
        "内置 GitHub 更新源（gh-proxy / ghproxy.net 镜像优先，raw 兜底），装一次以后不用再管",
        "更新源是公开仓库，以后改网页包不用再发安装包；仓库连不上时还能从房主手机同步",
        "更新完成后进游戏给一条提示：「已自动更新到 vX（网页包 N）」，15 秒后自己收",
        "首页底部小字显示「检查更新… / 已是最新版 / 更新检查失败」，平时不占地方"
      ],
      "changed": [
        "更新源按「国内能通的镜像 → raw」排序；平板实测 raw 被墙，镜像 2.5 秒能下",
        "检查更新失败不再弹提示，只在底部留一行字，照常玩",
        "「已是最新版」按本机版本显示，CDN 还缓存着旧清单时也不会显示成旧版本号",
        "「版本与更新」里的手动检查和填地址都保留，用来兜底/换源",
        "raw 有 CDN 缓存：刚发布完的几分钟内，先启动的玩家可能还拿到旧清单，下次启动就会更新"
      ],
      "removed": [
        "删除了「必须手动点一下才会更新」的旧行为",
        "删除了「改了游戏就得重新发安装包」的旧做法（只有动 Java 才需要）"
      ]
    },
    {
      "v": "0.6",
      "date": "2026-11-14",
      "title": "自动更新",
      "added": [
        "自动更新：启动后静默查更新包，下载、校验 sha256、装好再自动重启到新版",
        "局域网同步：加入房间前先问房主版本，房主比你新就从房主手机拉一份网页包，不用重装 APK",
        "手机房主的 8788 端口多了 /update.json 和 /update/bundle.zip，自己就是更新源",
        "「版本与更新」页显示当前网页包版本，带「检查更新」和「设置更新地址」",
        "更新后保留两版：新版起不来会自动退回上一版，再不行回 APK 自带版"
      ],
      "changed": [
        "网页包和 APK 分开发版本：小改动只换网页包（9 个文件），不换安装包",
        "页面从手机里的更新目录加载时仍是 file:// 协议，存档不丢",
        "加入房间会多一次 2.5 秒内的版本探测；房主没更新源就直接连，不卡"
      ],
      "removed": [
        "删除了「改了游戏就必须重新装 APK」的旧限制"
      ]
    },
    {
      "v": "0.5",
      "date": "2026-11-14",
      "title": "打 AI",
      "added": [
        "打 AI：简单 / 普通 / 困难三档",
        "AI 枚举「旋转 × 列」模拟落地，按 -0.51×高度 -0.36×洞 -0.18×高低差 +0.76×消行 打分，避开顶部两行",
        "AI 和玩家同一串种子；简单从前 4 个候选随机，普通取最优，困难取最优且落子更快",
        "AI 小棋盘、分数、消行、等级、债显示",
        "玩家死亡后按比分结算：你 vs AI"
      ],
      "changed": [
        "AI 模式不写单机自动存档、不继承常驻块和账",
        "AI 模式不能重开，返回菜单再开；AI 自己的场照样会顶块、转场、变形"
      ],
      "removed": [
        "删除了「打 AI 待做」标记"
      ]
    },
    {
      "v": "0.4",
      "date": "2026-11-14",
      "title": "局域网联机",
      "added": [
        "局域网并行赛：两个人各打各的，右上角只比分",
        "局域网干扰战：你消的行会变成对面场上的一块合体块",
        "多人面板拆成「和谁玩（手机玩家 / 电脑玩家）」×「开房 / 加入」四个组合",
        "手机玩家 · 开房：这台手机内置服务端，另一台手机加入",
        "手机玩家 · 加入：填另一台手机的地址和房间码",
        "电脑玩家 · 开房：这台手机开房，电脑浏览器打开 start.html 加入",
        "电脑玩家 · 加入：电脑跑 server.mjs，手机填电脑地址",
        "联机顶部比分条：你 / 对手分数、对手消行、对手死活",
        "开局 3 秒倒数，两台设备按服务端 startAt 同时开始",
        "结算：死的人分高也算赢；同分活着的人赢"
      ],
      "changed": [
        "APK 增加了 INTERNET / 网络状态权限，允许局域网明文 HTTP",
        "联机时不能暂停、不能重开（返回菜单再开）",
        "联机不写单机自动存档，不继承跨局常驻块和账",
        "干扰战里自己的消行不再顶自己的场，只往对面送"
      ],
      "removed": [
        "删除了「多人对战 待做」标记",
        "删除了旧版只有「房间码」、没有房主选择的联机面板",
        "删除了 v0.3 APK（dist 和平板 Download 只留 v0.4）"
      ]
    },
    {
      "v": "0.3",
      "date": "2026-11-14",
      "title": "新手教程 / 设备检测 / 帧率",
      "added": [
        "8 页新手教程：第一次点「单人」或「继续」自动弹，菜单和玩法说明里也能重看",
        "教程讲清「方块会自己掉」「15 秒转场不是重开」「R/重开要按两次」「两种死法」",
        "设备检测：屏幕分辨率、游戏窗口、屏幕刷新率，设置页显示实测值，可重新检测",
        "帧率设置：默认 60，可选 自动 / 30 / 60 / 90 / 120",
        "超过屏幕刷新率的帧率档位自动灰掉；存过的高档会降到屏幕能跑的档",
        "6 秒没有操作时提示「方块会自己往下掉」",
        "「版本与更新」页：当前版本号和每个版本的新增 / 优化 / 删除",
        "游戏顶栏显示版本号"
      ],
      "changed": [
        "R 键和暂停里的「重开」改成 3 秒内按两次才生效，第一次只提示",
        "游戏循环按帧率上限跳帧，游戏逻辑仍按真实时间走",
        "分辨率按物理屏幕取整显示（2560×1600，不再是 2561×1602）",
        "Android 壳关闭 WebView 缓存并在启动时清缓存，更新后不会加载旧页面",
        "Android 壳去掉全局 pauseTimers，锁屏时启动也能把页面完整加载出来",
        "暂停页显示屏幕 / 刷新率 / 当前帧率上限摘要",
        "版本号统一放到 version.js，首页、更多、关于、游戏顶栏都读同一份"
      ],
      "removed": [
        "删除了「按一次 R / 点一次重开就立刻重开」的旧行为（改成两次确认）",
        "删除了 Android 壳里的 pauseTimers / resumeTimers",
        "删除了 WebView 的默认缓存模式（改成 LOAD_NO_CACHE + 启动清缓存）",
        "删除了旧 v0.2 APK 和旧安装包（平板 Download 只留 v0.3）",
        "删除了遗留的「常驻块累积」死代码（S.perm / permSeg 绑定 / 弹层里那一行）"
      ]
    },
    {
      "v": "0.2",
      "date": "2026-11-13",
      "title": "游戏本体 / 安卓壳",
      "added": [
        "10×10 完整规则：七种块、7-bag、锁定 1 秒、15 秒转场落沙",
        "合体块、债、常驻块、50 次奖励期、第 100 次字母块",
        "1000 分后的方向块（只抹箭头那一侧）",
        "画布棋盘、信息栏、键盘和触屏按钮、暂停、3 个存档槽、导入导出",
        "Cues 双通道提示接入",
        "Android WebView 壳 APK（离线，无网络权限）"
      ],
      "changed": [
        "菜单键盘不再抢游戏按键",
        "「继续」按钮跟着自动存档实时刷新",
        "版本标签从 v0.1 界面原型改成 v0.2 游戏本体"
      ],
      "removed": [
        "删除了设置里的「常驻块累积」开关（关 / 只罚一局 / 累积）——SPEC 里常驻块规则是固定的，这个开关没实现，留着会误导"
      ]
    },
    {
      "v": "0.1",
      "date": "2026-11-13",
      "title": "界面原型",
      "added": [
        "主菜单、玩法页、更多、设置、玩法说明",
        "背景动画和第一版视觉"
      ],
      "changed": [
        "只有界面，没有游戏本体；点「单人」只会提示还没接进来"
      ],
      "removed": []
    }
  ],
  logEn: [
    {
      "title": "Vibration removed",
      "summary": "Vibration was not worth it: removed the setting, the VIBRATE permission and every haptic call; the audio group is now just “Sound”.",
      "added": [],
      "changed": [
        "Settings “Sound & Haptics” is now “Sound”, with the toggle and volume only",
        "The start summary shows sound only; buttons and events no longer vibrate"
      ],
      "balance": [],
      "removed": [
        "The VIBRATE permission, TetrisHost.vibrate and navigator.vibrate calls",
        "The vibration switch in Settings"
      ]
    },
    {
      "title": "Import, export and vibration",
      "summary": "Save import/export now work on Android: export writes to Downloads and import uses the system file picker; vibration goes through the system Vibrator with the VIBRATE permission.",
      "added": [
        "More → Import save: system file picker, parse JSON and replace that mode’s autosave",
        "Export current save writes straight to Downloads (Android 10+)",
        "TetrisHost.vibrate() plus the VIBRATE permission; falls back to navigator.vibrate"
      ],
      "changed": [
        "No longer relies on WebView blob downloads (which failed silently)",
        "Import asks for confirmation before replacing an existing autosave"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Release signing",
      "summary": "The APK is now signed with a release key instead of the debug key; every future build uses the same key so updates can install over the old app and keep saves.",
      "added": [
        "release.keystore with the fixed alias fusiondebt and certificate CN=Fusion Debt",
        "The build script signs with the release key; the password is read from a local encrypted file or an environment variable"
      ],
      "changed": [
        "The APK certificate changes from CN=Android Debug to CN=Fusion Debt",
        "The first release build requires uninstalling the old debug app; this device backed up and restored its localStorage saves"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Pause keeps only time and saves",
      "summary": "The pause card drops the resolution / refresh-rate / FPS note and the skin picker, leaving only the clock, save slots, Continue / Restart / Exit.",
      "added": [],
      "changed": [
        "Pause no longer shows screen resolution, refresh rate, FPS cap or the long autosave sentence",
        "Pause no longer switches block skins; skins remain in Settings"
      ],
      "balance": [],
      "removed": [
        "The device summary and skin picker from the pause card"
      ]
    },
    {
      "title": "Mode subpages slide from the right",
      "summary": "The mode list stays put; subpages and saves now slide in from the right. Tapping a mode opens it when a save exists, starts directly when not, and the arrow toggles it.",
      "added": [
        "Mode subpages slide in from the right; the list no longer grows"
      ],
      "changed": [
        "Mode choices / Continue / multiplayer panel move into the right sheet and return on close"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Mode drawers",
      "summary": "The play page is now drawer-style: tapping a mode expands it when a save exists, or starts it directly when there is none; the arrow on the right opens and closes it independently.",
      "added": [
        "An arrow on each mode row expands / collapses it like a drawer",
        "With a save, tapping the mode name opens the subpage; without one it starts immediately"
      ],
      "changed": [
        "The old right-side sheet is now an inline drawer under each mode (Main / Casual / AI / Multiplayer)",
        "The multiplayer panel lives inside the “Multiplayer” drawer; Main is highlighted by default"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Saves move into mode sheets",
      "summary": "The play page keeps only Main / Casual / AI / Multiplayer; each mode’s Continue button now lives in its own sheet next to the mode.",
      "added": [
        "Main sheet: Continue for Debt and Classic, with score",
        "Casual sheet: Continue for Casual and Zen, with the Zen time left"
      ],
      "changed": [
        "The play page is no longer half taken by four Continue rows; sheets hide Continue when there is no save",
        "Continue still reads each mode’s own autosave, matching the Saves page"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "English cue hints",
      "summary": "The top-right cue hints (rotation, danger, line clears, debt paid, arrow blocks, game over) and the multiplayer status lines are now English; also fixed the stale 50-clear grace note to 18.",
      "added": [],
      "changed": [
        "cues.js event hints follow the language: Rotating / Debt 80% / 2 lines / Debt paid / Arrow blocks / Debt unpaid, etc.",
        "net.js connection status and errors (connecting, waiting, reconnect, Bluetooth) support English",
        "The “Debt paid” hint now says 18 clears instead of the stale 50"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "English canvas layout",
      "summary": "English labels in the tutorial canvas and the game-over screen no longer clip or overlap: shorter arrow/clear labels, and a re-laid-out Debt / score / restart block.",
      "added": [],
      "changed": [
        "Tutorial page 1 “Clear a row →” and page 6 arrow labels shortened so they no longer clip at the canvas edge",
        "Page 8 Debt no longer overlaps the score and restart hints",
        "Game over uses a top DEBT headline with score / carry / restart lines; the bottom-right hint now says “Tap Debt 5× to clear debt”"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "English polish",
      "summary": "The English home logo no longer translates 合体债 to Debt; fixed the rule count, plurals and the pause clock; the first-run guide now shows once per install.",
      "added": [
        "The first-run guide now shows once per install instead of once per web bundle"
      ],
      "changed": [
        "The English logo stays 合体债 instead of being translated to Debt",
        "The pause clock follows the system 12/24-hour setting; English plurals fixed (1 line / 1 pt)",
        "The changelog now says 13 rules instead of 15"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "English name: FUSION DEBT",
      "summary": "The home logo no longer says TETRIS; the English brand is now FUSION DEBT. The Chinese name, package, saves and update path are unchanged.",
      "added": [
        "English subtitle FUSION DEBT (replacing TETRIS · DEBT)"
      ],
      "changed": [
        "Version page and README use the new English name; the Chinese name stays 合体债"
      ],
      "balance": [],
      "removed": [
        "The TETRIS word from the home logo (trademark risk)"
      ]
    },
    {
      "title": "Changelog in English",
      "summary": "English mode now translates all 33 release entries — titles, summaries and every added / changed / balance / removed line — so the version page is fully English.",
      "added": [
        "English changelog for all 33 releases (including this one)",
        "English section labels (Added / Changed / Balance / Removed) and “Details”"
      ],
      "changed": [
        "The version page is fully English in English mode; Chinese mode keeps the original entries"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Tutorial & help in English",
      "summary": "English mode now has all 8 tutorial pages, the full How to Play page and the mode / save / LAN / Bluetooth sheets; scores use k / M.",
      "added": [
        "All 8 tutorial pages in English: titles, body, canvas labels and buttons",
        "The full How to Play page in English (13 rules), same structure as Chinese",
        "English copy for mode pickers, AI, saves, LAN, Bluetooth and update dialogs/toasts"
      ],
      "changed": [
        "English scores use k / M (10k / 12k); Chinese keeps its ten-thousand / hundred-million units",
        "The language note now says English covers menus, settings, gameplay, tutorial and help",
        "Sheets and dynamic text are translated when built, not by the MutationObserver, so no flash of Chinese"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "English preview · Follow system",
      "summary": "Language setting added: Simplified Chinese / English / Follow system; English first covered menus, settings, game HUD, pause and results.",
      "added": [
        "Language options: Simplified Chinese, English, Follow system (non-Chinese systems default to English)",
        "English menus / settings / mode tips / game HUD / pause / results / update messages"
      ],
      "changed": [
        "Tutorial, How to Play and old changelog entries stayed Chinese for the next round"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Debt restructuring",
      "summary": "If debt is still unpaid after 3 games in a row, the next game's debt is halved; paying it off or carrying none resets the counter.",
      "added": [
        "Debt restructuring: after 3 unpaid games, debt is halved (rounded down) with a “3 unpaid games — debt restructured” toast"
      ],
      "changed": [
        "Classic, Casual and Zen no longer clear the old Debt carry; only Debt results handle debt"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Skippable intro · per-mode tips",
      "summary": "The intro can be turned off or shown only once, with “Tap to skip”; Classic / Casual / Zen / AI / Watch show a one-page rules tip the first time.",
      "added": [
        "Intro setting: every time / first only / off; a “Tap to skip” corner on mode intros",
        "First entry into Classic, Casual, Zen, AI and Watch shows a key-rules page (online duel intros unaffected)"
      ],
      "changed": [
        "“First only” counts per launch: the first solo intro still plays after a restart"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Fewer skins · clock into pause",
      "summary": "Block skins are now Original / Minimal / Modern / Pixel / Neon, with old Glass / Matte mapped automatically; the clock moved from the top bar into the pause screen.",
      "added": [
        "Minimal: flat solid color, thin light edge, no highlight",
        "Modern: opaque vertical gradient + inner light line, cleaner than Glass"
      ],
      "changed": [
        "Original keeps its rounded corners + top highlight; Pixel and Neon stay",
        "No mode shows the clock top-left anymore; the pause card shows system time top-right (12/24-hour + early morning / morning / noon / afternoon / evening)"
      ],
      "balance": [],
      "removed": [
        "The clock in the top bar",
        "The old Glass and Matte skins (old settings map to Modern / Minimal)"
      ]
    },
    {
      "title": "Tap the version to update",
      "summary": "Removed the web bundle / check update / update URL controls from the version page; tapping the home version number checks and updates.",
      "added": [
        "The home version number is tappable: one tap checks for updates, downloads and restarts"
      ],
      "changed": [
        "The Version & Updates page keeps only the changelog and mode list; no bundle info or update buttons"
      ],
      "balance": [],
      "removed": [
        "“Web bundle”, “Check update”, “Set update URL” and the URL field on the version page"
      ]
    },
    {
      "title": "Intros & skins",
      "summary": "Mode intro slogans, system clock and time-of-day, five block skins, skin switching in pause, aligned version page; particles in the online intro.",
      "added": [
        "Mode intros: Debt “Debts must be paid”, Classic “Classics never age”, AI “Let's spar!”, AI Watch “Only one survives”; all but Classic shatter into particles",
        "Five block skins: Solid / Pixel / Glass / Matte / Neon with previews, shared by Debt / Classic / Casual / Zen / AI duel / AI mini board / NEXT",
        "Top-left system clock: 12/24-hour follows the system, prefixed with early morning / morning / late morning / noon / afternoon / evening"
      ],
      "changed": [
        "Online intro: “You / Me” collide and shatter, “fight to the death” shakes and falls, then the board appears",
        "Each game can use “Manual” (fixed skin) or “Auto” (random per game, avoiding the last one)",
        "Switch skins right in the pause screen, effective immediately without leaving the game",
        "Version page cards share width and header grid; dates right-aligned, titles on their own line, long logs no longer skew"
      ],
      "balance": [],
      "removed": [
        "Export / import buttons in the pause screen (still available in Saves)"
      ]
    },
    {
      "title": "Bluetooth fixes",
      "summary": "Bluetooth prefers secure connections with an insecure fallback; host/join status and failure reasons show in the sheet.",
      "added": [
        "Bluetooth host/join sheets stay open and show “room open / connecting / failure reason” live",
        "Connection failures show the actual reason instead of a dead button"
      ],
      "changed": [
        "Secure connection first, insecure fallback, compatible with more pairing states",
        "How to Play updated: main / Casual combo / Zen / Classic / AI / Bluetooth / separate saves / score format",
        "AI “Auto”: picks Easy / Normal / Hard from device power (cores / RAM / GPU / refresh rate / resolution), score shown in the sheet",
        "Multiplayer remembers the last Bluetooth opponent and last LAN room, with one-tap continue",
        "After both sides are ready, a handshake animation plays with “Duel start”, then the board",
        "Handshake is pixel-art: two hands rush in from the sides with sparks and a slight bounce, no harsh white flash"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Bluetooth duel",
      "summary": "Direct Bluetooth multiplayer: pair two Android phones and play 1v1 parallel or battle with no network.",
      "added": [
        "Classic RFCOMM Bluetooth direct link, no Wi-Fi or data; host or join",
        "“Bluetooth duel” in the multiplayer panel lists paired devices; entries for permission and Bluetooth toggle"
      ],
      "changed": [
        "Bluetooth games use a local countdown instead of relying on both clocks"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Overwrite updates",
      "summary": "Installing a new APK over the old one no longer loses saves; a reminder to save/export before updating; home shows only the version number.",
      "added": [
        "On overwrite install the APK syncs its bundled web files to files/web without uninstalling or clearing localStorage",
        "Pre-update reminder: save/export from Saves first; overwrite usually keeps data, but do not gamble"
      ],
      "changed": [
        "Home shows only the version number; update notes live in Version & Updates",
        "First visit shows a 3-second guide listing Main / Casual / Zen / AI"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Zen mode",
      "summary": "The Casual sheet gains Zen at 5/10 minutes; a full board auto-tidies and cannot kill you; pause stops the clock and saves the remainder.",
      "added": [
        "If the system refuses to rotate, the page rotates itself 90°: picking Landscape always works",
        "“Landscape (reverse)” rotates the other way for the other hand",
        "“Auto rotate” gains a gravity fallback: even with system rotation locked, turning the tablet sideways rotates the view",
        "Old APKs get a prompt with the new APK link copied to the clipboard, ready to paste in a browser",
        "Saves: Solo / Classic listed separately, auto-save and slots 1–3 deletable individually, Clear all asks twice",
        "Update checks carry a timestamp to bypass mirror/CDN caches so old manifests cannot block new patches"
      ],
      "changed": [
        "Fallback rotation turns menus, game, sheets and hints together, not half the screen",
        "Landscape layout now fits the actual usable height, so rotated landscape fits too",
        "Version & Updates gives each version a one-line summary with details collapsed; the back button is pinned to the top",
        "Scores show text + number like “12k”, unified across modes, no more 999+",
        "Fusion block delay is a 2.5s countdown: the top two rows flash red for the last 0.9s and preview the next holes",
        "Permanent rows scale 1–4 with debt, debt caps at 800; HUD shows the live projected end debt",
        "Arrow blocks start at 4000 points, 1 in 12 pieces, clear stack only and do not pay debt directly",
        "After paying off, an 18-clear grace period; letter blocks morph from the 40th clear and evolve every 40",
        "Landscape version entries left-aligned instead of pushed apart by space-between",
        "Cue bus raised from 0.55×0.9 to 0.9×3.2 with a compressor; Bluetooth headphones no longer need max volume",
        "Volume setting added: Low / Medium / High",
        "Play page condensed to Main / Casual / AI / Multiplayer; Debt or Classic chosen in the Main sheet",
        "Casual mode added: 10×10, no debt or fusion, consecutive clears build a multiplier, broken after 3 non-clears",
        "AI moved into a sheet: pick Easy / Normal / Hard, then duel or watch",
        "Casual gets its own saves: auto + slots 1–3, separate from Solo / Classic",
        "Saves gain a Casual group, deletable separately; home gains “Continue Casual”",
        "Settings condensed into four entries: Game (FPS / rotation), Orientation, Sound & Haptics, Device, each opening a right-side sheet",
        "Zen added to the Casual sheet: 5/10 minutes, 10×12, a full board auto-clears 4 rows and cannot kill you; pause/background stops the clock, auto-save keeps the remainder",
        "Zen high scores stored separately for 5/10 minutes; Saves gains a Zen auto slot"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Fixed landscape",
      "summary": "",
      "added": [
        "Orientation gains “Landscape”: requests fixed landscape directly without relying on system auto-rotate",
        "Settings show “Current (requested …)” so you can see whether the system granted landscape"
      ],
      "changed": [
        "If auto-rotate does not work, choose Landscape; old APKs still show the red warning"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Two versions, clearly",
      "summary": "",
      "added": [
        "Settings show the APK (shell) version — the web bundle updates itself, the APK does not",
        "Old APKs get a red warning: changing orientation needs the latest APK, with the reason"
      ],
      "changed": [
        "The version in Version & Updates is the web bundle; see Settings → APK (shell) for the APK"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Orientation",
      "summary": "",
      "added": [
        "Settings gain “Orientation”: Follow system / Auto rotate / Portrait",
        "Default “Auto rotate”: turning the phone sideways gives landscape regardless of the system lock"
      ],
      "changed": [
        "Old builds were hard-locked to portrait and ignored system rotation; the APK now sets orientation and remembers your choice"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "AI counts the cost",
      "summary": "",
      "added": [],
      "changed": [
        "The AI factors in “each clear pushes up 2 fusion rows”: it no longer rushes 1–2 line clears, only 3–4 are worth it"
      ],
      "balance": [
        "AI Watch still uses hard temperature 1.0 at 0.5s per move, but now counts the fusion cost",
        "10 seeds measured: hard AI survives 115 moves and 35 clears on average, no longer killing itself with 1–2 line clears"
      ],
      "removed": []
    },
    {
      "title": "AI balance",
      "summary": "",
      "added": [
        "Update bundles now carry notes; after updating, the home hint mentions what changed"
      ],
      "changed": [
        "AI Watch uses hard temperature (1.0) at 0.5s per move instead of random placements"
      ],
      "balance": [
        "AI thinking temperature: Easy 0.3 / Normal 0.5 / Hard 1.0 (higher is closer to optimal)",
        "AI move interval: Easy 2s / Normal 3s / Hard 5s per piece",
        "AI Watch: both sides hard 1.0 at 0.5s per move, actively clearing lines and keeping the stack low"
      ],
      "removed": []
    },
    {
      "title": "AI temperature",
      "summary": "",
      "added": [
        "AI duel gains thinking temperature: Easy 0.3 / Normal 0.5 / Hard 1.0, higher is closer to optimal",
        "AI move intervals by difficulty: 2 / 3 / 5 seconds per piece, no longer finishing before the player",
        "AI Watch is no longer pure random: A uses normal 0.5, B uses hard 1.0, both clear lines and keep low"
      ],
      "changed": [
        "Temperature uses softmax over legal rotation × column placements weighted by score instead of always taking the best"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "AI Watch",
      "summary": "",
      "added": [
        "Play page gains “AI Watch · random match”: two random AIs play while you rest your hands",
        "The next round starts 3.5s after one ends, so it can run in the background",
        "The watch view shows both boards, scores, clears, levels and debt"
      ],
      "changed": [
        "Random AI drops every 0.6s, choosing randomly among legal rotation × column placements, not by score"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Online rules",
      "summary": "",
      "added": [
        "Multiplayer gains a “Rules” choice: Debt / Classic (10×20)",
        "Rooms remember the host's rules; joiners start with them and get a notice if they differ",
        "Classic online supports Parallel only — no fusion blocks, so Battle is greyed out"
      ],
      "changed": [
        "Online lines follow the rules: Classic uses total lines, Debt still uses clear count",
        "The PC host server.mjs and phone host NetServer.java both store rules in the room and keep them across reconnects"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Two save sets",
      "summary": "",
      "added": [
        "Classic gets its own saves: auto + 3 slots named “Classic 1/2/3”",
        "Debt saves rename to “Solo 1/2/3”; the two sets are independent and never overwrite each other",
        "Play page has two Continue buttons: Continue Solo 1 / Continue Classic 1, each reading its own save",
        "High scores are per mode, so Classic no longer overwrites Debt"
      ],
      "changed": [
        "Save export names follow the mode (solo-save.json / classic-save.json)",
        "Saves record mode, board size, level and lines; both 10×10 and 10×20 load back"
      ],
      "balance": [],
      "removed": [
        "The old limit that Classic had no saves and no import/export"
      ]
    },
    {
      "title": "Classic mode",
      "summary": "",
      "added": [
        "Play page gains “Original · Classic”: 10×20 board, standard scoring (1/2/3/4 lines = 100/300/500/800 × level)",
        "Level up every 10 lines, fall speed rises with level (1000ms → 80ms minimum)",
        "Classic has no fusion blocks, debt, permanent rows, field rotation, arrow or letter blocks — pure classic Tetris"
      ],
      "changed": [
        "Board rendering adapts by mode: Classic 16px cells at 10×20, Debt still 32px at 10×10",
        "Classic does not write auto-saves or slots to avoid mixing the two boards"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Phone controls",
      "summary": "",
      "added": [
        "Portrait controls use the usual two-thumb layout: left ◀ ▶ / soft drop, right rotate / hard drop / hold",
        "In landscape each hand takes a side with the board centered, both thumbs reach without crossing the screen",
        "The rotate button is bigger (64px portrait, full row landscape); hard drop and hold sit on the bottom row"
      ],
      "changed": [
        "Landscape no longer crams every key into a right column; key zones stay beside the board, clear of your hands"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Optional rotation / landscape",
      "summary": "",
      "added": [
        "Settings gain “Auto-rotate field”, off by default — no more random rotations",
        "Challenge seekers can enable it: 90° clockwise every 15s, sand fall, 1.5s warning",
        "Landscape layout: board left, direction and action keys right, no more vertical squeeze",
        "Menus adapt to landscape too (flatter buttons, smaller title), usable held sideways",
        "APK allows portrait/landscape switching and follows system auto-rotate (lock portrait in the system if wanted)"
      ],
      "changed": [
        "With rotation off, no warning ring and no sudden rotations",
        "Tutorial and How to Play describe rotation as “off by default, can be enabled”"
      ],
      "balance": [],
      "removed": [
        "The old “always rotate every 15s” default"
      ]
    },
    {
      "title": "Join no longer stuck grey",
      "summary": "",
      "added": [
        "Join watchdog: if not connected in 20s it stops and re-enables the button instead of staying grey",
        "Join requests time out after 6s with “host did not respond”, no infinite wait",
        "Host sync aborts after 20s with a notice; tap Join room again"
      ],
      "changed": [
        "While joining, the button shows “Joining…” so you can see it working",
        "Backing out or leaving the multiplayer panel resets the join state"
      ],
      "balance": [],
      "removed": [
        "The old “join button stays grey until you kill the app” behaviour"
      ]
    },
    {
      "title": "Online version gate",
      "summary": "",
      "added": [
        "Online version gate: if the host's web bundle is newer, sync it before joining (code and rules included)",
        "If sync fails you do not enter the room, with “update before playing online” — no old rules against a new host",
        "The multiplayer panel shows the host version and yours (web number) so the gap is obvious"
      ],
      "changed": [
        "If the host is older, warn that rules may differ and ask them to update, instead of silently starting"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Silent updates",
      "summary": "",
      "added": [
        "Silent auto-update: on launch it checks, downloads, verifies sha256 and restarts without any button",
        "Built-in GitHub sources (gh-proxy / ghproxy.net mirrors first, raw as fallback); install once and forget",
        "The source is a public repo, so web changes no longer need a new APK; if the repo is unreachable it can still sync from the host phone",
        "After updating, the game shows “Auto-updated to vX (web N)” for 15s",
        "The home footer shows “Checking… / Up to date / Check failed” quietly"
      ],
      "changed": [
        "Sources ordered “mirrors reachable in China → raw”; on the tablet raw was blocked and mirrors downloaded in 2.5s",
        "Update check failures no longer pop up, just a footer line; play continues",
        "“Up to date” uses the local version so a cached old manifest cannot show an old number",
        "Manual check and URL entry in Version & Updates remain as a fallback / source switch",
        "raw has CDN caching: for a few minutes after release early players may get the old manifest and update on the next launch"
      ],
      "balance": [],
      "removed": [
        "The old “must tap to update” behaviour",
        "The old “any game change needs a new APK” approach (only Java changes need one)"
      ]
    },
    {
      "title": "Auto-update",
      "summary": "",
      "added": [
        "Auto-update: on launch it silently checks, downloads, verifies sha256, installs and restarts",
        "LAN sync: before joining it asks the host version; if newer, pull the web bundle from the host phone without reinstalling",
        "The phone host's port 8788 also serves /update.json and /update/bundle.zip, so it is an update source",
        "Version & Updates shows the current web bundle with “Check update” and “Set update URL”",
        "Two versions kept after update: a broken new build falls back to the previous one, then to the APK bundle"
      ],
      "changed": [
        "Web bundle and APK version separately: small changes ship 9 web files, not an APK",
        "Pages loaded from the phone's update directory still use file://, so saves survive",
        "Joining adds a 2.5s version probe; if the host has no update source it connects directly"
      ],
      "balance": [],
      "removed": [
        "The old “game change requires reinstalling the APK” limit"
      ]
    },
    {
      "title": "Versus AI",
      "summary": "",
      "added": [
        "Versus AI: Easy / Normal / Hard",
        "The AI enumerates rotation × column landings and scores -0.51×height -0.36×holes -0.18×bumpiness +0.76×lines, avoiding the top two rows",
        "The AI shares the player's seed; Easy picks randomly from the top 4, Normal takes the best, Hard takes the best and moves faster",
        "AI mini board, score, lines, level and debt display",
        "After the player dies, results compare you vs AI"
      ],
      "changed": [
        "AI mode does not write solo auto-saves and does not inherit permanent rows or debt",
        "AI mode cannot restart; exit to menu. The AI's board still gets fusion blocks, rotation and morphs"
      ],
      "balance": [],
      "removed": [
        "The “Versus AI — to do” marker"
      ]
    },
    {
      "title": "LAN multiplayer",
      "summary": "",
      "added": [
        "LAN parallel: both play their own board, top-right compares scores",
        "LAN battle: your clears become a fusion block on the opponent's board",
        "The multiplayer panel splits into opponent (phone / PC) × host / join",
        "Phone · Host: this phone runs the server, the other phone joins",
        "Phone · Join: enter the other phone's address and room code",
        "PC · Host: this phone hosts, the PC opens start.html in a browser to join",
        "PC · Join: run server.mjs on the PC, enter its address on the phone",
        "Online score bar: your / opponent score, opponent lines, opponent alive/dead",
        "A 3-second countdown starts both devices together via the server's startAt",
        "Results: a dead player with more points still wins; on a tie the living player wins"
      ],
      "changed": [
        "APK adds INTERNET / network-state permissions and allows cleartext LAN HTTP",
        "No pausing or restarting online (exit to menu)",
        "Online does not write solo auto-saves and does not inherit permanent rows or debt",
        "In Battle your own clears no longer push your own board, only the opponent's"
      ],
      "balance": [],
      "removed": [
        "The “Multiplayer — to do” marker",
        "The old multiplayer panel with only a room code and no host choice",
        "The v0.3 APK (dist and tablet Download keep only v0.4)"
      ]
    },
    {
      "title": "Tutorial / device detection / FPS",
      "summary": "",
      "added": [
        "An 8-page tutorial: auto-opens on the first Single or Continue, replayable from the menu and How to Play",
        "The tutorial explains “blocks fall by themselves”, “the 15s rotation is not a restart”, “R/restart needs two presses” and “two ways to die”",
        "Device detection: screen resolution, game window, refresh rate, with measured values in Settings and a re-detect button",
        "FPS setting: default 60, options Auto / 30 / 60 / 90 / 120",
        "FPS options above the screen refresh rate are greyed out; a saved high value drops to what the screen can do",
        "A hint after 6s without input: “Blocks fall on their own”",
        "Version & Updates: current version and each release's added / changed / removed",
        "The game top bar shows the version"
      ],
      "changed": [
        "R and pause-menu Restart now need two presses within 3s; the first only warns",
        "The game loop skips frames to the FPS cap while logic still uses real time",
        "Resolution rounds to the physical screen (2560×1600, not 2561×1602)",
        "The Android shell disables WebView cache and clears it on launch so updates do not load old pages",
        "The Android shell drops global pauseTimers so the page loads fully even when launched on the lock screen",
        "The pause page summarises screen / refresh rate / current FPS cap",
        "The version lives in version.js and is read by home, More, About and the game top bar"
      ],
      "balance": [],
      "removed": [
        "The old “one R press / one Restart tap restarts immediately” behaviour (now two-step)",
        "pauseTimers / resumeTimers in the Android shell",
        "The WebView default cache mode (now LOAD_NO_CACHE + clear on launch)",
        "The old v0.2 APK and installer (tablet Download keeps only v0.3)",
        "Leftover “permanent row accumulation” dead code (S.perm / permSeg bindings / that row in the sheet)"
      ]
    },
    {
      "title": "Game core / Android shell",
      "summary": "",
      "added": [
        "Full 10×10 rules: seven shapes, 7-bag, 1s lock delay, 15s rotation with sand fall",
        "Fusion blocks, debt, permanent rows, a 50-clear grace period, letter blocks from the 100th clear",
        "Arrow blocks after 1000 points (clear only the arrow side)",
        "Canvas board, info panel, keyboard and touch buttons, pause, 3 save slots, import/export",
        "Cues two-channel sound",
        "Android WebView shell APK (offline, no network permission)"
      ],
      "changed": [
        "Menu keyboard no longer steals game keys",
        "The Continue button refreshes live with the auto-save",
        "Version label changes from v0.1 UI prototype to v0.2 game core"
      ],
      "balance": [],
      "removed": [
        "The “permanent row accumulation” setting (off / one game / accumulate) — SPEC fixes the rule and the switch was never implemented, so it misled"
      ]
    },
    {
      "title": "UI prototype",
      "summary": "",
      "added": [
        "Main menu, play page, More, Settings, How to Play",
        "Background animation and the first visual pass"
      ],
      "changed": [
        "UI only, no game yet; tapping Single says it is not wired up"
      ],
      "balance": [],
      "removed": []
    }
  ]
  };
})();
