/* i18n.js —— 语言切换（简体 / English / 跟随系统）
 * 先覆盖菜单、设置、游戏 HUD、暂停/结算；教程/帮助/旧更新记录暂保留中文。
 */
(function () {
  'use strict';

  const DICT = {
    /* 首页 / 玩法 */
    '开始': 'Start',
    '新手教程': 'Tutorial',
    '更多': 'More',
    '设置': 'Settings',
    '返回': 'Back',
    '主玩法': 'Main',
    '常驻': 'Casual',
    '多人对战': 'Multiplayer',
    '合体债 / 经典': 'Debt / Classic',
    '连击 · 轻松': 'Combo · Chill',
    '决斗 / 对打': 'Duel / Watch',
    '合体债': 'Debt',
    '原味': 'Original',
    '极简': 'Minimal',
    '现代': 'Modern',
    '像素': 'Pixel',
    '霓虹': 'Neon',
    '经典': 'Classic',
    '经典玩法': 'Classic',
    '打 AI': 'Versus AI',
    'AI 观战': 'AI Watch',
    '常驻 · 禅模式': 'Casual · Zen',
    '继续': 'Continue',
    '继续经典': 'Continue Classic',
    '继续常驻': 'Continue Casual',
    '继续禅': 'Continue Zen',
    '继续禅模式': 'Continue Zen',
    '版本与更新': 'Version & Updates',
    '存档管理': 'Saves',
    '玩法说明': 'How to Play',
    '关于': 'About',
    '语言': 'Language',
    '帧率和场地自动旋转。': 'Frame rate and field rotation.',
    '只换外观，不改规则；开局后生效。': 'Visuals only; applies next game.',
    '系统不转时，页面会自己转画面。': 'If the system does not rotate, the page rotates itself.',
    '音量、静音和提示方式。': 'Volume, mute and hint style.',
    '安装包、屏幕和刷新率。': 'APK, screen and refresh rate.',
    '菜单、设置和游戏内界面；教程/帮助下一步再翻。': 'Menu, settings and in-game UI; guides come next.',

    /* 设置入口 */
    '游戏': 'Game',
    '方块材质': 'Block Skin',
    '屏幕方向': 'Orientation',
    '设备信息': 'Device',
    '帧率 / 场地旋转': 'FPS / Rotation',

    /* 设置：游戏 */
    '帧率（默认 60）': 'Frame rate (default 60)',
    '自动': 'Auto',
    '场地自动旋转（15 秒转 90°）': 'Auto-rotate field (90° / 15s)',
    '关闭（默认）': 'Off (default)',
    '开启（挑战）': 'On (challenge)',
    '开场动画': 'Intro animation',
    '每次': 'Every time',
    '只看第一次': 'First only',
    '关闭': 'Off',
    '联机决斗开场不受影响；关掉后单机开局直接进棋盘。':
      'The online duel intro is unchanged; when off, solo games start directly.',

    /* 语言 */
    '简体中文': '简体中文',
    '跟随系统': 'Follow system',
    '语言 / Language': 'Language',
    '英文先做菜单、设置和游戏内界面；教程/帮助/旧更新记录下一步再翻。':
      'English preview: menus, settings and in-game HUD. Guides and old changelogs come next.',

    /* 设置：材质 */
    '方块材质（只换外观）': 'Block skin (visual only)',
    '自己选': 'Manual',
    '系统选': 'Auto',
    '每次对局': 'Per game',
    '开局后生效，不改规则和分数。': 'Applies next game; rules and scoring are unchanged.',
    '「系统选」每局从五套里随机一套；点下面任意一套会切回「自己选」。':
      'Auto picks a random skin each game; tapping a skin switches back to Manual.',

    /* 设置：屏幕 */
    '当前方向': 'Current',
    '自动旋转': 'Auto rotate',
    '横屏': 'Landscape',
    '横屏反向': 'Landscape (reverse)',
    '竖屏': 'Portrait',

    /* 设置：声音 */
    '音效': 'Sound',
    '声音': 'Sound',
    '开': 'On',
    '关': 'Off',
    '音量': 'Volume',
    '小': 'Low',
    '中': 'Medium',
    '大': 'High',
    '右上角提示（静音时靠它）': 'Corner hints (for muted play)',
    '总是': 'Always',
    '试听一声': 'Test sound',
    '听到了': 'Heard it',
    '没声音': 'No sound',

    /* 设置：设备 */
    '安装包（壳）': 'APK (shell)',
    '设备（自动检测）': 'Device (auto)',
    '屏幕': 'Screen',
    '游戏窗口': 'Game window',
    '屏幕刷新率': 'Refresh rate',
    '重新检测': 'Detect again',
    '复制新版 APK 下载地址': 'Copy latest APK link',
    '旧安装包': 'Old APK',

    /* 存档 */
    '单人玩法': 'Solo',
    '经典玩法': 'Classic',
    '常驻玩法': 'Casual',
    '禅模式': 'Zen',
    '禅': 'Zen',
    '时间到': 'Time up',
    '自动存档': 'Auto save',
    '槽位 1': 'Slot 1',
    '槽位 2': 'Slot 2',
    '槽位 3': 'Slot 3',
    '空': 'Empty',
    '分': 'pts',
    '存': 'Save',
    '读': 'Load',
    '删': 'Del',

    /* 版本页 */
    '更新前先存档': 'Save before updating',
    '更新记录': 'Changelog',
    '玩法一览': 'Modes',
    '详细': 'Details',
    '新增': 'Added',
    '优化 / 调整': 'Changed',
    '平衡性调整': 'Balance',
    '删除': 'Delete',
    '暂无更新记录': 'No changelog yet',

    /* 游戏 HUD / 暂停 */
    '暂停': 'Pause',
    '重开': 'Restart',
    '退出到菜单': 'Exit to menu',
    '返回菜单': 'Back to menu',
    '每块落地自动存档。': 'Auto-saves after every lock.',
    '分数': 'Score',
    '等级': 'Level',
    '结束欠': 'Debt',
    '消行': 'Lines',
    '最高': 'Best',
    '债已清': 'Debt paid',
    '变形': 'Morph',
    '字母块': 'Letter',
    '连击': 'Combo',
    '倍数': 'Multiplier',
    '剩余': 'Time',
    '准备': 'Ready',
    '对手': 'Opponent',
    '你': 'You',
    '你赢': 'You win',
    '你输': 'You lose',
    '平局': 'Draw',
    '本局': 'Score',
    '带走': 'Carry',
    '按 R 重开': 'Press R to restart',
    '原版规则': 'Classic rules',
    '奖励期': 'Grace',
    '还债中': 'Paying debt',
    '顶块': 'Fusion in',
    '洞': 'holes',
    '最高连击': 'Max combo',
    '债': 'Debt',
    '债还不完，本局结束': 'Debt unpaid — run over',
    '常驻 · 连击': 'Casual · Combo',
    '禅 · 时间到': 'Zen · Time up',

    /* 模式提示 */
    '经典玩法提示': 'Classic',
    '10×20 标准盘，消 1/2/3/4 行按 100/300/500/800×等级计分；没有债、合体块、方向块。堆到顶就结束。':
      '10×20 standard board. Lines score 100/300/500/800 × level; no debt, fusion or arrow blocks. Top out to end.',
    '10×10，无债、无合体块；连续消行叠连击（最高 2.25 倍），连续 3 块没消就断。':
      '10×10, no debt or fusion. Consecutive clears build a combo up to 2.25×; 3 non-clears break it.',
    '10×12，5/10 分钟；不会死，堆满自动清掉底部 4 行；暂停会停表，剩余时间自动存档。':
      '10×12, 5/10 minutes. You cannot die; a full board auto-clears the bottom 4 rows. Pause stops the clock and saves the remainder.',
    '和 AI 同时开局，谁先死谁输；AI 也会算合体块，难度越高落子越快、越准。':
      'Start together with the AI; whoever tops out first loses. Higher difficulty moves faster and smarter.',
    '两个 AI 自己打，你只负责看；一局结束约 3.5 秒自动开下一局。':
      'Two AIs play each other; just watch. The next round starts about 3.5s later.',
    '知道了，开始': 'Got it, start',
    '点一下跳过': 'Tap to skip',
    '欠债还钱天经地义': 'Debts must be paid',
    '经典永不过时': 'Classics never age',
    '来！咱俩练练！': "Let's spar!",
    '不是你死就是他亡': 'Only one survives',

    /* 教程 */
    '跳过': 'Skip',
    '上一步': 'Back',
    '下一步': 'Next',
    '开始游戏': 'Start game',
    '填满一行 → 消': 'Clear a row →',
    '↓ 软降': '↓ soft drop',
    '↻ 转': 'Rotate',
    '空格 硬降': 'Space hard drop',
    '落沙': 'sand falls',
    '洞 1~2 个': '1–2 holes',
    '按债 1~4 行': '1–4 rows by debt',
    '消一行 -100': 'clear a row −100',
    '↑ 清上面整列': '↑ clear above',
    '↓ 清下面整列': '↓ clear below',
    '← / → 清左边 / 右边整行': '← / → clear sides',
    '第 40 次起': 'From the 40th clear',
    '洞越来越少': 'fewer holes over time',
    '连点「债」5 下清档': 'Tap Debt 5× to clear debt',

    /* 玩法说明页（英文整页替换） */
    '玩法说明': 'How to Play',
    '打开新手教程': 'Open tutorial',
    '玩法': 'How to play',
    '版本说明': 'Version notes',
    '知道了': 'Got it',
    '主玩法：合体债 / 经典 · 常驻：连击 / 禅 · AI：决斗 / 对打':
      'Main: Debt / Classic · Casual: Combo / Zen · AI: Duel / Watch',

    /* 首页 / 玩法页 */
    '第一次玩？先看 1 分钟新手教程——尤其是「方块会自己掉」和「R 要按两次」。':
      'First time? Take the 1-minute tutorial — especially “blocks fall on their own” and “R must be pressed twice”.',
    'AI': 'AI',
    '规则': 'Rules',
    '模式': 'Mode',
    '和谁玩': 'Opponent',
    '操作': 'Action',
    '并行赛': 'Parallel',
    '干扰战': 'Battle',
    '手机玩家': 'Phone',
    '电脑玩家': 'PC',
    '开房': 'Host',
    '加入': 'Join',
    '创建房间（这台手机当房主）': 'Create room (this phone hosts)',
    '房主地址': 'Host address',
    '房间码': 'Room code',
    '加入房间': 'Join room',
    '同一个 Wi-Fi，先选和谁玩，再开房或加入': 'On the same Wi-Fi: pick an opponent, then host or join',
    '蓝牙对打（无网）': 'Bluetooth duel (offline)',

    /* 存档页 */
    '单人玩法和经典玩法分开存；点某一项的「删除」只清那一档。':
      'Solo and Classic save separately; “Del” clears only that save.',
    '当前存档': 'Current save',
    '导出当前存档': 'Export current save',
    '导入存档': 'Import save',
    '导入': 'Import',
    '清空全部存档': 'Clear all saves',
    '存档': 'Saves',
    '无': 'None',

    /* 设置页静态说明 */
    '正在测屏幕刷新率…': 'Measuring refresh rate…',
    '检测中…': 'Detecting…',
    '关掉以后场地不会自己转；喜欢挑战的可以打开。':
      'When off, the field never rotates; turn it on for a challenge.',
    '自动旋转不生效就选「横屏」：系统不转，画面也会自己转。':
      'If auto-rotate does not work, pick Landscape: the page rotates itself.',
    '开关': 'Toggles',
    '总是': 'Always',
    '看看听得见吗': 'Can you hear it?',
    '设备（自动检测）': 'Device (auto)',
    '屏幕': 'Screen',
    '游戏窗口': 'Game window',
    '屏幕刷新率': 'Refresh rate',
    '重新检测': 'Detect again',
    '英文先做菜单、设置和游戏内界面；教程/帮助/旧更新记录下一步再翻。':
      'English now covers menus, settings, gameplay, tutorial and help; old changelogs come next.',

    /* 玩法选择 / AI 面板 / 存档 */
    '先选规则；进入后还能在设置里调方向/音量。': 'Pick a ruleset; orientation and volume live in Settings.',
    '消行顶块 · 跨局还债': 'clears push up · debt carries over',
    '10×20 · 标准计分': '10×20 · standard scoring',
    '连击随时结束；禅模式 5/10 分钟，堆满自动整理、不会死。':
      'Combo ends whenever you top out; Zen runs 5/10 minutes, auto-tidies and never dies.',
    '禅模式时长': 'Zen duration',
    '5 分钟': '5 min',
    '10 分钟': '10 min',
    '堆满不会死，只清底 4 行并断连击；时间到结算。':
      'A full board will not kill you: it clears the bottom 4 rows and breaks the combo; the run ends when time is up.',
    '开始禅模式': 'Start Zen',
    '先选难度，再选决斗或观战。自动会按本机算力定档。':
      'Pick a difficulty, then duel or watch. Auto sizes it to this device.',
    '难度': 'Difficulty',
    '简单': 'Easy',
    '普通': 'Normal',
    '困难': 'Hard',
    '与 AI 决斗': 'Duel AI',
    'AI 对打（观战）': 'AI vs AI (watch)',
    '英文已覆盖菜单、设置、游戏、教程与帮助；旧更新记录下一步再翻。':
      'English now covers menus, settings, gameplay, tutorial and help; old changelogs come next.',
    '禅模式自动': 'Zen auto',
    '取消': 'Cancel',
    '删除存档': 'Delete save',
    '点一下检查更新': 'Tap to check for updates',
    '‹ 返回': '‹ Back',
    '单人': 'Solo',
    '局域网 · 并行赛': 'LAN · Parallel',
    '局域网 · 干扰战': 'LAN · Battle',
    '继续上一局': 'Continue last run',
    '覆盖安装一般保留存档，但更新会重启游戏；先在「更多 → 存档管理」保存或导出，再更新。':
      'Installing over it usually keeps saves, but updating restarts the game; save or export first from More → Saves.',
    '▼ 软降': '▼ Soft',
    '⤓ 硬降': '⤓ Hard',
    '暂存': 'Hold',
    '重开 R': 'Restart R',
    '←→ 移动 · ↓ 软降 · 空格 硬降 · ↑/X 转 · Z 反着转 · C 暂存 · P 暂停 · R 重开×2':
      '←→ move · ↓ soft drop · Space hard drop · ↑/X rotate · Z reverse · C hold · P pause · R restart×2',

    /* 蓝牙 / 联机弹层 */
    '蓝牙对打': 'Bluetooth duel',
    '这个安装包还不支持蓝牙。': 'This build does not support Bluetooth.',
    '装一次最新 APK（0.8.0）再回来。': 'Install the latest APK (0.8.0) and come back.',
    '这台设备没有蓝牙。': 'This device has no Bluetooth.',
    '换个有蓝牙的安卓手机。': 'Use an Android phone with Bluetooth.',
    '蓝牙没开。': 'Bluetooth is off.',
    '开蓝牙': 'Turn on Bluetooth',
    '再检测': 'Check again',
    '需要蓝牙权限。': 'Bluetooth permission is required.',
    '允许蓝牙权限': 'Allow Bluetooth',
    '去系统设置': 'System settings',
    '没有已配对设备。先去系统蓝牙里把两台手机配对，再回来刷新。':
      'No paired devices. Pair both phones in system Bluetooth first, then refresh.',
    '不用 Wi-Fi/流量；两台手机先系统配对。': 'No Wi-Fi or data needed; pair both phones in system settings first.',
    '我是房主，等对方连': 'I host, wait for the other player',
    '已配对设备（点一个加入）': 'Paired devices (tap one to join)',
    '去系统蓝牙配对': 'Pair in system Bluetooth',
    '让手机搜到我（120 秒）': 'Make this phone discoverable (120s)',
    '刷新': 'Refresh',
    '本机': 'This device',
    '上次的对手': 'Last opponent',
  };

  const EN_HELP = ''
    + '<p class="h2">How to Play</p>'
    + '<button class="btn primary" id="btnHelpTutorial">Open tutorial</button>'
    + '<div class="rule"><b>Main</b> Tap Main, then choose <b>Debt</b> (10×10, clears push blocks up, debt carries across games) or <b>Classic</b> (10×20, standard scoring).</div>'
    + '<div class="rule"><b>Casual</b> Tap Casual, then choose:'
    + '<ul>'
    + '<li><b>Combo</b>: 10×10, no debt or fusion blocks; consecutive clears build a 1 → 2.25 multiplier, broken after 3 non-clearing pieces.</li>'
    + '<li><b>Zen</b>: 10×12, 5/10 minutes; a full board auto-clears the bottom 4 rows and you cannot die; pausing or exiting saves the remaining time.</li>'
    + '</ul></div>'
    + '<div class="rule"><b>AI</b> Tap AI, pick a difficulty (Easy / Normal / Hard), then <b>Duel AI</b> or <b>AI vs AI (watch)</b>.</div>'
    + '<div class="rule"><b>Fusion blocks</b> After each clear, 2.5s later a hard block rises from the bottom: 2 rows tall, only 1–2 holes. The top two rows flash red for the last 0.9s; if those rows are occupied when it rises, it cannot rise = death.</div>'
    + '<div class="rule"><b>Debt</b> Each fusion row left on the board when you die is carried into the next game (the <i>−500</i> in the corner). The bottom starts with <b>1–4 rows</b> of permanent blocks scaled to debt; clearing one pays 100. Once paid, the next <b>18 clears</b> push no blocks. “End debt” at top-right is what the next game will carry.</div>'
    + '<div class="rule"><b>Rotation</b> Enable in Settings → Game → Auto-rotate field. Then every 15s the whole field turns 90° clockwise and the stack collapses once. A flashing border and spinning corner arrow are a warning — <b>not a restart</b>.</div>'
    + '<div class="rule"><b>Arrow blocks</b> Start falling after 4000 points, 1 in 12 pieces. On lock, the side the arrow points to is wiped (↑ clears only the column above). It clears stack only, not debt.</div>'
    + '<div class="rule"><b>Letter blocks</b> From the 40th clear, rising fusion blocks become letter shapes; one more hole disappears every 40 clears. The panel shows “Morph X/40”.</div>'
    + '<div class="rule"><b>Classic</b> 10×20; 1/2/3/4 lines = 100/300/500/800 × level, level up every 10 lines and speed rises with it; no debt, fusion or arrow blocks.</div>'
    + '<div class="rule"><b>Score</b> Below 10k shown as-is; above that as text + number like “10k / 12k”, the same in every mode.</div>'
    + '<div class="rule"><b>Saves</b> Solo, Classic, Casual and Zen each save separately; autosave + 3 manual slots (Zen is auto only). Before updating, save or export from More → Saves.</div>'
    + '<div class="rule"><b>Multiplayer</b> Direct connection over the same Wi-Fi or paired Bluetooth; parallel races compare scores only, interference matches push blocks to the opponent; classic rules support parallel only.</div>'
    + '<div class="rule"><b>Restart / reset</b> R must be pressed twice; the pause-menu Restart also needs two taps. On the game-over screen tap the red “Debt” word at bottom-left 5 times to clear next game’s debt.</div>'
    + '<button class="btn small" data-back>Back</button>';

  let lang = 'zh';
  let watching = false;
  let applying = false;
  let scheduled = false;

  function resolve(setting) {
    if (setting === 'en') return 'en';
    if (setting === 'zh') return 'zh';
    var l = (navigator.language || 'zh').toLowerCase();
    return l.indexOf('zh') === 0 ? 'zh' : 'en';
  }

  function set(setting) {
    lang = resolve(setting);
    try { document.documentElement.lang = lang === 'en' ? 'en' : 'zh-CN'; } catch (e) {}
    localizeHelp(lang);
    if (lang === 'en') {
      if (document.body) {
        apply(document.body);
        watch();
      } else {
        document.addEventListener('DOMContentLoaded', function () { apply(document.body); watch(); }, { once: true });
      }
    }
    return lang;
  }

  var zhHelpHTML = null;
  function localizeHelp(now) {
    var sec = document.querySelector ? document.querySelector('.screen[data-screen="help"]') : null;
    if (!sec) return;
    if (zhHelpHTML === null) zhHelpHTML = sec.innerHTML;
    if (now === 'en') {
      if (sec.innerHTML !== EN_HELP) sec.innerHTML = EN_HELP;
    } else if (sec.innerHTML !== zhHelpHTML) {
      sec.innerHTML = zhHelpHTML;
    }
  }

  function fmtScoreLang(n) {
    n = Math.max(0, Math.floor(n || 0));
    if (n < 10000) return String(n);
    if (lang === 'en') {
      var v = n < 1000000 ? n / 1000 : n / 1000000;
      var s = v >= 100 ? String(Math.round(v)) : String(Math.round(v * 10) / 10);
      return s.replace(/\.0$/, '') + (n < 1000000 ? 'k' : 'M');
    }
    if (n < 100000000) {
      var w = n / 10000;
      var sw = w >= 100 ? String(Math.round(w)) : String(Math.round(w * 10) / 10);
      return sw.replace(/\.0$/, '') + '万';
    }
    var y = n / 100000000;
    var sy = y >= 100 ? String(Math.round(y)) : String(Math.round(y * 10) / 10);
    return sy.replace(/\.0$/, '') + '亿';
  }

  function t(s) {
    if (lang !== 'en' || s == null) return s;
    var key = String(s).trim();
    return DICT[key] || s;
  }

  function apply(root) {
    if (lang !== 'en' || !root || applying) return;
    applying = true;
    var scope = root.nodeType === 9 ? root.body : root;
    if (!scope) { applying = false; return; }
    var walker = document.createTreeWalker(scope, NodeFilter.SHOW_TEXT, null);
    var nodes = [], n;
    while ((n = walker.nextNode())) nodes.push(n);
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      var p = node.parentElement;
      if (!p) continue;
      if (p.closest('script,style,canvas,#tut,.screen[data-screen="help"],#aboutLog,.logo')) continue;
      var raw = node.nodeValue || '';
      var key = raw.trim();
      if (!key) continue;
      var val = DICT[key];
      if (key === '关闭') val = p.closest('.seg') ? 'Off' : 'Close';
      if (!val) continue;
      node.nodeValue = raw.replace(key, val);
    }
    var attrs = scope.querySelectorAll ? scope.querySelectorAll('[placeholder],[title]') : [];
    for (var j = 0; j < attrs.length; j++) {
      var el = attrs[j];
      ['placeholder', 'title'].forEach(function (a) {
        var v = el.getAttribute(a);
        if (v && DICT[v.trim()]) el.setAttribute(a, DICT[v.trim()]);
      });
    }
    applying = false;
  }

  function watch() {
    if (watching || !document.body) return;
    watching = true;
    new MutationObserver(function () {
      if (lang !== 'en' || applying || scheduled) return;
      scheduled = true;
      requestAnimationFrame(function () {
        scheduled = false;
        apply(document.body);
      });
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  window.TetrisI18n = {
    set: set,
    t: t,
    apply: apply,
    fmtScore: fmtScoreLang,
    get lang() { return lang; }
  };
})();

/* game.js —— 合体债 · 画面 / 输入 / 存档 / 提示
 *
 * 规则全在 engine.js；这里只负责把状态画出来、把手感做出来。
 * 入口：window.TetrisGame.start({mode, seed, settings})
 *   mode: 'solo' | 'resume'（ai / lan 还没做，返回 false 让菜单提示）
 */
(function () {
  'use strict';

  const E = window.TetrisEngine;
  if (!E) { console.error('[tetris] engine.js 没加载'); return; }
  const C = E.CONST;
  const SHAPES = E.SHAPES;
  const COLORS = E.COLORS;
  const fmtScore = (window.TetrisI18n && window.TetrisI18n.fmtScore) || E.fmtScore;
  function T(s) { return window.TetrisI18n ? window.TetrisI18n.t(s) : s; }
  function EN() { return !!(window.TetrisI18n && window.TetrisI18n.lang === 'en'); }
  function unit(n, one, many) { return String(n) === '1' ? one : many; }
  function lineCount(n) { return n + ' ' + unit(n, 'line', 'lines'); }

  /* 方块材质：只改画法，不改规则。尺寸按 32px 格设计，其他格子按比例缩。 */
  const SKINS = [
    { id: 'solid', name: '原味', pad: 2, radius: 6, line: 1, glow: 12 },
    { id: 'minimal', name: '极简', pad: 3, radius: 7, line: 1, glow: 3 },
    { id: 'modern', name: '现代', pad: 2, radius: 8, line: 1, glow: 8 },
    { id: 'pixel', name: '像素', pad: 1, radius: 0, line: 1, glow: 4 },
    { id: 'neon', name: '霓虹', pad: 2, radius: 7, line: 2, glow: 0 }
  ];
  const SKIN_ALIAS = { glass: 'modern', matte: 'minimal' };
  function skinDef(id) {
    const raw = id || (settings && settings.skin) || 'solid';
    const key = SKIN_ALIAS[raw] || raw;
    for (let i = 0; i < SKINS.length; i++) if (SKINS[i].id === key) return SKINS[i];
    return SKINS[0];
  }
  function randomSkin(exclude) {
    let id = SKINS[Math.floor(Math.random() * SKINS.length)].id;
    let guard = 0;
    while (id === exclude && guard++ < 8) {
      id = SKINS[Math.floor(Math.random() * SKINS.length)].id;
    }
    return id;
  }
  function hexRgb(hex) {
    if (!/^#[0-9a-f]{6}$/i.test(hex || '')) return null;
    return {
      r: parseInt(hex.slice(1, 3), 16),
      g: parseInt(hex.slice(3, 5), 16),
      b: parseInt(hex.slice(5, 7), 16)
    };
  }
  function shade(hex, amt) {
    const c = hexRgb(hex);
    if (!c) return hex;
    const t = amt >= 0 ? 255 : 0, p = Math.min(1, Math.abs(amt));
    return 'rgb(' + Math.round(c.r + (t - c.r) * p) + ','
      + Math.round(c.g + (t - c.g) * p) + ','
      + Math.round(c.b + (t - c.b) * p) + ')';
  }
  function tint(hex, a) {
    const c = hexRgb(hex);
    return c ? 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',' + a + ')' : hex;
  }
  const LS = {
    auto: 'tetris.auto',
    autoClassic: 'tetris.auto.classic',
    autoCasual: 'tetris.casual.auto',
    zenAuto: 'tetris.zen.auto',
    slot: 'tetris.slot',
    slotClassic: 'tetris.cslot',
    slotCasual: 'tetris.casual.slot',
    carry: 'tetris.carry',
    debtFails: 'tetris.debtFails',
    high: 'tetris.high',
    highClassic: 'tetris.high.classic',
    highCasual: 'tetris.high.casual',
    zenHigh5: 'tetris.zen.high.5',
    zenHigh10: 'tetris.zen.high.10'
  };

  const SAVE_NAME = { normal: '单人玩法', classic: '经典玩法', casual: '常驻玩法' };

  let W = 480, H = 320, BOARD = 320, PX = 328, PW = 144, BW = 320;

  // 棋盘尺寸跟着引擎走：合体债 10×10（32px 格），原版 10×20（16px 格，盘面更高）
  function layoutFor(g) {
    const classic = !!(g && g.classic);
    C.CELL = classic ? 16 : 32;
    const cols = g ? g.cols : C.COLS;
    const rows = g ? g.rows : C.ROWS;
    BW = C.CELL * cols;
    H = C.CELL * rows;
    BOARD = H;
    PX = BW + 8;
    W = PX + PW + 8;
  }
  const FONT = 'system-ui,-apple-system,"Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif';

  let root = null, canvas = null, ctx = null, stageEl = null;
  let pauseLayer = null, slotsBox = null, skinsBox = null, overBar = null, toastEl = null;
  let fileInput = null, modeEl = null;
  let built = false;
  let running = false;
  let raf = 0, lastFrame = 0;
  let game = null;
  let paused = false;
  let over = false;
  let overInfo = null;
  let effects = [];
  let dasDir = 0, dasT = 0, arrT = 0;
  let touchAct = null;
  let taps = { n: 0, t: 0 };
  let toastTimer = 0;
  let highScore = 0;
  let settings = { sound: true, fps: '60', skin: 'solid', intro: 'every' };

  // 统一入口：按设置决定场地要不要自己转
  function highKey() {
    if (game && game.zen) return game.zenMinutes === 10 ? LS.zenHigh10 : LS.zenHigh5;
    return game && game.casual ? LS.highCasual
      : (game && game.classic ? LS.highClassic : LS.high);
  }

  function mk(opts) {
    const g = new E.Tetris(opts || {});
    if (!g.casual) g.rotateEnabled = !!settings.rotate;
    return g;
  }
  let startSeed = null;
  let modeLabel = '单人';
  let fpsCap = 60;
  let frameAcc = 0;
  let restartArmed = 0;
  let lastInputAt = 0;
  let idleHintShown = false;
  let net = null;
  let multi = null;
  let modeIntro = null;
  let modeIntroSeen = false;
  let introStamp = 0;
  let clockEl = null, clockTimer = 0;
  let spectate = null;
  let aiMode = false;
  let aiState = null;
  let resultEl = null, vsEl = null, vsYou = null, vsOpp = null, vsState = null;
  let aiCanvas = null, aiCtx = null, aiScoreEl = null, aiInfoEl = null, aiDebtEl = null;

  /* ---------------- 小工具 ---------------- */

  function $(sel) { return root ? root.querySelector(sel) : null; }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function readJSON(key) {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : null; } catch (e) { return null; }
  }
  function writeJSON(key, obj) {
    try { localStorage.setItem(key, JSON.stringify(obj)); return true; } catch (e) { return false; }
  }
  function readCarry() {
    try { const n = parseInt(localStorage.getItem(LS.carry) || '0', 10); return isFinite(n) && n > 0 ? n : 0; } catch (e) { return 0; }
  }
  function setCarry(n) {
    try { localStorage.setItem(LS.carry, String(Math.max(0, n | 0))); } catch (e) {}
  }
  function readDebtFails() {
    try { const n = parseInt(localStorage.getItem(LS.debtFails) || '0', 10); return isFinite(n) && n > 0 ? n : 0; } catch (e) { return 0; }
  }
  function setDebtFails(n) {
    try { localStorage.setItem(LS.debtFails, String(Math.max(0, n | 0))); } catch (e) {}
  }
  function restructureDebt(debt) {
    const n = Math.max(0, debt | 0);
    if (n <= 0) { setDebtFails(0); return 0; }
    const fails = readDebtFails() + 1;
    if (fails >= 3) {
      const next = Math.floor(n / 2);
      setDebtFails(0);
      toast(EN()
        ? '3 unpaid games — debt restructured: -' + n + ' → -' + next
        : '连续 3 局没还清，债务重组：-' + n + ' → -' + next);
      return next;
    }
    setDebtFails(fails);
    return n;
  }
  function dispatch(name, detail) {
    try { document.dispatchEvent(new CustomEvent(name, { detail: detail })); } catch (e) {}
  }
  function toast(msg) {
    if (!toastEl) return;
    msg = T(msg);
    toastEl.textContent = msg;
    toastEl.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('on'); }, 2200);
  }
  function cue(name, data) {
    if (!window.Cues) return;
    try { window.Cues.cue(name, data); } catch (e) {}
  }

  function applyFps() {
    const v = settings.fps;
    if (v === 'auto') fpsCap = 0;
    else fpsCap = clamp(parseInt(v, 10) || 60, 30, 144);
    frameAcc = 0;
    updatePauseNote();
  }

  function updatePauseNote() {
    const el = $('#tgNote');
    if (!el) return;
    let dev = '';
    if (window.TetrisDevice) {
      try {
        const d = window.TetrisDevice.info();
        dev = '屏幕 ' + d.width + '×' + d.height + (d.hz ? ' · ' + d.hz + 'Hz' : '') + ' · ';
      } catch (e) {}
    }
    if (EN()) {
      let devEn = '';
      if (window.TetrisDevice) {
        try {
          const d = window.TetrisDevice.info();
          devEn = 'Screen ' + d.width + '×' + d.height + (d.hz ? ' · ' + d.hz + 'Hz' : '') + ' · ';
        } catch (e) {}
      }
      el.textContent = devEn + 'FPS ' + (fpsCap ? ('cap ' + fpsCap) : 'auto')
        + '. Auto-saves after every lock.';
      return;
    }
    el.textContent = dev + '帧率' + (fpsCap ? ('上限 ' + fpsCap + ' 帧') : '跟随屏幕')
      + '。每块落地自动存档。';
  }

  /* R / 暂停里的「重开」都走这里：第一次只提醒，3 秒内再来一次才真的重开 */
  function requestRestart() {
    if (!game) return;
    if (multi) { toast(EN() ? 'Cannot restart mid-match — exit to menu and start a new game' : '联机中不能重开，返回菜单再开一局'); return; }
    if (aiMode) { toast(EN() ? 'Cannot restart against the AI — exit to menu and start a new game' : '打 AI 中不能重开，返回菜单再开一局'); return; }
    if (over) { restartGame(); return; }
    const now = performance.now();
    if (restartArmed && now - restartArmed < 3000) {
      restartArmed = 0;
      restartGame();
      return;
    }
    restartArmed = now;
    toast(EN() ? 'Press R again / tap Restart again to confirm' : '再按一次 R / 再点一次「重开」确认');
    const b = $('#tgRestart');
    if (b) {
      b.textContent = EN() ? 'Tap again to confirm' : '再点一次确认';
      if (b._armTimer) clearTimeout(b._armTimer);
      b._armTimer = setTimeout(function () { b.textContent = T('重开'); }, 3000);
    }
  }

  function resetRestartButton() {
    restartArmed = 0;
    const b = $('#tgRestart');
    if (b) {
      b.textContent = T('重开');
      if (b._armTimer) clearTimeout(b._armTimer);
    }
  }

  /* ---------------- DOM / CSS ---------------- */

  const CSS = `
  #tg{
    position:fixed;inset:0;z-index:50;display:none;flex-direction:column;align-items:center;
    gap:8px;padding:calc(env(safe-area-inset-top) + 8px) 10px calc(env(safe-area-inset-bottom) + 8px);
    background:radial-gradient(120% 70% at 50% -12%,rgba(62,224,198,.10),transparent 55%),#08090d;
    color:#e9edf6;font-family:${FONT};user-select:none;-webkit-user-select:none;
    overflow:hidden;touch-action:manipulation;
  }
  #tg.on{display:flex}
  /* AI 观战：只留画布和返回，其他操作全藏掉 */
  #tg.is-spectate .tg-pad,
  #tg.is-spectate .tg-keys,
  #tg.is-spectate .tg-vs,
  #tg.is-spectate .tg-ai,
  #tg.is-spectate .tg-over,
  #tg.is-spectate [data-cmd="pause"]{display:none!important}
  .tg-bar{width:100%;max-width:560px;height:38px;display:flex;align-items:center;justify-content:space-between;gap:8px;flex:0 0 auto}
  .tg-pause-head{display:flex;align-items:baseline;justify-content:space-between;gap:10px}
  .tg-pause-clock{
    font:600 12px/1 ui-monospace,SFMono-Regular,Consolas,"Noto Sans SC",monospace;
    color:#79839a;letter-spacing:.04em;font-variant-numeric:tabular-nums;white-space:nowrap;
  }
  .tg-btn{
    height:38px;padding:0 14px;border-radius:11px;border:1px solid #232838;background:#12141b;color:#e9edf6;
    font:inherit;font-size:13px;cursor:pointer;transition:.15s;
  }
  .tg-btn:active{transform:scale(.96)}
  .tg-title{font-size:11px;letter-spacing:.28em;color:#79839a;white-space:nowrap}
  .tg-vs{
    display:none;width:100%;max-width:560px;height:24px;flex:0 0 auto;
    align-items:center;justify-content:center;gap:12px;font-size:11px;color:#79839a;
  }
  #tg.is-multi .tg-vs{display:flex}
  .tg-vs b{color:#e9edf6;font-size:13px;font-variant-numeric:tabular-nums}
  .tg-vs-state{margin-left:auto;color:#5b6479;font-size:10px}
  .tg-ai{
    display:none;width:100%;max-width:560px;height:100px;flex:0 0 auto;
    align-items:center;justify-content:center;gap:12px;
  }
  #tg.is-ai .tg-ai{display:flex}
  #tg.is-ai .tg-keys{display:none}
  #tg.is-ai .tg-vs{display:flex}
  .tg-ai canvas{width:96px;height:96px;border-radius:10px;border:1px solid #232838;background:#0a0c12}
  .tg-ai-info{display:flex;flex-direction:column;gap:4px;font-size:11px;color:#79839a;line-height:1.4}
  .tg-ai-info b{color:#ffd479;font-size:15px;font-variant-numeric:tabular-nums}
  .tg-result{
    position:absolute;inset:0;z-index:6;display:none;align-items:center;justify-content:center;
    padding:18px;background:rgba(4,5,8,.78);backdrop-filter:blur(6px);
  }
  .tg-result.on{display:flex}
  #tg.is-result .tg-pad,#tg.is-result .tg-keys{display:none}
  .tg-result .tg-btn{margin-top:4px}
  .tg-stage{flex:1 1 auto;min-height:0;width:100%;display:flex;align-items:center;justify-content:center}
  /* 联机开局：双方握手，然后进入棋盘 */
  .tg-intro{
    position:absolute;inset:0;z-index:60;display:none;flex-direction:column;
    align-items:center;justify-content:center;gap:6px;
    background:rgba(5,6,10,.86);backdrop-filter:blur(5px);
  }
  #tg.is-intro #tgIntro,#tgIntro.show{display:flex}
  #tg.is-mode-intro #tgModeIntro,#tgModeIntro.show{display:flex}
  .tg-intro{transition:opacity .32s ease}
  .tg-intro.out{opacity:0}
  .tg-duel-stage{position:relative;width:min(92vw,520px);height:180px;margin:0 0 2px}
  .tg-duel-side{
    position:absolute;top:50%;left:50%;font-size:72px;font-weight:800;line-height:1;
    will-change:transform,opacity;font-family:ui-monospace,"Noto Sans SC","Microsoft YaHei",monospace;
  }
  .tg-duel-side.you{color:#3ee0c6;text-shadow:4px 4px 0 rgba(0,0,0,.6);animation:duelYou 1.5s cubic-bezier(.2,.8,.3,1) both}
  .tg-duel-side.me{color:#ffc857;text-shadow:4px 4px 0 rgba(0,0,0,.6);animation:duelMe 1.5s cubic-bezier(.2,.8,.3,1) both}
  .tg-duel-burst{position:absolute;top:50%;left:50%;width:0;height:0;pointer-events:none}
  .tg-duel-burst i{
    position:absolute;left:0;top:0;width:var(--w,6px);height:var(--h,6px);
    margin:calc(var(--h,6px) / -2) 0 0 calc(var(--w,6px) / -2);
    background:var(--c,#3ee0c6);opacity:0;border-radius:1px;
    will-change:transform,opacity;
    animation:duelBurst .62s cubic-bezier(.15,.75,.25,1) .3s both;
  }
  .tg-duel-spark{
    position:absolute;top:50%;left:50%;width:12px;height:12px;margin:-6px 0 0 -6px;
    border-radius:50%;border:2px solid rgba(233,237,246,.45);opacity:0;pointer-events:none;
    animation:duelSpark .4s ease-out .3s both;
  }
  .tg-duel-title{
    position:absolute;top:50%;left:50%;white-space:nowrap;
    transform:translate(-50%,-50%);opacity:0;will-change:transform,opacity;
    animation:duelTitle 1.04s cubic-bezier(.32,.06,.4,1) .5s both;
  }
  .tg-duel-title span{
    display:inline-block;font-size:42px;font-weight:800;letter-spacing:.18em;color:#e9edf6;
    text-shadow:3px 3px 0 #1b2430,0 0 16px rgba(62,224,198,.16);
    animation:duelPop .2s ease-out .5s both;
  }
  .tg-mode-stage{position:relative;width:min(92vw,620px);height:210px;display:flex;align-items:center;justify-content:center}
  .tg-mode-text{
    font-size:clamp(28px,5.4vw,46px);font-weight:800;letter-spacing:.14em;color:#e9edf6;
    white-space:nowrap;will-change:transform,opacity,filter;
    text-shadow:3px 3px 0 #1b2430,0 0 18px rgba(62,224,198,.14);
  }
  .tg-mode-intro.shatter .tg-mode-text{animation:modeShatter 1.02s cubic-bezier(.2,.8,.3,1) both}
  .tg-mode-intro.retire .tg-mode-text{animation:modeRetire 1.02s cubic-bezier(.3,.8,.3,1) both}
  .tg-mode-skip{font-size:11px;color:#5b6479;letter-spacing:.14em;margin-top:8px}
  .tg-intro h3,.tg-intro p{display:none}
  #tg .tg-stage{transition:opacity .3s ease,transform .3s ease}
  #tg.is-intro .tg-stage,#tg.is-mode-intro .tg-stage{opacity:.3;transform:scale(.97)}
  @keyframes duelYou{
    0%{transform:translate(-50%,-50%) translateX(-210px) scale(.82);opacity:0}
    10%{opacity:1}
    20%{transform:translate(-50%,-50%) translateX(-30px) scale(1.06)}
    25%{transform:translate(-50%,-50%) translateX(-30px) scale(1)}
    29%{transform:translate(-50%,-50%) translateX(-48px) scale(1.2);opacity:.9}
    33%,100%{transform:translate(-50%,-50%) translateX(-76px) scale(1.42);opacity:0}
  }
  @keyframes duelMe{
    0%{transform:translate(-50%,-50%) translateX(210px) scale(.82);opacity:0}
    10%{opacity:1}
    20%{transform:translate(-50%,-50%) translateX(30px) scale(1.06)}
    25%{transform:translate(-50%,-50%) translateX(30px) scale(1)}
    29%{transform:translate(-50%,-50%) translateX(48px) scale(1.2);opacity:.9}
    33%,100%{transform:translate(-50%,-50%) translateX(76px) scale(1.42);opacity:0}
  }
  @keyframes duelBurst{
    0%{opacity:0;transform:translate(0,0) scale(.8) rotate(0)}
    6%{opacity:1}
    55%{opacity:.7}
    100%{opacity:0;transform:translate(var(--dx,60px),var(--dy,0)) scale(1) rotate(var(--r,90deg))}
  }
  @keyframes duelSpark{
    0%{opacity:.55;transform:scale(.35)}
    100%{opacity:0;transform:scale(7)}
  }
  @keyframes duelTitle{
    0%{opacity:0;transform:translate(-50%,-50%) translate(0,0) scale(.96)}
    8%{opacity:1}
    14%{transform:translate(-50%,-50%) translate(-10px,0) rotate(-2.2deg)}
    20%{transform:translate(-50%,-50%) translate(10px,0) rotate(2.2deg)}
    26%{transform:translate(-50%,-50%) translate(-8px,0) rotate(-1.6deg)}
    32%{transform:translate(-50%,-50%) translate(8px,0) rotate(1.6deg)}
    38%{transform:translate(-50%,-50%) translate(-6px,0) rotate(-1.2deg)}
    44%{transform:translate(-50%,-50%) translate(6px,0) rotate(1.2deg)}
    50%{transform:translate(-50%,-50%) translate(0,0) rotate(0)}
    56%{transform:translate(-50%,-50%) translate(0,-9px) scale(1.05)}
    64%{opacity:1;transform:translate(-50%,-50%) translate(0,0) scale(1)}
    90%{opacity:1;transform:translate(-50%,-50%) translate(0,150px) scale(.8) rotate(3.5deg)}
    100%{opacity:0;transform:translate(-50%,-50%) translate(0,214px) scale(.7) rotate(5deg)}
  }
  @keyframes duelPop{
    0%{opacity:0;transform:scale(.62)}
    100%{opacity:1;transform:scale(1)}
  }
  @keyframes modeShatter{
    0%{opacity:0;transform:scale(.9)}
    10%{opacity:1;transform:scale(1.02)}
    24%{transform:scale(1)}
    32%{transform:scale(1.05)}
    37%{opacity:1;transform:scale(1.16)}
    49%,100%{opacity:0;transform:scale(1.44)}
  }
  @keyframes modeRetire{
    0%{opacity:0;transform:translateY(18px) scale(.96)}
    12%{opacity:1;transform:translateY(0) scale(1)}
    55%{opacity:1;transform:translateY(0) scale(1)}
    100%{opacity:0;transform:translateY(-54px) scale(.8);filter:blur(1.5px)}
  }
  #tgCanvas{
    max-width:min(96vw,560px);max-height:100%;width:auto;height:auto;border-radius:12px;display:block;
    box-shadow:0 22px 60px -26px #000,0 0 0 1px rgba(62,224,198,.09);
    touch-action:none;
  }
  .tg-pad{
    width:100%;max-width:560px;display:flex;justify-content:space-between;align-items:flex-end;
    gap:10px;flex:0 0 auto;touch-action:none;
  }
  .pad-side{display:grid;gap:8px;width:calc(50% - 5px)}
  .pad-left{grid-template-columns:1fr 1fr}
  .pad-left [data-act="down"]{grid-column:1 / -1}
  .pad-right{grid-template-columns:1fr 1fr}
  .pad-right [data-act="cw"]{grid-column:1 / -1;height:64px}
  .tg-pad button{
    height:52px;border-radius:13px;border:1px solid #232838;background:linear-gradient(180deg,#171a23,#101219);
    color:#e9edf6;font:inherit;font-size:15px;font-weight:600;cursor:pointer;touch-action:none;
    transition:transform .06s,background .12s,border-color .12s;
  }
  .tg-pad button:active{transform:scale(.97);background:#1c2029;border-color:rgba(62,224,198,.4)}
  .tg-keys{font-size:9px;line-height:1.6;color:#5b6479;text-align:center;letter-spacing:.02em;flex:0 0 auto;padding:0 4px}
  .tg-over{display:none;width:100%;max-width:560px;flex-direction:column;gap:8px;flex:0 0 auto}
  #tg.is-over .tg-pad,#tg.is-over .tg-keys{display:none}
  #tg.is-over .tg-over{display:flex}
  .tg-over-tip{font-size:12px;color:#ff8b96;text-align:center;letter-spacing:.1em}
  .tg-over-btns{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .tg-over-btns button,.tg-cmds button,.tg-ghost{
    height:52px;border-radius:13px;border:1px solid #232838;background:#12141b;color:#e9edf6;
    font:inherit;font-size:15px;font-weight:600;cursor:pointer;
  }
  .tg-over-btns button:first-child{border-color:rgba(62,224,198,.42);color:#c9fff6;background:linear-gradient(180deg,rgba(62,224,198,.14),rgba(62,224,198,.04))}
  .tg-pause{
    position:absolute;inset:0;z-index:5;display:none;align-items:center;justify-content:center;
    padding:18px;background:rgba(4,5,8,.76);backdrop-filter:blur(6px);
  }
  .tg-pause.on{display:flex}
  .tg-card{
    width:100%;max-width:380px;max-height:calc(100% - 12px);overflow-y:auto;scrollbar-width:none;
    background:#12141b;border:1px solid #232838;border-radius:18px;padding:18px;
    display:flex;flex-direction:column;gap:10px;box-shadow:0 30px 80px -30px #000;
  }
  .tg-card::-webkit-scrollbar{display:none}
  .tg-card h3{margin:0;font-size:17px;letter-spacing:.08em}
  .tg-note{margin:0;font-size:11px;line-height:1.6;color:#79839a}
  .tg-slots{display:flex;flex-direction:column;gap:8px}
  .tg-slot{display:flex;align-items:center;justify-content:space-between;gap:10px;background:#0d0f16;border:1px solid #232838;border-radius:12px;padding:8px 10px}
  .tg-slot-t{display:flex;flex-direction:column;gap:2px;min-width:0}
  .tg-slot-t b{font-size:12px;letter-spacing:.12em;color:#aab3c6}
  .tg-slot-t span{font-size:11px;color:#5b6479;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .tg-slot-b{display:flex;gap:6px;flex:0 0 auto}
  .tg-slot-b button{height:34px;padding:0 10px;border-radius:9px;border:1px solid #232838;background:#171a23;color:#c6cdda;font:inherit;font-size:12px;cursor:pointer}
  .tg-slot-b button:disabled{opacity:.3;pointer-events:none}
  .tg-cmds{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .tg-cmds button{height:46px;font-size:13px;font-weight:500}
  .tg-skin-label{font-size:10px;letter-spacing:.14em;color:#5b6479;margin:2px 0 -2px}
  .tg-skins{display:grid;grid-template-columns:repeat(5,1fr);gap:6px}
  .tg-skin{
    display:flex;flex-direction:column;align-items:center;gap:4px;padding:6px 2px;
    border:1px solid #232838;border-radius:11px;background:#0d0f16;color:#79839a;
    font:inherit;font-size:10px;cursor:pointer;transition:.15s;
  }
  .tg-skin canvas{width:40px;height:40px;display:block}
  .tg-skin.on{border-color:rgba(62,224,198,.55);background:rgba(62,224,198,.1);color:#bff7ee}
  .tg-ghost{height:42px;font-size:13px;font-weight:400;color:#79839a;background:transparent}
  .tg-toast{
    position:absolute;left:50%;bottom:calc(env(safe-area-inset-bottom) + 22px);z-index:8;
    transform:translate(-50%,14px);opacity:0;pointer-events:none;transition:.2s;
    background:#181c26;border:1px solid #232838;color:#e9edf6;font-size:13px;
    padding:10px 16px;border-radius:12px;white-space:nowrap;
  }
  .tg-toast.on{opacity:1;transform:translate(-50%,0)}

  /* 横屏（含强制旋转）：左右手各占一边，棋盘在中间 */
  html.land .tg-pad{
    position:fixed;left:0;right:0;bottom:calc(env(safe-area-inset-bottom) + 8px);
    max-width:none;padding:0 12px;display:block;pointer-events:none;
  }
  html.land .pad-side{
    position:absolute;bottom:0;pointer-events:auto;width:auto;
    grid-template-columns:repeat(2,minmax(58px,84px));gap:8px;
  }
  html.land .pad-left{left:12px}
  html.land .pad-right{right:12px}
  html.land .tg-pad button{height:64px;font-size:14px}
  html.land .tg-stage{padding:0 152px}
  html.land .tg-keys{display:none}
  html.land .tg-toast{bottom:calc(env(safe-area-inset-bottom) + 120px)}
  /* 内容自己转 90° 时，把按键条放到物理屏幕的底边：
     正转（cw）时内容右边=物理下边，反转（ccw）时内容左边=物理下边 */
  html.rot .tg-pad{
    position:fixed;top:0;bottom:0;left:auto;right:0;width:168px;
    display:flex;flex-direction:column-reverse;justify-content:center;gap:12px;
    padding:10px;max-width:none;pointer-events:none;
  }
  html.rot.rot-ccw .tg-pad{left:0;right:auto;flex-direction:column}
  html.rot .pad-side{position:static;width:100%;grid-template-columns:1fr 1fr;gap:8px}
  html.rot .tg-pad button{height:56px;font-size:13px}
  html.rot .tg-stage{padding:0 178px}
  html.rot #tgCanvas{max-width:min(80vw,640px)}
  `;

  const HTML = `
    <div class="tg-bar">
      <button class="tg-btn" data-cmd="exit">返回</button>
      <div class="tg-title" id="tgMode">合体债 · 单人</div>
      <button class="tg-btn" data-cmd="pause">暂停</button>
    </div>
    <div class="tg-vs">
      <span>你 <b id="vsYou">0</b></span>
      <span>对手 <b id="vsOpp">0</b></span>
      <span class="tg-vs-state" id="vsState">准备</span>
    </div>
    <div class="tg-stage"><canvas id="tgCanvas" width="480" height="320"></canvas></div>
    <div class="tg-ai" id="tgAI">
      <canvas id="aiCanvas" width="96" height="96"></canvas>
      <div class="tg-ai-info">
        <div>AI <b id="aiScore">0</b></div>
        <div id="aiInfo">消 0 · 活</div>
        <div id="aiDebt"></div>
      </div>
    </div>
    <div class="tg-pad">
      <div class="pad-side pad-left">
        <button data-act="left">◀</button>
        <button data-act="right">▶</button>
        <button data-act="down">${T('▼ 软降')}</button>
      </div>
      <div class="pad-side pad-right">
        <button data-act="cw">${T('↻ 转')}</button>
        <button data-act="drop">${T('⤓ 硬降')}</button>
        <button data-act="hold">${T('暂存')}</button>
      </div>
    </div>
    <div class="tg-keys">${T('←→ 移动 · ↓ 软降 · 空格 硬降 · ↑/X 转 · Z 反着转 · C 暂存 · P 暂停 · R 重开×2')}</div>
    <div class="tg-over">
      <div class="tg-over-tip">债还不完，本局结束</div>
      <div class="tg-over-btns">
        <button data-cmd="restart">重开 R</button>
        <button data-cmd="exit">返回</button>
      </div>
    </div>
    <div class="tg-result" id="tgResult">
      <div class="tg-card">
        <h3 id="resTitle">对局结束</h3>
        <p class="tg-note" id="resText"></p>
        <button class="tg-btn" data-cmd="exit">返回菜单</button>
      </div>
    </div>
    <div class="tg-pause" id="tgPause">
      <div class="tg-card">
        <div class="tg-pause-head">
          <h3>暂停</h3>
          <span class="tg-pause-clock" id="tgClock">--:--</span>
        </div>
        <div class="tg-slots" id="tgSlots"></div>
        <div class="tg-cmds">
          <button data-cmd="resume">继续</button>
          <button data-cmd="restart" id="tgRestart">重开</button>
        </div>
        <button class="tg-ghost" data-cmd="exit">退出到菜单</button>
      </div>
    </div>
    <div class="tg-intro" id="tgIntro">
      <div class="tg-duel-stage">
        <span class="tg-duel-side you">你</span>
        <span class="tg-duel-side me">我</span>
        <div class="tg-duel-burst" aria-hidden="true">
          <i style="--dx:-96px;--dy:-56px;--r:70deg;--c:#3ee0c6;--w:9px;--h:9px"></i>
          <i style="--dx:-64px;--dy:-80px;--r:130deg;--c:#3ee0c6;--w:7px;--h:7px"></i>
          <i style="--dx:-118px;--dy:8px;--r:200deg;--c:#3ee0c6;--w:9px;--h:9px"></i>
          <i style="--dx:-52px;--dy:58px;--r:250deg;--c:#3ee0c6;--w:10px;--h:10px"></i>
          <i style="--dx:-18px;--dy:-104px;--r:300deg;--c:#7fb4ff;--w:7px;--h:7px"></i>
          <i style="--dx:88px;--dy:-66px;--r:40deg;--c:#ffc857;--w:10px;--h:10px"></i>
          <i style="--dx:62px;--dy:-94px;--r:100deg;--c:#ffc857;--w:7px;--h:7px"></i>
          <i style="--dx:112px;--dy:4px;--r:190deg;--c:#ffc857;--w:9px;--h:9px"></i>
          <i style="--dx:46px;--dy:62px;--r:260deg;--c:#ffc857;--w:10px;--h:10px"></i>
          <i style="--dx:16px;--dy:-108px;--r:320deg;--c:#e9edf6;--w:7px;--h:7px"></i>
          <i style="--dx:-78px;--dy:34px;--r:160deg;--c:#ffc857;--w:6px;--h:6px"></i>
          <i style="--dx:78px;--dy:38px;--r:80deg;--c:#3ee0c6;--w:6px;--h:6px"></i>
          <i style="--dx:-34px;--dy:76px;--r:220deg;--c:#7fb4ff;--w:7px;--h:7px"></i>
          <i style="--dx:34px;--dy:78px;--r:300deg;--c:#ffc857;--w:7px;--h:7px"></i>
          <i style="--dx:0;--dy:-66px;--r:10deg;--c:#3ee0c6;--w:6px;--h:6px"></i>
          <i style="--dx:0;--dy:66px;--r:350deg;--c:#e9edf6;--w:6px;--h:6px"></i>
          <i style="--dx:-138px;--dy:-18px;--r:110deg;--c:#3ee0c6;--w:4px;--h:16px"></i>
          <i style="--dx:138px;--dy:-12px;--r:70deg;--c:#ffc857;--w:4px;--h:16px"></i>
          <i style="--dx:-60px;--dy:-40px;--r:30deg;--c:#3ee0c6;--w:13px;--h:6px"></i>
          <i style="--dx:64px;--dy:-36px;--r:25deg;--c:#ffc857;--w:13px;--h:6px"></i>
        </div>
        <b class="tg-duel-spark"></b>
        <div class="tg-duel-title"><span>决一死战</span></div>
      </div>
    </div>
    <div class="tg-intro tg-mode-intro" id="tgModeIntro">
      <div class="tg-mode-stage">
        <div class="tg-mode-text" id="tgModeText"></div>
        <div class="tg-duel-burst" id="tgModeBurst" aria-hidden="true"></div>
      </div>
      <div class="tg-mode-skip">点一下跳过</div>
    </div>
    <div class="tg-toast" id="tgToast"></div>
    <input id="tgFile" type="file" accept="application/json,.json" hidden>
  `;

  function build() {
    if (built) return;
    const style = document.createElement('style');
    style.textContent = CSS;
    document.head.appendChild(style);

    root = document.createElement('div');
    root.id = 'tg';
    root.innerHTML = HTML;
    document.body.appendChild(root);
    if (window.TetrisI18n) window.TetrisI18n.apply(root);

    canvas = $('#tgCanvas');
    ctx = canvas.getContext('2d');
    stageEl = root.querySelector('.tg-stage');
    pauseLayer = $('#tgPause');
    slotsBox = $('#tgSlots');
    skinsBox = $('#tgSkins');
    buildPauseSkins();
    toastEl = $('#tgToast');
    fileInput = $('#tgFile');
    modeEl = $('#tgMode');
    overBar = root.querySelector('.tg-over');
    resultEl = $('#tgResult');
    vsEl = root.querySelector('.tg-vs');
    vsYou = $('#vsYou');
    vsOpp = $('#vsOpp');
    vsState = $('#vsState');
    aiCanvas = $('#aiCanvas');
    aiCtx = aiCanvas ? aiCanvas.getContext('2d') : null;
    aiScoreEl = $('#aiScore');
    aiInfoEl = $('#aiInfo');
    aiDebtEl = $('#aiDebt');
    clockEl = $('#tgClock');
    tickClock();
    if (clockTimer) clearInterval(clockTimer);
    clockTimer = setInterval(tickClock, 1000);

    root.addEventListener('click', onClick);
    root.addEventListener('pointerdown', onPadDown);
    root.addEventListener('pointerup', onPadUp);
    root.addEventListener('pointercancel', onPadUp);
    const modeOverlay = $('#tgModeIntro');
    if (modeOverlay) modeOverlay.addEventListener('pointerdown', skipModeIntro);
    canvas.addEventListener('pointerdown', onCanvasDown);
    fileInput.addEventListener('change', onImportFile);

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('resize', fit);
    document.addEventListener('visibilitychange', function () {
      if (document.hidden && running && !paused && !over && !modeIntro) togglePause(true);
    });

    built = true;
  }

  /* ---------------- 启动 / 退出 ---------------- */

  function endDuelIntro() {
    if (!multi || multi.introOut) return;
    multi.introOut = true;
    const intro = $('#tgIntro');
    if (!root || !intro) {
      if (root) root.classList.remove('is-intro');
      return;
    }
    intro.classList.add('show');
    intro.classList.add('out');
    root.classList.remove('is-intro');
    setTimeout(function () {
      intro.classList.remove('out');
      intro.classList.remove('show');
    }, 380);
  }

  const MODE_INTRO_TEXT = {
    solo: '欠债还钱天经地义',
    classic: '经典永不过时',
    ai: '来！咱俩练练！',
    spectate: '不是你死就是他亡'
  };

  function fillModeBurst(box) {
    if (!box) return;
    const colors = ['#3ee0c6', '#ffc857', '#e9edf6', '#7fb4ff'];
    box.innerHTML = '';
    for (let i = 0; i < 24; i++) {
      const ang = Math.random() * Math.PI * 2;
      const dist = 70 + Math.random() * 120;
      const w = 4 + Math.random() * 6;
      const h = Math.random() < 0.3 ? w * (1.8 + Math.random()) : w;
      const el = document.createElement('i');
      el.style.setProperty('--dx', (Math.cos(ang) * dist).toFixed(0) + 'px');
      el.style.setProperty('--dy', (Math.sin(ang) * dist * 0.6).toFixed(0) + 'px');
      el.style.setProperty('--r', (Math.random() * 240 - 120).toFixed(0) + 'deg');
      el.style.setProperty('--c', colors[i % colors.length]);
      el.style.setProperty('--w', w.toFixed(0) + 'px');
      el.style.setProperty('--h', h.toFixed(0) + 'px');
      box.appendChild(el);
    }
  }

  function shouldShowModeIntro() {
    const mode = settings.intro || 'every';
    if (mode === 'off') return false;
    if (mode === 'first') {
      if (modeIntroSeen) return false;
      modeIntroSeen = true;
      return true;
    }
    return true;
  }

  function showModeIntro(kind) {
    const text = MODE_INTRO_TEXT[kind];
    const el = $('#tgModeIntro');
    if (!text || !el) return;
    introStamp += 1;
    modeIntro = null;
    const txt = $('#tgModeText');
    if (txt) txt.textContent = T(text);
    el.classList.remove('out', 'show', 'shatter', 'retire');
    const burst = $('#tgModeBurst');
    if (burst) burst.innerHTML = '';
    void el.offsetWidth;
    el.classList.add('show');
    el.classList.add(kind === 'classic' ? 'retire' : 'shatter');
    if (burst && kind !== 'classic') fillModeBurst(burst);
    if (root) {
      root.classList.remove('is-intro');
      root.classList.add('is-mode-intro');
    }
    const now = performance.now();
    modeIntro = { kind: kind, fadeAt: now + 820, endAt: now + 1150, fading: false };
  }

  function endModeIntro() {
    if (!modeIntro || modeIntro.fading) return;
    modeIntro.fading = true;
    const intro = $('#tgModeIntro');
    if (!intro || !root) return;
    intro.classList.add('out');
    root.classList.remove('is-mode-intro');
    const stamp = ++introStamp;
    setTimeout(function () {
      if (introStamp === stamp && !modeIntro) intro.classList.remove('show', 'out');
    }, 360);
  }

  function skipModeIntro() {
    if (!modeIntro) return;
    modeIntro.fadeAt = 0;
    modeIntro.endAt = 0;
  }

  function dayPart(h) {
    if (h < 5) return '凌晨';
    if (h < 9) return '早上';
    if (h < 11) return '上午';
    if (h < 13) return '中午';
    if (h < 18) return '下午';
    return '晚上';
  }

  function tickClock() {
    if (!clockEl) return;
    let text = '';
    try {
      if (window.TetrisHost && typeof window.TetrisHost.timeText === 'function') {
        text = window.TetrisHost.timeText();
      }
    } catch (e) {}
    if (!text) {
      try {
        text = new Date().toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
      } catch (e) {
        const d = new Date();
        text = String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
      }
    }
    if (EN()) {
      var en = String(text)
        .replace(/凌晨|早上|上午/g, 'AM')
        .replace(/中午|下午|傍晚|晚上/g, 'PM')
        .trim();
      var ampm = en.match(/^(AM|PM)\s*(.+)$/i);
      if (ampm) en = ampm[2].trim() + ' ' + ampm[1].toUpperCase();
      clockEl.textContent = en;
      return;
    }
    // 系统 12 小时制会自带「上午/下午」或 AM/PM；前缀用更细的时段，先去掉旧的再拼
    text = String(text).replace(/凌晨|早上|上午|中午|下午|傍晚|晚上|A\.?M\.?|P\.?M\.?/gi, '').trim();
    clockEl.textContent = dayPart(new Date().getHours()) + ' ' + text;
  }

  function start(payload) {
    payload = payload || {};
    const mode = payload.mode || 'solo';
    build();
    settings = Object.assign({ sound: true, fps: '60', skin: 'solid', intro: 'every' }, payload.settings || {});
    settings.skin = skinDef(settings.skin).id;
    applyFps();
    if (typeof payload.seed === 'number' && isFinite(payload.seed)) startSeed = payload.seed >>> 0;
    net = payload.net || null;
    if (mode === 'spectate') return startSpectate();

    aiMode = (mode === 'ai');
    aiState = null;
    multi = net ? {
      mode: mode,
      opponent: { score: 0, clears: 0, debt: 0, dead: false, name: payload.opponentName || '对手' },
      started: false,
      settled: false,
      result: null,
      startAtLocal: 0,
      introOut: false,
      introFadeAt: 0,
      lastState: 0
    } : null;

    const labelMap = EN() ? {
      solo: 'Solo', casual: 'Casual · Combo', zen: 'Zen', resume: 'Continue',
      resumeCasual: 'Continue Casual', resumeZen: 'Continue Zen',
      lan_parallel: 'Parallel', lan_battle: 'Battle', ai: 'Versus AI', classic: 'Classic'
    } : {
      solo: '单人', casual: '常驻 · 连击', zen: '禅模式', resume: '继续',
      resumeCasual: '继续常驻', resumeZen: '继续禅模式',
      lan_parallel: '并行赛', lan_battle: '干扰战', ai: '打 AI', classic: '原版'
    };
    modeLabel = labelMap[mode] || (EN() ? 'Solo' : '单人');
    if (payload.bt) modeLabel = EN()
      ? (mode === 'lan_battle' ? 'Bluetooth · Battle' : 'Bluetooth · Parallel')
      : (mode === 'lan_battle' ? '蓝牙 · 干扰战' : '蓝牙 · 并行赛');
    if (mode === 'ai') {
      const d = payload.difficulty || 'normal';
      if (EN()) {
        const en = { easy: 'Easy', normal: 'Normal', hard: 'Hard' }[d] || 'Normal';
        const tv = { easy: '0.3', normal: '0.5', hard: '1.0' }[d] || '0.5';
        modeLabel += ' · ' + en + ' (temp ' + tv + ')';
        if (payload.aiAuto) modeLabel += ' · Auto';
      } else {
        const tn = { easy: '简单', normal: '普通', hard: '困难' }[d] || '普通';
        const tv = { easy: '0.3', normal: '0.5', hard: '1.0' }[d] || '0.5';
        modeLabel += ' · ' + tn + '（温度 ' + tv + '）';
        if (payload.aiAuto) modeLabel += ' · 自动';
      }
    }
    if (modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel;
    }

    try { highScore = parseInt(localStorage.getItem(LS.high) || '0', 10) || 0; } catch (e) { highScore = 0; }

    if (window.Cues) {
      try {
        window.Cues.setSound(!!settings.sound);
        window.Cues.selfCheck();
      } catch (e) {}
    }

    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    taps = { n: 0, t: 0 };
    dasDir = 0;

    if (multi) {
      const classicRules = payload.rules === 'classic';
      game = classicRules
        ? new E.Tetris({ seed: (payload.seed >>> 0) || 1, classic: true, cols: 10, rows: 20 })
        : mk({ seed: (payload.seed >>> 0) || 1, carryDebt: 0 });
      game.suppressFusion = (mode === 'lan_battle' && !classicRules);
      net.onMessage = onNetMessage;
      net.onError = function () {
        if (multi && !multi.settled) settleMulti('disconnect');
      };
      const delay = Math.max(0, (payload.startAt || 0) - (Date.now() + (net.offset || 0)));
      multi.startAtLocal = performance.now() + delay;
      multi.started = delay <= 0;
      paused = !multi.started;
    } else if (aiMode) {
      const seed = (payload.seed >>> 0) || 1;
      game = mk({ seed: seed, carryDebt: 0 });
      aiState = {
        game: mk({ seed: seed, carryDebt: 0 }),
        difficulty: payload.difficulty || 'normal',
        nextStep: performance.now() + 600,
        dead: false
      };
      aiState.game.noGravity = true;
      paused = false;
    } else if (mode === 'classic') {
      // 原版：10×20，标准计分，没有债/合体块/旋转/方向块
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({ seed: seed, classic: true, cols: 10, rows: 20 });
      paused = false;
    } else if (mode === 'casual') {
      // 常驻：10×10，没有债/合体块，连续消行叠连击倍数
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({ seed: seed, casual: true, cols: 10, rows: 10 });
      paused = false;
    } else if (mode === 'zen') {
      // 禅模式：10×12，5/10 分钟倒计时，堆满自动整理，不会死
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = new E.Tetris({
        seed: seed, zen: true,
        zenMinutes: payload.zenMinutes === 10 ? 10 : 5,
        cols: 10, rows: 12
      });
      paused = false;
    } else {
      let resumed = false;
      if (mode === 'resume') resumed = loadAutoIntoGame(!!payload.classic, false);
      if (mode === 'resumeCasual') resumed = loadAutoIntoGame(false, true);
      if (mode === 'resumeZen') resumed = loadAutoIntoGame(false, false, true);
      if (!resumed) {
        if (mode === 'resumeCasual') game = new E.Tetris({ seed: (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0, casual: true, cols: 10, rows: 10 });
        else if (mode === 'resumeZen') game = new E.Tetris({ seed: (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0, zen: true, zenMinutes: 5, cols: 10, rows: 12 });
        else game = makeGame(readCarry());
        if (mode === 'resume' || mode === 'resumeCasual' || mode === 'resumeZen') toast(EN() ? 'Save could not be read — starting a new run' : '存档读不了，先开新局');
      }
    }

    if (game && game.zen && modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + T('禅模式') + ' · ' + game.zenMinutes + (EN() ? ' min' : ' 分钟');
    }

    try {
      highScore = parseInt(localStorage.getItem(highKey()) || '0', 10) || 0;
    } catch (e) { highScore = 0; }
    if ((mode === 'resume' || mode === 'resumeCasual' || mode === 'resumeZen') && modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeLabel = game.zen ? ('禅模式 · ' + game.zenMinutes + ' 分钟')
        : (game.casual ? '继续常驻' : (game.classic ? '经典玩法' : '继续'));
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel;
    }
    if (multi && modeEl && game && game.classic) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeLabel = EN()
        ? 'Classic · ' + (multi.mode === 'lan_battle' ? 'Battle' : 'Parallel')
        : '经典 · ' + (multi.mode === 'lan_battle' ? '干扰战' : '并行赛');
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel;
    }

    root.classList.add('on');
    root.classList.remove('is-over');
    root.classList.remove('is-result');
    root.classList.remove('is-mode-intro');
    const oldModeIntro = $('#tgModeIntro');
    if (oldModeIntro) oldModeIntro.classList.remove('show', 'out', 'shatter', 'retire');
    modeIntro = null;
    if (multi && !multi.started) {
      const introEl = $('#tgIntro');
      if (introEl) introEl.classList.remove('out', 'show');
      root.classList.add('is-intro');
      const leftMs = multi.startAtLocal - performance.now();
      multi.introFadeAt = performance.now() + Math.max(320, Math.min(1500, leftMs - 700));
      const sub = $('#tgIntroSub');
      if (sub) sub.textContent = EN() ? 'Opponent: ' + (multi.opponent.name || 'Opponent') + ' · both connected' : '对手：' + (multi.opponent.name || '对手') + ' · 双方已握手';
    } else {
      root.classList.remove('is-intro');
    }
    root.classList.toggle('is-multi', !!multi);
    root.classList.toggle('is-ai', !!aiMode);
    root.classList.toggle('is-classic', !!(game && game.classic));
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    if (multi || aiMode) updateVs();
    resetRestartButton();
    frameAcc = 0;
    lastInputAt = performance.now();
    idleHintShown = false;
    layoutFor(game);
    fit();
    if (!multi && MODE_INTRO_TEXT[mode] && shouldShowModeIntro()) showModeIntro(mode);
    lastFrame = 0;
    running = true;
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
    return true;
  }

  /* ---------------- AI 观战：两个随机 AI 自己打 ---------------- */

  function spectateSeed() {
    return (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
  }

  function makeSpectateEngine() {
    const g = new E.Tetris({ seed: spectateSeed(), carryDebt: 0 });
    g.noGravity = true;          // 由 AI 直接落子
    g.rotateEnabled = false;     // 观战不转场，画面稳一点
    return g;
  }

  function resetSpectate() {
    spectate = spectate || { round: 0 };
    spectate.a = makeSpectateEngine();
    spectate.b = makeSpectateEngine();
    spectate.accA = 0;
    spectate.accB = 0;
    spectate.over = false;
    spectate.winner = '';
    spectate.nextAt = 0;
    spectate.round = (spectate.round || 0) + 1;
  }

  function startSpectate() {
    build();
    multi = null;
    aiMode = false;
    aiState = null;
    game = null;
    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    resetSpectate();
    modeLabel = T('AI 观战');
    if (modeEl) {
      const ver = (window.TetrisVersion && window.TetrisVersion.version) || '0.3';
      modeEl.textContent = T('合体债') + ' v' + ver + ' · ' + modeLabel;
    }
    root.classList.add('on');
    root.classList.remove('is-over', 'is-result', 'is-multi', 'is-ai', 'is-classic');
    root.classList.add('is-spectate');
    root.classList.remove('is-mode-intro');
    const oldModeIntro = $('#tgModeIntro');
    if (oldModeIntro) oldModeIntro.classList.remove('show', 'out', 'shatter', 'retire');
    modeIntro = null;
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    W = 520;
    H = 360;
    BW = W;
    BOARD = H;
    PX = W;
    if (canvas) { canvas.width = 1; canvas.height = 1; }
    fit();
    if (shouldShowModeIntro()) showModeIntro('spectate');
    lastFrame = 0;
    running = true;
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(frame);
    return true;
  }

  function AI_step(g, diff) {
    if (!g || g.status !== 'playing') return;
    const AI = window.TetrisAI;
    if (!AI) return;
    const mv = AI.choose(g, diff || 'normal');
    if (mv) AI.apply(g, mv);
    else g.gameOver('blockout');
  }

  function stepSpectate(dt) {
    const sp = spectate;
    if (!sp) return;
    const now = performance.now();
    if (sp.over) {
      if (now >= sp.nextAt) resetSpectate();
      return;
    }
    sp.accA += dt;
    sp.accB += dt;
    if (sp.accA >= 500) { sp.accA = 0; AI_step(sp.a, 'hard'); }
    if (sp.accB >= 500) { sp.accB = 0; AI_step(sp.b, 'hard'); }
    const aDead = sp.a.status === 'over';
    const bDead = sp.b.status === 'over';
    if (aDead || bDead) {
      sp.over = true;
      if (aDead && bDead) sp.winner = sp.a.score === sp.b.score ? '平局' : (sp.a.score > sp.b.score ? 'AI-1' : 'AI-2');
      else sp.winner = aDead ? 'AI-2' : 'AI-1';
      sp.nextAt = now + 3500;
    }
  }

  function drawSpectateBoard(g, x, y, cell, name, accent) {
    const bw = cell * 10;
    ctx.save();
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = accent;
    ctx.font = '700 13px ' + FONT;
    ctx.fillText(name, x, y - 34);
    ctx.fillStyle = '#e9edf6';
    ctx.font = '700 20px ' + FONT;
    ctx.textAlign = 'right';
    ctx.fillText(fmtScore(g.score), x + bw, y - 34);
    ctx.textAlign = 'left';

    ctx.fillStyle = '#0a0c12';
    ctx.fillRect(x, y, bw, bw);
    ctx.strokeStyle = 'rgba(255,255,255,.04)';
    ctx.lineWidth = 1;
    for (let i = 1; i < 10; i++) {
      ctx.beginPath(); ctx.moveTo(x + i * cell + 0.5, y); ctx.lineTo(x + i * cell + 0.5, y + bw); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x, y + i * cell + 0.5); ctx.lineTo(x + bw, y + i * cell + 0.5); ctx.stroke();
    }
    for (let yy = 0; yy < g.rows; yy++) {
      for (let xx = 0; xx < g.cols; xx++) {
        const c = g.board[yy][xx];
        if (!c) continue;
        const px = x + xx * cell, py = y + yy * cell;
        let col = '#39415a';
        if (c.k === 'p') col = '#4a2630';
        else if (c.k === 'n') col = cellColor(c.t);
        paintCellOn(ctx, px, py, cell, col);
      }
    }
    if (g.piece && g.status === 'playing') {
      const cells = g.pieceCells();
      const col = g.piece.type === 'ARROW' ? '#f2f5ff' : cellColor(g.piece.type);
      for (let i = 0; i < cells.length; i++) {
        const px = x + cells[i][0] * cell, py = y + cells[i][1] * cell;
        paintCellOn(ctx, px, py, cell, col);
      }
    }
    ctx.strokeStyle = 'rgba(255,255,255,.10)';
    ctx.strokeRect(x + 0.5, y + 0.5, bw - 1, bw - 1);

    ctx.fillStyle = '#79839a';
    ctx.font = '11px ' + FONT;
    ctx.fillText(EN() ? g.clears + ' lines · Lv ' + g.lockLevel + (g.debt > 0 ? ' · debt -' + g.debt : ' · debt 0')
      : '消 ' + g.clears + ' · 等级 ' + g.lockLevel + (g.debt > 0 ? ' · 债 -' + g.debt : ' · 债 0'), x, y + bw + 18);
    ctx.restore();
  }

  function drawSpectate(now) {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#08090d';
    ctx.fillRect(0, 0, W, H);

    const cell = 18;
    const bw = cell * 10;
    const gap = 42;
    const x0 = Math.round((W - (bw * 2 + gap)) / 2);
    const y0 = 96;
    drawSpectateBoard(spectate.a, x0, y0, cell, EN() ? 'AI-1 · random' : 'AI-1 · 随机', '#3ee0c6');
    drawSpectateBoard(spectate.b, x0 + bw + gap, y0, cell, EN() ? 'AI-2 · random' : 'AI-2 · 随机', '#ff9f43');

    ctx.save();
    ctx.textAlign = 'center';
    ctx.fillStyle = '#5b6479';
    ctx.font = '700 12px ' + FONT;
    ctx.fillText('VS', W / 2, y0 + 84);
    ctx.fillStyle = '#ffd479';
    ctx.font = '700 22px ' + FONT;
    ctx.fillText(EN() ? 'Round ' + spectate.round : '第 ' + spectate.round + ' 局', W / 2, 42);
    if (spectate.over) {
      ctx.fillStyle = '#fff';
      ctx.font = '700 18px ' + FONT;
      ctx.fillText(EN() ? spectate.winner + ' wins' : spectate.winner.replace('AI-', 'AI-') + ' 赢', W / 2, y0 + bw + 62);
      ctx.fillStyle = '#79839a';
      ctx.font = '11px ' + FONT;
      ctx.fillText(EN() ? 'Next round in 3s' : '3 秒后自动下一局', W / 2, y0 + bw + 82);
    } else {
      ctx.fillStyle = '#79839a';
      ctx.font = '11px ' + FONT;
      ctx.fillText(EN() ? 'Two random AIs play · sit back and watch' : '两个随机 AI 自己打 · 双手可以歇着', W / 2, y0 + bw + 62);
    }
    ctx.restore();
  }

  function makeGame(carry) {
    const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
    return mk({ seed: seed, carryDebt: Math.max(0, carry | 0) });
  }

  function loadAutoIntoGame(wantClassic, wantCasual, wantZen) {
    const key = wantZen ? LS.zenAuto
      : (wantCasual ? LS.autoCasual : (wantClassic ? LS.autoClassic : LS.auto));
    const data = readJSON(key);
    if (!data) return false;
    const g = data.classic
      ? new E.Tetris({ seed: (data.seed >>> 0) || 1, classic: true, cols: data.cols || 10, rows: data.rows || 20 })
      : (data.zen
        ? new E.Tetris({ seed: (data.seed >>> 0) || 1, zen: true, zenMinutes: data.zenMinutes || 5, cols: data.cols || 10, rows: data.rows || 12 })
        : (data.casual
          ? new E.Tetris({ seed: (data.seed >>> 0) || 1, casual: true, cols: data.cols || 10, rows: data.rows || 10 })
          : mk({ seed: (data.seed >>> 0) || 1 })));
    if (g.loadJSON(data)) return false;
    game = g;
    return true;
  }

  function exitToMenu() {
    if (game && game.status === 'playing' && !over) saveAuto();
    spectate = null;
    if (root) root.classList.remove('is-spectate');
    if (multi) {
      if (net) { try { net.leave(); } catch (e) {} }
      net = null;
      multi = null;
    }
    aiMode = false;
    aiState = null;
    modeIntro = null;
    introStamp += 1;
    running = false;
    cancelAnimationFrame(raf);
    raf = 0;
    if (root) {
      root.classList.remove('on');
      root.classList.remove('is-over');
      root.classList.remove('is-multi');
      root.classList.remove('is-ai');
      root.classList.remove('is-result');
      root.classList.remove('is-intro');
      root.classList.remove('is-mode-intro');
      const mi = $('#tgModeIntro');
      if (mi) mi.classList.remove('show', 'out', 'shatter', 'retire');
    }
    if (pauseLayer) pauseLayer.classList.remove('on');
    if (resultEl) resultEl.classList.remove('on');
    paused = false;
    dispatch('tetris-exit');
    dispatch('tetris-save-change');
  }

  function restartGame() {
    const wasClassic = !!(game && game.classic);
    const wasZen = !!(game && game.zen);
    const wasCasual = !!(game && game.casual && !wasZen);
    const carry = over ? (game.carryDebt || 0)
      : (game && game.debt > 0 ? game.debt : readCarry());
    if (settings.skinMode === 'auto') settings.skin = randomSkin(settings.skin);
    if (wasClassic || wasCasual || wasZen) {
      const seed = (startSeed !== null) ? startSeed : (Date.now() ^ Math.floor(Math.random() * 0xFFFFFFF)) >>> 0;
      game = wasClassic
        ? new E.Tetris({ seed: seed, classic: true, cols: 10, rows: 20 })
        : (wasZen
          ? new E.Tetris({ seed: seed, zen: true, zenMinutes: game.zenMinutes, cols: 10, rows: 12 })
          : new E.Tetris({ seed: seed, casual: true, cols: 10, rows: 10 }));
    } else {
      game = makeGame(carry);
    }
    layoutFor(game);
    paused = false;
    over = false;
    overInfo = null;
    effects = [];
    taps = { n: 0, t: 0 };
    dasDir = 0;
    frameAcc = 0;
    resetRestartButton();
    lastInputAt = performance.now();
    idleHintShown = false;
    if (root) root.classList.remove('is-over');
    if (pauseLayer) pauseLayer.classList.remove('on');
    lastFrame = 0;
    if (!running) {
      running = true;
      raf = requestAnimationFrame(frame);
    }
  }

  function togglePause(force) {
    if (!running || over || !game || modeIntro) return;
    if (multi) { toast(EN() ? 'Cannot pause during a match' : '联机中不能暂停'); return; }
    paused = (force === undefined) ? !paused : !!force;
    if (paused) {
      dasDir = 0;
      if (game) game.setSoftDrop(false);
      saveAuto();
      refreshSlots();
      updatePauseSkins();
      tickClock();
      updatePauseNote();
      resetRestartButton();
      dispatch('tetris-save-change');
    } else {
      frameAcc = 0;
      lastInputAt = performance.now();
      resetRestartButton();
    }
    if (pauseLayer) pauseLayer.classList.toggle('on', paused);
  }

  /* ---------------- 主循环 ---------------- */

  function frame(t) {
    if (!running) return;
    raf = requestAnimationFrame(frame);

    let dt = lastFrame ? (t - lastFrame) : 16;
    lastFrame = t;
    if (!isFinite(dt) || dt < 0) dt = 0;
    if (dt > 120) dt = 120;

    // 帧率上限：默认 60；「自动」= 不限，跟屏幕 rAF 走
    frameAcc += dt;
    if (frameAcc > 200) frameAcc = 0;
    const gap = fpsCap ? 1000 / fpsCap : 0;
    if (gap && frameAcc < gap - 1.5) return;
    const step = Math.min(frameAcc, 120);
    frameAcc = gap ? Math.max(0, frameAcc - step) : 0;

    if (modeIntro) {
      const nowMs = performance.now();
      if (nowMs >= modeIntro.fadeAt) endModeIntro();
      if (nowMs >= modeIntro.endAt) {
        modeIntro = null;
        lastInputAt = nowMs;
      } else {
        render(nowMs);
        return;
      }
    }

    if (spectate) {
      stepSpectate(step);
      render(performance.now());
      return;
    }

    if (multi && !multi.started) {
      const nowMs = performance.now();
      if (multi.introFadeAt && nowMs >= multi.introFadeAt) endDuelIntro();
      if (nowMs >= multi.startAtLocal) {
        multi.started = true;
        paused = false;
        lastInputAt = nowMs;
        endDuelIntro();
        toast(EN() ? 'Go!' : '开始');
      } else {
        if (game) render(nowMs);
        return;
      }
    }
    if (multi && multi.settled) {
      if (game) render(performance.now());
      return;
    }

    if (!paused && !over && game) {
      game.tick(step);
      updateDAS(step);
      pumpEvents();

      if (aiMode) stepAI(step);

      if (multi && !multi.settled) {
        const nowMs = performance.now();
        if (nowMs - multi.lastState >= 250 && game.status === 'playing') {
          multi.lastState = nowMs;
          if (net) net.send({ t: 'state', score: game.score, debt: game.debt, clears: (game.classic ? game.lines : game.clears), dead: false });
        }
        updateVs();
      } else if (game.score > highScore) {
        highScore = game.score;
        try { localStorage.setItem(highKey(), String(highScore)); } catch (e) {}
      }
      if (game.status === 'over' && !over) {
        onGameOver({ debt: game.carryDebt, score: game.score, reason: game.reason });
      }
      if (!multi && !idleHintShown && game.status === 'playing' && (game.classic ? game.lines : game.clears) === 0
          && performance.now() - lastInputAt > 6000) {
        idleHintShown = true;
        toast(EN() ? 'Blocks fall on their own: ← → to move, Space to drop' : '方块会自己往下掉：← → 移动，空格直接落到底');
      }
    }

    const now = performance.now();
    effects = effects.filter(function (e) { return e.until > now; });
    if (game) render(now);
  }

  function updateDAS(dt) {
    if (!game || game.status !== 'playing' || paused || over) return;
    if (dasDir === 0) return;
    dasT += dt;
    if (dasT < C.DAS_MS) return;
    arrT += dt;
    while (arrT >= C.ARR_MS) {
      arrT -= C.ARR_MS;
      if (!game.move(dasDir)) break;
    }
  }

  /* AI 一方的时间推进：转场/合体块照走，落子由 AI 直接给 */
  function stepAI(step) {
    if (!aiMode || !aiState || aiState.dead) return;
    const ag = aiState.game;
    const nowMs = performance.now();
    ag.tick(step);
    if (ag.status === 'over') {
      aiState.dead = true;
    } else if (nowMs >= aiState.nextStep) {
      const mv = window.TetrisAI ? window.TetrisAI.choose(ag, aiState.difficulty) : null;
      if (!mv) {
        aiState.dead = true;
      } else {
        window.TetrisAI.apply(ag, mv);
        aiState.nextStep = nowMs + window.TetrisAI.stepMs(aiState.difficulty);
        if (ag.status === 'over') aiState.dead = true;
      }
    }
    ag.drainEvents();
    updateVs();
  }

  function pumpEvents() {
    if (!game) return;
    const evs = game.drainEvents();
    const now = performance.now();
    for (let i = 0; i < evs.length; i++) {
      const ev = evs[i];
      switch (ev.type) {
        case 'lock':
          saveAuto();
          break;
        case 'lineClear':
          cue('lineClear', { lines: ev.lines });
          effects.push({ type: 'rows', rows: ev.rows || [], until: now + 260 });
          if (multi && multi.mode === 'lan_battle' && net) {
            net.send({ t: 'clear', lines: ev.lines });
          }
          break;
        case 'rotateSoon':
          cue('rotateSoon');
          break;
        case 'fieldRotate':
          effects.push({ type: 'flash', until: now + 420 });
          break;
        case 'fusion':
          effects.push({ type: 'fusion', until: now + 460 });
          break;
        case 'arrowWipe':
          effects.push({ type: 'arrow', until: now + 360 });
          break;
        case 'arrowClear':
          cue('lineClear', { lines: 1 });
          if (multi && multi.mode === 'lan_battle' && net) {
            net.send({ t: 'clear', lines: 1 });
          }
          break;
        case 'debtHigh':
          cue('debtHigh', { pct: ev.pct });
          break;
        case 'debtCleared':
          cue('debtCleared');
          setCarry(0);
          break;
        case 'zenRescue':
          toast(EN() ? 'Board full — tidied up · combo broken' : '堆满了，整理一下 · 连击断了');
          effects.push({ type: 'flash', until: now + 360 });
          break;
        case 'arrowUnlock':
          cue('arrowUnlock');
          break;
        case 'topOut':
          cue('topOut');
          break;
        case 'gameOver':
          onGameOver(ev);
          break;
      }
    }
  }

  function onGameOver(ev) {
    if (over) return;
    over = true;
    overInfo = ev || { debt: 0, score: game.score, reason: 'topout' };
    paused = false;
    dasDir = 0;
    if (game) game.setSoftDrop(false);
    if (multi) {
      if (net) net.send({ t: 'dead', score: game.score });
      settleMulti('youDead');
      return;
    }
    if (aiMode) {
      paused = true;
      if (aiState) aiState.dead = true;
      const ys = game ? game.score : 0;
      const as = aiState && aiState.game ? aiState.game.score : 0;
      const winner = ys > as ? 'you' : (ys < as ? 'opp' : 'draw');
      if (resultEl) {
        const title = $('#resTitle');
        const text = $('#resText');
        if (title) title.textContent = winner === 'you' ? T('你赢') : (winner === 'opp' ? T('你输') : T('平局'));
        if (text) text.textContent = EN() ? ('You ' + ys + ' : AI ' + as) : ('你 ' + ys + ' ： AI ' + as);
        resultEl.classList.add('on');
      }
      if (root) root.classList.add('is-result');
      return;
    }
    if (game) {
      try {
        localStorage.removeItem(game.zen ? LS.zenAuto
          : (game.casual ? LS.autoCasual
            : (game.classic ? LS.autoClassic : LS.auto)));
      } catch (e) {}
    }
    if (game && !game.classic && !game.casual && !game.zen) {
      const before = overInfo.debt || 0;
      const nextDebt = restructureDebt(before);
      overInfo.debt = nextDebt;
      if (game) game.carryDebt = nextDebt;
      setCarry(nextDebt);
    }
    if (game && game.score > highScore) {
      highScore = game.score;
      try { localStorage.setItem(highKey(), String(highScore)); } catch (e) {}
    }
    if (game && game.zen) {
      const tip = root ? root.querySelector('.tg-over-tip') : null;
      if (tip) tip.textContent = EN() ? 'Time up — run over' : '时间到，本局结束';
    }
    if (root) root.classList.add('is-over');
    if (pauseLayer) pauseLayer.classList.remove('on');
    resetRestartButton();
    if (ev && ev.reason !== 'topout' && !(game && game.zen)) cue('gameOver', { debt: overInfo.debt });
    dispatch('tetris-save-change');
  }

  /* ---------------- 联机 ---------------- */

  function updateVs() {
    if (!vsEl) return;
    if (aiMode && aiState) {
      if (vsYou) vsYou.textContent = fmtScore(game ? game.score : 0);
      if (vsOpp) vsOpp.textContent = fmtScore(aiState.game ? aiState.game.score : 0);
      if (vsState) {
        vsState.textContent = aiState.dead
          ? (EN() ? 'AI dead' : 'AI 已死')
          : (EN() ? 'AI cleared ' + lineCount(aiState.game ? aiState.game.clears : 0)
            : 'AI 消 ' + (aiState.game ? aiState.game.clears : 0) + ' 行');
      }
      return;
    }
    if (!multi) return;
    if (vsYou) vsYou.textContent = fmtScore(game ? game.score : 0);
    if (vsOpp) vsOpp.textContent = fmtScore(multi.opponent.score || 0);
    if (vsState) {
      if (!multi.started) vsState.textContent = EN() ? 'Ready' : '准备';
      else if (multi.opponent.dead) vsState.textContent = EN() ? 'Opponent dead' : '对手已死';
      else vsState.textContent = EN() ? 'Opponent ' + lineCount(multi.opponent.clears || 0)
        : '对手消 ' + (multi.opponent.clears || 0) + ' 行';
    }
  }

  function onNetMessage(m) {
    if (!multi || !m) return;
    if (m.t === 'state') {
      multi.opponent.score = m.score | 0;
      multi.opponent.debt = m.debt | 0;
      multi.opponent.clears = m.clears | 0;
      if (m.dead) multi.opponent.dead = true;
      updateVs();
      if (m.dead && !multi.settled) settleMulti('oppDead');
      return;
    }
    if (m.t === 'dead') {
      multi.opponent.score = m.score | 0;
      multi.opponent.dead = true;
      updateVs();
      if (!multi.settled) settleMulti('oppDead');
      return;
    }
    if (m.t === 'clear') {
      if (multi.mode === 'lan_battle' && game && game.status === 'playing') {
        game.pendingFusion += 1;
        toast(EN() ? 'Opponent sent a fusion block' : '对手送来一块合体块');
      }
      return;
    }
    if (m.t === 'peerLeft') {
      multi.opponent.dead = true;
      updateVs();
      toast(EN() ? 'Opponent disconnected' : '对手掉线了');
      if (!multi.settled) settleMulti('oppLeft');
    }
  }

  function settleMulti(reason) {
    if (!multi || multi.settled) return;
    multi.settled = true;
    paused = true;
    dasDir = 0;
    if (game) game.setSoftDrop(false);

    const youDead = !!(game && game.status === 'over');
    const oppDead = !!(multi.opponent.dead || reason === 'oppDead'
      || reason === 'oppLeft' || reason === 'disconnect');
    const ys = game ? game.score : 0;
    const os = multi.opponent.score || 0;
    let winner;
    if (youDead && oppDead) winner = ys > os ? 'you' : (ys < os ? 'opp' : 'draw');
    else if (youDead) winner = ys > os ? 'you' : 'opp';
    else if (oppDead) winner = ys > os ? 'you' : (ys === os ? 'you' : 'opp');
    else winner = 'draw';

    multi.result = { winner: winner, you: ys, opp: os, reason: reason };
    updateVs();

    if (resultEl) {
      const title = $('#resTitle');
      const text = $('#resText');
      if (title) title.textContent = winner === 'you' ? T('你赢') : (winner === 'opp' ? T('你输') : T('平局'));
      if (text) {
        let why = '';
        if (reason === 'oppLeft') why = EN() ? ' · opponent left' : ' · 对手掉线';
        else if (reason === 'disconnect') why = EN() ? ' · disconnected' : ' · 连接断了';
        text.textContent = EN()
          ? ('You ' + ys + ' : Opponent ' + os + why + (winner === 'you' && youDead ? ' · higher score wins' : ''))
          : ('你 ' + ys + ' ： 对手 ' + os + why + (winner === 'you' && youDead ? ' · 死的人分高也算赢' : ''));
      }
      resultEl.classList.add('on');
    }
    if (root) root.classList.add('is-result');
  }

  function drawCountdown(now) {
    const left = Math.max(0, multi.startAtLocal - now);
    const n = Math.ceil(left / 1000);
    ctx.save();
    ctx.fillStyle = 'rgba(5,6,10,.62)';
    ctx.fillRect(0, 0, BW, H);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e9edf6';
    ctx.font = '800 64px ' + FONT;
    ctx.fillText(n > 0 ? String(n) : (EN() ? 'Go!' : '开始'), BW / 2, 140);
    ctx.fillStyle = '#3ee0c6';
    ctx.font = '600 14px ' + FONT;
    ctx.fillText(multi.mode === 'lan_battle' ? (EN() ? 'Battle' : '干扰战') : (EN() ? 'Parallel' : '并行赛'), BW / 2, 200);
    ctx.fillStyle = '#79839a';
    ctx.font = '11px ' + FONT;
    ctx.fillText(EN() ? 'Opponent: ' + (multi.opponent.name || 'Opponent') : '对手：' + (multi.opponent.name || '对手'), BW / 2, 222);
    ctx.restore();
  }

  /* ---------------- 输入 ---------------- */

  function onKeyDown(e) {
    if (!running) return;
    if (modeIntro) return;
    if (spectate) {
      if (e.key === 'Escape') { e.preventDefault(); exitToMenu(); }
      return;
    }
    lastInputAt = performance.now();
    const k = e.key;

    if (k === 'Escape' || k === 'p' || k === 'P') {
      e.preventDefault();
      if (!over) togglePause();
      return;
    }
    if (k === 'r' || k === 'R') {
      e.preventDefault();
      if (!e.repeat) requestRestart();
      return;
    }
    if (paused || over || !game) return;

    switch (k) {
      case 'ArrowLeft':
        e.preventDefault();
        if (!e.repeat) { dasDir = -1; dasT = 0; arrT = 0; game.move(-1); }
        break;
      case 'ArrowRight':
        e.preventDefault();
        if (!e.repeat) { dasDir = 1; dasT = 0; arrT = 0; game.move(1); }
        break;
      case 'ArrowDown':
        e.preventDefault();
        game.setSoftDrop(true);
        touchAct = 'down';
        break;
      case 'ArrowUp':
      case 'x':
      case 'X':
        e.preventDefault();
        game.rotate(1);
        break;
      case 'z':
      case 'Z':
        e.preventDefault();
        game.rotate(-1);
        break;
      case 'c':
      case 'C':
        e.preventDefault();
        game.holdPiece();
        break;
      case ' ':
      case 'Spacebar':
        e.preventDefault();
        game.hardDrop();
        break;
      default:
        break;
    }
  }

  function onKeyUp(e) {
    if (!running) return;
    const k = e.key;
    if (k === 'ArrowLeft' && dasDir === -1) dasDir = 0;
    if (k === 'ArrowRight' && dasDir === 1) dasDir = 0;
    if (k === 'ArrowDown' && game) game.setSoftDrop(false);
  }

  function onPadDown(e) {
    const b = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!b || !running || paused || over || !game) return;
    e.preventDefault();
    lastInputAt = performance.now();
    const act = b.dataset.act;
    touchAct = act;
    try { b.setPointerCapture(e.pointerId); } catch (err) {}
    if (act === 'left') { dasDir = -1; dasT = 0; arrT = 0; game.move(-1); }
    else if (act === 'right') { dasDir = 1; dasT = 0; arrT = 0; game.move(1); }
    else if (act === 'down') { game.setSoftDrop(true); }
    else if (act === 'cw') { game.rotate(1); }
    else if (act === 'ccw') { game.rotate(-1); }
    else if (act === 'drop') { game.hardDrop(); }
    else if (act === 'hold') { game.holdPiece(); }
  }

  function onPadUp() {
    if (touchAct === 'left' || touchAct === 'right') dasDir = 0;
    if (touchAct === 'down' && game) game.setSoftDrop(false);
    touchAct = null;
  }

  function onCanvasDown(e) {
    if (!over || !game) return;
    const r = canvas.getBoundingClientRect();
    const x = (e.clientX - r.left) * W / r.width;
    const y = (e.clientY - r.top) * H / r.height;
    if (x < 8 || x > 82 || y < 246 || y > 312) return;
    const now = performance.now();
    if (now - taps.t > 1400) taps.n = 0;
    taps.t = now;
    taps.n += 1;
    if (taps.n >= 5) {
      taps.n = 0;
      game.carryDebt = 0;
      if (overInfo) overInfo.debt = 0;
      setCarry(0);
      toast(EN() ? 'Cleared — next game carries no debt' : '档清了，下一局不用还');
    }
  }

  function onClick(e) {
    const b = e.target.closest ? e.target.closest('button') : null;
    if (!b) return;
    const cmd = b.dataset.cmd;
    if (cmd) {
      if (cmd === 'exit') exitToMenu();
      else if (cmd === 'pause') togglePause();
      else if (cmd === 'resume') togglePause(false);
      else if (cmd === 'restart') requestRestart();
      return;
    }
    if (b.dataset.save) { saveSlot(parseInt(b.dataset.save, 10)); return; }
    if (b.dataset.load) { loadSlot(parseInt(b.dataset.load, 10)); return; }
    if (b.dataset.del) { delSlot(parseInt(b.dataset.del, 10)); return; }
  }

  /* ---------------- 存档 ---------------- */

  function saveAuto() {
    if (!game || multi || aiMode || game.status !== 'playing' || over) return;
    const data = game.toJSON();
    data.savedAt = Date.now();
    const ok = writeJSON(game.zen ? LS.zenAuto
      : (game.casual ? LS.autoCasual
        : (game.classic ? LS.autoClassic : LS.auto)), data);
    if (ok) dispatch('tetris-save-change', { score: game.score, classic: !!game.classic, casual: !!game.casual });
  }

  function slotKey(n) {
    if (game && game.casual) return LS.slotCasual + n;
    return (game && game.classic ? LS.slotClassic : LS.slot) + n;
  }

  function slotModeName(n) {
    const base = (game && game.casual ? SAVE_NAME.casual
      : (game && game.classic ? SAVE_NAME.classic : SAVE_NAME.normal));
    return EN() ? (T(base) + ' ' + n) : (base + n);
  }

  function refreshSlots() {
    if (!slotsBox) return;
    let html = '';
    for (let n = 1; n <= 3; n++) {
      const data = readJSON(slotKey(n));
      const valid = !!data && !E.validateSave(data);
      let title = EN() ? 'Empty' : '空';
      if (valid) {
        if (EN()) {
          title = fmtScore(data.score) + ' ' + unit(fmtScore(data.score), 'pt', 'pts') + ' · '
            + (data.classic ? lineCount(data.lines || 0) + ' · Lv ' + (data.level || 1)
              : lineCount(data.clears || 0) + (data.debt > 0 ? ' · debt -' + data.debt : ''));
        } else if (data.classic) {
          title = fmtScore(data.score) + ' 分 · 消 ' + (data.lines || 0) + ' 行 · 等级 ' + (data.level || 1);
        } else {
          title = fmtScore(data.score) + ' 分 · 消 ' + (data.clears || 0) + ' 行'
            + (data.debt > 0 ? ' · 欠 -' + data.debt : '');
        }
      }
      html += '<div class="tg-slot">'
        + '<div class="tg-slot-t"><b>' + slotModeName(n) + '</b><span>' + title + '</span></div>'
        + '<div class="tg-slot-b">'
        + '<button data-save="' + n + '"' + (over || !game ? ' disabled' : '') + '>' + T('存') + '</button>'
        + '<button data-load="' + n + '"' + (valid ? '' : ' disabled') + '>' + T('读') + '</button>'
        + '<button data-del="' + n + '"' + (valid ? '' : ' disabled') + '>' + T('删') + '</button>'
        + '</div></div>';
    }
    slotsBox.innerHTML = html;
  }

  function saveSlot(n) {
    if (game && game.zen) { toast(EN() ? 'Zen only autosaves' : '禅模式只自动存档'); return; }
    if (!game || over) { toast(EN() ? 'No run in progress' : '现在没有在玩的局'); return; }
    if (writeJSON(slotKey(n), game.toJSON())) {
      refreshSlots();
      toast(EN() ? 'Saved to ' + slotModeName(n) : '存进「' + slotModeName(n) + '」');
    } else {
      toast(EN() ? 'Could not save (browser denied write)' : '存不进去（浏览器不给写）');
    }
  }

  function loadSlot(n) {
    if (game && game.zen) { toast(EN() ? 'Zen only autosaves' : '禅模式只自动存档'); return; }
    const data = readJSON(slotKey(n));
    if (!data) { toast(EN() ? slotModeName(n) + ' is empty' : '「' + slotModeName(n) + '」是空的'); return; }
    const g = data.classic
      ? new E.Tetris({ seed: (data.seed >>> 0) || 1, classic: true, cols: data.cols || 10, rows: data.rows || 20 })
      : (data.casual
        ? new E.Tetris({ seed: (data.seed >>> 0) || 1, casual: true, cols: data.cols || 10, rows: data.rows || 10 })
        : mk({ seed: (data.seed >>> 0) || 1 }));
    const err = g.loadJSON(data);
    if (err) { toast(EN() ? 'This slot cannot be loaded: ' + err : '这个槽读不了：' + err); return; }
    game = g;
    layoutFor(game);
    over = false;
    overInfo = null;
    paused = false;
    effects = [];
    taps = { n: 0, t: 0 };
    dasDir = 0;
    if (root) root.classList.remove('is-over');
    if (pauseLayer) pauseLayer.classList.remove('on');
    lastFrame = 0;
    toast(EN() ? 'Loaded ' + slotModeName(n) : '读了「' + slotModeName(n) + '」');
    saveAuto();
    if (!running) { running = true; raf = requestAnimationFrame(frame); }
  }

  function delSlot(n) {
    try { localStorage.removeItem(slotKey(n)); } catch (e) {}
    refreshSlots();
    toast(EN() ? 'Deleted ' + slotModeName(n) : '「' + slotModeName(n) + '」删了');
  }

  function exportSave() {
    if (!game) { toast(EN() ? 'No run started yet' : '还没开局'); return; }
    const data = game.toJSON();
    data.savedAt = new Date().toISOString();
    const text = JSON.stringify(data, null, 2);
    try {
      const blob = new Blob([text], { type: 'application/json' });
      const a = document.createElement('a');
      const d = new Date();
      const pad = function (v) { return v < 10 ? '0' + v : '' + v; };
      a.download = (game.classic ? (EN() ? 'classic' : '经典玩法') : (EN() ? 'solo' : '单人玩法')) + '-save-' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate())
        + '-' + pad(d.getHours()) + pad(d.getMinutes()) + '.json';
      a.href = URL.createObjectURL(blob);
      document.body.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      toast(EN() ? 'Save exported' : '存档已导出');
    } catch (e) {
      toast(EN() ? 'Export failed' : '导出失败');
    }
  }

  function onImportFile() {
    const f = fileInput && fileInput.files && fileInput.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = function () {
      try {
        const data = JSON.parse(String(reader.result || ''));
        const err = E.validateSave(data);
        if (err) { toast(EN() ? 'This file is invalid: ' + err : '这个文件不对：' + err); return; }
        const g = data.classic
          ? new E.Tetris({ seed: (data.seed >>> 0) || 1, classic: true, cols: data.cols || 10, rows: data.rows || 20 })
          : mk({ seed: (data.seed >>> 0) || 1 });
        if (g.loadJSON(data)) { toast(EN() ? 'Could not load it' : '读不进去'); return; }
        game = g;
        layoutFor(game);
        over = false;
        overInfo = null;
        paused = false;
        effects = [];
        if (root) root.classList.remove('is-over');
        if (pauseLayer) pauseLayer.classList.remove('on');
        lastFrame = 0;
        saveAuto();
        toast(EN() ? 'Save imported' : '存档导入成功');
        if (!running) { running = true; raf = requestAnimationFrame(frame); }
      } catch (e) {
        toast(EN() ? 'Not a JSON file' : '不是 JSON 文件');
      }
    };
    reader.readAsText(f);
    fileInput.value = '';
  }

  /* ---------------- 画 ---------------- */

  function fit() {
    if (!canvas) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.round(W * dpr), h = Math.round(H * dpr);
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }
    if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function rrOn(c, x, y, w, h, r) {
    c.beginPath();
    if (c.roundRect) { c.roundRect(x, y, w, h, r); return; }
    const rad = Math.max(0, Math.min(r, w / 2, h / 2));
    c.moveTo(x + rad, y);
    c.arcTo(x + w, y, x + w, y + h, rad);
    c.arcTo(x + w, y + h, x, y + h, rad);
    c.arcTo(x, y + h, x, y, rad);
    c.arcTo(x, y, x + w, y, rad);
    c.closePath();
  }
  function rr(x, y, w, h, r) {
    rrOn(ctx, x, y, w, h, r);
  }

  function render(now) {
    if (!ctx) return;
    if (spectate) { drawSpectate(now); return; }
    if (!game) return;
    ctx.clearRect(0, 0, W, H);

    ctx.fillStyle = '#08090d';
    ctx.fillRect(0, 0, W, H);

    drawBoard(now);
    drawPanel(now);
    renderAI();
    if (multi && !multi.started && !multi.introOut && !root.classList.contains('is-intro')) drawCountdown(now);
    if (over && !multi && !aiMode) drawGameOver();
  }

  function renderAI() {
    if (!aiMode || !aiState || !aiCtx) return;
    const g = aiState.game;
    const size = 96, n = 10, cell = size / n;
    aiCtx.clearRect(0, 0, size, size);
    aiCtx.fillStyle = '#0a0c12';
    aiCtx.fillRect(0, 0, size, size);
    aiCtx.strokeStyle = 'rgba(255,255,255,.06)';
    aiCtx.lineWidth = 1;
    for (let i = 1; i < n; i++) {
      aiCtx.beginPath(); aiCtx.moveTo(i * cell, 0); aiCtx.lineTo(i * cell, size); aiCtx.stroke();
      aiCtx.beginPath(); aiCtx.moveTo(0, i * cell); aiCtx.lineTo(size, i * cell); aiCtx.stroke();
    }
    function paint(cx, cy, color) {
      paintCellOn(aiCtx, cx * cell, cy * cell, cell, color);
    }
    for (let y = 0; y < n; y++) {
      for (let x = 0; x < n; x++) {
        const c = g.board[y][x];
        if (!c) continue;
        paint(x, y, c.k === 'f' ? '#5c6a88' : (c.k === 'p' ? '#7a3442' : (E.COLORS[c.t] || '#8b95a8')));
      }
    }
    if (g.piece) {
      const cells = g.pieceCells();
      for (let i = 0; i < cells.length; i++) {
        const x = cells[i][0], y = cells[i][1];
        if (x >= 0 && x < n && y >= 0 && y < n) paint(x, y, '#f2f5ff');
      }
    }
    if (aiScoreEl) aiScoreEl.textContent = fmtScore(g.score);
    if (aiInfoEl) {
      aiInfoEl.textContent = EN()
        ? g.clears + ' lines · ' + (aiState.dead ? 'dead' : 'alive') + ' · Lv ' + g.lockLevel
        : '消 ' + g.clears + ' · ' + (aiState.dead ? '死' : '活') + ' · 等级 ' + g.lockLevel;
    }
    if (aiDebtEl) {
      const d = g.projectedDebt ? g.projectedDebt() : g.debt;
      aiDebtEl.textContent = d > 0 ? (EN() ? 'Debt -' + d : '结束欠 -' + d) : (EN() ? 'Debt 0' : '债 0');
    }
  }

  function cellColor(type) { return COLORS[type] || '#8b95a8'; }

  function paintCellOn(c, px, py, size, fill, opts, skinId) {
    opts = opts || {};
    const sk = skinDef(skinId);
    const k = size / 32;
    const extra = opts.ghost ? 2 * k : 0;
    const pad = Math.max(1, sk.pad * k + extra);
    const r = Math.max(0, sk.radius * k);
    const x = px + pad, y = py + pad, s = Math.max(2, size - pad * 2);
    c.save();
    if (opts.alpha !== undefined) c.globalAlpha = opts.alpha;

    if (opts.ghost) {
      c.globalAlpha = 0.16;
      rrOn(c, x, y, s, s, r);
      c.fillStyle = fill;
      c.fill();
      c.restore();
      return;
    }

    if (sk.id === 'pixel') {
      const ix = Math.round(x), iy = Math.round(y), is = Math.round(s);
      const lw = Math.max(1, Math.round(2 * k));
      c.fillStyle = fill;
      c.fillRect(ix, iy, is, is);
      c.fillStyle = 'rgba(255,255,255,.38)';
      c.fillRect(ix, iy, is, lw);
      c.fillRect(ix, iy, lw, is);
      c.fillStyle = 'rgba(0,0,0,.28)';
      c.fillRect(ix, iy + is - lw, is, lw);
      c.fillRect(ix + is - lw, iy, lw, is);
      c.strokeStyle = opts.stroke || 'rgba(0,0,0,.55)';
      c.lineWidth = 1;
      c.strokeRect(ix + 0.5, iy + 0.5, is - 1, is - 1);
    } else if (sk.id === 'modern') {
      const grad = c.createLinearGradient(0, y, 0, y + s);
      grad.addColorStop(0, shade(fill, 0.3));
      grad.addColorStop(0.52, fill);
      grad.addColorStop(1, shade(fill, -0.16));
      rrOn(c, x, y, s, s, r);
      c.fillStyle = grad;
      c.fill();
      c.strokeStyle = opts.stroke || 'rgba(0,0,0,.24)';
      c.lineWidth = Math.max(1, sk.line * k);
      c.stroke();
      rrOn(c, x + 1.5 * k, y + 1.5 * k, s - 3 * k, s - 3 * k, Math.max(1, r - 1.5 * k));
      c.strokeStyle = 'rgba(255,255,255,.10)';
      c.lineWidth = 1;
      c.stroke();
      c.beginPath();
      c.moveTo(x + 3 * k, y + 1.5 * k);
      c.lineTo(x + s - 3 * k, y + 1.5 * k);
      c.strokeStyle = 'rgba(255,255,255,.48)';
      c.lineWidth = Math.max(1, 1.1 * k);
      c.stroke();
    } else if (sk.id === 'minimal') {
      rrOn(c, x, y, s, s, r);
      c.fillStyle = fill;
      c.fill();
      c.strokeStyle = opts.stroke || 'rgba(255,255,255,.18)';
      c.lineWidth = Math.max(1, sk.line * k);
      c.stroke();
    } else if (sk.id === 'neon') {
      rrOn(c, x, y, s, s, r);
      c.fillStyle = '#0b0e14';
      c.fill();
      const rim = opts.stroke || fill;
      c.save();
      c.strokeStyle = rim;
      c.lineWidth = Math.max(2, 2.2 * k);
      c.shadowColor = tint(fill, 0.6);
      c.shadowBlur = 8 * k;
      c.stroke();
      c.restore();
      rrOn(c, x + 2.5 * k, y + 2.5 * k, s - 5 * k, s - 5 * k, Math.max(1, r - 2 * k));
      c.fillStyle = tint(fill, 0.3);
      c.fill();
    } else {
      rrOn(c, x, y, s, s, r);
      c.fillStyle = fill;
      c.fill();
      c.strokeStyle = opts.stroke || 'rgba(0,0,0,.28)';
      c.lineWidth = Math.max(1, sk.line * k);
      c.stroke();
      c.beginPath();
      c.moveTo(x + 3 * k, y + 1.5 * k);
      c.lineTo(x + s - 3 * k, y + 1.5 * k);
      c.strokeStyle = 'rgba(255,255,255,.28)';
      c.lineWidth = Math.max(1, 1 * k);
      c.stroke();
    }
    c.restore();
  }

  function drawBlock(px, py, fill, opts) {
    paintCellOn(ctx, px, py, C.CELL, fill, opts);
  }

  function drawBoard(now) {
    // 底
    ctx.fillStyle = '#0a0c12';
    ctx.fillRect(0, 0, BW, H);

    // 格线
    ctx.strokeStyle = 'rgba(255,255,255,.035)';
    ctx.lineWidth = 1;
    for (let i = 1; i < game.cols; i++) {
      ctx.beginPath(); ctx.moveTo(i * C.CELL + 0.5, 0); ctx.lineTo(i * C.CELL + 0.5, H); ctx.stroke();
    }
    for (let i = 1; i < game.rows; i++) {
      ctx.beginPath(); ctx.moveTo(0, i * C.CELL + 0.5); ctx.lineTo(BW, i * C.CELL + 0.5); ctx.stroke();
    }

    // 场上
    const fusionGroups = {};
    for (let y = 0; y < game.rows; y++) {
      for (let x = 0; x < game.cols; x++) {
        const c = game.board[y][x];
        if (!c) continue;
        const px = x * C.CELL, py = y * C.CELL;
        if (c.k === 'f') {
          drawBlock(px, py, '#39415a', { stroke: 'rgba(160,178,210,.5)' });
          if (c.l) {
            const grp = fusionGroups[c.g] ||
              (fusionGroups[c.g] = { l: c.l, minx: x, maxx: x, miny: y, maxy: y });
            if (x < grp.minx) grp.minx = x;
            if (x > grp.maxx) grp.maxx = x;
            if (y < grp.miny) grp.miny = y;
            if (y > grp.maxy) grp.maxy = y;
          }
        } else if (c.k === 'p') {
          drawBlock(px, py, '#4a2630', { stroke: 'rgba(255,77,94,.55)' });
          ctx.save();
          ctx.strokeStyle = 'rgba(255,120,135,.28)';
          ctx.beginPath();
          ctx.moveTo(px + 9, py + 16); ctx.lineTo(px + 23, py + 16);
          ctx.moveTo(px + 16, py + 9); ctx.lineTo(px + 16, py + 23);
          ctx.stroke();
          ctx.restore();
        } else {
          drawBlock(px, py, cellColor(c.t));
        }
      }
    }

    // 字母块的字母：整块画一次，不一个格子一个
    for (const key in fusionGroups) {
      const grp = fusionGroups[key];
      const cx = (grp.minx + grp.maxx + 1) / 2 * C.CELL;
      const cy = (grp.miny + grp.maxy + 1) / 2 * C.CELL;
      ctx.save();
      ctx.fillStyle = 'rgba(255,212,121,.5)';
      ctx.font = '800 28px ' + FONT;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(grp.l, cx, cy + 1);
      ctx.restore();
    }

    // 顶块预警：最后 0.9 秒 / 顶上两行已经有东西，直接把危险画在盘面上
    if (!game.classic && game.pendingFusion > 0) {
      const danger = game.topBusy(2);
      const warn = game.fusionWarned || danger;
      ctx.save();
      ctx.fillStyle = danger ? 'rgba(255,77,94,.14)' : 'rgba(255,200,80,.07)';
      ctx.fillRect(0, 0, BW, 2 * C.CELL);
      ctx.strokeStyle = danger ? 'rgba(255,77,94,.85)' : 'rgba(255,200,80,.45)';
      ctx.lineWidth = warn ? 2 : 1;
      ctx.strokeRect(1, 1, BW - 2, 2 * C.CELL - 2);
      ctx.restore();
    }

    // 消行闪光
    for (let i = 0; i < effects.length; i++) {
      const e = effects[i];
      if (e.type !== 'rows') continue;
      const k = clamp((e.until - now) / 260, 0, 1);
      ctx.save();
      ctx.fillStyle = 'rgba(255,255,255,' + (0.55 * k) + ')';
      for (let r = 0; r < e.rows.length; r++) ctx.fillRect(0, e.rows[r] * C.CELL, BW, C.CELL);
      ctx.restore();
    }

    // 落点预览 + 当前块
    if (game.piece && game.status === 'playing') {
      drawGhost();
      drawActive();
    }

    // 转场闪白
    for (let i = 0; i < effects.length; i++) {
      const e = effects[i];
      if (e.type === 'flash') {
        const k = clamp((e.until - now) / 420, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(255,255,255,' + (0.16 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
      if (e.type === 'fusion') {
        const k = clamp((e.until - now) / 460, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(62,224,198,' + (0.13 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
      if (e.type === 'arrow') {
        const k = clamp((e.until - now) / 360, 0, 1);
        ctx.save();
        ctx.fillStyle = 'rgba(255,255,255,' + (0.18 * k) + ')';
        ctx.fillRect(0, 0, BW, H);
        ctx.restore();
      }
    }

    // 边框 + 转场预警
    const muted = document.documentElement.classList.contains('cues-muted');
    ctx.strokeStyle = muted ? 'rgba(62,224,198,.35)' : 'rgba(255,255,255,.08)';
    ctx.lineWidth = 1;
    ctx.strokeRect(0.5, 0.5, BW - 1, H - 1);
    if (muted) {
      // 没有声音的时候，边框常亮，替声音告诉你“局还在”
      ctx.save();
      ctx.strokeStyle = 'rgba(62,224,198,.22)';
      ctx.strokeRect(2.5, 2.5, BW - 5, H - 5);
      ctx.restore();
    }

    if (game.status === 'playing' && game.rotateEnabled !== false) {
      const rem = C.ROTATE_MS - game.rotTimer;
      if (rem <= C.ROTATE_WARN_MS) {
        const k = 1 - rem / C.ROTATE_WARN_MS;
        const pulse = 0.5 + 0.5 * Math.sin(now / 90);
        ctx.save();
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.18 + 0.55 * k * pulse) + ')';
        ctx.lineWidth = 2;
        ctx.strokeRect(1, 1, BW - 2, H - 2);
        ctx.restore();
        drawSpin(now, k);
      }
    }
  }

  function drawSpin(now, k) {
    ctx.save();
    ctx.translate(300, 20);
    ctx.rotate((now / 260) % (Math.PI * 2));
    ctx.strokeStyle = 'rgba(255,255,255,' + (0.45 + 0.45 * k) + ')';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 9, -Math.PI * 0.75, Math.PI * 0.75);
    ctx.stroke();
    // 箭头
    ctx.beginPath();
    ctx.moveTo(0, -12);
    ctx.lineTo(-4.5, -6.5);
    ctx.lineTo(4.5, -6.5);
    ctx.closePath();
    ctx.fillStyle = 'rgba(255,255,255,' + (0.55 + 0.4 * k) + ')';
    ctx.fill();
    ctx.restore();
  }

  function ghostY() {
    const p = game.piece;
    if (!p) return 0;
    let y = p.y;
    while (!game.collides({ type: p.type, rot: p.rot, x: p.x, y: y + 1 })) y++;
    return y;
  }

  function drawGhost() {
    const p = game.piece;
    if (!p) return;
    const gy = ghostY();
    if (gy === p.y) return;
    const cells = game.pieceCells({ type: p.type, rot: p.rot, x: p.x, y: gy });
    const color = p.type === 'ARROW' ? '#f2f5ff' : cellColor(p.type);
    for (let i = 0; i < cells.length; i++) {
      const px = cells[i][0] * C.CELL, py = cells[i][1] * C.CELL;
      paintCellOn(ctx, px, py, C.CELL, color, { ghost: true });
    }
  }

  function drawActive() {
    const p = game.piece;
    if (!p) return;
    const cells = game.pieceCells();
    const isArrow = p.type === 'ARROW';
    const color = isArrow ? '#f2f5ff' : cellColor(p.type);
    const sk = skinDef(settings.skin);
    ctx.save();
    if (sk.id !== 'neon') {
      ctx.shadowColor = isArrow ? 'rgba(255,255,255,.85)' : color;
      ctx.shadowBlur = Math.max(4, sk.glow);
    }
    for (let i = 0; i < cells.length; i++) {
      const px = cells[i][0] * C.CELL, py = cells[i][1] * C.CELL;
      drawBlock(px, py, color, sk.id === 'neon' ? {} : {
        stroke: sk.id === 'minimal' ? 'rgba(255,255,255,.22)' : 'rgba(255,255,255,.4)'
      });
    }
    ctx.restore();
    if (isArrow) {
      const glyph = { up: '↑', down: '↓', left: '←', right: '→' }[p.dir] || '↑';
      ctx.save();
      ctx.fillStyle = '#08090d';
      ctx.font = '700 22px ' + FONT;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(glyph, p.x * C.CELL + 16, p.y * C.CELL + 17);
      ctx.restore();
    }
  }

  function drawPreview(entry, x, y, size) {
    ctx.save();
    rr(x, y, size, size, 9);
    ctx.fillStyle = '#10131b';
    ctx.fill();
    ctx.strokeStyle = '#232838';
    ctx.lineWidth = 1;
    ctx.stroke();

    if (entry) {
      if (entry.t === 'ARROW') {
        const glyph = { up: '↑', down: '↓', left: '←', right: '→' }[entry.d] || '↑';
        ctx.fillStyle = '#f2f5ff';
        ctx.font = '700 ' + Math.round(size * 0.5) + 'px ' + FONT;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(glyph, x + size / 2, y + size / 2 + 1);
      } else {
        const shape = SHAPES[entry.t];
        let minx = 9, maxx = -9, miny = 9, maxy = -9;
        for (let i = 0; i < shape.cells.length; i++) {
          minx = Math.min(minx, shape.cells[i][0]); maxx = Math.max(maxx, shape.cells[i][0]);
          miny = Math.min(miny, shape.cells[i][1]); maxy = Math.max(maxy, shape.cells[i][1]);
        }
        const bw = maxx - minx + 1, bh = maxy - miny + 1;
        const u = size / 4.6;
        const ox = (size - bw * u) / 2 - minx * u;
        const oy = (size - bh * u) / 2 - miny * u;
        for (let i = 0; i < shape.cells.length; i++) {
          const cx = x + ox + shape.cells[i][0] * u;
          const cy = y + oy + shape.cells[i][1] * u;
          paintCellOn(ctx, cx, cy, u, cellColor(entry.t));
        }
      }
    }
    ctx.restore();
  }

  function drawPanel(now) {
    ctx.save();
    rr(PX, 0, PW, H, 12);
    ctx.fillStyle = '#0d0f16';
    ctx.fill();
    ctx.strokeStyle = '#1c2130';
    ctx.lineWidth = 1;
    ctx.stroke();

    const L = PX + 8, R = PX + PW - 8;

    // NEXT
    label('NEXT', L, 14);
    for (let i = 0; i < 3; i++) {
      drawPreview(game.queue[i] || null, L + i * 44, 20, 40);
    }

    // HOLD
    label('HOLD', L, 77);
    drawPreview(game.hold || null, L, 83, 40);

    // 分数
    label(T('分数'), L, 141);
    ctx.fillStyle = '#e9edf6';
    ctx.font = '700 26px ' + FONT;
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(fmtScore(game.score), L, 168);

    // 三行数据
    const projected = game.projectedDebt ? game.projectedDebt() : game.debt;
    if (game.zen) {
      const left = Math.max(0, game.zenTimeLeft || 0);
      const mm = Math.floor(left / 60000);
      const ss = Math.floor(left % 60000 / 1000);
      stat(T('剩余'), mm + ':' + (ss < 10 ? '0' : '') + ss, 192, left < 30000 ? '#ff5c6c' : '#3ee0c6');
      stat(T('连击'), game.combo > 0 ? game.combo + 'x' : '0', 214, game.combo > 0 ? '#ffc857' : '#c6cdda');
      stat(T('消行'), String(game.clears), 236, '#c6cdda');
      stat(T('最高'), fmtScore(highScore), 258, '#79839a');
    } else if (game.casual) {
      const mult = 1 + Math.min(Math.max(0, game.combo - 1), 5) * 0.25;
      stat(T('连击'), game.combo > 0 ? game.combo + 'x' : '0', 192, game.combo > 0 ? '#ffc857' : '#c6cdda');
      stat(T('倍数'), 'x' + mult.toFixed(2).replace(/\.?0+$/, ''), 214, '#ffc857');
      stat(T('消行'), String(game.clears), 236, '#c6cdda');
      stat(T('最高'), fmtScore(highScore), 258, '#79839a');
    } else {
      stat(T('等级'), String(game.classic ? game.level : game.lockLevel), 192, '#c6cdda');
      stat(T('结束欠'), game.classic ? '—' : (projected > 0 ? '-' + projected : '0'), 214,
        game.classic ? '#79839a' : (projected > 0 ? '#ff5c6c' : '#79839a'));
      stat(T('消行'), String(game.classic ? game.lines : game.clears), 236, '#c6cdda');
      stat(T('最高'), fmtScore(highScore), 258, '#79839a');
    }

    // 状态小字
    ctx.textAlign = 'left';
    ctx.font = '10px ' + FONT;
    ctx.fillStyle = '#4a5264';
    if (game.zen) {
      ctx.fillStyle = game.zenTimeLeft < 30000 ? '#ff8b96' : '#4a5264';
      ctx.fillText(EN()
        ? 'Zen · ' + game.zenMinutes + ' min · rescues ' + (game.zenRescues || 0)
        : '禅 · ' + game.zenMinutes + ' 分钟 · 整理 ' + (game.zenRescues || 0), L, 286);
      ctx.fillStyle = '#4a5264';
    } else if (game.casual) {
      const next = 1 + Math.min(Math.max(0, game.combo), 5) * 0.25;
      if (game.combo > 0) {
        ctx.fillStyle = '#ffc857';
        ctx.fillText(EN()
          ? 'Next clear x' + next.toFixed(2).replace(/\.?0+$/, '') + ' · misses ' + game.comboMiss + '/3'
          : '下一消 x' + next.toFixed(2).replace(/\.?0+$/, '') + ' · 断击 ' + game.comboMiss + '/3', L, 286);
      } else {
        ctx.fillText(EN()
          ? 'Clear a line to start a combo · misses ' + game.comboMiss + '/3'
          : '消一行起连击 · 断击 ' + game.comboMiss + '/3', L, 286);
      }
    } else if (game.classic) {
      ctx.fillText(T('原版规则'), L, 286);
    } else if (game.pendingFusion > 0) {
      const left = Math.max(0, ((E.CONST ? E.CONST.FUSION_DELAY_MS : 2500) - game.fusionTimer) / 1000);
      let holes = '';
      if (game.fusionPreview && game.fusionPreview.holes) {
        const xs = [];
        game.fusionPreview.holes.forEach(function (h) {
          const v = String(h[0] + 1);
          if (xs.indexOf(v) < 0) xs.push(v);
        });
        holes = EN() ? ' · holes ' + xs.join('/') : ' · 洞 ' + xs.join('/');
      }
      ctx.fillStyle = '#ff8b96';
      ctx.fillText(T('顶块') + ' ' + left.toFixed(1) + 's' + holes, L, 286);
      ctx.fillStyle = '#4a5264';
    } else if (game.grace > 0) {
      ctx.fillText(T('奖励期') + ' ' + game.grace + (EN() ? 'x' : ' 次'), L, 286);
    } else if (game.debt > 0) {
      ctx.fillText(T('还债中'), L, 286);
    } else {
      ctx.fillText(T('债已清'), L, 286);
    }
    ctx.fillStyle = '#3a4152';
    if (game.zen) {
      ctx.fillText((EN() ? 'Zen · max combo ' : '禅 · 最高连击 ') + (game.maxCombo || 0) + 'x', L, 304);
    } else if (game.casual) {
      ctx.fillText((EN() ? 'Casual · max combo ' : '常驻 · 最高连击 ') + (game.maxCombo || 0) + 'x', L, 304);
    } else if (game.classic) {
      ctx.fillText('SEED ' + game.seed, L, 304);
    } else if (game.clears < (E.CONST ? E.CONST.MORPH_AT_CLEARS : 40)) {
      ctx.fillText(T('变形') + ' ' + game.clears + '/' + (E.CONST ? E.CONST.MORPH_AT_CLEARS : 40), L, 304);
    } else {
      ctx.fillText(T('字母块') + ' ' + Math.floor(game.clears / (E.CONST ? E.CONST.MORPH_AT_CLEARS : 40)), L, 304);
    }

    ctx.restore();

    function label(t, x, y) {
      ctx.fillStyle = '#5b6479';
      ctx.font = '600 9px ' + FONT;
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
      ctx.fillText(t, x, y);
    }
    function stat(k, v, y, color) {
      ctx.textAlign = 'left';
      ctx.font = '11px ' + FONT;
      ctx.fillStyle = '#79839a';
      ctx.fillText(k, L, y);
      ctx.textAlign = 'right';
      ctx.font = '600 13px ' + FONT;
      ctx.fillStyle = color;
      ctx.fillText(v, R, y);
    }
  }

  function drawGameOver() {
    const info = overInfo || { debt: 0 };
    ctx.save();
    ctx.fillStyle = 'rgba(5,6,10,.78)';
    ctx.fillRect(0, 0, BW, H);

    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';

    if (EN()) {
      ctx.shadowColor = 'rgba(255,77,94,.7)';
      ctx.shadowBlur = 20;
      ctx.fillStyle = '#ff4d5e';
      ctx.font = '800 34px ' + FONT;
      ctx.fillText('DEBT', 14, 60);
      ctx.shadowBlur = 0;

      ctx.fillStyle = '#e9edf6';
      ctx.font = '700 18px ' + FONT;
      ctx.fillText('Score ' + fmtScore(game.score), 14, 94);

      ctx.fillStyle = '#ffc857';
      ctx.font = '700 15px ' + FONT;
      if (game.casual) ctx.fillText('Max combo ' + (game.maxCombo || 0) + 'x', 14, 120);
      else ctx.fillText((info.debt || 0) > 0 ? 'Carry -' + info.debt : 'Carry 0', 14, 120);

      ctx.fillStyle = '#79839a';
      ctx.font = '11px ' + FONT;
      ctx.fillText('Press R to restart', 14, 144);

      ctx.fillStyle = '#6b7488';
      ctx.font = '9px ' + FONT;
      ctx.textAlign = 'right';
      ctx.fillText(game.zen ? 'Zen · time up'
        : (game.casual ? 'Casual · Combo'
          : (game.classic ? T('原版规则') : 'Tap Debt 5× to clear debt')), BW - 12, 308);
      ctx.restore();
      return;
    }

    ctx.shadowColor = 'rgba(255,77,94,.7)';
    ctx.shadowBlur = 24;
    ctx.fillStyle = '#ff4d5e';
    ctx.font = '800 48px ' + FONT;
    ctx.fillText(game.zen ? T('禅') : (game.casual ? T('常驻') : T('债')), 14, 300);
    ctx.shadowBlur = 0;

    ctx.fillStyle = '#e9edf6';
    ctx.font = '700 18px ' + FONT;
    ctx.fillText(T('本局') + ' ' + fmtScore(game.score), 80, 262);

    ctx.fillStyle = '#ffc857';
    ctx.font = '700 15px ' + FONT;
    if (game.casual) {
      ctx.fillText(T('最高连击') + ' ' + (game.maxCombo || 0) + 'x', 80, 286);
    } else {
      ctx.fillText((info.debt || 0) > 0 ? T('带走') + ' -' + info.debt : T('带走') + ' 0', 80, 286);
    }

    ctx.fillStyle = '#79839a';
    ctx.font = '11px ' + FONT;
    ctx.fillText(T('按 R 重开'), 80, 308);

    ctx.fillStyle = '#3a4152';
    ctx.font = '9px ' + FONT;
    ctx.textAlign = 'right';
    ctx.fillText(game.zen ? (EN() ? 'Zen · time up' : '禅模式 · 时间到')
      : (game.casual ? (EN() ? 'Casual · Combo' : '常驻 · 连击')
        : (game.classic ? T('原版规则')
          : (EN() ? 'Tap Debt 5× to clear saves' : '连点「债」5 下清档'))), BW - 12, 308);
    ctx.restore();
  }

  /* ---------------- 对外 ---------------- */

  function paintSkinSwatch(canvas, id) {
    if (!canvas) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const size = 40;
    canvas.width = Math.round(size * dpr);
    canvas.height = Math.round(size * dpr);
    const c = canvas.getContext('2d');
    if (!c) return;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, size, size);
    paintCellOn(c, 1, 1, size - 2, COLORS.I, {}, id);
  }

  function updatePauseSkins() {
    if (!skinsBox) return;
    for (let i = 0; i < skinsBox.children.length; i++) {
      const b = skinsBox.children[i];
      b.classList.toggle('on', b.dataset.skin === settings.skin);
    }
  }

  function buildPauseSkins() {
    if (!skinsBox) return;
    skinsBox.innerHTML = '';
    SKINS.forEach(function (sk) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'tg-skin';
      b.dataset.skin = sk.id;
      const cv = document.createElement('canvas');
      b.appendChild(cv);
      const span = document.createElement('span');
      span.textContent = T(sk.name);
      b.appendChild(span);
      b.addEventListener('click', function (ev) {
        ev.stopPropagation();
        applySkin(sk.id);
      });
      skinsBox.appendChild(b);
      paintSkinSwatch(cv, sk.id);
    });
    updatePauseSkins();
  }

  function applySkin(id) {
    settings.skin = id;
    settings.skinMode = 'manual';
    try {
      const st = JSON.parse(localStorage.getItem('tetris.settings') || '{}');
      st.skin = id;
      st.skinMode = 'manual';
      st.lastSkin = id;
      localStorage.setItem('tetris.settings', JSON.stringify(st));
    } catch (e) {}
    updatePauseSkins();
    if (game) render(performance.now());
    toast(EN() ? 'Skin: ' + T(skinDef(id).name) : '方块材质：' + skinDef(id).name);
    dispatch('tetris-skin', { skin: id, mode: 'manual' });
  }

  function previewSkin(canvas, id) {
    if (!canvas) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const cw = 132, ch = 40;
    const pw = Math.round(cw * dpr), ph = Math.round(ch * dpr);
    if (canvas.width !== pw || canvas.height !== ph) {
      canvas.width = pw;
      canvas.height = ph;
    }
    const c = canvas.getContext('2d');
    if (!c) return;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    c.clearRect(0, 0, cw, ch);
    c.fillStyle = '#0a0c12';
    c.fillRect(0, 0, cw, ch);
    const cols = ['#3ee0c6', '#ffc857', '#b07cff', '#5bd75b'];
    const size = 26, gap = 6;
    const total = cols.length * size + gap * (cols.length - 1);
    const x0 = (cw - total) / 2, y0 = (ch - size) / 2;
    for (let i = 0; i < cols.length; i++) {
      paintCellOn(c, x0 + i * (size + gap), y0, size, cols[i], {}, id);
    }
  }

  window.TetrisGame = {
    start: start,
    stop: exitToMenu,
    skins: function () {
      return SKINS.map(function (s) { return { id: s.id, name: s.name }; });
    },
    previewSkin: previewSkin,
    isRunning: function () { return running; },
    // 给控制台 / 测试用的把手，不参与游戏逻辑
    _state: function () { return game; },
    _skin: function () { return settings.skin; },
    _aiState: function () { return aiState; },
    _spectate: function () { return spectate; },
    _spectateStep: function (ms) {
      if (!spectate) return;
      stepSpectate(Math.max(0, ms || 16));
      render(performance.now());
    },
    _stepForTest: function (ms) {
      if (!game || over) return;
      const step = Math.max(0, Math.min(ms || 16, 120));
      game.tick(step);
      updateDAS(step);
      pumpEvents();
      if (aiMode) stepAI(step);
      render(performance.now());
    }
  };
})();
