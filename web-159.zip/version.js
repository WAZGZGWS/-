/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '1.55',
  code: 61,
  web: 159,
  date: '2026-11-20',
  title: '音量别缩两次',
  titleEn: 'Stop scaling the volume twice',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单/普通/困难。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard."
    }
  ],
  log: [
    {
      "v": "1.55",
      "date": "2026-11-20",
      "title": "音量别缩两次",
      "summary": "上一版把系统音量映射成游戏音量，结果缩了两次——手机 50% × 游戏 50% = 25%，比设的还小。现在游戏音量固定 1，只跟系统走；系统音量那行只显示真实值。顺带把多人页两句「没人开就替你开一个 N 人的」改成「让你选开几人的」（上一版已经改成先问人数了，文字没跟上）。",
      "added": [],
      "changed": [
        "音量：游戏不再按系统音量二次缩放，只跟随系统",
        "多人页提示：没人开房时会先问你开几人"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.54",
      "date": "2026-11-20",
      "title": "更多页瘦身",
      "summary": "「更多」从 7 行收成 4 行：存档那三行（分组标题 + 当前存档 + 存档管理按钮）并成一个「存档管理」按钮，当前存档摘要写进它的 tag；删掉两个空行；页面底部那行脚注（又写一遍版本号）也删了。",
      "added": [],
      "changed": [
        "更多页：7 行 → 4 行，当前存档摘要并进「存档管理」按钮"
      ],
      "balance": [],
      "removed": [
        "更多页的分组标题、空行和底部脚注"
      ]
    },
    {
      "v": "1.53",
      "date": "2026-11-20",
      "title": "人数挪进开房时",
      "summary": "多人面板上那行「2 人 / 3 人 / 4 人」删了——它只对自己开房有用，客人永远用不到。现在改成「开房那一刻才问」：快速匹配没找到房间时，出来一张小卡「没人开房。开一间：[2 人][3 人][4 人]」，点一下就开。",
      "added": [
        "开房时机里选人数（2/3/4 一次点击）"
      ],
      "changed": [
        "多人面板：去掉常驻的人数选择，首屏少一行"
      ],
      "balance": [],
      "removed": [
        "多人面板的「人数 2/3/4」seg"
      ]
    },
    {
      "v": "1.52",
      "date": "2026-11-19",
      "title": "版本页只留这一版",
      "summary": "版本页的「更新记录」那 15 张卡片删了——没人往下翻，占地方还占包体。现在页面只显示这一版是什么（版本号、日期、标题），要更新就看「怎么更新」，「复制这一版说明」仍然带本次和上一版的正文；全量历史在仓库 CHANGELOG.md。顺带把「更新前先存档」那条红字改成只在安装包真的旧了时才出现。",
      "added": [],
      "changed": [
        "版本页：去掉更新记录列表，只显示当前版本",
        "「更新前先存档」只在安装包旧了时显示"
      ],
      "balance": [],
      "removed": [
        "版本页的更新记录卡片（15 条）"
      ]
    },
    {
      "v": "1.51",
      "date": "2026-11-19",
      "title": "帮助页收成速查",
      "summary": "「玩法说明」从 12 条压到 7 条：模式入口、经典玩法、分数、存档、联机、安装与更新、以及一句「细节看教程」。合体块、债、转场、方向块、怎么算死和重开这几条原来和教程逐句重复，删掉了——教程那 7 页带图，还更清楚。中英文两份一起改。",
      "added": [
        "玩法说明补上「安装与更新」一条"
      ],
      "changed": [
        "「玩法说明」12 条 → 7 条速查，过程讲解归到新手教程"
      ],
      "balance": [],
      "removed": [
        "帮助页里与教程重复的 5 条（合体块/债/转场/方向块/重开清档）"
      ]
    }
  ],
  logEn: [
    {
      "v": "1.55",
      "date": "2026-11-20",
      "title": "Stop scaling the volume twice",
      "summary": "The last version mapped the system volume onto the game volume, which attenuated twice — 50% on the phone times 50% in the game is 25%, quieter than set. Game volume is now fixed at 1 and simply follows the system; the system-volume line shows the real value. Also fixed two multiplayer hints that still claimed the game opens a room for you.",
      "added": [],
      "changed": [
        "Volume: no second scaling inside the game; it just follows the system",
        "Multiplayer hint: when nobody hosts, it asks how many players"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.54",
      "date": "2026-11-20",
      "title": "A leaner More screen",
      "summary": "More went from seven rows to four: the three save rows (group label, current save, Saves button) are now one button whose tag carries the current-save summary; two blank rows and the footer line (which repeated the version) are gone.",
      "added": [],
      "changed": [
        "More screen: seven rows to four; the current-save summary lives in the Saves button tag"
      ],
      "balance": [],
      "removed": [
        "The save group label, blank rows and footer line on the More screen"
      ]
    },
    {
      "v": "1.53",
      "date": "2026-11-20",
      "title": "Pick the player count when hosting",
      "summary": "The 2/3/4 player row is gone from the multiplayer panel — it only mattered when you host, and guests never used it. The choice now happens at the moment of hosting: when quick match finds no room, a small card asks \"Nobody is hosting. Open a room: [2][3][4]\" and one tap opens it.",
      "added": [
        "Choose the player count at hosting time (one tap for 2/3/4)"
      ],
      "changed": [
        "Multiplayer panel: the always-on player-count row is gone; one less row up front"
      ],
      "balance": [],
      "removed": [
        "The 2/3/4 player row in the multiplayer panel"
      ]
    },
    {
      "v": "1.52",
      "date": "2026-11-19",
      "title": "Version page shows just this build",
      "summary": "The changelog cards on the version page are gone — nobody scrolls that far, and they cost space and bytes. The page now shows only what this build is (version, date, title); How to update keeps the steps, Copy this version still carries this and the previous entry, and the full history lives in CHANGELOG.md.",
      "added": [],
      "changed": [
        "Version page: no changelog list, just the current build",
        "The save-first warning only appears when the APK is actually old"
      ],
      "balance": [],
      "removed": [
        "The changelog cards on the version page"
      ]
    },
    {
      "v": "1.51",
      "date": "2026-11-19",
      "title": "Help is a quick-reference now",
      "summary": "How to Play went from 12 blocks to 7: mode entry, classic rules, score, saves, multiplayer, install & update, and one line pointing at the tutorial. Fusion blocks, debt, rotation, arrow blocks and restart were word-for-word duplicates of the tutorial, which has pictures — those are gone. Both languages updated.",
      "added": [
        "An Install & update line in How to Play"
      ],
      "changed": [
        "How to Play: 12 blocks to 7; the walk-throughs live in the tutorial"
      ],
      "balance": [],
      "removed": [
        "Five help blocks that duplicated the tutorial (fusion blocks, debt, rotation, arrow blocks, restart)"
      ]
    }
  ],




  };
})();
