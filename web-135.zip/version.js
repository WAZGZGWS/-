/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '1.31',
  code: 59,
  web: 135,
  date: '2026-11-17',
  title: '修 1.30 界面报错',
  titleEn: 'Fix 1.30 UI crash',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单/普通/困难。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard."
    }
  ],
  log: [
    {
      "v": "1.31",
      "date": "2026-11-17",
      "title": "修 1.30 界面报错",
      "summary": "1.30 里设置页有个选择器写错（单 $ 却调用 forEach），报错导致首页版本号停在 v0.3、按钮也没反应；这一版修掉，界面恢复正常。",
      "added": [],
      "changed": ["修复设置页脚本错误：语言分组的选择器改回批量查询"],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.30",
      "date": "2026-11-17",
      "title": "手感可调 · DAS/ARR",
      "summary": "设置 → 游戏里多了「手感」三档：标准 / 快 / 极快，调的是按住左右键后多久开始连移、连移多快；老玩家能按自己的习惯调，默认还是标准。",
      "added": ["设置 → 游戏 → 手感：标准 170/30ms、快 130/15ms、极快 105/8ms"],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.29",
      "date": "2026-11-17",
      "title": "菜单合并 · 语言并组",
      "summary": "设置里「语言」不再单独开一个抽屉，并进「游戏」组末尾；入口标签同步改成「帧率 / 声音 / 材质 / 语言」。",
      "added": [],
      "changed": ["语言三选一移入游戏设置组，少一个入口"],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.28",
      "date": "2026-11-17",
      "title": "联机走壳 · 手机也能连",
      "summary": "手机 WebView 是 file:// 页面，直接 fetch 局域网会被 Chromium 拦掉，所以两台安卓一直连不上；现在联机的 HTTP 全部改走安装包里的 Java 通道（1.6 壳），不用再靠浏览器。",
      "added": [],
      "changed": [
        "联机：加入房间 / 轮询 / 心跳改走壳的 lanGet / lanPost，file:// 页面不再被跨域拦",
        "房主版本探测也走壳，加入前能正常比对版本",
        "安装包升到 v1.6（壳 59）"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.27",
      "date": "2026-11-17",
      "title": "侧栏极简 · 大字不挤",
      "summary": "右侧数据栏原来是四行小字加两条 9px 注释，挤在一起；现在收成三条大字（等级 / 消行 / 最高）加一行状态，分数再长也不缩成蚂蚁字。",
      "added": [],
      "changed": [
        "侧栏：去掉重复的「结束欠 / 债已清 / 消行」小字，债放进底部状态行（债 -N 变红）",
        "字号：标签 11→12、数值 13→15，行距 22→26，行与行之间不再贴在一起",
        "长分数：先试 28px，塞不下就换紧凑写法（一百二十三万余），不再缩到 11px"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.26",
      "date": "2026-11-17",
      "title": "英文记录去中文 · 统计标签",
      "summary": "英文模式的版本记录里，1.25 那条还举了「一万二千三百四十五」这种中文例子，已改成英文描述；「更多」里统计标签在没打过分时会显示「12 局」，英文下改成 games。",
      "added": [],
      "changed": [
        "英文更新记录：去掉中文数字与「万/亿」示例，1.23 那条的品牌名也改成英文描述",
        "统计标签：英文模式显示 games 而不是「局」"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.25",
      "date": "2026-11-16",
      "title": "分数用汉字写",
      "summary": "中文模式下的分数改成汉字：12345 显示「一万二千三百四十五」，HUD 会按宽度自动缩小字号不顶出面板；英文模式仍用英文自己的写法（12.3k / 1.2M）。",
      "added": [],
      "changed": [
        "中文分数：一万以下直接写汉字（九百九十九），一万以上按 万/亿 写全（十二万三千四百五十六、一亿零一）",
        "分数变长后 HUD 与观战比分自动缩字号，不挤坏面板；结算、最高分、统计、存档列表同步"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.24",
      "date": "2026-11-16",
      "title": "浮层英文补齐 · 教程补画一帧",
      "summary": "英文模式下结算浮层（对局结束 / 债还不完，本局结束 / 重开 R）和对战条（你 / 对手 / 准备 / 我 / 决一死战）原来还是中文，现在补齐；继续上一局时标题里的「继续」也改了。教程打开时补画一帧，避免个别 WebView 首帧空白。",
      "added": [],
      "changed": [
        "教程打开后补画一帧 canvas（只影响首帧，不改画面内容）",
        "英文模式：结算浮层、对战条、决一死战、继续局标签（Resumed / Combo · resumed / Classic · resumed）全部英文化"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.23",
      "date": "2026-11-16",
      "title": "英文联机 · 中文漏译补全",
      "summary": "英文模式下「多人对战」抽屉里的副标题、快速匹配、附近的房间、开房提示、复制下载链接、蓝牙发安装包等一批文字原来还是中文，现在补齐；设置里的分组标题和存档说明也一并翻了。",
      "added": [],
      "changed": [
        "英文模式：多人对战抽屉（副标题/快速匹配/附近房间/开房与加入/复制链接/蓝牙发安装包/分享步骤/上次的对手/蓝牙配对）全部英文化",
        "英文模式：设置分组标题（帧率声音材质、屏幕与设备、方向刷新率性能、性能档自动）、存档说明、最近错误、复制这一版说明、怎么更新 同步英文化",
        "英文模式唯一的剩中文是标题 logo「合体债」（品牌名），下面是 FUSION DEBT"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.22",
      "date": "2026-11-16",
      "title": "本地统计 · 英文补齐",
      "summary": "「更多」里多了本地统计（局数/消行/最高/最长连击/累计还债，只存本机）；英文教程补齐到现在的规则，不再教已经删掉的东西；更新会优先走上次连上的源。",
      "added": [
        "更多 → 统计：局数、消行数、最高分、最长连击、累计还债，可一键清空（只存这台设备，不上传）"
      ],
      "changed": [
        "英文教程重写：删掉已移除的字母块页，转场改成「轻松不转、普通/困难每 15 秒转」，最后一页回到「怎么算死、怎么重开」",
        "英文帮助页的转场说明同步成现在的规则（不再写「设置里打开自动旋转」）",
        "更新优先用上次连上的源，被墙的源不再每次启动白等 3 秒超时"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.21",
      "date": "2026-11-16",
      "title": "坏包自愈 · 一键重装",
      "summary": "网页包万一坏到打不开（白屏、点不动、一开就退），启动时会自动退回上一版，也能在「怎么更新」里手动重装；手机上的方向键又放大一档。",
      "added": [
        "启动自检：网页脚本没起来就自动退回上一个能用的网页包",
        "「更多 → 版本与更新 → 怎么更新」新增「重装网页包（修坏包）」，同版本也重下，存档不受影响",
        "方向键放大：手机横屏 53→66px、平板 66→76px、大屏上限 96→104px；小屏先缩棋盘，不缩键位"
      ],
      "changed": [
        "安装包升到 v1.5（壳 58）：带自检回落与强制重装能力；网页包仍是自动更新"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.20",
      "date": "2026-11-16",
      "title": "记录错误 · 暂停省电",
      "summary": "页面出错会自动记下最近一条（设置里能看到，复制版本说明时也带上）；暂停时彻底停掉渲染循环，不再空转耗电。",
      "added": [
        "设置 → 屏幕与设备 多一行「最近错误」，复制版本说明时一并带上"
      ],
      "changed": [
        "暂停时停掉 requestAnimationFrame 循环，恢复时重启（原来暂停还在每秒空转）",
        "清理没用的翻译词条与残留开关"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.19",
      "date": "2026-11-16",
      "title": "长局减压 · 新手推荐",
      "summary": "每 15 次消行，下一块合体块只顶 1 行——长局不再只剩「越来越难」；轻松档标上「新手推荐」。",
      "added": [
        "长局减压：每 15 次消行，下一块合体块只顶 1 行（会弹提示）"
      ],
      "changed": [
        "轻松档的说明前面加了「新手推荐」，第一次玩更容易找到"
      ],
      "balance": [
        "删掉字母块后长局缺一个「逐渐变简单」的出口，用每 15 次消行的 1 行块补上"
      ],
      "removed": []
    },
    {
      "v": "1.18",
      "date": "2026-11-16",
      "title": "砍掉多余的",
      "summary": "删掉字母块、债务重组改成每局 -15%、常驻和计时合并、多人面板去掉重复选项、开场与提示各收一档；更新记录只留最近 15 条：version.js 从 106KB 瘦到 22KB，更新包（压缩后）从 161KB 降到 133KB。",
      "added": [],
      "changed": [
        "字母块删除：合体块始终是 2 行、1~2 个洞，不再变形",
        "债务重组：连续 3 局没还清减半 → 每局没还清自动消 15%",
        "常驻与计时（原禅模式）合并成一个面板：连击 / 计时 5·10 分钟",
        "多人面板：去掉「和谁玩」「操作」两个选项，「上次房间」「上次蓝牙」并成一个「上次的对手」",
        "设置：开场动画只留开/关，去掉「右上角提示」三档（固定自动）",
        "更新记录只保留最近 15 条，更早的看仓库 CHANGELOG.md"
      ],
      "balance": [],
      "removed": [
        "字母块（变形与字母绘制）",
        "「和谁玩」「操作」选项",
        "「右上角提示」三档"
      ]
    },
    {
      "v": "1.17",
      "date": "2026-11-16",
      "title": "键位再大一点 · 更新引导",
      "summary": "方向键在所有模式里再放大一档，并往屏幕中间收了一点（仍然不压棋盘）；版本页新增「怎么更新」，讲清网页包和安装包的区别。",
      "added": [
        "版本与更新页新增「怎么更新」：判断安装包新旧、三步说明、复制安装包地址/镜像、检查网页包更新"
      ],
      "changed": [
        "键位基准再上调（横屏 12%、竖屏 14%、大屏 9%），上限 66 / 78 / 96",
        "键位离边框的留白从约 2% 提到约 6%，整体往中间收一点",
        "小屏塞不下时仍会自动缩回去，不会压棋盘或出屏"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.16",
      "date": "2026-11-16",
      "title": "键位放大一档",
      "summary": "所有模式的方向键和暂存键都在原来基础上放大了一点，手指更好按；「不压棋盘、不出屏」的自动复核照旧兜底。",
      "added": [],
      "changed": [
        "横屏：基准从屏幕短边的 10% 提到 10.8%，上限 52 → 56",
        "竖屏：基准从宽度的 12% 提到 13%，上限 66 → 72",
        "大屏：上限 84 → 88（1080p 横屏约 86px）",
        "旋转/强制横屏的布局同步放大"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.15",
      "date": "2026-11-16",
      "title": "复制里补上下文",
      "summary": "复制出来的说明多了两行：上一版是什么、几个术语什么意思——这样模型不只答得出「这版改了什么」，还能答「跟上一版比改了什么」。",
      "added": [],
      "changed": [
        "复制内容加「上一版：v1.14 · 标题」",
        "复制内容加术语解释：合体块 / 债 / 网页包 / 安装包（壳）"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.14",
      "date": "2026-11-16",
      "title": "复制内容适合发给 AI",
      "summary": "「复制这一版说明」改成结构化文本：先一句这游戏是什么，再一行一个字段，最后带明确小节的更新记录；粘给任何模型都能直接读懂。",
      "added": [],
      "changed": [
        "复制内容：开头补一句玩法（10×10、消行顶合体块、债跨局），避免对方不知道这是什么游戏",
        "字段拆成一行一个：版本 / 网页包 / 安装包（壳）/ 设备；更新记录带「简介 / 新增 / 调整」小节"
      ],
      "balance": [],
      "removed": []
    }
  ],
  logEn: [
    {
      "v": "1.31",
      "date": "2026-11-17",
      "title": "Fix 1.30 UI crash",
      "summary": "1.30 had a wrong selector in Settings (single $ calling forEach), which threw and left the home version at v0.3 and buttons dead. Fixed here.",
      "added": [],
      "changed": ["Fixed the settings script error: language group selector now queries all nodes"],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.30",
      "date": "2026-11-17",
      "title": "Handling: DAS/ARR",
      "summary": "Settings → Game now has Handling: Standard / Fast / Instant, controlling how soon and how fast held left/right auto-repeats. Defaults to Standard.",
      "added": ["Settings → Game → Handling: Standard 170/30ms, Fast 130/15ms, Instant 105/8ms"],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.29",
      "date": "2026-11-17",
      "title": "Settings merged",
      "summary": "Language no longer opens its own sheet; it now sits at the end of the Game group, and the entry label says Frame rate / Sound / Skin / Language.",
      "added": [],
      "changed": ["Language moved into the Game settings group — one less entry"],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.28",
      "date": "2026-11-17",
      "title": "LAN through the shell",
      "summary": "The WebView page runs on file://, so plain fetch to the LAN is blocked by Chromium — that is why two Android devices could never connect. LAN HTTP now goes through the shell (APK 1.6).",
      "added": [],
      "changed": [
        "Multiplayer: join, polling and heartbeats go through the shell lanGet/lanPost instead of fetch",
        "Host version probing also goes through the shell, so the pre-join version check works",
        "APK is now v1.6 (shell 59)"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.27",
      "date": "2026-11-17",
      "title": "Cleaner HUD",
      "summary": "The side panel used to stack four small rows plus two 9px captions; it is now three larger rows (Level / Lines / Best) and a single status line, and long scores no longer shrink to ant-size.",
      "added": [],
      "changed": [
        "Panel: dropped the duplicate End-debt / Debt-paid / Lines captions; debt now lives in the bottom status line (Debt -N in red)",
        "Type: labels 11 to 12, values 13 to 15, row pitch 22 to 26 — rows no longer touch",
        "Long scores: try 28px first, then switch to the compact form instead of shrinking to 11px"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.26",
      "date": "2026-11-17",
      "title": "English changelog cleanup",
      "summary": "The English 1.25 entry still used Chinese numerals as examples and the stats tag said the Chinese word for games when no score existed — both fixed.",
      "added": [],
      "changed": [
        "English changelog: removed the Chinese numeral and unit examples, and the brand name in the 1.23 entry is now described in English",
        "Stats tag now reads games instead of the Chinese word"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.25",
      "date": "2026-11-16",
      "title": "Scores in words",
      "summary": "Chinese mode now spells scores out in Chinese numerals, and the HUD shrinks the font to fit; English mode keeps the English convention (12.3k / 1.2M).",
      "added": [],
      "changed": [
        "Chinese scores: written out in characters below 10k, and in the 10k / 100M units above",
        "The HUD and spectator score auto-shrink so long scores stay inside the panel; result screen, best score, stats and save list follow"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.24",
      "date": "2026-11-16",
      "title": "Overlay English · tutorial repaint",
      "summary": "In English the game-over overlay (Game over / Debt unpaid — run over / Restart R) and the versus bar (You / Opponent / Ready / Me / duel title) were still Chinese — translated now, along with the resume label.",
      "added": [],
      "changed": [
        "Tutorial repaints one extra frame on open (first frame only; artwork unchanged)",
        "English: game-over overlay, versus bar, duel title and resume labels (Resumed / Combo · resumed / Classic · resumed) translated"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.23",
      "date": "2026-11-16",
      "title": "English multiplayer complete",
      "summary": "In English mode the Multiplayer drawer still had Chinese subtitles, Quick match, Rooms nearby, hosting hints, Copy download link, Send APK over Bluetooth and more — all translated now, plus the settings group titles and save notes.",
      "added": [],
      "changed": [
        "English: the Multiplayer drawer is fully English (subtitle, Quick match, rooms nearby, host/join, share steps, last opponent, Bluetooth pairing)",
        "English: settings group titles (frame rate/sound/skin, screen & device, orientation/refresh/performance, quality auto), save notes, Last error, Copy this version note and How to update are translated",
        "The only Chinese left in English mode is the title logo — the game\u2019s Chinese name, with FUSION DEBT underneath"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.22",
      "date": "2026-11-16",
      "title": "Local stats · English fixed",
      "summary": "More → Stats shows games, lines, best score, best combo and debt paid (this device only); the English tutorial now matches the current rules; updates try the last working source first.",
      "added": [
        "More → Stats: games, lines, best score, best combo, debt paid, with one-tap clear (stored locally, never uploaded)"
      ],
      "changed": [
        "English tutorial rewritten: the removed letter-block page is gone, rotation now says \u201cEasy never, Normal/Hard every 15s\u201d, and the last page is how you die / restart again",
        "English help no longer tells players to enable a removed auto-rotate setting",
        "Updater remembers the last working source, so blocked mirrors stop costing a 3s timeout every launch"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.21",
      "date": "2026-11-16",
      "title": "Self-heal · one-tap reinstall",
      "summary": "If a web bundle ever breaks badly (white screen, taps do nothing, closes on open), the app falls back to the previous working bundle at startup and can be reinstalled from How to update; the on-screen keys are a size bigger on phones.",
      "added": [
        "Startup self-check: falls back to the last working web bundle when the page scripts fail to boot",
        "How to update now has \u201cReinstall web bundle (repair)\u201d \u2014 same version re-downloads too; saves untouched",
        "Bigger on-screen keys: phone landscape 53 \u2192 66px, tablet 66 \u2192 76px, large-screen cap 96 \u2192 104px; on small screens the board shrinks first, not the keys"
      ],
      "changed": [
        "APK is now v1.5 (shell 58): includes the fallback and forced reinstall; the web bundle still updates itself"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Error log · pause saves power",
      "summary": "The last JS error is recorded (shown in Settings and included in the copied version note); pausing now stops the render loop instead of spinning.",
      "added": [
        "Screen & device shows the last error; the copied version note includes it"
      ],
      "changed": [
        "Pausing stops the requestAnimationFrame loop and resumes it on unpause",
        "Dropped unused translation entries and leftover switches"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Late-game relief · beginner pick",
      "summary": "Every 15 clears the next fusion block is only one row, so long runs are not just harder and harder; the Easy tier is now labelled as the beginner pick.",
      "added": [
        "Late-game relief: every 15 clears, the next fusion block is 1 row instead of 2 (with a toast)"
      ],
      "changed": [
        "The Easy tier now says Recommended for newcomers"
      ],
      "balance": [
        "Removing letter blocks took away the only late-game easing; the 1-row block every 15 clears puts a rhythm back"
      ],
      "removed": []
    },
    {
      "title": "Trim the fat",
      "summary": "Letter blocks removed, debt restructuring eased 15% per run, casual and zen merged, multiplayer panel de-duplicated, intro and hints simplified; the changelog keeps the last 15 entries, cutting the update bundle from 160KB to about 60KB.",
      "added": [],
      "changed": [
        "Letter blocks removed: fusion blocks are always 2 rows with 1-2 holes",
        "Debt restructuring: instead of halving after 3 unpaid runs, every unpaid run eases the debt by 15%",
        "Casual and Zen merged into one panel: Combo / Timed 5 or 10 minutes",
        "Multiplayer panel: Who-to-play and Action switches removed; last LAN room and last Bluetooth opponent merged into one button",
        "Settings: intro is on/off, the three-way top-right hint switch is gone (always auto)",
        "Changelog keeps the last 15 entries; older ones live in the repo CHANGELOG.md"
      ],
      "balance": [],
      "removed": [
        "Letter blocks (morph and glyph drawing)",
        "Who-to-play and Action switches",
        "Three-way hint switch"
      ]
    },
    {
      "title": "Bigger controls again · update guide",
      "summary": "Direction keys grow another step in every mode and sit a little further from the screen edges (still never covering the board); the version page gains a How to update guide.",
      "added": [
        "Version page: How to update — checks whether the APK is old, shows three steps, copies the APK or mirror link, and can check the web bundle"
      ],
      "changed": [
        "Larger key baseline (landscape 12%, portrait 14%, big screens 9%), caps 66 / 78 / 96",
        "Edge margin grows from about 2% to 6%, pulling the pads inward",
        "On very small screens the keys still shrink automatically instead of covering the board"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Bigger controls",
      "summary": "The direction and hold keys grow a little in every mode; the existing check that keeps them off the board and inside the screen still applies.",
      "added": [],
      "changed": [
        "Landscape baseline 10% → 10.8% of the short edge, cap 52 → 56",
        "Portrait baseline 12% → 13% of width, cap 66 → 72",
        "Large screens: cap 84 → 88 (about 86px at 1080p landscape)",
        "Rotated/forced-landscape layouts scale with the same numbers"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "More context in the copy",
      "summary": "The copied note gains two lines — what the previous version was and what the main terms mean — so a model can answer what changed compared with the last version, not just this version.",
      "added": [],
      "changed": [
        "Adds Previous: v1.14 with its title",
        "Adds a glossary: fusion block / debt / web bundle / APK shell"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy text is AI-friendly",
      "summary": "The copied version note is now structured: one line saying what the game is, one field per line, then the changelog entry with labelled sections — paste it into any model and it reads cleanly.",
      "added": [],
      "changed": [
        "The note opens with a one-line description (10×10, clearing lines pushes a fusion block, debt carries over)",
        "Fields are one per line: version / web bundle / APK shell / device; the changelog uses Summary, Added, Changed sections"
      ],
      "balance": [],
      "removed": []
    }
  ],




  };
})();
