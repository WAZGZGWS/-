/* net.js —— 局域网联机客户端（HTTP 轮询，电脑/手机房主共用同一套）
 *
 * 用法：
 *   const s = await TetrisNet.join({base, room, name, onReady, onMessage, onStatus, onError});
 *   s.send({t:'state', score, debt, clears});
 *   s.leave();
 */
(function () {
  'use strict';

  const POLL_MS = 250;
  const RECONNECT_MS = 8000;

  function normalizeBase(input) {
    let s = String(input || '').trim();
    if (!s) return '';
    if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
    s = s.replace(/\/+$/, '');
    try {
      const u = new URL(s);
      if (!u.port) u.port = '8788';
      return u.protocol + '//' + u.host;
    } catch (e) {
      return s;
    }
  }

  const REQ_MS = 6000;      // 单个 HTTP 请求最多等这么久，别让界面一直卡在「连接中」
  function EN() { return !!(window.TetrisI18n && window.TetrisI18n.lang === 'en'); }
  function S(zh, en) { return EN() ? en : zh; }

  async function timedFetch(url, opt) {
    if (typeof AbortController !== 'function') return fetch(url, opt);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), REQ_MS);
    try {
      return await fetch(url, Object.assign({}, opt, { signal: ctrl.signal }));
    } catch (e) {
      if (e && (e.name === 'AbortError' || /aborted/i.test(String(e.message)))) {
        const en = !!(window.TetrisI18n && window.TetrisI18n.lang === 'en');
        throw new Error(en ? 'Host did not respond (' + (REQ_MS / 1000) + 's timeout)' : '房主没响应（' + (REQ_MS / 1000) + ' 秒超时）');
      }
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  async function postJSON(url, body) {
    const res = await timedFetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=UTF-8' },
      body: JSON.stringify(body || {}),
      cache: 'no-store',
      credentials: 'omit'
    });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const err = new Error((data && data.error) || ('HTTP ' + res.status));
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  async function getJSON(url) {
    const res = await timedFetch(url, { cache: 'no-store', credentials: 'omit' });
    let data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      const err = new Error((data && data.error) || ('HTTP ' + res.status));
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function Session(opts) {
    this.base = normalizeBase(opts.base);
    this.room = String(opts.room || '').replace(/\D/g, '').slice(0, 4);
    this.rules = (opts.rules === 'classic') ? 'classic' : 'debt';
    this.name = String(opts.name || '玩家').slice(0, 10);
    this.onReady = opts.onReady || function () {};
    this.onMessage = opts.onMessage || function () {};
    this.onStatus = opts.onStatus || function () {};
    this.onError = opts.onError || function () {};

    this.playerId = '';
    this.token = '';
    this.seed = 0;
    this.startAt = 0;
    this.players = [];
    this.seq = 0;
    this.offset = 0;
    this.ready = false;
    this.readyFired = false;
    this.closed = false;
    this.timer = 0;
    this.polling = false;
    this.reconnectingSince = 0;
  }

  Session.prototype.status = function (text, kind) {
    try { this.onStatus(text, kind || ''); } catch (e) {}
  };

  Session.prototype.connect = async function () {
    if (!this.base) throw new Error(S('没有房主地址', 'No host address'));
    if (this.room.length !== 4) throw new Error(S('房间码要 4 位数字', 'Room code must be 4 digits'));
    const fresh = !this.playerId;
    this.status(S('连接房主…', 'Connecting to host…'), 'wait');
    const data = await postJSON(this.base + '/api/join', {
      room: this.room,
      name: this.name,
      rules: this.rules,
      playerId: this.playerId || undefined,
      token: this.token || undefined
    });
    this.applyState(data);
    if (fresh) this.seq = data.seq || 0;
    if (!this.reconnectingSince) this.status(this.ready ? S('已就绪', 'Ready') : S('等另一个人进来…', 'Waiting for the other player…'), 'wait');
    this.offset = data.serverTime - Date.now();
    this.schedulePoll(0);
    return this;
  };

  Session.prototype.applyState = function (data) {
    if (!data) return;
    if (data.playerId) this.playerId = data.playerId;
    if (data.token) this.token = data.token;
    if (typeof data.seed === 'number') this.seed = data.seed;
    if (data.startAt) this.startAt = data.startAt;
    if (data.players) this.players = data.players;
    if (data.rules) this.rules = (data.rules === 'classic') ? 'classic' : 'debt';
    if (data.serverTime) this.offset = data.serverTime - Date.now();
    const wasReady = this.ready;
    this.ready = !!data.ready;
    if (this.ready && !this.readyFired) {
      this.readyFired = true;
      try {
        this.onReady({
          seed: this.seed,
          startAt: this.startAt,
          players: this.players,
          rules: this.rules,
          serverTime: data.serverTime || Date.now()
        });
      } catch (e) {}
    }
    if (!wasReady && this.ready) this.status(S('两人到齐，准备开始', 'Both players here — get ready'), 'ok');
  };

  Session.prototype.schedulePoll = function (ms) {
    if (this.closed) return;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.poll(), ms == null ? POLL_MS : ms);
  };

  Session.prototype.poll = async function () {
    if (this.closed || this.polling) return;
    this.polling = true;
    try {
      const url = this.base + '/api/poll?playerId=' + encodeURIComponent(this.playerId)
        + '&token=' + encodeURIComponent(this.token) + '&since=' + this.seq;
      const data = await getJSON(url);
      this.applyState(data);
      if (data.messages && data.messages.length) {
        for (const m of data.messages) {
          try { this.onMessage(m); } catch (e) {}
        }
      }
      if (typeof data.seq === 'number') this.seq = Math.max(this.seq, data.seq);
      if (this.reconnectingSince) {
        this.reconnectingSince = 0;
        this.status(S('重连成功', 'Reconnected'), 'ok');
      }
      this.polling = false;
      this.schedulePoll(POLL_MS);
    } catch (e) {
      this.polling = false;
      if (this.closed) return;
      if (!this.reconnectingSince) {
        this.reconnectingSince = Date.now();
        this.status(S('连接断了，重连中…', 'Disconnected — reconnecting…'), 'err');
      }
      if (Date.now() - this.reconnectingSince > RECONNECT_MS) {
        this.status(S('重连失败，退出联机', 'Reconnect failed — leaving the match'), 'err');
        try { this.onError(e); } catch (err) {}
        return;
      }
      this.connect().catch(() => {});
      this.schedulePoll(800);
    }
  };

  Session.prototype.send = function (msg) {
    if (this.closed || !this.playerId) return;
    postJSON(this.base + '/api/msg', {
      playerId: this.playerId,
      token: this.token,
      msg: msg
    }).catch(() => {});
  };

  Session.prototype.leave = function () {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    if (this.playerId) {
      postJSON(this.base + '/api/leave', { playerId: this.playerId, token: this.token }).catch(() => {});
    }
  };

  /* ---------------- 蓝牙经典 RFCOMM 直连 ---------------- */
  function BtSession(opts) {
    this.host = !!opts.host;
    this.mac = String(opts.mac || '');
    this.rules = (opts.rules === 'classic') ? 'classic' : 'debt';
    this.mode = (opts.mode === 'lan_battle') ? 'lan_battle' : 'lan_parallel';
    this.name = String(opts.name || '玩家').slice(0, 10);
    this.onReady = opts.onReady || function () {};
    this.onMessage = opts.onMessage || function () {};
    this.onStatus = opts.onStatus || function () {};
    this.onError = opts.onError || function () {};
    this.seed = opts.seed || ((Date.now() ^ Math.floor(Math.random() * 0xFFFFFFFF)) >>> 0);
    this.offset = 0;
    this.ready = false;
    this.closed = false;
    this.timer = 0;
    this._helloSent = false;
    this._startIn = 2200;
    this._lastState = '';
  }

  BtSession.prototype.status = function (text, kind) {
    try { this.onStatus(text, kind || ''); } catch (e) {}
  };

  BtSession.prototype._bridge = function () {
    if (window.TetrisHost && typeof window.TetrisHost.btInfo === 'function') return window.TetrisHost;
    return null;
  };

  BtSession.prototype.start = function () {
    var h = this._bridge();
    if (!h) {
      this.status(S('这个安装包还不支持蓝牙，装一次 0.8.0', 'This build has no Bluetooth — install 0.8.0'), 'err');
      try { this.onError(new Error('no bt bridge')); } catch (e) {}
      return this;
    }
    var r;
    try {
      r = JSON.parse(this.host ? h.btHost() : h.btJoin(this.mac));
    } catch (e) {
      r = { ok: false, error: String(e) };
    }
    if (!r || !r.ok) {
      this.status((r && r.error) || S('蓝牙开不了', 'Bluetooth could not start'), 'err');
      try { this.onError(new Error((r && r.error) || 'bt start failed')); } catch (e) {}
      return this;
    }
    this.status(this.host ? S('蓝牙房主已开，等另一台手机连…', 'Bluetooth room open — waiting for the other phone…') : S('正在连蓝牙…', 'Connecting Bluetooth…'), 'wait');
    var self = this;
    this.timer = setTimeout(function () { self._poll(); }, 120);
    return this;
  };

  BtSession.prototype._sendRaw = function (obj) {
    var h = this._bridge();
    if (!h || typeof h.btSend !== 'function') return false;
    try {
      var r = JSON.parse(h.btSend(JSON.stringify(obj)));
      return !!(r && r.ok);
    } catch (e) { return false; }
  };

  BtSession.prototype.send = function (msg) {
    if (this.closed || !this.ready) return;
    this._sendRaw(msg);
  };

  BtSession.prototype._poll = function () {
    if (this.closed) return;
    var h = this._bridge();
    if (!h) return;
    var info = null;
    try { info = JSON.parse(h.btInfo()); } catch (e) { info = null; }
    if (!info) {
      this._fail('读不到蓝牙状态');
      return;
    }
    if (info.state !== this._lastState) {
      this._lastState = info.state;
      if (info.state === 'connected') {
        this.status(S('蓝牙已连上', 'Bluetooth connected'), 'ok');
        if (this.host && !this._helloSent) {
          this._helloSent = true;
          this._sendRaw({
            t: 'btHello', seed: this.seed, rules: this.rules, mode: this.mode,
            startIn: this._startIn, name: this.name
          });
          this.status(S('等另一台手机准备…', 'Waiting for the other phone…'), 'wait');
        }
      } else if (info.state === 'connecting') {
        this.status(S('正在连蓝牙…', 'Connecting Bluetooth…'), 'wait');
      } else if (info.state === 'error') {
        this._fail(info.error || '蓝牙连接失败');
        return;
      } else if (info.state === 'closed' && this.ready) {
        this.closed = true;
        clearTimeout(this.timer);
        try { this.onError(new Error('蓝牙断了')); } catch (e) {}
        return;
      }
    }

    var arr = [];
    try { arr = JSON.parse(h.btPoll()); } catch (e) { arr = []; }
    if (arr && arr.length) {
      for (var i = 0; i < arr.length; i++) {
        var m = null;
        try { m = JSON.parse(arr[i]); } catch (e) { m = null; }
        if (!m) continue;
        if (m.t === 'btHello' && !this.host) {
          if (m.seed) this.seed = m.seed >>> 0;
          this.rules = (m.rules === 'classic') ? 'classic' : 'debt';
          this.mode = (m.mode === 'lan_battle') ? 'lan_battle' : 'lan_parallel';
          this._startIn = Math.max(300, Math.min(5000, Number(m.startIn) || 2200));
          this._sendRaw({ t: 'btReady' });
          this._ready();
          continue;
        }
        if (m.t === 'btReady' && this.host) {
          this._ready();
          continue;
        }
        if (this.ready) {
          try { this.onMessage(m); } catch (e) {}
        }
      }
    }
    var self = this;
    this.timer = setTimeout(function () { self._poll(); }, 100);
  };

  BtSession.prototype._ready = function () {
    if (this.ready || this.closed) return;
    this.ready = true;
    this.offset = 0;
    var startAt = Date.now() + this._startIn;
    this.status(S('准备好了，开局', 'Ready — starting'), 'ok');
    try {
      this.onReady({
        seed: this.seed,
        startAt: startAt,
        rules: this.rules,
        mode: this.mode,
        players: ['你', this.host ? '对手' : '房主'],
        serverTime: Date.now()
      });
    } catch (e) {}
  };

  BtSession.prototype._fail = function (msg) {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    this.status(msg || S('蓝牙失败', 'Bluetooth failed'), 'err');
    try { this.onError(new Error(msg || 'bt error')); } catch (e) {}
  };

  BtSession.prototype.leave = function () {
    if (this.closed) return;
    this.closed = true;
    clearTimeout(this.timer);
    if (this.ready) this._sendRaw({ t: 'peerLeft' });
    var h = this._bridge();
    if (h && typeof h.btClose === 'function') {
      try { h.btClose(); } catch (e) {}
    }
  };

  /* ---------------- 附近的房间（UDP 广播） ----------------
     房主每秒喊一次「我在，房间码 xxxx」，想加入的那台只听着，把听到的攒成列表。
     省掉手输 IP；收不到就退回手动填地址。 */
  function beaconBridge() {
    return (window.TetrisHost && typeof window.TetrisHost.lanStart === 'function') ? window.TetrisHost : null;
  }

  window.TetrisNet = {
    normalizeBase: normalizeBase,
    discover: {
      supported: function () { return !!beaconBridge(); },
      // self 非空 = 我也开房，让别人找到我；空 = 只听
      start: function (self) {
        var h = beaconBridge();
        if (!h) return { ok: false, error: 'no bridge', supported: false };
        try {
          var r = JSON.parse(h.lanStart(self ? JSON.stringify(self) : ''));
          return r || { ok: false };
        } catch (e) { return { ok: false, error: String(e) }; }
      },
      poll: function () {
        var h = beaconBridge();
        if (!h) return [];
        try { return JSON.parse(h.lanPoll()) || []; } catch (e) { return []; }
      },
      stop: function () {
        var h = beaconBridge();
        if (!h) return;
        try { h.lanStop(); } catch (e) {}
      }
    },
    join: async function (opts) {
      const s = new Session(opts);
      await s.connect();
      return s;
    },
    bt: function (opts) {
      return new BtSession(opts).start();
    }
  };
})();
