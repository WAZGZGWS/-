/* perf.js —— 设备算力粗评分：只给 AI 自动档用
 *
 * 不追求跑分，只看几个能拿到的信号：
 *   核数、内存、GPU 型号、刷新率、物理分辨率。
 * 分数 0~100；强机 AI 可以更狠，弱机自动收一点，但不影响手感和输入。
 */
(function () {
  'use strict';

  function gpuTier() {
    try {
      const c = document.createElement('canvas');
      const gl = c.getContext('webgl') || c.getContext('experimental-webgl');
      if (!gl) return 1;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const s = String(ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER) || '').toLowerCase();
      if (/adreno (7|8)\d\d|mali-g(7|8)|apple gpu|rtx|radeon rx|arc/.test(s)) return 3;
      if (/adreno (6)\d\d|mali-g(5|6)|intel iris|vega/.test(s)) return 2;
      if (/adreno|mali|powervr|intel/.test(s)) return 1;
      return 1;
    } catch (e) { return 1; }
  }

  function score() {
    if (score.cached != null) return score.cached;
    const cores = Number(navigator.hardwareConcurrency) || 4;
    const mem = Number(navigator.deviceMemory) || 3;
    let hz = 60;
    try {
      if (window.TetrisDevice && TetrisDevice.info) hz = TetrisDevice.info().hz || 60;
    } catch (e) {}
    let pixels = 0;
    try {
      const dpr = window.devicePixelRatio || 1;
      pixels = Math.max(0, (window.screen.width || innerWidth) * (window.screen.height || innerHeight) * dpr * dpr);
    } catch (e) {}
    const coresScore = Math.min(cores / 8, 1);
    const memScore = Math.min(mem / 6, 1);
    const gpuScore = gpuTier() / 3;
    const hzScore = Math.min(hz / 90, 1);
    const pixelScore = pixels ? Math.min(2000000 / pixels, 1) : 0.5;
    score.cached = Math.round(100 * (0.30 * coresScore + 0.25 * memScore + 0.20 * gpuScore
      + 0.15 * hzScore + 0.10 * pixelScore));
    return score.cached;
  }

  function resolve() {
    const s = score();
    if (s >= 70) return { score: s, difficulty: 'hard', label: '困难' };
    if (s >= 45) return { score: s, difficulty: 'normal', label: '普通' };
    return { score: s, difficulty: 'easy', label: '简单' };
  }

  window.TetrisPerf = { score: score, resolve: resolve };
})();
