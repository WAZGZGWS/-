/* device.js —— 运行设备信息：分辨率、窗口、刷新率
 *
 * 给设置页和游戏本体共用。
 *   TetrisDevice.info()   同步拿缓存（分辨率每次现算，hz 用上次测的）
 *   TetrisDevice.detect(cb) 异步测一次刷新率，回调 {width,height,cssW,cssH,dpr,hz}
 *
 * 刷新率用 rAF 的间隔中位数估算，再把 58~62 之类吸附到 60/90/120。
 */
(function () {
  'use strict';

  const KEY = 'tetris.device';
  let cache = {};
  try { cache = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { cache = {}; }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(cache)); } catch (e) {}
  }

  function info() {
    const dpr = window.devicePixelRatio || 1;
    const sw = window.screen && window.screen.width ? window.screen.width : window.innerWidth;
    const sh = window.screen && window.screen.height ? window.screen.height : window.innerHeight;
    // 物理分辨率一般是 10 的倍数；screen.width 是取整过的 CSS px，这里取整到 10 位
    return {
      width: Math.round(sw * dpr / 10) * 10,
      height: Math.round(sh * dpr / 10) * 10,
      cssW: Math.round(window.innerWidth),
      cssH: Math.round(window.innerHeight),
      dpr: Math.round(dpr * 100) / 100,
      hz: cache.hz || 0
    };
  }

  function detectHz(cb) {
    let times = [];
    let t0 = 0;
    let done = false;

    function finish() {
      if (done) return;
      done = true;
      const ds = [];
      for (let i = 1; i < times.length; i++) {
        const d = times[i] - times[i - 1];
        if (d >= 4 && d <= 40) ds.push(d);
      }
      if (ds.length < 8) { cb(0); return; }
      ds.sort(function (a, b) { return a - b; });
      const med = ds[Math.floor(ds.length / 2)];
      let hz = Math.round(1000 / med);
      // 实际测得 59.7 / 60.2 这种，吸附到整档
      const common = [30, 48, 60, 90, 120, 144, 165, 240];
      for (let i = 0; i < common.length; i++) {
        if (Math.abs(common[i] - hz) <= 3) { hz = common[i]; break; }
      }
      if (hz < 30 || hz > 240) hz = 0;
      cb(hz);
    }

    function step(t) {
      if (!t0) t0 = t;
      times.push(t);
      if (times.length < 80 && t - t0 < 1200) { requestAnimationFrame(step); return; }
      finish();
    }

    requestAnimationFrame(step);
    // 页面在后台时 rAF 会停；1.6 秒后无论如何收尾
    setTimeout(function () {
      if (!done && times.length >= 8) finish();
    }, 1600);
  }

  function detect(cb) {
    const base = info();
    detectHz(function (hz) {
      if (hz) {
        cache.hz = hz;
        cache.width = base.width;
        cache.height = base.height;
        cache.dpr = base.dpr;
        save();
      }
      base.hz = hz || cache.hz || 0;
      cb(base);
    });
  }

  window.TetrisDevice = { info: info, detect: detect };
})();
