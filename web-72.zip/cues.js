/* cues.js —— 提示的双通道
 *
 * 思路：不要问“玩家静音了吗”，而是让每个提示同时有声音和画面两路。
 * 声音只是一个渲染器，关掉它，画面照样把信息送到。
 *
 * 用法：
 *   <script src="cues.js"></script>
 *   Cues.cue('rotateSoon');        // 转场前 1.5 秒
 *   Cues.cue('debtHigh', {pct:72});
 *   Cues.cue('lineClear', {lines:4});
 *   Cues.setSound(false);          // 玩家关声音
 *
 * 它会自己建 DOM、自己管 AudioContext，不依赖任何库。
 */
(function (global) {
  'use strict';

  /* ---------------- 音频 ---------------- */
  const A = { ctx: null, master: null, comp: null, music: null, sfx: null, enabled: true, failed: false, volume: 1 };

  function ensureAudio() {
    if (A.ctx || A.failed) return A.ctx;
    try {
      const C = global.AudioContext || global.webkitAudioContext;
      if (!C) { A.failed = true; return null; }
      A.ctx = new C();
      // 之前的 0.55×0.9 太小：蓝牙耳机要开到很大声才勉强听见。
      // 这里把总线推高，再用压缩器兜住峰值，避免爆音。
      A.master = A.ctx.createGain(); A.master.gain.value = 0.9 * (A.volume == null ? 1 : A.volume);
      A.sfx = A.ctx.createGain(); A.sfx.gain.value = 3.2;
      A.music = A.ctx.createGain(); A.music.gain.value = 1.6;
      A.sfx.connect(A.master); A.music.connect(A.master);
      if (A.ctx.createDynamicsCompressor) {
        A.comp = A.ctx.createDynamicsCompressor();
        A.comp.threshold.value = -14;
        A.comp.knee.value = 10;
        A.comp.ratio.value = 6;
        A.comp.attack.value = 0.003;
        A.comp.release.value = 0.25;
        A.master.connect(A.comp); A.comp.connect(A.ctx.destination);
      } else {
        A.master.connect(A.ctx.destination);
      }
    } catch (e) { A.failed = true; A.ctx = null; }
    return A.ctx;
  }

  function muted() {
    if (!A.enabled || A.failed) return true;
    if (!A.ctx) return true;
    return A.ctx.state !== 'running';
  }

  function env(t, a, d, peak) {
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
    return g;
  }
  function tone(t, freq, dur, type, peak, bus) {
    const o = A.ctx.createOscillator();
    o.type = type || 'sine';
    o.frequency.value = freq;
    const g = env(t, 0.006, dur, peak || 0.12);
    o.connect(g); g.connect(bus || A.sfx);
    o.start(t); o.stop(t + dur + 0.12);
  }
  function riser(t, dur) {
    const len = Math.floor(A.ctx.sampleRate * dur);
    const buf = A.ctx.createBuffer(1, len, A.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const s = A.ctx.createBufferSource(); s.buffer = buf;
    const f = A.ctx.createBiquadFilter();
    f.type = 'bandpass'; f.Q.value = 2.4;
    f.frequency.setValueAtTime(280, t);
    f.frequency.exponentialRampToValueAtTime(4200, t + dur);
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.18, t + dur * 0.8);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(A.sfx);
    s.start(t); s.stop(t + dur + 0.05);
  }

  /* 一段往下扫的噪声：给结尾用的“余味” */
  function noise(t, dur, f0, f1, peak) {
    const len = Math.floor(A.ctx.sampleRate * dur);
    const buf = A.ctx.createBuffer(1, len, A.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = A.ctx.createBufferSource(); s.buffer = buf;
    const f = A.ctx.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 1;
    f.frequency.setValueAtTime(f0, t);
    f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    const g = A.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + 0.06);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(A.sfx);
    s.start(t); s.stop(t + dur + 0.05);
  }

  /* 一下“塌下来”：锯齿波从 240 滑到 58，带滤波，手机喇叭也听得见 */
  function collapse(t) {
    const o = A.ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.setValueAtTime(240, t);
    o.frequency.exponentialRampToValueAtTime(58, t + 0.75);
    const f = A.ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.setValueAtTime(2200, t);
    f.frequency.exponentialRampToValueAtTime(320, t + 0.9);
    const g = env(t, 0.008, 0.95, 0.26);
    o.connect(f); f.connect(g); g.connect(A.music);
    o.start(t); o.stop(t + 1.05);
  }

  /* ---------------- 画面 ---------------- */
  const R = { root: null, box: null, hideTimer: 0, edgeTimer: 0 };

  function build() {
    if (R.root) return;
    const css = document.createElement('style');
    css.textContent = `
      #cue-layer{position:fixed;inset:0;z-index:9999;pointer-events:none}
      #cue-edge{position:absolute;inset:0;box-shadow:inset 0 0 0 2px transparent;transition:box-shadow .18s}
      #cue-box{
        position:absolute;top:calc(env(safe-area-inset-top) + 12px);right:12px;
        max-width:min(76vw,320px);padding:10px 16px 11px;border-radius:12px;
        background:rgba(18,20,27,.95);border:1px solid rgba(62,224,198,.45);
        box-shadow:0 10px 30px -8px rgba(0,0,0,.75);
        transform:translateX(120%);opacity:0;
        transition:transform .22s cubic-bezier(.2,.9,.3,1),opacity .22s;
        font-family:system-ui,-apple-system,"Noto Sans SC","PingFang SC",sans-serif;
      }
      #cue-box.on{transform:none;opacity:1}
      #cue-box::before{content:'';position:absolute;left:0;top:9px;bottom:9px;width:3px;
        border-radius:0 3px 3px 0;background:#3ee0c6}
      #cue-box.warn::before{background:#ffc857}
      #cue-box.danger::before{background:#ff4d5e}
      #cue-box b{display:block;font-size:14px;letter-spacing:.04em;line-height:1.3;color:#e9edf6}
      #cue-box em{display:block;font-style:normal;font-size:11px;color:#79839a;margin-top:2px;line-height:1.35}
    `;
    document.head.appendChild(css);
    const root = document.createElement('div');
    root.id = 'cue-layer';
    root.innerHTML = '<div id="cue-edge"></div><div id="cue-box"><b></b><em></em></div>';
    document.body.appendChild(root);
    R.root = root;
    R.box = root.querySelector('#cue-box');
  }

  function flashEdge(tone, ms) {
    build();
    const edge = R.root.querySelector('#cue-edge');
    const color = tone === 'danger' ? '255,77,94' : tone === 'warn' ? '255,200,87' : '62,224,198';
    edge.style.boxShadow = 'inset 0 0 0 2px rgba(' + color + ',.55), inset 0 0 40px rgba(' + color + ',.18)';
    clearTimeout(R.edgeTimer);
    R.edgeTimer = setTimeout(function () {
      edge.style.boxShadow = 'inset 0 0 0 2px transparent';
    }, ms || 420);
  }

  function showHint(title, sub, tone, ttl) {
    build();
    R.box.className = 'on' + (tone ? ' ' + tone : '');
    R.box.querySelector('b').textContent = title;
    R.box.querySelector('em').textContent = sub || '';
    clearTimeout(R.hideTimer);
    R.hideTimer = setTimeout(function () { R.box.className = ''; }, ttl || 3000);
  }

  /* ---------------- 提示表 ---------------- */
  // 每一条：声音（可能没有）+ 画面（一定有）
  function EN() { return !!(window.TetrisI18n && window.TetrisI18n.lang === 'en'); }
  const TABLE = {
    rotateSoon: {
      ttl: 1600, tone: 'warn',
      text: function () { return EN() ? ['Rotating', 'Field turns 90° in 1.5s'] : ['要转了', '1.5 秒后场地转 90°']; },
      audio: function (t) { riser(t, 1.5); }
    },
    debtHigh: {
      ttl: 2600, tone: 'danger',
      text: function (d) { return EN() ? ['Debt ' + (d && d.pct != null ? d.pct + '%' : 'high'), 'Two more rows and it cannot rise'] : ['债 ' + (d && d.pct != null ? d.pct + '%' : '偏高'), '再堆两块就顶不上来']; },
      audio: function (t) { tone(t, 120, 0.5, 'sawtooth', 0.1, A.music); tone(t + 0.28, 108, 0.5, 'sawtooth', 0.08, A.music); }
    },
    debtCleared: {
      ttl: 3000, tone: '',
      text: function () { return EN() ? ['Debt paid', 'Next 18 clears push no blocks'] : ['债清了', '接下来 18 次消行不顶块']; },
      audio: function (t) { [523, 659, 784, 1046].forEach(function (f, i) { tone(t + i * 0.07, f, 0.28, 'triangle', 0.12); }); }
    },
    arrowUnlock: {
      ttl: 2600, tone: '',
      text: function () { return EN() ? ['Arrow blocks', 'Landing wipes the arrow side'] : ['方向块出现', '落地抹掉箭头那半边']; },
      audio: function (t) { tone(t, 1568, 0.12, 'square', 0.07); tone(t + 0.1, 2093, 0.16, 'square', 0.06); }
    },
    lineClear: {
      ttl: 1200, tone: '',
      text: function (d) {
        const n = d && d.lines || 1;
        return EN() ? [n + ' ' + (n === 1 ? 'line' : 'lines'), ''] : ['消 ' + n + ' 行', ''];
      },
      audio: function (t, d) { tone(t, 660 + Math.min(d && d.lines || 1, 4) * 110, 0.12, 'triangle', 0.1); }
    },
    topOut: {
      ttl: 3000, tone: 'danger',
      text: function () { return EN() ? ['Debt unpaid', 'Run over'] : ['还不完债', '本局结束']; },
      audio: function (t) {
        tone(t, 392, 0.16, 'square', 0.12);
        tone(t + 0.13, 294, 0.2, 'square', 0.11);
        tone(t + 0.27, 196, 0.55, 'sawtooth', 0.13, A.music);
        noise(t + 0.05, 0.9, 1800, 300, 0.07);
      }
    },
    gameOver: {
      ttl: 4200, tone: 'danger',
      text: function (d) {
        if (EN()) return ['Debt', d && d.debt != null ? 'Next game carries -' + d.debt : 'Press R to restart'];
        return ['债', d && d.debt != null ? '下一局带着 -' + d.debt : '按 R 重开'];
      },
      audio: function (t) {
        collapse(t);
        [523.3, 392, 311.1, 196].forEach(function (fr, i) {
          tone(t + 0.28 + i * 0.24, fr, 0.55, 'triangle', 0.13, A.music);
        });
        noise(t + 0.18, 2.6, 2600, 260, 0.11);
      }
    }
  };

  /* ---------------- 对外 ---------------- */
  const Cues = {
    cue: function (name, data) {
      const c = TABLE[name];
      if (!c) return;
      ensureAudio();
      if (A.ctx && A.ctx.state === 'suspended') A.ctx.resume().catch(function () {});

      if (!muted() && c.audio) {
        try { c.audio(A.ctx.currentTime + 0.02, data || {}); } catch (e) {}
      }
      // 画面永远走，不管有没有声音
      const txt = typeof c.text === 'function' ? c.text(data || {}) : c.text;
      showHint(txt[0], txt[1], c.tone, c.ttl);
      if (c.tone) flashEdge(c.tone, 420);
    },

    setSound: function (on) {
      A.enabled = !!on;
      if (A.ctx && !A.enabled) A.ctx.suspend().catch(function () {});
      if (A.ctx && A.enabled) A.ctx.resume().catch(function () {});
      document.documentElement.classList.toggle('cues-muted', !A.enabled);
    },

    setVolume: function (v) {
      A.volume = Math.max(0, Math.min(1, Number(v) || 0));
      if (A.master) A.master.gain.value = 0.9 * A.volume;
    },

    /* 开局自检：能出声就静音模式关，出不了声就把画面加强 */
    selfCheck: function () {
      ensureAudio();
      if (!A.ctx) { A.failed = true; document.documentElement.classList.add('cues-muted'); return Promise.resolve(false); }
      return A.ctx.resume().then(function () {
        const ok = A.ctx.state === 'running';
        if (!ok) document.documentElement.classList.add('cues-muted');
        return ok;
      }).catch(function () {
        document.documentElement.classList.add('cues-muted');
        return false;
      });
    },

    state: function () {
      return {
        enabled: A.enabled, failed: A.failed, running: !!(A.ctx && A.ctx.state === 'running'),
        master: A.master ? A.master.gain.value : 0,
        sfx: A.sfx ? A.sfx.gain.value : 0,
        music: A.music ? A.music.gain.value : 0
      };
    }
  };

  global.Cues = Cues;
})(window);
