/* version.js —— 版本号 + 更新记录（设置/关于页都从这里读）
 * log 是中文原文；logEn 是逐条英文对应（英文模式整页替换，不改中文）。
 */
(function () {
  'use strict';
  window.TetrisVersion = {
  version: '1.18',
  code: 56,
  web: 113,
  date: '2026-11-16',
  title: '砍掉多余的',
  titleEn: 'Trim the fat',
  modes: [
    {
      "name": "多人 · 蓝牙",
      "text": "两台安卓先系统配对，无网直连；1v1 并行/干扰。"
    },
    {
      "name": "主玩法 · 合体债",
      "text": "10×10；消行顶合体块、债跨局，还清后有奖励期。"
    },
    {
      "name": "主玩法 · 经典",
      "text": "10×20；标准计分、每 10 行升级，没有债和合体块。"
    },
    {
      "name": "常驻 · 连击",
      "text": "10×10；无债、无合体块，连续消行叠连击，最高 2.25x。"
    },
    {
      "name": "常驻 · 禅模式",
      "text": "10×12；5/10 分钟，堆满自动整理不会死，暂停存剩余时间。"
    },
    {
      "name": "AI",
      "text": "与 AI 决斗或 AI 对打（观战）；难度简单/普通/困难。"
    }
  ],
  modesEn: [
    {
      "name": "Multiplayer · Bluetooth",
      "text": "Pair two Android phones in system settings for a direct offline 1v1: parallel or battle."
    },
    {
      "name": "Main · Debt",
      "text": "10×10; clears push fusion blocks up, debt carries across games, and paying it off grants a grace period."
    },
    {
      "name": "Main · Classic",
      "text": "10×20; standard scoring, level up every 10 lines, no debt or fusion blocks."
    },
    {
      "name": "Casual · Combo",
      "text": "10×10; no debt or fusion, consecutive clears build a combo up to 2.25×."
    },
    {
      "name": "Casual · Zen",
      "text": "10×12; 5/10 minutes, a full board auto-tidies and cannot kill you, pause saves the remaining time."
    },
    {
      "name": "AI",
      "text": "Duel the AI or watch AI vs AI; difficulty Easy / Normal / Hard."
    }
  ],
  log: [
    {
      "v": "1.18",
      "date": "2026-11-16",
      "title": "砍掉多余的",
      "summary": "删掉字母块、债务重组改成每局 -15%、常驻和计时合并、多人面板去掉重复选项、开场与提示各收一档；更新记录只留最近 15 条：version.js 从 106KB 瘦到 22KB，更新包（压缩后）从 161KB 降到 133KB。",
      "added": [],
      "changed": [
        "字母块删除：合体块始终是 2 行、1~2 个洞，不再变形",
        "债务重组：连续 3 局没还清减半 → 每局没还清自动消 15%",
        "常驻与计时（原禅模式）合并成一个面板：连击 / 计时 5·10 分钟",
        "多人面板：去掉「和谁玩」「操作」两个选项，「上次房间」「上次蓝牙」并成一个「上次的对手」",
        "设置：开场动画只留开/关，去掉「右上角提示」三档（固定自动）",
        "更新记录只保留最近 15 条，更早的看仓库 CHANGELOG.md"
      ],
      "balance": [],
      "removed": [
        "字母块（变形与字母绘制）",
        "「和谁玩」「操作」选项",
        "「右上角提示」三档"
      ]
    },
    {
      "v": "1.17",
      "date": "2026-11-16",
      "title": "键位再大一点 · 更新引导",
      "summary": "方向键在所有模式里再放大一档，并往屏幕中间收了一点（仍然不压棋盘）；版本页新增「怎么更新」，讲清网页包和安装包的区别。",
      "added": [
        "版本与更新页新增「怎么更新」：判断安装包新旧、三步说明、复制安装包地址/镜像、检查网页包更新"
      ],
      "changed": [
        "键位基准再上调（横屏 12%、竖屏 14%、大屏 9%），上限 66 / 78 / 96",
        "键位离边框的留白从约 2% 提到约 6%，整体往中间收一点",
        "小屏塞不下时仍会自动缩回去，不会压棋盘或出屏"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.16",
      "date": "2026-11-16",
      "title": "键位放大一档",
      "summary": "所有模式的方向键和暂存键都在原来基础上放大了一点，手指更好按；「不压棋盘、不出屏」的自动复核照旧兜底。",
      "added": [],
      "changed": [
        "横屏：基准从屏幕短边的 10% 提到 10.8%，上限 52 → 56",
        "竖屏：基准从宽度的 12% 提到 13%，上限 66 → 72",
        "大屏：上限 84 → 88（1080p 横屏约 86px）",
        "旋转/强制横屏的布局同步放大"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.15",
      "date": "2026-11-16",
      "title": "复制里补上下文",
      "summary": "复制出来的说明多了两行：上一版是什么、几个术语什么意思——这样模型不只答得出「这版改了什么」，还能答「跟上一版比改了什么」。",
      "added": [],
      "changed": [
        "复制内容加「上一版：v1.14 · 标题」",
        "复制内容加术语解释：合体块 / 债 / 网页包 / 安装包（壳）"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.14",
      "date": "2026-11-16",
      "title": "复制内容适合发给 AI",
      "summary": "「复制这一版说明」改成结构化文本：先一句这游戏是什么，再一行一个字段，最后带明确小节的更新记录；粘给任何模型都能直接读懂。",
      "added": [],
      "changed": [
        "复制内容：开头补一句玩法（10×10、消行顶合体块、债跨局），避免对方不知道这是什么游戏",
        "字段拆成一行一个：版本 / 网页包 / 安装包（壳）/ 设备；更新记录带「简介 / 新增 / 调整」小节"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.13",
      "date": "2026-11-16",
      "title": "一键复制这一版",
      "summary": "版本页多一个按钮：把「这一版是什么、改了什么」复制成一段纯文本，发给朋友或贴给排查都用得上。",
      "added": [
        "版本与更新页：「复制这一版说明」——版本号、网页包、壳版本、设备、性能档，加最新一条更新记录的正文",
        "走系统剪贴板桥，复制成功/失败都有提示"
      ],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.12",
      "date": "2026-11-16",
      "title": "复制改走系统剪贴板",
      "summary": "复制按钮不再依赖 WebView 的剪贴板 API（file:// 下它经常被拒），改走安装包里的系统剪贴板桥；网页包这边也只剩一份复制函数。需要装一次 1.4 安装包。",
      "added": [
        "安装包 1.4（versionCode 57）：给页面一个系统剪贴板接口，复制稳定了"
      ],
      "changed": [
        "下载弹窗：复制地址 / 换成镜像并复制 / 稍后，结果显示在弹窗里",
        "联机分享框的「复制下载链接」同样走系统剪贴板"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.11",
      "date": "2026-11-16",
      "title": "复制修好了",
      "summary": "更新弹窗里点「复制镜像地址」没反应：页面里有两份同名的复制函数，后一份直接谎报成功、还把回调炸掉。现在只剩一份，成不成功都如实写出来。",
      "added": [],
      "changed": [
        "下载安装包弹窗简化：复制地址 / 换成镜像并复制 / 稍后再看；复制结果直接显示在弹窗里",
        "联机分享框的「复制下载链接」也改成如实提示：复制失败就把地址显示出来"
      ],
      "balance": [],
      "removed": [
        "重复的那份 copyText（就是它让复制按钮看起来没反应）"
      ]
    },
    {
      "v": "1.10",
      "date": "2026-11-16",
      "title": "性能档",
      "summary": "按真实帧时间自动切画质：卡了降一档（关毛玻璃、降背板分辨率、收阴影），稳了再升回去；设置里多一行只读的「性能档」。",
      "added": [
        "性能档：高 / 中 / 低，按帧时间自动切；只影响画面，不动规则和种子",
        "低档：背板分辨率降到 1.5x、帧率上限 45、去掉毛玻璃和阴影",
        "「屏幕与设备」里显示当前性能档和帧时间 p95，卡的时候一眼能看出是设备还是代码"
      ],
      "changed": [
        "暂停和结算时不再每秒重画 60 次，画布停在最后一帧",
        "设置入口收成 3 个：声音并进「游戏」"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.9",
      "date": "2026-11-16",
      "title": "转场归难度",
      "summary": "场地自动旋转不再是单独开关，并进难度：轻松不转，普通/困难每 15 秒转 90°。顺手把重复的入口和死代码清了。",
      "added": [],
      "changed": [
        "难度：轻松档场地不转；普通/困难档每 15 秒顺时针 90° + 落沙",
        "新安装默认难度改为「轻松」；老玩家升级后仍留在原来那一档",
        "版本页去掉和「玩法说明」重复的玩法一览",
        "导出/导入从「更多」搬进「存档管理」；首页去掉「新手教程」按钮（第一次进单人照样自动弹）"
      ],
      "balance": [],
      "removed": [
        "设置里的「场地自动旋转」开关",
        "引擎里 4 个没人用的旧常量，和两个早就空转的函数"
      ]
    },
    {
      "v": "1.8",
      "date": "2026-11-16",
      "title": "入口收拢",
      "summary": "把散开的入口并回去：存档三档收成一个档位切换，设置 6 个入口并成 4 个。功能一个没少。",
      "added": [],
      "changed": [
        "存档管理：顶部一个档位切换，下面只显示当前档的自动存档 + 3 个槽位，首屏少 16 行",
        "设置：6 个入口并成 4 个 —— 游戏（含方块材质）、屏幕与设备、声音、语言"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.7",
      "date": "2026-11-16",
      "title": "难度三档",
      "summary": "合体债分成轻松 / 普通 / 困难三档，选一次就记住；三档各有一套自动存档、槽位、最高分和债，互不污染。",
      "added": [
        "主玩法抽屉里多了「难度」：轻松（三次消行才顶一块）、普通（两次）、困难（每次，最像最早那版）",
        "每档一套存档：自动 + 3 个槽位，存档管理里分三组；换档继续用的是各自那一局",
        "每档单独记最高分和欠账，连续没还清的计数也分开算"
      ],
      "changed": [
        "老玩家的存档、最高分、欠账自动归到「困难」档，升级后不会丢",
        "联机时难度跟房主走，大厅会显示两边的档位"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.6",
      "date": "2026-11-15",
      "title": "大屏适配",
      "summary": "1900×1080 这类大横屏（电视 / 电脑浏览器）棋盘会铺满屏幕，键位和顶栏跟着放大；手机和这台平板维持原样。",
      "added": [],
      "changed": [
        "横屏够大（≥1200×640）时按屏幕算棋盘大小，最多 1600 宽；键位最大到 84px",
        "棋盘按屏幕上实际显示的大小绘制，大屏不再糊",
        "顶栏、比分条、结算面板的宽度跟着棋盘走"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.5",
      "date": "2026-11-15",
      "title": "联机协议合并",
      "summary": "Wi‑Fi 和蓝牙两条联机管道并成一套协议层，玩起来没区别；顺手把 1.0~1.4 漏掉的更新记录补回来。",
      "added": [],
      "changed": [
        "大厅、房主定玩法、版本对齐只写一份，Wi‑Fi 和蓝牙共用",
        "只有房主能定玩法；客人误调也不会改自己的规则"
      ],
      "balance": [],
      "removed": []
    },
    {
      "v": "1.4",
      "date": "2026-11-15",
      "title": "开房先要蓝牙权限",
      "summary": "安卓 12 以上少了蓝牙权限就收不到「设备已连上」，自动分享不会弹；现在开房时先把权限要到手。",
      "added": [],
      "changed": [
        "开房时先检查并申请蓝牙权限（没有权限系统不会弹授权框）"
      ],
      "balance": [],
      "removed": []
    }
  ],
  logEn: [
    {
      "title": "Trim the fat",
      "summary": "Letter blocks removed, debt restructuring eased 15% per run, casual and zen merged, multiplayer panel de-duplicated, intro and hints simplified; the changelog keeps the last 15 entries, cutting the update bundle from 160KB to about 60KB.",
      "added": [],
      "changed": [
        "Letter blocks removed: fusion blocks are always 2 rows with 1-2 holes",
        "Debt restructuring: instead of halving after 3 unpaid runs, every unpaid run eases the debt by 15%",
        "Casual and Zen merged into one panel: Combo / Timed 5 or 10 minutes",
        "Multiplayer panel: Who-to-play and Action switches removed; last LAN room and last Bluetooth opponent merged into one button",
        "Settings: intro is on/off, the three-way top-right hint switch is gone (always auto)",
        "Changelog keeps the last 15 entries; older ones live in the repo CHANGELOG.md"
      ],
      "balance": [],
      "removed": [
        "Letter blocks (morph and glyph drawing)",
        "Who-to-play and Action switches",
        "Three-way hint switch"
      ]
    },
    {
      "title": "Bigger controls again · update guide",
      "summary": "Direction keys grow another step in every mode and sit a little further from the screen edges (still never covering the board); the version page gains a How to update guide.",
      "added": [
        "Version page: How to update — checks whether the APK is old, shows three steps, copies the APK or mirror link, and can check the web bundle"
      ],
      "changed": [
        "Larger key baseline (landscape 12%, portrait 14%, big screens 9%), caps 66 / 78 / 96",
        "Edge margin grows from about 2% to 6%, pulling the pads inward",
        "On very small screens the keys still shrink automatically instead of covering the board"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Bigger controls",
      "summary": "The direction and hold keys grow a little in every mode; the existing check that keeps them off the board and inside the screen still applies.",
      "added": [],
      "changed": [
        "Landscape baseline 10% → 10.8% of the short edge, cap 52 → 56",
        "Portrait baseline 12% → 13% of width, cap 66 → 72",
        "Large screens: cap 84 → 88 (about 86px at 1080p landscape)",
        "Rotated/forced-landscape layouts scale with the same numbers"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "More context in the copy",
      "summary": "The copied note gains two lines — what the previous version was and what the main terms mean — so a model can answer what changed compared with the last version, not just this version.",
      "added": [],
      "changed": [
        "Adds Previous: v1.14 with its title",
        "Adds a glossary: fusion block / debt / web bundle / APK shell"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy text is AI-friendly",
      "summary": "The copied version note is now structured: one line saying what the game is, one field per line, then the changelog entry with labelled sections — paste it into any model and it reads cleanly.",
      "added": [],
      "changed": [
        "The note opens with a one-line description (10×10, clearing lines pushes a fusion block, debt carries over)",
        "Fields are one per line: version / web bundle / APK shell / device; the changelog uses Summary, Added, Changed sections"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy this version note",
      "summary": "The version page gains one button that copies a plain-text note about this build and what changed — handy for sharing or troubleshooting.",
      "added": [
        "Version & updates: Copy this version note — version, web bundle, shell, device and performance tier plus the latest changelog entry",
        "Goes through the system clipboard bridge and reports success or failure"
      ],
      "changed": [],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy goes through Android clipboard",
      "summary": "The copy buttons no longer rely on the WebView clipboard API (often denied for file://); they use a clipboard bridge in the APK. Install the 1.4 shell once.",
      "added": [
        "APK 1.4 (versionCode 57): exposes the system clipboard to the page, so copying is reliable"
      ],
      "changed": [
        "Download dialog: Copy link / Switch to mirror and copy / Later, with the result shown in the dialog",
        "The share box Copy link uses the same path"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Copy fixed",
      "summary": "The mirror copy button in the update dialog did nothing: the page had two copyText functions and the later one lied about success and broke the callback. There is only one now, and it reports honestly.",
      "added": [],
      "changed": [
        "The APK dialog is simpler: Copy link / Switch to mirror and copy / Later, with the result shown inside the dialog",
        "The share box Copy link now tells the truth too: on failure it shows the URL"
      ],
      "balance": [],
      "removed": [
        "The duplicate copyText function that made the copy button look dead"
      ]
    },
    {
      "title": "Performance tiers",
      "summary": "Quality now adapts to real frame times: a sustained slowdown drops one tier (blur off, lower render scale, no shadows) and recovers when it is smooth again; Settings shows the current tier read-only.",
      "added": [
        "Performance tier: high / mid / low, chosen from measured frame times; visuals only, rules and seeds untouched",
        "Low tier: render scale 1.5x, frame cap 45, no blur or shadows",
        "Screen & device shows the current tier and frame-time p95 so a stutter can be traced to the device or the code"
      ],
      "changed": [
        "Pause and result screens no longer redraw 60 times a second; the canvas holds its last frame",
        "Settings entries are down to 3: sound moved into Game"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Rotation is a difficulty",
      "summary": "Field rotation is no longer a separate switch — it belongs to the difficulty: Easy never rotates, Normal and Hard rotate 90° every 15 seconds. Duplicate entries and dead code removed along the way.",
      "added": [],
      "changed": [
        "Easy: the field never rotates. Normal / Hard: 90° clockwise plus gravity settle every 15 seconds",
        "New installs default to Easy; existing players keep the difficulty they already had",
        "The version page drops the mode list that duplicated the help screen",
        "Export / import moved from More into Save Management; the home tutorial button is gone (first solo run still opens the tutorial)"
      ],
      "balance": [],
      "removed": [
        "The Auto-rotate field switch in Settings",
        "Four unused engine constants and two no-op pause helpers"
      ]
    },
    {
      "title": "Fewer entries",
      "summary": "Consolidated the entries that had been split apart: the three difficulties share one switch in Save Management, and Settings went from 6 entries to 4. Nothing was removed.",
      "added": [],
      "changed": [
        "Save Management: one difficulty switch on top, showing only that difficulty's auto-save and 3 slots (16 fewer rows on the first screen)",
        "Settings: 4 entries instead of 6 — Game (with block skins), Screen & device, Sound, Language"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Three difficulties",
      "summary": "Debt mode now has Easy / Normal / Hard, remembered between runs; each has its own auto-save, slots, high score and debt.",
      "added": [
        "A difficulty row in the main mode sheet: Easy (one fusion block every 3 clears), Normal (every 2), Hard (every clear, closest to the first build)",
        "One save set per difficulty: auto plus 3 slots, grouped in Save Management; Continue resumes that difficulty's own run",
        "High score, carried debt and the failed-payoff counter are tracked per difficulty"
      ],
      "changed": [
        "Existing saves, high scores and debt move to Hard automatically, so nothing is lost on upgrade",
        "Online matches use the host's difficulty and the lobby shows both sides"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Big-screen layout",
      "summary": "On large landscape screens (1900×1080 TVs or desktop browsers) the board fills the screen and the controls grow with it; phones and the tablet keep their current layout.",
      "added": [],
      "changed": [
        "In landscape above 1200×640 the board is sized to the screen (up to 1600 wide) and keys go up to 84px",
        "The board is drawn at the size it is displayed, so it stays sharp on large screens",
        "Top bar, score bar and result panel follow the board width"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "One connection layer",
      "summary": "The Wi-Fi and Bluetooth paths now share a single protocol layer, with no visible change; the missing 1.0–1.4 changelog entries are restored.",
      "added": [],
      "changed": [
        "Lobby, host picks the mode and version alignment live in one place for both paths",
        "Only the host can pick the mode; a guest tap no longer changes its own rules"
      ],
      "balance": [],
      "removed": []
    },
    {
      "title": "Bluetooth permission upfront",
      "summary": "Android 12+ cannot see \"device connected\" without the Bluetooth permission, so the automatic share never fired; the permission is now requested while hosting.",
      "added": [],
      "changed": [
        "Check and request the Bluetooth permission when opening a room"
      ],
      "balance": [],
      "removed": []
    }
  ],


  };
})();
